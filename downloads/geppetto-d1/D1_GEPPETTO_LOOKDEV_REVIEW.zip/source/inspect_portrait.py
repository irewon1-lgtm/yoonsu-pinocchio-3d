"""Inspect the reopened artist-facing studio file. Run inside Blender."""
import json
from pathlib import Path
import sys
from collections import Counter

import bpy
from mathutils import Vector

root=Path(sys.argv[sys.argv.index('--')+1])
scene=bpy.context.scene
coll=bpy.data.collections['GEP_LOOKDEV']
deps=bpy.context.evaluated_depsgraph_get()
objects=list(coll.all_objects)
low=[float('inf')]*3
high=[float('-inf')]*3
meshes=[]
for ob in objects:
    if ob.type not in {'MESH','CURVE','SURFACE'}:
        continue
    ev=ob.evaluated_get(deps)
    mesh=ev.to_mesh()
    # Use evaluated points, including all subdivision and actual beveling of curves.
    for vertex in mesh.vertices:
        w=ev.matrix_world @ vertex.co
        for i in range(3):
            low[i]=min(low[i],w[i])
            high[i]=max(high[i],w[i])
    meshes.append({'object':ob.name,'source_type':ob.type,'evaluated_vertices':len(mesh.vertices),
                   'evaluated_faces':len(mesh.polygons),'uv_layers':list(mesh.uv_layers.keys()),
                   'modifiers':[m.type for m in ob.modifiers]})
    ev.to_mesh_clear()
images={im.name:{'packed':bool(im.packed_file),'size':list(im.size)}
        for im in bpy.data.images if im.type=='IMAGE' and im.source=='FILE'}
audit={'file':Path(bpy.data.filepath).name,'blender':bpy.app.version_string,'engine':scene.render.engine,
       'device':scene.cycles.device,'samples':scene.cycles.samples,'denoise':scene.cycles.use_denoising,
       'color':scene.view_settings.view_transform,'look':scene.view_settings.look,'exposure':scene.view_settings.exposure,
       'resolution':[scene.render.resolution_x,scene.render.resolution_y], 'images':images,
       'modifiers':dict(Counter(m.type for ob in objects for m in ob.modifiers)),
       'armatures':len(bpy.data.armatures),'actions':len(bpy.data.actions),'libraries':len(bpy.data.libraries),
       'bbox_min':low,'bbox_max':high,'height_studio_units':high[2]-low[2],
       'art_objects':len(meshes),'uv_objects':sum(bool(x['uv_layers']) for x in meshes),'objects':meshes}
assert audit['armatures']==0 and audit['actions']==0 and audit['libraries']==0
assert len(images)>=2 and all(im['packed'] for im in images.values())
assert len(meshes)>0 and audit['uv_objects']>0 and 1.5<audit['height_studio_units']<1.9
(root/'qa'/'PORTRAIT_INSPECT.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in audit.items() if k!='objects'},indent=2,ensure_ascii=False))
