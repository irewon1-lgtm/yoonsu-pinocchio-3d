"""Drape the CC0 Fabric026 weave across the workshop clothing at real garment scale."""
from pathlib import Path

import bpy


def prepare_uv(mesh):
    # Local planar charts preserve constant physical weave pitch on curved sleeve and apron.
    if mesh.uv_layers.get('Fabric metric projection'):
        return
    uv = mesh.uv_layers.new(name='Fabric metric projection')
    for face in mesh.polygons:
        dominant = max(range(3),key=lambda i:abs(face.normal[i]))
        axes = [(1,2),(0,2),(0,1)][dominant]
        for loop in face.loop_indices:
            v = mesh.vertices[mesh.loops[loop].vertex_index].co
            uv.data[loop].uv = (v[axes[0]]/.32,v[axes[1]]/.32)


def apply_detail(assets):
    image=bpy.data.images.load(str(Path(assets)/'ambientcg/Fabric026_weave.png'))
    image.colorspace_settings.name='Non-Color'
    image.pack()
    names={'GEP Body · '+n for n in ['apron','apronEdge','shirt','linenShadow','trousers']}
    for ob in bpy.data.objects:
        if ob.type=='MESH' and any(s.material and s.material.name in names for s in ob.material_slots):
            prepare_uv(ob.data)
    for name in names:
        mat = bpy.data.materials.get(name)
        if mat is None: continue
        nodes,links=mat.node_tree.nodes,mat.node_tree.links
        shader=nodes.get('Principled BSDF')
        source_color=shader.inputs['Base Color'].links[0].from_socket
        previous_normal=shader.inputs['Normal'].links[0].from_socket
        tex=nodes.new('ShaderNodeTexImage')
        tex.image=image
        tex.label='ambientCG · Fabric026 weave'
        uv=nodes.new('ShaderNodeUVMap')
        uv.uv_map='Fabric metric projection'
        links.new(uv.outputs['UV'],tex.inputs['Vector'])
        tint=nodes.new('ShaderNodeMixRGB')
        tint.blend_type='MULTIPLY'
        tint.inputs[0].default_value=.19
        links.new(source_color,tint.inputs[1])
        links.new(tex.outputs['Color'],tint.inputs[2])
        links.new(tint.outputs['Color'],shader.inputs['Base Color'])
        relief=nodes.new('ShaderNodeBump')
        relief.inputs['Distance'].default_value=.00046
        relief.inputs['Strength'].default_value=.14
        links.new(previous_normal,relief.inputs['Normal'])
        links.new(tex.outputs['Color'],relief.inputs['Height'])
        links.new(relief.outputs['Normal'],shader.inputs['Normal'])
