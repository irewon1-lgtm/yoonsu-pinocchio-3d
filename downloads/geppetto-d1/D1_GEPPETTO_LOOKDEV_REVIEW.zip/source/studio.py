"""Build a portable Geppetto study and photograph both revisions on the same set."""
import argparse
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))


def aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()


def point_camera(scene, view):
    angle, target, scale = {
        'front': (0, (0, 0, .88), 1.99),
        'quarter': (-35, (0, 0, .88), 1.99),
        'profile': (-89, (0, 0, .88), 1.99),
        'face': (-22, (0, -.03, 1.465), .73),
        'face_front': (0, (0, -.03, 1.465), .73),
    }[view]
    a = math.radians(angle)
    cam = scene.camera
    cam.location = Vector(target) + Vector((2.45 * math.sin(a), -2.45 * math.cos(a), .2597))
    aim(cam, target)
    cam.data.ortho_scale = scale


def studio(scene, hdr):
    scene.name = 'Geppetto | portrait studio'
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = 32
    scene.cycles.use_denoising = False
    scene.cycles.max_bounces = 5
    scene.cycles.transparent_max_bounces = 8
    scene.render.resolution_x = 692
    scene.render.resolution_y = 824
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGB'
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - Medium High Contrast'
    scene.view_settings.exposure = -.28
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = 3
    world = bpy.data.worlds.new('Poly Haven studio | bounce and reflections')
    scene.world = world
    world.use_nodes = True
    env = world.node_tree.nodes.new('ShaderNodeTexEnvironment')
    env.image = bpy.data.images.load(str(hdr))
    env.image.pack()
    bs = world.node_tree.nodes.get('Background')
    bs.inputs['Strength'].default_value = .32
    world.node_tree.links.new(env.outputs['Color'], bs.inputs['Color'])

    # Lathed sweep with a soft quarter-round between the deck and wall.
    profile = [(.001, -.005), (2.2, -.005)]
    for i in range(1, 15):
        t = i / 14 * math.pi / 2
        profile.append((2.2 + 1.2 * math.sin(t), 1.195 - 1.2 * math.cos(t)))
    profile.append((3.4, 5))
    vertices = [(r * math.cos(i*math.tau/128), r * math.sin(i*math.tau/128), z)
                for r,z in profile for i in range(128)]
    faces = [(j*128+i, j*128+(i+1)%128, (j+1)*128+(i+1)%128, (j+1)*128+i)
             for j in range(len(profile)-1) for i in range(128)]
    mesh = bpy.data.meshes.new('Curved portrait sweep')
    mesh.from_pydata(vertices, [], faces)
    obj = bpy.data.objects.new('Studio | cyclorama', mesh)
    scene.collection.objects.link(obj)
    for p in mesh.polygons: p.use_smooth = True
    mat = bpy.data.materials.new('Studio | desaturated spruce')
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = (.036, .078, .079, 1)
    shader.inputs['Roughness'].default_value = .92
    obj.data.materials.append(mat)
    # The wall around the set should not intercept rays from the cameras.
    obj.visible_camera = True
    cam = bpy.data.objects.new('Matched orthographic portrait', bpy.data.cameras.new('Portrait lens'))
    scene.collection.objects.link(cam)
    cam.data.type = 'ORTHO'
    cam.data.clip_start = .02
    scene.camera = cam
    for name, loc, target, power, color, size in [
        ('Warm window', (-1.8,-2.35,3.1), (0,0,1.12), 190, (1,.84,.68), 1.75),
        ('Cool book light', (1.65,-1.3,1.9), (0,0,1.22), 76, (.74,.87,1), 1.6),
        ('Hair edge', (.85,1.25,2.65), (0,0,1.38), 160, (1,.85,.67), .95),
    ]:
        light = bpy.data.lights.new(name, 'AREA')
        light.shape = 'DISK'
        light.size = size
        light.energy = power
        light.color = color
        o = bpy.data.objects.new(name, light)
        scene.collection.objects.link(o)
        o.location = loc
        aim(o,target)
    point_camera(scene,'quarter')


def render(scene, root, prefix, views):
    for view in views:
        point_camera(scene, view)
        scene.render.filepath = str(root / f'{prefix}_{view}.png')
        bpy.ops.render.render(write_still=True)


def archived_character(scene, base):
    with bpy.data.libraries.load(str(base)) as (available, selected):
        selected.collections = [next(n for n in available.collections if n.startswith('CHAR_GEP'))]
    collection = selected.collections[0]
    collection.name = 'BLOCKOUT_ARCHIVE'
    scene.collection.children.link(collection)
    bpy.context.view_layer.update()
    deps = bpy.context.evaluated_depsgraph_get()
    z_min, z_max = 1000., -1000.
    for o in collection.all_objects:
        if o.type not in {'MESH','CURVE'}: continue
        ev = o.evaluated_get(deps)
        mesh = ev.to_mesh()
        heights = [(ev.matrix_world @ v.co).z for v in mesh.vertices]
        ev.to_mesh_clear()
        if heights: z_min, z_max = min(z_min,min(heights)), max(z_max,max(heights))
    scene.collection.children.unlink(collection)
    instance = bpy.data.objects.new('Height-normalized archive for paired portrait', None)
    instance.instance_type = 'COLLECTION'
    instance.instance_collection = collection
    scene.collection.objects.link(instance)
    factor = 1.76 / (z_max-z_min)
    instance.scale = (factor,)*3
    instance.location.z = -z_min * factor
    print('ARCHIVE NORMALIZATION', z_min,z_max,factor)


def build_character(scene, assets):
    from head import build_head
    from body import build_body
    body = build_body()
    head = build_head()
    # Broaden the illustrated head and bring it into the collar at the forward stoop.
    from mathutils import Matrix
    pivot = Vector((0,0,1.22))
    placement = (Matrix.Translation((0,-.026,-.033)) @ Matrix.Translation(pivot)
                 @ Matrix.Diagonal(Vector((1.14,1.07,1.035,1))) @ Matrix.Translation(-pivot))
    bpy.context.view_layer.update()
    for ob in head.all_objects:
        if ob.parent is None:
            ob.matrix_world = placement @ ob.matrix_world
    coll = bpy.data.collections.new('GEP_LOOKDEV')
    scene.collection.children.link(coll)
    for part in (body,head):
        coll.children.link(part)
        scene.collection.children.unlink(part)
    if (assets/'ambientcg/Fabric026_weave.png').is_file():
        from studio_materials import apply_detail
        apply_detail(assets)
    return coll


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['archive','build','render','lighting','eevee'])
    parser.add_argument('root', type=Path)
    parser.add_argument('--base', type=Path)
    parser.add_argument('--views', nargs='+', default=['front','quarter','profile','face','face_front'])
    args = parser.parse_args(sys.argv[sys.argv.index('--')+1:])
    root = args.root.resolve()
    portrait = root / 'GEPPETTO_STUDIO.blend'
    if args.mode in ('render','lighting','eevee'):
        bpy.ops.wm.open_mainfile(filepath=str(portrait))
        sc = bpy.context.scene
        if args.mode == 'eevee':
            sc.render.engine = 'BLENDER_EEVEE_NEXT'
            sc.eevee.taa_render_samples = 12
            sc.render.resolution_percentage = 65
            render(sc,root/'qa','eevee',['quarter'])
            return
        if args.mode == 'lighting':
            # Same geometry, lens, exposure and render engine; change only lighting.
            sc.objects['Hair edge'].data.energy = 0
            sc.objects['Warm window'].data.energy = 65
            sc.objects['Cool book light'].data.energy = 90
            render(sc, root/'renders','fill', ['face'])
            return
        render(sc, root/'renders','new',args.views)
        return
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    studio(scene,root/'assets'/'studio.exr')
    if args.mode=='archive':
        archived_character(scene,args.base.resolve())
        render(scene,root/'renders','old',args.views)
        return
    build_character(scene, root/'assets')
    point_camera(scene,'quarter')
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D': area.spaces.active.region_3d.view_perspective = 'CAMERA'
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(portrait),compress=True)
    print('PORTABLE PORTRAIT',portrait)


if __name__=='__main__':
    main()
