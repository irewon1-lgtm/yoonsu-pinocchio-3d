"""Geppetto's sculpt and groom. +Z up. He looks along -Y."""
import math
import bpy
import bmesh
from mathutils import Vector

pi = math.pi
sin, cos, exp, sqrt = math.sin, math.cos, math.exp, math.sqrt


def mix(a, b, t):
    return a * (1-t) + b * t


def smooth(t):
    t = min(1, max(0, t))
    return t*t*(3-2*t)


def profile(keys, z, idx):
    # Cubic Hermite interpolation with unequal knot spacing.
    if z <= keys[0][0]:
        return keys[0][idx]
    if z >= keys[-1][0]:
        return keys[-1][idx]
    i = next(i for i in range(len(keys)-1) if z <= keys[i+1][0])
    a, b = keys[i:i+2]
    left, right = keys[max(i-1,0)], keys[min(i+2,len(keys)-1)]
    t = (z-a[0]) / (b[0]-a[0])
    ma = (b[idx]-left[idx])/(b[0]-left[0])*(b[0]-a[0])
    mb = (right[idx]-a[idx])/(right[0]-a[0])*(b[0]-a[0])
    return (1-smooth(t))*a[idx] + smooth(t)*b[idx] + t*(1-t)*((1-t)*ma-t*mb)


def sample_path(points, count):
    p = [Vector(x) for x in points]
    values = []
    for k in range(count):
        v = k*(len(p)-1)/(count-1)
        i = min(int(v), len(p)-2)
        t = v-i
        a,b,c,d = p[max(0,i-1)],p[i],p[i+1],p[min(i+2,len(p)-1)]
        values.append(.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t))
    return values


class Portrait:
    def __init__(self):
        self.collection = bpy.data.collections.new("GEP | Face, beard and hair")
        bpy.context.collection.children.link(self.collection)
        self.skin = self.material("Sienna · skin", (.55,.259,.125), .65)
        skin_bs = self.skin.node_tree.nodes.get("Principled BSDF")
        skin_bs.inputs["Subsurface Weight"].default_value = .045
        skin_bs.inputs["Subsurface Radius"].default_value = (.085,.038,.021)
        self.hair = self.material("Silver · warm midtone", (.35,.303,.309), .67)
        self.silver = self.material("Silver · lit wave", (.57,.505,.484), .65)
        self.pearl = self.material("Silver · pearl", (.746,.678,.604), .63)
        self.beard = self.material("Beard · ivory", (.73,.643,.539), .71)
        self.shadow = self.material("Beard · shadow", (.51,.429,.372), .72)
        self.crease = self.material("Smile · warm crease", (.345,.138,.073), .76)
        self.lip = self.material("Lip · terracotta", (.58,.216,.131), .72)
        self.mouth = self.material("Mouth · deep rose", (.093,.021,.014), .75)
        self.tongue = self.material("Tongue · rose", (.60,.172,.110), .66)
        self.white = self.material("Eyes · warm ivory", (.96,.815,.62), .35)
        self.iris = self.material("Iris · hazelnut", (.16,.068,.020), .38)
        self.eye_dark = self.material("Eye · dark umber", (.038,.014,.006), .40)
        self.pupil = self.material("Pupils", (.012,.008,.005), .28)
        self.glint = self.material("Eyes · gleam", (.99,.96,.82), .23)
        self.brass = self.material("Spectacles · aged brass", (.28,.145,.055), .35, .66)
        self.groom_materials = {}
        self.sections = [
            (1.243,.007,.011,.0),(1.256,.060,.065,-.012),(1.281,.102,.101,-.010),
            (1.310,.114,.120,-.007),(1.354,.135,.129,-.001),(1.400,.161,.145,.0),
            (1.448,.177,.152,.003),(1.483,.165,.146,.004),(1.535,.160,.147,.007),
            (1.579,.158,.146,.009),(1.62,.149,.140,.011),(1.655,.137,.122,.012),
            (1.688,.106,.099,.012),(1.714,.062,.062,.012),(1.729,.005,.005,.012)]

    def material(self, name, rgb, rough, metal=0):
        m = bpy.data.materials.new("GEP | " + name)
        m.diffuse_color = (*rgb,1)
        m.use_nodes = True
        b = m.node_tree.nodes.get("Principled BSDF")
        b.inputs["Base Color"].default_value = (*rgb,1)
        b.inputs["Roughness"].default_value = rough
        b.inputs["Metallic"].default_value = metal
        return m

    def mesh(self, name, verts, faces, mat):
        m = bpy.data.meshes.new("GEP · "+name)
        m.from_pydata(verts, [], faces)
        m.materials.append(mat)
        m.update()
        ob = bpy.data.objects.new("GEP · "+name, m)
        self.collection.objects.link(ob)
        for p in m.polygons:
            p.use_smooth=True
        return ob

    def grid(self, name, fn, rows, cols, mat, wrap=False):
        n = cols if wrap else cols+1
        verts = [fn(i/rows,j/cols) for i in range(rows+1) for j in range(n)]
        faces = []
        for i in range(rows):
            for j in range(cols):
                a=i*n+j
                b=i*n+(j+1)%n
                faces.append((a,b,b+n,a+n))
        return self.mesh(name,verts,faces,mat)

    def blob(self,name,center,scale,mat):
        x,y,z = center
        a,b,c = scale
        return self.grid(name,lambda t,s:(x+a*sin(t*pi)*cos(s*2*pi),y+b*sin(t*pi)*sin(s*2*pi),z+c*cos(t*pi)),24,40,mat,True)

    def stroke(self, name, points, thick, mat, factors=None, cyclic=False):
        c=bpy.data.curves.new("GEP · "+name,'CURVE')
        c.dimensions='3D'
        c.resolution_u=8
        c.bevel_depth=thick
        c.bevel_resolution=3
        c.use_fill_caps=True
        s=c.splines.new('BEZIER')
        s.bezier_points.add(len(points)-1)
        for i,(b,p) in enumerate(zip(s.bezier_points,points)):
            b.co=p
            b.handle_left_type='AUTO'
            b.handle_right_type='AUTO'
            b.radius=factors[i] if factors is not None else 1
        s.use_cyclic_u=cyclic
        ob=bpy.data.objects.new("GEP · "+name,c)
        self.collection.objects.link(ob)
        c.materials.append(mat)
        return ob

    def groom_finish(self,ob,n,rows,mat):
        # UV follows the lock in its growth direction. Fine variations in the
        # chalk-white/silver pigment remain visible between the carved ridges.
        mesh=ob.data
        uv=mesh.uv_layers.new(name="Groom")
        for poly in mesh.polygons:
            vals=[mesh.loops[i].vertex_index%n for i in poly.loop_indices]
            cross=max(vals)-min(vals)>n//2
            for i,k in zip(poly.loop_indices,vals):
                idx=mesh.loops[i].vertex_index
                u=(n if cross and k==0 else k)/n
                uv.data[i].uv=(u,(idx//n)/(rows-1))
        if mat.name not in self.groom_materials:
            pigment=mat.copy()
            pigment.name=mat.name+" · combed"
            g=pigment.node_tree
            tex=g.nodes.new("ShaderNodeTexCoord")
            scale=g.nodes.new("ShaderNodeVectorMath")
            scale.operation="MULTIPLY"
            scale.inputs[1].default_value=(68,3,1)
            g.links.new(tex.outputs["UV"],scale.inputs[0])
            noise=g.nodes.new("ShaderNodeTexNoise")
            noise.inputs["Scale"].default_value=1
            noise.inputs["Detail"].default_value=2.8
            noise.inputs["Roughness"].default_value=.55
            noise.inputs["Distortion"].default_value=.21
            g.links.new(scale.outputs[0],noise.inputs["Vector"])
            ramp=g.nodes.new("ShaderNodeValToRGB")
            rgb=mat.diffuse_color[:3]
            ramp.color_ramp.elements[0].position=.20
            ramp.color_ramp.elements[0].color=(*(v*.43 for v in rgb),1)
            ramp.color_ramp.elements[1].position=.80
            ramp.color_ramp.elements[1].color=(*(min(1,v*1.14) for v in rgb),1)
            ramp.color_ramp.elements.new(.39).color=(*(v*.79 for v in rgb),1)
            g.links.new(noise.outputs['Fac'],ramp.inputs[0])
            g.links.new(ramp.outputs[0],g.nodes.get("Principled BSDF").inputs["Base Color"])
            self.groom_materials[mat.name]=pigment
        mesh.materials[0]=self.groom_materials[mat.name]
        return ob

    def lock(self, name, points, widths, heights, normal, mat, grooves=0.07):
        # A single sculpted hank with shallow flutes from root to tapered tip.
        n=(len(points)-1)*6+1
        p=sample_path(points,n)
        sizes=sample_path(list(zip(widths,heights)),n)
        verts=[]
        faces=[]
        sides=32
        for i, v in enumerate(p):
            t=i/(n-1)
            tangent=(p[min(n-1,i+1)]-p[max(0,i-1)]).normalized()
            direct=normal(v,t) if callable(normal) else normal
            norm=Vector(direct).normalized()
            across=tangent.cross(norm).normalized()
            norm=across.cross(tangent).normalized()
            w,h=sizes[i]
            for j in range(sides):
                a=j*2*pi/sides
                flute=1+grooves*cos(pi*6*cos(a)+.48*sin(t*pi))*max(0,sin(a))
                verts.append(v+across*(max(.00012,w)*cos(a))+norm*(max(.00012,h)*sin(a)*flute))
            if i:
                for j in range(sides):
                    a=(i-1)*sides+j
                    b=(i-1)*sides+(j+1)%sides
                    faces.append((a,b,b+sides,a+sides))
        faces.extend([tuple(reversed(range(sides))),tuple(range((n-1)*sides,n*sides))])
        return self.groom_finish(self.mesh(name,verts,faces,mat),sides,n,mat)

    def dims(self,z):
        return [profile(self.sections,z,i) for i in (1,2,3)]

    def planes(self, x, z):
        def g(cx,cz,wx,wz): return exp(-((abs(x)-cx)/wx)**2-((z-cz)/wz)**2)
        return (-.039*g(.090,1.449,.047,.030) + .014*g(.055,1.502,.032,.023)
                - .012*g(.061,1.535,.046,.020) - .009*g(0,1.378,.089,.036)
                - .012*g(0,1.298,.069,.029) - .008*g(.114,1.386,.034,.035))

    def face_y(self,x,z):
        rx,ry,cy=self.dims(z)
        f=sqrt(max(.0001,1-(x/max(.001,rx))**2))
        return cy-ry*f+self.planes(x,z)*f**1.3

    def head_surface(self, t,s):
        z=mix(self.sections[0][0],self.sections[-1][0],t)
        rx,ry,cy=self.dims(z)
        a=2*pi*s
        x=rx*sin(a)
        y=cy-ry*cos(a)+self.planes(x,z)*max(0,cos(a))**1.3
        return (x,y,z)

    def make_skin(self):
        main=self.grid("Continuous face sculpt",self.head_surface,105,144,self.skin,True)
        parts=[main]
        for name,xyz,scale in [
            ("Neck", (0,.025,1.249),(.074,.078,.094)),
            ("Nasal root", (0,-.139,1.492),(.027,.026,.050)),
            ("Nasal dorsum",(0,-.159,1.468),(.030,.034,.045)),
            ("Nasal tip", (0,-.180,1.453),(.042,.039,.032))]:
            parts.append(self.blob(name,xyz,scale,self.skin))
        for side in (-1,1):
            parts.append(self.blob("Nasal ala",(.030*side,-.162,1.444),(.024,.025,.015),self.skin))
        for side in (-1,1):
            def ear(t,s):
                a=2*pi*s
                r=sin(pi*t)
                q=cos(pi*t)
                u=.035*cos(a)*r*(1+.13*sin(a))
                v=.050*sin(a)*r+.006*cos(a)*r
                outer=max(0,q)
                depth=.015*q+.011*exp(-((r-.81)/.14)**2)*outer**.40-.009*exp(-(r/.45)**2)*outer
                return (side*(.181+.62*u+.785*depth),-.012+.785*u-.62*depth+.18*v,1.436+v)
            parts.append(self.grid("Auricle",ear,44,64,self.skin,True))
        bpy.ops.object.select_all(action='DESELECT')
        for ob in parts: ob.select_set(True)
        bpy.context.view_layer.objects.active=main
        bpy.ops.object.join()
        bm=bmesh.new()
        bm.from_mesh(main.data)
        bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00006)
        ends=[e for e in bm.edges if e.is_boundary]
        if ends: bmesh.ops.holes_fill(bm,edges=ends)
        bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
        bm.to_mesh(main.data)
        bm.free()
        main.data.remesh_voxel_size=.0027
        bpy.ops.object.voxel_remesh()
        smooth_mod=main.modifiers.new("Polish transitions","SMOOTH")
        smooth_mod.factor=.68
        smooth_mod.iterations=7
        bpy.ops.object.modifier_apply(modifier=smooth_mod.name)
        for p in main.data.polygons: p.use_smooth=True
        main["construction"]="Sectioned facial planes, recessed orbits, cheek pads, nose and auricles unified using voxel remesh."
        # A vertex-painted glaze on prominent planes, integrated into the sculpt.
        mat=self.skin.copy()
        mat.name="GEP | Sienna · painted facial planes"
        main.data.materials.clear(); main.data.materials.append(mat)
        col=main.data.color_attributes.new(name="Complexion",type='BYTE_COLOR',domain='POINT')
        for v in main.data.vertices:
            x,y,z=v.co
            cheeks=.60*exp(-((abs(x)-.109)/.040)**2-((z-1.445)/.032)**2)*smooth((-y-.037)/.075)
            nose=.65*smooth((-y-.162)/.049)
            ear=.48*smooth((abs(x)-.155)/.034)*exp(-((z-1.435)/.05)**2)
            strength=min(.82,cheeks+nose+ear)
            base=(.55,.259,.125)
            blush=(.66,.194,.099)
            col.data[v.index].color=(*(mix(a,b,strength) for a,b in zip(base,blush)),1)
        attr=mat.node_tree.nodes.new("ShaderNodeVertexColor")
        attr.layer_name="Complexion"
        mat.node_tree.links.new(attr.outputs["Color"],mat.node_tree.nodes.get("Principled BSDF").inputs["Base Color"])
        return main

    def eyes_and_expression(self):
        for side in (-1,1):
            cx=.058*side
            cz=1.502
            def coords(u,v,d=0):
                x=cx+side*u*.032
                z=cz+v*.032+.0025*u
                radius=min(1,u*u+v*v)
                return (x,self.face_y(x,z)-.0013-.018*(1-radius)**.75-d,z)
            def lid(u,upper):
                return (.95 if upper else -.66)*sqrt(max(0,1-u*u))*(1-.11*u)
            def aperture(t,s):
                u=2*s-1
                return coords(u,mix(lid(u,False),lid(u,True),t))
            self.grid("Almond sclera",aperture,18,48,self.white)
            for title, rx,rz, dx,dz,depth,mat in [
                ("Limbal ring",.54,.67,-.085,.082,.00055,self.eye_dark),
                ("Amber iris",.50,.63,-.085,.082,.00085,self.iris),
                ("Pupil",.354,.47,-.09,.095,.0012,self.pupil),
                ("Window glint",.143,.148,-.22*side-.085,.34,.0017,self.glint),
                ("Small glint",.050,.050,.18*side-.085,-.18,.0017,self.glint)]:
                def disc(t,s):
                    a=s*2*pi
                    u=dx+rx*t*cos(a)
                    v=min(lid(u,True)-.006,max(lid(u,False)+.006,dz+rz*t*sin(a)))
                    return coords(u,v,depth)
                self.grid(title,disc,9,40,mat,True)
            for upper in (True,False):
                def eyelid(t,s):
                    u=2*s-1
                    b=lid(u,upper)
                    p=Vector(coords(u,b))
                    o=Vector(coords(u*1.13,b*(1.33 if upper else 1.26)+(.13 if upper else -.15)))
                    o.y=self.face_y(o.x,o.z)+.0015
                    v=p.lerp(o,t)
                    v.y-=.0013*(1-t)+.0023*sin(pi*t)
                    return v
                self.grid("Upper eyelid" if upper else "Lower eyelid",eyelid,9,44,self.skin)
                if upper:
                    us=[-.99,-.82,-.55,-.25,0,.3,.6,.85,.99]
                    self.stroke("Upper lash line",[coords(u,lid(u,True),.0015) for u in us],
                                .00135,self.eye_dark,[.1,.55,.9,1,1,1,.81,.53,.08])
            sweep=[(.022,1.545),(.036,1.563),(.055,1.568),(.075,1.562),(.090,1.550),(.101,1.540)]
            pts=[(x*side,self.face_y(x,z)-.0035,z+(.002 if side<0 else 0)) for x,z in sweep]
            self.lock("Swept eyebrow",pts,[.004,.009,.009,.008,.005,.0006],
                      [.001,.006,.007,.006,.004,.0005],(0,-1,.20),self.silver,.19)
            for num in range(3):
                pp=[(x,y-.0043,z+.002*(num-1)) for x,y,z in pts[1:-1]]
                self.stroke("Eyebrow hair",pp,.00062,self.pearl,[.12,1,.87,.1])
            creases=[
                [(.081,1.468),(.094,1.469),(.107,1.473),(.115,1.477)],
                [(.092,1.465),(.102,1.465),(.111,1.467)],
                [(.100,1.490),(.111,1.494),(.119,1.499)],
                [(.042,1.435),(.058,1.428),(.073,1.414),(.079,1.402)]]
            for path in creases:
                self.stroke("Smile fold",[(side*x,self.face_y(x,z)-.0005,z) for x,z in path],
                            .0008,self.crease,[.09]+[.83]*(len(path)-2)+[.08])
            # Nostril slits sit on the underside of the nasal wings.
            pts=[(x*side,y,z) for x,y,z in [(.023,-.197,1.437),(.028,-.194,1.437),(.033,-.189,1.437),(.037,-.184,1.439)]]
            self.stroke("Nostril",pts,.0018,self.crease,[.17,.98,.77,.13])
            # The antihelix is a second curved ridge inside the outer ear.
            earline=[]
            for u,v in [( .012,.023),(.005,.027),(-.006,.022),(-.011,.010),(-.010,-.002),(-.006,-.011)]:
                depth=.010
                earline.append((side*(.181+.62*u+.785*depth),-.012+.785*u-.62*depth+.18*v,1.436+v))
            self.stroke("Inner ear fold",earline,.0026,self.skin,[.06,.67,1,1,.8,.06])
        for z in (1.590,1.602):
            pts=[]
            for x in [-.064,-.040,-.015,.012,.037,.060]:
                h=z+.002*sin(x*39)+.001*cos(x*59)
                pts.append((x,self.face_y(x,h)-.00025,h))
            self.stroke("Forehead crease",pts,.0006,self.crease,[.06,.65,1,.91,.53,.04])
        def lips(u,top):
            base=1.386+.016*u*u+.0012*u
            return base+(.009 if top else -.038)*(max(0,1-u*u))**.78
        def mouth(t,s):
            u=2*s-1
            x=.075*u
            z=mix(lips(u,False),lips(u,True),t)
            return (x,self.face_y(x,z)-.0025,z)
        self.grid("Open smile",mouth,18,60,self.mouth)
        porcelain=self.material("Smile · warm enamel",(.86,.700,.51),.51)
        def tooth_band(t,s):
            u=(2*s-1)*.90
            x=.075*u
            z=lips(u,True)-(.004+.003*cos(u*pi/1.8))*(1-t)*max(0,1-(u/.90)**2)**.6
            return (x,self.face_y(x,z)-.0033,z)
        self.grid("Smile · upper teeth",tooth_band,5,40,porcelain)
        def tongue(t,s):
            u=(2*s-1)*.71
            z=lips(u,False)+(.015*(1-(u/.71)**2)+.0001)*t
            x=.075*u
            return (x,self.face_y(x,z)-.0032,z)
        self.grid("Tongue in smile",tongue,12,36,self.tongue)
        vals=[-.99,-.83,-.55,-.26,0,.26,.55,.83,.99]
        self.stroke("Lower lip",[(.075*u,self.face_y(.075*u,lips(u,False))-.0027,lips(u,False)-.0005) for u in vals],
                    .0032,self.lip,[.07,.42,.83,1,1,.96,.78,.43,.07])

    def hair_cap_point(self,u,v,offset=0):
        # a is longitude around the scalp; e is colatitude.
        a=(u-.5)*2*pi
        front=(1+cos(a))/2
        end=2.21-1.27*front**2.2
        end-=.12*exp(-((a-.29)/.38)**2)
        end+=.24*exp(-((a+.91)/.37)**2)
        end+=.015*sin(a*12+.2)*min(1,abs(a))
        e=.011+v*(end-.011)
        phase=15*a+3.4*e+.60*sin(2*a+e)
        wave=(.0028*cos(phase)+.0008*cos(phase*3))*sin(e)
        d=wave+offset
        return Vector(((.180+d)*sin(e)*sin(a),.009-(.169+d)*sin(e)*cos(a),1.531+(.208+d)*cos(e)))

    def hair_normal(self,p,t):
        return (p.x/.172**2,(p.y-.016)/.153**2,(p.z-1.531)/.208**2)

    def scalp(self):
        self.groom_finish(self.grid("Silver hair mass",lambda t,s:self.hair_cap_point(s,t),64,160,self.hair,True),160,65,self.hair)
        # Parallel ribbons turn around the crown, then break into loose temple curls.
        for k in range(23):
            u=k/23
            # The parted hairline stays unbroken above the forehead.
            if .28<u<.68:
                continue
            off=.065 if u<.53 else -.050
            samples=[.17,.38,.59,.76,.89,.976,1.016]
            pts=[self.hair_cap_point((u+off*(1-h)+.010*sin(h*pi*2))%1,h,.0009) for h in samples]
            self.lock("Combed crown wave",pts,[.001,.009,.014,.017,.016,.010,.00018],
                      [.0006,.001,.002,.004,.006,.004,.0003],self.hair_normal,
                      [self.hair,self.silver,self.hair,self.silver][k%4],.21)
        # The left foreground quiff curls back from the part, with a strong,
        # single swept silhouette and distinct ribbons along its surface.
        forelocks=[
            ([(.038,-.083,1.701),(.027,-.063,1.733),(-.007,-.058,1.742),(-.046,-.083,1.715),(-.087,-.104,1.678),(-.122,-.093,1.648),(-.153,-.059,1.622),(-.16,-.026,1.632)],
             [.003,.011,.018,.023,.025,.023,.014,.001],[.003,.007,.011,.014,.015,.014,.010,.001],self.silver),
            ([(.037,-.090,1.700),(.018,-.080,1.721),(-.018,-.093,1.718),(-.053,-.119,1.684),(-.087,-.134,1.646),(-.116,-.122,1.624),(-.147,-.103,1.619),(-.157,-.085,1.631)],
             [.004,.014,.018,.019,.021,.018,.012,.0006],[.003,.007,.010,.012,.013,.012,.009,.0005],self.pearl),
            ([(.042,-.070,1.702),(.028,-.047,1.730),(-.010,-.035,1.736),(-.060,-.055,1.715),(-.102,-.070,1.680),(-.149,-.040,1.652),(-.158,-.004,1.644)],
             [.002,.012,.017,.021,.029,.018,.001],[.003,.007,.011,.013,.013,.011,.001],self.silver),
            ([(.042,-.085,1.699),(.065,-.073,1.710),(.096,-.062,1.698),(.117,-.052,1.672),(.140,-.049,1.642),(.152,-.021,1.634)],
             [.002,.011,.015,.017,.015,.001],[.002,.006,.008,.011,.009,.001],self.silver)]
        for i,(pts,w,h,m) in enumerate(forelocks):
            self.lock("Parted fringe",pts,w,h,self.hair_normal,m,.25)
        for i,(u0,u1,shift) in enumerate([(.534,.68,.01),(.545,.72,.013),(.492,.323,-.055),(.465,.276,-.055)]):
            flow=[.22,.37,.52,.68,.82,.93,1.0]
            pts=[self.hair_cap_point(mix(u0,u1,smooth(t))+shift*sin(pi*t),v,.003) for t,v in [(j/(len(flow)-1),h) for j,h in enumerate(flow)]]
            self.lock("Sweeping front wave",pts,[.002,.011,.018,.022,.020,.013,.001],
                      [.001,.004,.008,.011,.012,.009,.001],self.hair_normal,
                      [self.silver,self.hair,self.silver,self.hair][i],.21)
        for side in (-1,1):
            # Below the fringe the ear is exposed between temple curl and nape.
            curls=[
                ([(.125,-.079,1.640),(.147,-.084,1.611),(.163,-.081,1.580),(.167,-.066,1.552),(.163,-.036,1.534),(.154,-.025,1.539)],[.009,.017,.023,.019,.012,.0005]),
                ([(.139,-.072,1.610),(.156,-.083,1.581),(.164,-.076,1.546),(.163,-.055,1.518),(.153,-.046,1.496),(.154,-.053,1.488)],[.007,.016,.021,.021,.011,.0004]),
                ([(.140,.038,1.607),(.164,.047,1.565),(.174,.049,1.534),(.179,.060,1.512),(.174,.076,1.503),(.162,.080,1.516)],[.006,.022,.026,.025,.016,.0005]),
                ([(.147,.054,1.571),(.161,.059,1.530),(.167,.064,1.494),(.169,.081,1.467),(.164,.100,1.459),(.150,.109,1.478)],[.008,.019,.025,.023,.013,.0008]),
                ([(.143,.056,1.538),(.153,.057,1.506),(.151,.064,1.470),(.149,.079,1.444),(.137,.099,1.432),(.128,.111,1.449)],[.004,.014,.022,.022,.015,.0005])]
            for i,(pts,w) in enumerate(curls):
                xyz=[(side*x,y,z-(.007 if side>0 and i in (0,1) else 0)) for x,y,z in pts]
                self.lock("Temple wave",xyz,w,[max(.0004,a*.54) for a in w],
                          self.hair_normal,[self.silver,self.pearl,self.hair,self.silver,self.hair][i],.15)

    def beard_point(self,u,v,extra=0):
        # A deep, U-shaped envelope runs continuously over chin and both jowls.
        a=u*1.40
        upper=1.337+.119*abs(u)**2.35
        scallop=.006*cos(16*u+.6)+.005*cos(27*u-.2)
        lower=1.240+.103*abs(u)**1.64+scallop
        z=mix(upper,lower,v)
        radius_x=mix(.170,.136,v)+.029*sin(pi*v)
        depth=mix(.149,.124,v)+.029*sin(pi*v)
        return Vector(((radius_x+extra)*sin(a),.005-(depth+extra)*cos(a),z))

    def whiskers(self):
        self.grid("Forked chin beard mass",lambda t,s:self.beard_point(2*s-1,t),38,95,self.shadow)
        for k in range(17):
            u=(k-8)/8.45
            bend=.083*cos(k*2.5)-.035*u
            vals=[.005,.23,.46,.66,.84,.96,1.005+.037*cos(k*1.4),.994+.032*cos(k*1.4)]
            pts=[]
            for j,v in enumerate(vals):
                shift=bend*v**1.2+.038*sin(2*pi*v+.47*k)*v
                if j==7: shift+=.031*(1 if k%2 else -1)
                p=self.beard_point(u+shift,v,.0015+(.004 if j in (5,6) else 0))
                if j==7: p.y+=.005
                pts.append(p)
            width=.024+.004*cos(2.23*k)
            self.lock("Chin curl",pts,[.002,width*.85,width,width*1.08,width*.93,width*.65,width*.30,.0003],
                      [.001,.005,.008,.011,.013,.012,.005,.0005],
                      lambda p,t:(p.x*5,-max(.15,-p.y*7),-.35*t),
                      [self.beard,self.silver,self.beard,self.pearl,self.beard][k%5],.25)
        for k in range(12):
            u=(k-5.5)/6.0
            vs=[.02,.15,.32,.46,.57,.62]
            pts=[self.beard_point(u+.047*sin(v*pi*2-.4+k*.6)*v,v,.008+.001*cos(k)) for v in vs]
            self.lock("Overlapping beard wave",pts,[.001,.010,.015,.013,.007,.0003],
                      [.0005,.003,.005,.007,.005,.0003],
                      lambda p,t:(p.x*5,-max(.15,-p.y*7),-.23*t),
                      [self.beard,self.pearl,self.beard][k%3],.19)
        for side in (-1,1):
            pts=[(.001,-.179,1.427),(.019,-.185,1.421),(.040,-.181,1.415),(.063,-.167,1.416),(.080,-.151,1.426),(.091,-.135,1.437),(.094,-.130,1.444)]
            self.lock("Handlebar moustache",[(side*x,y,z) for x,y,z in pts],
                      [.009,.017,.019,.017,.011,.005,.0004],[.009,.014,.015,.014,.009,.004,.0004],
                      (side*.12,-1,.16),self.beard,.21)
            for i in range(4):
                h=(i-1.5)*.0026
                pts=[(.008,-.185,1.428+h),(.025,-.195,1.425+h),(.045,-.194,1.420+h),
                     (.065,-.179,1.422+h),(.082,-.156,1.431+h*.6)]
                self.stroke("Moustache hair",[(side*x,y,z) for x,y,z in pts],.00083,self.pearl,[.09,.8,1,.68,.07])

    def spectacles(self):
        # Low, forward-leaning spectacles. A clear aperture preserves eye expression.
        for side in (-1,1):
            coords=[]
            for k in range(16):
                a=k*pi/8
                x=.062+.044*cos(a)
                z=1.466+.039*sin(a)+.002*cos(a)
                y=-.183+.021*(x-.062)/.062+.007*sin(a)
                coords.append((side*x,y,z))
            self.stroke("Oval spectacle rim",coords,.00215,self.brass,cyclic=True)
            self.stroke("Temple of spectacles",[(side*.107,-.168,1.468),(side*.127,-.133,1.470),
                        (side*.156,-.087,1.474),(side*.179,-.030,1.473),
                        (side*.180,-.005,1.471),(side*.18,.009,1.456)],.0019,self.brass)
        pts=[(-.022,-.194,1.479),(-.017,-.198,1.483),(-.009,-.199,1.486),
             (0,-.199,1.487),(.009,-.199,1.486),(.017,-.198,1.483),(.022,-.194,1.479)]
        self.stroke("Arched spectacle bridge",pts,.0020,self.brass)

    def build(self):
        skin=self.make_skin()
        sculpt_faces=len(skin.data.polygons)
        bpy.ops.object.quadriflow_remesh(target_faces=32000,use_mesh_symmetry=False,
                                         use_preserve_boundary=True,preserve_attributes=True,
                                         smooth_normals=True,seed=5)
        skin=bpy.context.view_layer.objects.active
        skin["sculpt_faces_before_retopology"]=sculpt_faces
        skin["retopology"]="Native Blender QuadriFlow, 32,000 target, seed 5; painted complexion transferred."
        if len(skin.data.polygons)>=sculpt_faces or "Complexion" not in skin.data.color_attributes:
            raise RuntimeError("Facial retopology or painted complexion transfer did not finish")
        self.eyes_and_expression()
        self.scalp()
        self.whiskers()
        self.spectacles()
        self.collection["sculpt"]="Native Blender sculpt/remesh and individually modeled facial planes, hair and whiskers."
        self.collection["reference"]="CHAR_GEP_APPROVED_REFERENCE.png"
        self.collection["inferred"]="Back of head and hair curl directions are inferred from the approved three-quarter view."
        return self.collection


def build_head():
    return Portrait().build()
