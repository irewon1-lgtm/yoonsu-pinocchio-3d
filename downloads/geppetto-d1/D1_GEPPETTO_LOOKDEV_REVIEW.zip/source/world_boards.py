"""Compose the D1 workshop and window diagrams from evaluated dimensions and stills."""
import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw
from boards import PAPER, INK, MUTED, GREEN, LINE, header, text, fill, foot


def paste(board, image, box):
    if not isinstance(image,Image.Image):
        image=Image.open(image)
    x,y,w,h=box
    factor=min(w/image.width,h/image.height)
    image=image.convert("RGB").resize((round(image.width*factor),round(image.height*factor)),Image.Resampling.LANCZOS)
    board.paste(image,(x+(w-image.width)//2,y+(h-image.height)//2))


def crop_uv(image, rect):
    return image.crop(tuple(round(x * (image.width if i%2 == 0 else image.height)) for i,x in enumerate(rect)))


def annotated_crop(path, box, pane, silhouette, previous=False):
    im = Image.open(path).convert("RGB")
    draw = ImageDraw.Draw(im)
    w,h = im.size
    draw.rectangle(tuple(round(a*(w if i%2==0 else h)) for i,a in enumerate(pane)),
                   outline="#B6FADE",width=3)
    draw.rectangle(tuple(round(a*(w/1440 if i%2==0 else h/810)) for i,a in enumerate(silhouette)),
                   outline="#E3AD6F" if previous else "#FFF1BD",width=2)
    return crop_uv(im,box)


def world_board(out, data):
    scene=data["states"]["C07"]
    board=Image.new("RGB",(1560,1650),PAPER)
    header(board,"작업실  ·  제페토와 작업대","C07 기상 후 정지 시안   /   메인 카메라와 두 진단 시점의 인물 높이를 비교합니다.")
    main=Image.open(out/"D1_C07_STANDING.png").convert("RGB")
    paste(board,main,(48,231,946,533))
    x=1030
    text(board,(x,242),"실제 메시 높이",28,GREEN,True)
    actors=scene["candidate"]
    for i,(code,label) in enumerate((("GEP","제페토"),("PIN","피노키오"))):
        value=actors[code]["world_size_xyz"][2]
        pix=actors[code]["projections"]["locked"]["size_wh_px"][1]
        text(board,(x,310+i*104),label,21,MUTED)
        text(board,(x,344+i*104),f"{value:.2f} BU   ·   {pix:.0f} px",33,INK,True)
    fill(board,(x,524,1498,526),LINE)
    text(board,(x,550),f"키 비율   {scene['adult_over_standing_pin_world']:.2f}배",27,GREEN,True)
    text(board,(x,603),f"상판 높이   {scene['table_z']:.2f} BU",23,INK)
    text(board,(x,644),f"제페토 키의 {scene['top_over_adult_height']:.0%}",22,MUTED)
    text(board,(x,704),"카메라 원본 프레임  1440 × 810",19,MUTED)
    for i,(cam,stem,title) in enumerate((("diagonal","DIAGNOSTIC_DIAGONAL","상부 사선  ·  정사영"),("eye_level","DIAGNOSTIC_EYE_LEVEL","눈높이  ·  32 mm 원근"))):
        px=48+i*743
        aspect=scene["adult_over_standing_pin_projected"][cam]
        text(board,(px,792),f"{title}    /    화면 키 비율 {aspect:.2f}배",22,GREEN,True)
        # Images show the measured actors, ground and diagnostic contact volumes.
        paste(board,out/(stem+".png"),(px,837,710,328))
    fill(board,(48,1190,1512,1192),LINE)
    text(board,(48,1215),"C06  ·  얼굴과 받침천",23,GREEN,True)
    text(board,(793,1215),"C07  ·  양발과 작업대",23,GREEN,True)
    sleep=Image.open(out/"D1_C06_SLEEPING.png").convert("RGB")
    paste(board,crop_uv(sleep,(.118,.43,.367,.65)),(48,1266,430,228))
    paste(board,crop_uv(main,(.155,.466,.267,.629)),(794,1266,280,228))
    text(board,(480,1282),"머리·등·다리",21,INK,True)
    text(board,(480,1326),"천과 간격  0.0005 BU",20,MUTED)
    text(board,(480,1370),"눈·입의 검사 광선 중",18,MUTED)
    text(board,(480,1406),"제페토에 가린 표본  0개",18,MUTED)
    margins=[v["traced_worktop_edge_margin_bu"] for v in scene["standing_contacts"].values()]
    text(board,(1090,1282),"양쪽 밑창 접지",21,INK,True)
    text(board,(1090,1326),"천과 간격  < 0.0001 BU",20,MUTED)
    text(board,(1090,1370),f"상판 모서리 최소 여유  {min(margins):.2f} BU",18,MUTED)
    text(board,(48,1519),"메인 화면에서 의자가 제페토의 다리를 가립니다. 위의 진단 시점에서 실제 발 위치와 성인 키를 함께 확인할 수 있습니다.",20,MUTED)
    foot(board,"실제 높이는 평가 메시의 최저점~최고점입니다. 하단은 공간 진단용 지오메트리입니다. 정지 배치와 조형은 사용자 검토 전입니다.")
    board.save(out/"D1_WORLD_SCALE.png")


def fairy_board(out, archive, data):
    scene=data["states"]["C07"]
    fairy=scene["fairy_window"]
    board=Image.new("RGB",(1560,1040),PAPER)
    header(board,"창문  ·  요정의 통과 여유","같은 카메라와 같은 확대율에서 창 아치, 가로살, 날개 끝의 거리를 비교합니다.")
    crop=(.553,.015,.917,.477)
    for i,(path,who,title,desc) in enumerate((
        (archive/"D1_C07_STANDING_PREVIEW.png","original_locked_layout","이전 배치","기존 창 프록시와 요정"),
        (out/"D1_C07_STANDING.png","candidate","크기·위치 시안","원화 창호와 축소한 기존 요정"))):
        x=48+743*i
        text(board,(x,230),title,29,GREEN if i else INK,True)
        text(board,(x,273),desc,19,MUTED)
        silhouette=scene[who]["FAI"]["projections"]["locked"]["bbox_ltrb_px"]
        pic=annotated_crop(path,crop,fairy["pane_uv_top_left"],silhouette,i==0)
        paste(board,pic,(x,315,712,433))
    fill(board,(48,765,1512,767),LINE)
    text(board,(48,793),f"날개 너비  {fairy['wing_width_world']:.2f} BU    /    창 한 칸의 폭  {fairy['pane_clear_width_world']:.2f} BU",26,INK,True)
    text(board,(48,842),f"몸높이  {fairy['body_height_excluding_wings_and_wand']:.2f} BU   ·   피노키오의 {scene['fairy_body_over_standing_pin_world']:.0%}    /    날개 너비는 창 한 칸의 {fairy['wing_over_clear_pane_world']:.0%}",22,MUTED)
    frame_gap=min(fairy["static_frame_clearance_ltrb_px"])
    text(board,(48,884),f"민트색은 유리 안쪽의 보수적 개구 범위, 황색은 지팡이·날개를 포함한 외곽입니다. 메인 화면 최소 여백은 {frame_gap:.0f} px입니다.",21,MUTED)
    foot(board,"그림에는 닫힌 유리가 보입니다. 이 수치는 개방을 가정한 고정 자세의 통과 여유입니다. 실제 창 여닫기와 날갯짓은 미검증입니다.")
    board.save(out/"D1_FAIRY_WINDOW.png")


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("out",type=Path)
    parser.add_argument("archive",type=Path)
    args=parser.parse_args()
    data=json.loads((args.out/"WORLD_MEASUREMENTS.json").read_text())
    world_board(args.out,data)
    fairy_board(args.out,args.archive,data)
