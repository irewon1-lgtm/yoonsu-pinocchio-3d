import bpy
import json
from pathlib import Path
from bl_ext.user_default.mpfb.services.humanservice import HumanService
from bl_ext.user_default.mpfb.services.targetservice import TargetService
from bl_ext.user_default.mpfb.services.objectservice import ObjectService
root = Path(__file__).resolve().parent
for obj in list(bpy.context.scene.objects):
    bpy.data.objects.remove(obj, do_unlink=True)
macro = TargetService.get_default_macro_info_dict()
macro.update(gender=1.0, age=0.94, muscle=0.38, weight=0.57)
obj = HumanService.create_human(macro_detail_dict=macro)
obj.name = 'MPFB2_Geppetto_elder_male_base'
bpy.context.view_layer.update()
mesh = obj.evaluated_get(bpy.context.evaluated_depsgraph_get()).data
probe = {'blender':bpy.app.version_string,'extension_tag':'v2.0.18','base':obj.name, 'operator_registered':bool(bpy.ops.mpfb.create_human.get_rna_type()), 'mpfb_recognized':ObjectService.object_is_basemesh(obj),'raw_vertices':len(obj.data.vertices),'evaluated_vertices':len(mesh.vertices),'evaluated_faces':len(mesh.polygons),'uv_layers':[uv.name for uv in mesh.uv_layers], 'armatures':len(bpy.data.armatures), 'actions':len(bpy.data.actions), 'macro':macro,'transform':{'location':list(obj.location),'scale':list(obj.scale),'euler':list(obj.rotation_euler)},'bounds':[list(v) for v in obj.bound_box]}
assert probe['mpfb_recognized'] and probe['armatures']==0 and probe['evaluated_vertices'] > 10000 and probe['uv_layers']
bpy.ops.wm.save_as_mainfile(filepath=str(root / 'MPFB2_GEPPETTO_ELDER_BASE.blend'),compress=True)
(root / 'mpfb_probe.json').write_text(json.dumps(probe,indent=2))
print(json.dumps(probe))
