import hashlib
import json
from pathlib import Path
import bpy
root = Path(__file__).resolve().parent
obj = bpy.data.objects['MPFB2_Geppetto_elder_male_base']
evaluated_mesh = obj.evaluated_get(bpy.context.evaluated_depsgraph_get()).data
report = {'blender_version':bpy.app.version_string, 'extension_enabled':any(a.module.endswith('.mpfb') for a in bpy.context.preferences.addons), 'file':Path(bpy.data.filepath).name,'armatures':len(bpy.data.armatures),'actions':len(bpy.data.actions),'evaluated_faces':len(evaluated_mesh.polygons),'evaluated_uv_layers':[uv.name for uv in evaluated_mesh.uv_layers],'images':{}}
assert report['armatures'] == 0 and report['actions'] == 0 and report['evaluated_faces'] == 13378
for filename in ('studio.exr','ambientcg/Fabric026_color.jpg','ambientcg/Fabric026_weave.png'):
    path = root / filename
    image = bpy.data.images.load(str(path),check_existing=False)
    assert image.size[0] > 0 and image.size[1] > 0
    report['images'][filename] = dict(size=list(image.size),file_format=image.file_format,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(root / 'asset_readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
