"""Geppetto's D1 costume and workshop gesture, in metres, facing -Y.

All panels, lasts, limbs and ornaments are authored in this file. The back
construction, hidden hand and tool tips are interpretations of a single view.
build_body() only adds the costume, forearms and hands to the current scene.
"""
import math
import bpy
from mathutils import Vector

TAU = 2 * math.pi
sin, cos, pi = math.sin, math.cos, math.pi


def linear(hex_color):
    channels = [int(hex_color[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple(v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in channels) + (1.,)


def surface(name, dark, middle, light, grain=180, rough=.78, metal=0, blotch=False):
    material = bpy.data.materials.new("GEP Body · " + name)
    material.diffuse_color = linear(middle)
    material.use_nodes = True
    nodes, links = material.node_tree.nodes, material.node_tree.links
    bsdf = nodes.get("Principled BSDF")
    bsdf.inputs["Roughness"].default_value = rough
    bsdf.inputs["Metallic"].default_value = metal
    coords = nodes.new("ShaderNodeTexCoord")
    noise = nodes.new("ShaderNodeTexNoise")
    noise.inputs["Scale"].default_value = 7 if blotch else 23
    noise.inputs["Detail"].default_value = 4.5 if blotch else 2.5
    noise.inputs["Roughness"].default_value = .7
    links.new(coords.outputs["Object"], noise.inputs["Vector"])
    ramp = nodes.new("ShaderNodeValToRGB")
    values = [(0.28, dark), (.46 if blotch else .50, middle), (.74, light)]
    for i, (pos, color) in enumerate(values):
        stop = ramp.color_ramp.elements[i] if i < 2 else ramp.color_ramp.elements.new(pos)
        stop.position, stop.color = pos, linear(color)
    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
    if blotch:
        # Old oil, green paint and pencil dust cluster near the lower working edge.
        # A two-scale breakup keeps their margins feathered in the canvas weave.
        plane=nodes.new("ShaderNodeVectorMath")
        plane.operation="MULTIPLY"
        plane.inputs[1].default_value=(1,0,1.12)
        links.new(coords.outputs["Object"],plane.inputs[0])
        daubs=[(-.181,.526),(-.154,.506),(-.143,.492),(.064,.552),(.079,.559),
               (.202,.546),(.192,.518),(-.062,.468),(.096,.946)]
        nearest=None
        for x,z in daubs:
            distance=nodes.new("ShaderNodeVectorMath")
            distance.operation="DISTANCE"
            links.new(plane.outputs["Vector"],distance.inputs[0])
            distance.inputs[1].default_value=(x,0,z*1.12)
            if nearest is None:
                nearest=distance.outputs["Value"]
            else:
                combine=nodes.new("ShaderNodeMath")
                combine.operation="MINIMUM"
                links.new(nearest,combine.inputs[0])
                links.new(distance.outputs["Value"],combine.inputs[1])
                nearest=combine.outputs[0]
        fleck=nodes.new("ShaderNodeTexNoise")
        fleck.inputs["Scale"].default_value=96
        fleck.inputs["Detail"].default_value=3.2
        links.new(coords.outputs["Object"],fleck.inputs[0])
        edge=nodes.new("ShaderNodeMath")
        edge.operation="MULTIPLY_ADD"
        links.new(fleck.outputs["Fac"],edge.inputs[0])
        edge.inputs[1].default_value=.086
        links.new(nearest,edge.inputs[2])
        mask=nodes.new("ShaderNodeValToRGB")
        mask.color_ramp.elements[0].position=.053
        mask.color_ramp.elements[0].color=(.78,.78,.78,1)
        mask.color_ramp.elements[1].position=.073
        mask.color_ramp.elements[1].color=(0,0,0,1)
        links.new(edge.outputs[0],mask.inputs[0])
        mix=nodes.new("ShaderNodeMixRGB")
        links.new(mask.outputs["Color"],mix.inputs[0])
        links.new(ramp.outputs["Color"],mix.inputs[1])
        mix.inputs[2].default_value=linear("555642")
        links.new(mix.outputs["Color"],bsdf.inputs["Base Color"])
    detail = nodes.new("ShaderNodeTexNoise")
    detail.inputs["Scale"].default_value = grain
    detail.inputs["Detail"].default_value = 2
    links.new(coords.outputs["Object"], detail.inputs["Vector"])
    bump = nodes.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value = .17
    bump.inputs["Distance"].default_value = .00065
    links.new(detail.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
    if rough > .74:
        bsdf.inputs["Sheen Weight"].default_value = .16
    return material


class Atelier:
    def __init__(self):
        self.collection = bpy.data.collections.new("GEP · tailored body")
        bpy.context.scene.collection.children.link(self.collection)
        self.materials = {}
        palette = [
            ("shirt", "C6AF8D", "E8D2AB", "EED9B6", 470, .88),
            ("linenShadow", "A58667", "C3AB84", "DCC29D", 380, .87),
            ("vest", "503522", "674027", "774A2C", 360, .81),
            ("binding", "523322", "805336", "9E704B", 310, .70),
            ("thread", "9A754D", "B59260", "CCAD7C", 380, .80),
            ("apron", "655538", "A57B3C", "BA9454", 370, .87),
            ("apronEdge", "805D32", "AC8549", "C9A267", 280, .84),
            ("trousers", "473A30", "594536", "65503D", 260, .86),
            ("sole", "30251F", "4C3426", "634530", 200, .70),
            ("shoe", "69482F", "775234", "8C6445", 160, .57),
            ("lace", "553B27", "97744C", "AE8A62", 200, .79),
            ("brass", "79572F", "AD8047", "D1A469", 200, .46),
            ("wood", "936539", "C39455", "E2B77B", 320, .62),
            ("skin", "BC825E", "C48B63", "CE966D", 250, .65),
            ("crease", "9B694C", "AB7653", "B67D57", 220, .73),
            ("nail", "DD9C7F", "F0BC9C", "F6CDAE", 220, .60),
        ]
        for name, dark, middle, light, grain, rough in palette:
            self.materials[name] = surface(name, dark, middle, light, grain, rough,
                                           metal=.57 if name == "brass" else 0, blotch=name == "apron")

    def mesh(self, name, vertices, faces, mat, sub=1, thick=0):
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(vertices, [], faces)
        mesh.update()
        obj = bpy.data.objects.new("GEP · " + name, mesh)
        self.collection.objects.link(obj)
        obj.data.materials.append(self.materials[mat])
        for p in mesh.polygons:
            p.use_smooth = True
        if sub:
            mod = obj.modifiers.new("Tailored fairing", "SUBSURF")
            mod.levels = mod.render_levels = sub
        if thick:
            mod = obj.modifiers.new("Turned edge", "SOLIDIFY")
            mod.thickness = thick
            mod.offset = 0
        return obj

    def grid(self, name, rows, mat, cyclic=True, cap=True, sub=1, thick=0, omit=None):
        n = len(rows[0])
        faces = []
        for j in range(len(rows) - 1):
            for i in range(n if cyclic else n - 1):
                if omit and omit(j, i):
                    continue
                k = (i + 1) % n
                faces.append((j*n+i, j*n+k, (j+1)*n+k, (j+1)*n+i))
        if cap and cyclic:
            faces.extend([tuple(reversed(range(n))), tuple((len(rows)-1)*n+i for i in range(n))])
        obj = self.mesh(name, [p for row in rows for p in row], faces, mat, sub, thick)
        uv = obj.data.uv_layers.new(name="Tailor pattern")
        for face in obj.data.polygons:
            indices = [obj.data.loops[i].vertex_index for i in face.loop_indices]
            across_wrap = cyclic and n-1 in [v % n for v in indices]
            for i, v in zip(face.loop_indices, indices):
                j, k = divmod(v,n)
                if len(indices) == 4:
                    u = 1 if across_wrap and k == 0 else k/(n if cyclic else n-1)
                    uv.data[i].uv = (u, j/(len(rows)-1))
                else:
                    uv.data[i].uv = (.5+.46*cos(TAU*k/n),.5+.46*sin(TAU*k/n))
        return obj

    def loft(self, name, sections, mat, folds=0, n=36, sub=2):
        rows = []
        for j, (z, x, y, rx, ry) in enumerate(sections):
            pts = []
            for i in range(n):
                t = TAU*i/n
                ripple = folds*(sin(7*t+.36*j) + .38*sin(11*t-.28*j))
                pts.append((x+(rx+ripple)*sin(t), y-(ry+ripple)*cos(t), z))
            rows.append(pts)
        return self.grid(name, rows, mat, sub=sub)

    def sweep(self, name, stations, mat, folds=0, n=24, sub=2, ref=(0, 1, 0), cloth=False):
        if cloth:
            dense=[]
            for idx in range(len(stations)-1):
                left=stations[max(0,idx-1)]
                a,b=stations[idx:idx+2]
                right=stations[min(len(stations)-1,idx+2)]
                for k in range(5):
                    t=k/5
                    dense.append(tuple(.5*((2*m)+(-l+r)*t+(2*l-5*m+4*r-nxt)*t*t+
                                    (-l+3*m-3*r+nxt)*t*t*t) for l,m,r,nxt in zip(left,a,b,right)))
            stations=dense+[stations[-1]]
        centers = [Vector(st[:3]) for st in stations]
        rows = []
        for j, st in enumerate(stations):
            tangent = (centers[min(j+1,len(stations)-1)]-centers[max(j-1,0)]).normalized()
            u = Vector(ref).cross(tangent).normalized()
            v = tangent.cross(u)
            row = []
            for i in range(n):
                t = TAU*i/n
                fraction=j/(len(stations)-1)
                ripple = folds*(sin(5*t + 4*fraction) + .4*sin(8*t - 2*fraction))
                if cloth:
                    # Broad diagonal compression and two short pinched folds around the lower arm.
                    for center, depth, width, angle, direction in (
                        (.42,.006,.044,1.6,.12),(.66,.008,.037,-1.7,-.10),(.83,.006,.047,.2,.14)
                    ):
                        d=fraction-center-direction*sin(t-angle)
                        gate=(.55+.45*cos(t-angle))**1.5
                        ripple+=depth*gate*(math.exp(-(d/width)**2)-.70*math.exp(-((d+.059)/(width*1.22))**2))
                row.append(centers[j] + u*((st[3]+ripple)*cos(t)) + v*((st[4]+ripple)*sin(t)))
            rows.append(row)
        return self.grid(name, rows, mat, sub=sub)

    def traces(self, name, lines, mat, radius, closed=False):
        """Multiple paths share a single curve datablock."""
        data = bpy.data.curves.new(name, "CURVE")
        data.dimensions = "3D"
        data.resolution_u = 4
        data.bevel_depth = radius
        data.bevel_resolution = 2
        data.use_fill_caps = True
        for line in lines:
            spline = data.splines.new("BEZIER")
            spline.bezier_points.add(len(line)-1)
            for p, xyz in zip(spline.bezier_points, line):
                p.co = xyz
                p.handle_left_type = p.handle_right_type = "AUTO"
            spline.use_cyclic_u = closed
        obj = bpy.data.objects.new("GEP · " + name, data)
        self.collection.objects.link(obj)
        data.materials.append(self.materials[mat])
        return obj

    def seam(self, name, line, mat="thread", radius=.0009, step=.012):
        points = [Vector(p) for p in line]
        lengths = [(b-a).length for a,b in zip(points,points[1:])]
        total = sum(lengths)
        def along(distance):
            for idx,length in enumerate(lengths):
                if distance <= length:
                    return points[idx].lerp(points[idx+1], distance/max(length,.0000001))
                distance -= length
            return points[-1]
        lines = [[along(i*step), along(i*step + .46*step)] for i in range(int(total/step))]
        if lines:
            self.traces(name, lines, mat, radius)

    def button(self, name, center, radius, mat="brass"):
        x,y,z = center
        stations = [(x,y+.002,z,.72*radius,.72*radius),(x,y,z,radius,radius),
                    (x,y-.003,z,radius,radius),(x,y-.004,z,.77*radius,.77*radius)]
        self.sweep(name, stations, mat, n=18, sub=1, ref=(0,0,1))
        self.traces(name+" crossed threads",
                    [[(x-.003,y-.004,z-.002),(x+.003,y-.005,z+.002)],
                     [(x+.003,y-.004,z-.002),(x-.003,y-.005,z+.002)]],"binding",.0012)


# Shared rounded pattern block, for a slight rearward rise across the shoulders.
FORM=[(.46,.212,.148,.022),(.60,.265,.184,.030),(.70,.284,.209,.029),
      (.80,.284,.208,.021),(.89,.269,.192,.018),(.99,.254,.180,.019),
      (1.07,.273,.170,.024),(1.115,.283,.156,.029),(1.15,.246,.143,.025),
      (1.18,.142,.095,.018),(1.21,.098,.084,.010)]


def lerp_profile(z, profile=FORM):
    for a,b in zip(profile,profile[1:]):
        if z <= b[0]:
            f = max(0,(z-a[0])/(b[0]-a[0]))
            return tuple(v+(w-v)*f for v,w in zip(a[1:],b[1:]))
    return profile[-1][1:]


def shellpoint(z,t,offset=0,wave=0):
    rx,ry,cy=lerp_profile(z)
    abdomen=.020*math.exp(-((z-.79)/.15)**2)*max(0,cos(t))**2
    shoulder_back=.036*math.exp(-((z-1.105)/.077)**2)*max(0,-cos(t))**1.6
    return ((rx+offset+wave)*sin(t), cy-(ry+offset+wave)*cos(t)-abdomen+shoulder_back,z)


def front(x,z,offset=0):
    rx,ry,cy=lerp_profile(z)
    t=math.asin(max(-.99,min(.99,x/(rx+offset))))
    return (x,cy-(ry+offset)*cos(t),z)


def shirt(a):
    a.loft("Ivory gathered shirt",[(z,0,cy,rx-.012,ry-.010) for z,rx,ry,cy in FORM if z>=.7],
           "shirt",folds=.0018,n=56)
    # The standing collar wraps the neck. Individually folded leaves meet at a loose placket.
    a.loft("Linen collar stand",[(1.15,0,.010,.116,.100),(1.158,0,.01,.115,.100),
                                  (1.197,0,.013,.096,.086),(1.21,0,.014,.094,.084)],"shirt",n=54)
    for side in (-1,1):
        rows=[]
        for f in (0,.05,.52,.96,1):
            row=[]
            for u in (0,.055,.16,.24,.27,.30,.47,.68,.95,1):
                t=(.035 + u*1.87)*side
                ztop=1.178+.027*sin(abs(t))
                zbot=1.149-.081*math.exp(-((u-.27)/.16)**2)+.042*u
                z=ztop*(1-f)+zbot*f
                row.append(shellpoint(z,t,.004+.012*sin(pi*f)))
            rows.append(row)
        a.grid("Turn-down collar "+str(side),rows,"shirt",False,False,2,.003)
    rows=[[front(x,z,-.005) for x in (-.014,-.012,.01,.012)] for z in (.974,.98,1.025,1.08,1.124,1.14)]
    a.grid("Turned shirt placket",rows,"shirt",False,False,1,.003)
    for i,z in enumerate((1.003,1.047,1.091)):
        a.button("Linen button "+str(i),front(0,z,-.005),.006,"wood")


def apron(a):
    levels=[(.433,1.68),(.439,1.68),(.451,1.67),(.54,1.67),(.64,1.66),(.721,1.7),(.78,1.80),(.802,1.7),
            (.816,1.47),(.838,.83),(.87,.63),(.963,.52),(.984,.53),(.991,.52)]
    def pos(z,t):
        hem=max(0,min(1,(.78-z)/.35))
        radius=.009 + .095*hem + .010*hem*cos(6*t+.65)+.005*hem*sin(4*t-.8)
        px,py,pz=shellpoint(z,t,radius)
        return (px,py,pz+hem*(.018*sin(t+.22)+.020*sin(t)**2+.005*cos(5*t+.6)))
    rows=[[pos(z,-extent+2*extent*i/48) for i in range(49)] for z,extent in levels]
    a.grid("Work apron · bib and skirt",rows,"apron",False,False,2,.005)
    a.traces("Rolled apron hem",[rows[0]],"apronEdge",.0028)
    a.seam("Apron hem running stitch",rows[2],radius=.00085)
    a.traces("Bib selvage",[[r[0] for r in rows],[r[-1] for r in rows],rows[-1]],"apronEdge",.0026)
    # A waist tape runs around the back and supports the apron front.
    belt=[[shellpoint(z + .007*cos(t),t, .013) for t in [TAU*i/72 for i in range(72)]]
          for z in (.785,.789,.811,.816)]
    a.grid("Apron waist tape",belt,"apronEdge",True,False,1,.002)
    # Tool pouch sits against the convex skirt and bellies forward at the lip.
    pouch=[]
    for v in (0,.035,.17,.53,.94,1):
        row=[]
        for u in (-1,-.95,-.68,-.35,0,.35,.68,.95,1):
            x=.049+(.09+.014*v)*u
            z=.50+.174*v+.021*(1-v)*u*u+.008*v*u
            px,py,pz=pos(z,math.asin(x/(lerp_profile(z)[0]+.048)))
            row.append((px,py-.005-.023*v*(1-.51*u*u)-.009*sin(pi*v)*(1-u*u),pz))
        pouch.append(row)
    a.grid("Apron tool pocket",pouch,"apron",False,False,2,.005)
    a.traces("Pocket lip",[pouch[-1]],"apronEdge",.0033)
    a.seam("Tool pocket stitched edge",[r[0] for r in reversed(pouch)]+pouch[0]+[r[-1] for r in pouch])
    handles=[(-.010,-.014,.102,.014,"wood"),(.055,.030,.139,.011,"wood"),(.094,.036,.092,.010,"binding")]
    for i,(x,lean,h,rad,mat) in enumerate(handles):
        _,y,_=pos(.68,math.asin(x/.286))
        y-=.012
        if i==0:
            outline=[(-.036,.65),(.012,.67),(.019,1.08),(.036,1.12),(.043,.91),
                     (.068,1.21),(.088,1.21),(.096,1.05),(.102,.67)]
        elif i==1:
            outline=[(-.033,.78),(.001,.86),(.014,.94),(.023,.97),(.115,.96),(.134,.80),(.139,.63)]
        else:
            outline=[(-.032,.80),(.018,.80),(.060,.84),(.068,1),(.088,.96),(.092,.69)]
        a.sweep("Apron pocket handle "+str(i),[(x+lean*dz/h,y+.002*dz/h,.669+dz,rad*r,rad*r)
                      for dz,r in outline],mat,sub=1,n=8 if i==1 else 16)
    for side in (-1,1):
        rows=[]
        for j in range(9):
            s=j/8
            x=side*(.028+.105*s+.015*sin(pi*s))
            y=.226-.018*s
            z=.806-.144*s+.014*sin(2*pi*s)
            rows.append([(x+u*.017,y+.005*cos(u*pi/2),z+u*.008) for u in (-1,-.92,0,.92,1)])
        a.grid("Rear apron tie end "+str(side),rows,"apronEdge",False,False,2,.003)


def waistcoat(a):
    levels=[(.67,.68,1.55,1.60),(.678,.68,1.53,1.62),(.712,.65,1.52,1.63),(.81,.53,1.50,1.65),
            (.887,.46,1.42,1.70),(.916,.44,1.38,1.77),(.953,.43,1.15,2.02),
            (1.034,.46,.96,2.22),(1.098,.47,.95,2.27),(1.133,.51,1.05,2.09),
            (1.154,.56,1.23,1.94),(1.167,.64,1.49,1.68),(1.178,.71,1.54,1.58),
            (1.182,.73,1.55,1.57)]
    rows=[]
    for z,opening,a0,a1 in levels:
        # Angular cuts run along both armscyes. The back and both front panels remain one mesh.
        half=[opening+(a0-opening)*i/10 for i in range(11)]
        half.extend(a0+(a1-a0)*i/8 for i in range(1,9))
        half.extend(a1+(pi-a1)*i/16 for i in range(1,17))
        angles=half+[TAU-t for t in reversed(half[:-1])]
        lower=max(0,1-(z-.67)/.16)
        row=[]
        for t in angles:
            fold=.0035*sin(5*t-.6)*sin(pi*max(0,min(1,(z-.67)/.32)))
            p=shellpoint(z,t,.020+.016*lower+fold)
            row.append((p[0],p[1],p[2]+lower*(.039*abs(sin(t))+.009*cos(2*t)+.010*sin(t+.57))))
        rows.append(row)
    def armhole(j,i):
        return 5<=j<12 and ((10<=i<18) or (50<=i<58))
    a.grid("Walnut waistcoat · cut armscyes",rows,"vest",False,False,2,.006,armhole)
    a.traces("Waistcoat bound opening",[[r[0] for r in rows],rows[0],[r[-1] for r in rows],rows[-1]],"binding",.0038)
    a.seam("Waistcoat front pickstitch right",[r[1] for r in rows])
    a.seam("Waistcoat front pickstitch left",[r[-2] for r in rows])
    a.seam("Waistcoat bottom pickstitch",rows[1])
    for side in (-1,1):
        idxs=(10,18) if side==1 else (50,58)
        i,k=idxs
        border=[rows[j][i] for j in range(5,13)]+list(rows[12][i+1:k+1])+[rows[j][k] for j in range(11,4,-1)]+list(reversed(rows[5][i+1:k]))
        a.traces("Leather armscye binding "+str(side),[border],"binding",.0043,True)
    for i,(z,t) in enumerate(((.724,.72),(.800,.62),(.877,.53),(.955,.50))):
        x,y,z=shellpoint(z,-t,.033)
        a.button("Waistcoat horn button "+str(i),(x,y,z),.010 if i<3 else .011,"wood")
    pocket=[]
    for v in (0,.06,.3,.77,.94,1):
        row=[]
        for u in (-1,-.94,-.60,0,.60,.94,1):
            t=-(1.04+.245*u)
            z=.742+.086*v+.012*(1-v)*u*u-.008*u
            row.append(shellpoint(z,t,.037+.006*(1-u*u)))
        pocket.append(row)
    a.grid("Waistcoat watch pocket",pocket,"vest",False,False,2,.003)
    a.traces("Watch pocket welt",[pocket[-1]],"binding",.0065)
    a.seam("Watch pocket side stitches",[r[0] for r in reversed(pocket)]+pocket[0]+[r[-1] for r in pocket])
    # Adjustable rear half-belt and small brass keeper.
    rear=[[shellpoint(z+.006*cos(t),t,.036) for t in [pi-.77+1.54*i/30 for i in range(31)]]
          for z in (.853,.855,.878,.880)]
    a.grid("Waistcoat rear half belt",rear,"binding",False,False,1,.002)
    a.traces("Rear brass slide",[[(-.019,.256,.849),(.018,.256,.849),(.018,.256,.877),(-.019,.256,.877)]],"brass",.002,True)


def trousers_and_boots(a):
    seat=a.loft("Trouser seat",[(.464,0,.027,.090,.058),(.499,0,.025,.162,.094),
            (.58,0,.029,.242,.162),(.67,0,.033,.249,.164),(.70,0,.03,.240,.151)],"trousers",.002)
    trouser_parts=[seat]
    for side in (-1,1):
        x=.136*side
        leg=[(.131,x,.027,.074,.078),(.154,x,.025,.075,.083),
             (.18,x,.026,.088,.084),(.216,x+.005*side,.027,.095,.094),
             (.243,x+.003*side,.032,.098,.098),(.254,x+.002*side,.033,.090,.092),
             (.272,x-.002*side,.038,.096,.099),(.286,x-.008*side,.042,.091,.105),
             (.31,x-.013*side,.041,.097,.101),(.344,x-.015*side,.029,.095,.109),
             (.384,x-.011*side,.019,.101,.116),(.421,x-.006*side,.038,.106,.121),
             (.493,x-.016*side,.042,.115,.135),(.575,x-.027*side,.026,.118,.132),
             (.65,x-.034*side,.024,.114,.123)]
        trouser_parts.append(a.loft("Folded trouser leg "+str(side),leg,"trousers",.0028,n=48))
        cuffs=[(.171,x,.027,.095,.093),(.173,x,.027,.099,.097),(.182,x,.026,.100,.101),
               (.215,x+.005*side,.028,.102,.103),(.229,x+.006*side,.032,.100,.106),
               (.233,x+.006*side,.033,.096,.101)]
        a.loft("Turned trouser cuff "+str(side),cuffs,"trousers",.0018,n=40)
        seam=[(cx+side*(rx-.002),cy-.016,z) for z,cx,cy,rx,ry in leg if z>.22]
        a.traces("Trouser side seam "+str(side),[seam],"binding",.0018)
        shoe(a,side)
    fuse_sculpt(trouser_parts,"Trouser legs and seat",.0035)


def shoe(a,side):
    # Hand-cut asymmetrical last, full toe box and welt. Rear stations rise to cover the ankle.
    outline=[(0,-.173),(.051,-.171),(.082,-.151),(.095,-.116),(.094,-.077),
             (.083,-.025),(.072,.024),(.071,.077),(.055,.094),(.008,.101),
             (-.048,.094),(-.069,.075),(-.073,.037),(-.069,-.005),
             (-.070,-.062),(-.076,-.106),(-.066,-.146),(-.042,-.166)]
    def world(x,y,z):
        turn=.135
        return (.14*side+side*(x*cos(turn)-y*sin(turn)),.020+x*sin(turn)+y*cos(turn),z)
    def outsole(f,z):
        return [world(x*f*1.105,y*f,z) for x,y in outline]
    a.grid("Boot ground sole "+str(side),[outsole(.94,.000),outsole(.995,.003),outsole(1,.009),outsole(1,.023),
               outsole(.998,.030),outsole(.978,.032)],"sole",sub=2)
    a.traces("Boot welt "+str(side),[outsole(.983,.030)],"shoe",.0028,True)
    rows=[]
    local_rows=[]
    # The apron of the shoe rises into its quarters around one continuous opening.
    # The front edge of the opening travels from the toe toward the ankle.
    for i in range(15):
        t=i/14
        pts=[]
        local=[]
        for x,y in outline:
            dest_x=.069*math.sin(math.atan2(x, -(y+.033)))
            dest_y=.046-.068*math.cos(math.atan2(x, -(y+.033)))
            xnew=(x*1.09)*(1-t)+dest_x*t
            progress=t*t*(3-2*t) if y<-.05 else t
            ynew=(y*.962)*(1-progress)+dest_y*progress
            if t<.11:
                xnew+=.008*sin(pi*t/.11)*x/.09
                ynew+=.009*sin(pi*t/.11)*y/.18
            forward=max(0,min(1,(-y-.014)/.16))
            height=.052*(1-math.exp(-9*t))+.104*t**1.4
            z=.030+(.155*t)*(1-forward)+height*forward
            local.append((xnew,ynew,z))
            pts.append(world(xnew,ynew,z))
        local_rows.append(local)
        rows.append(pts if side==1 else pts[::-1])
    a.grid("Work shoe upper "+str(side),rows,"shoe",sub=2)
    def upper_height(px,py):
        # Sample the underlying hand-cut last so the lacing follows its changing instep.
        heights=[]
        for lower,upper in zip(local_rows,local_rows[1:]):
            for j in range(len(outline)):
                k=(j+1)%len(outline)
                for aa,bb,cc in ((lower[j],lower[k],upper[k]),(lower[j],upper[k],upper[j])):
                    ax,ay,az=aa
                    bx,by,bz=bb
                    cx,cy,cz=cc
                    d=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
                    if abs(d)<1e-9:
                        continue
                    u=((by-cy)*(px-cx)+(cx-bx)*(py-cy))/d
                    v=((cy-ay)*(px-cx)+(ax-cx)*(py-cy))/d
                    w=1-u-v
                    if min(u,v,w)>=-.001:
                        heights.append(u*az+v*bz+w*cz)
        return max(heights,default=.154)
    a.traces("Shoe counter seam "+str(side),[[world(x,y,z) for x,y,z in
              [(side0*.071,-.076,.048),(side0*.078,-.039,.070),(side0*.065,-.003,.101),
               (side0*.061,.034,.139),(side0*.055,.063,.145)]] for side0 in (-1,1)],"lace",.0019)
    # Lace crossings sit on a hand-cut tongue, above the curved instep.
    flap=[]
    for t in (0,.04,.33,.64,.96,1):
        y=-.103+.076*t
        row=[]
        for u in (-1,-.94,-.50,0,.50,.94,1):
            x=u*(.046-.010*t)
            row.append(world(x,y,upper_height(x,y)+.002))
        flap.append(row)
    a.grid("Oxford tongue "+str(side),flap,"shoe",False,False,2,.002)
    crosses=[]
    for k in range(3):
        t=.12+k*.22
        for s in (-1,1):
            def lacepoint(f,q):
                x=q*(.042-.010*f)
                y=-.103+.076*f
                return world(x,y,upper_height(x,y)+.005)
            crosses.append([lacepoint(t,s),lacepoint(t+.08,0),lacepoint(t+.16,-s)])
    a.traces("Waxed shoe laces "+str(side),crosses,"lace",.0029)


def sleeves(a):
    left=[(-.192,.030,1.104,.057,.065),(-.247,.026,1.099,.091,.111),
          (-.270,.022,1.082,.096,.099),(-.308,.015,1.045,.093,.097),
          (-.337,.004,1.001,.091,.090),(-.365,.002,.962,.096,.086),
          (-.385,.012,.939,.092,.083),(-.397,.023,.916,.078,.081),
          (-.401,.037,.897,.080,.077),(-.404,.046,.884,.072,.073)]
    right=[(.193,.026,1.102,.056,.067),(.239,.021,1.102,.093,.102),
           (.270,.010,1.071,.091,.099),(.287,-.002,1.023,.081,.086),
           (.296,-.012,.973,.079,.080),(.315,-.018,.934,.088,.085),
           (.337,-.032,.910,.091,.087),(.362,-.049,.904,.090,.086),
           (.389,-.065,.912,.083,.082),(.414,-.082,.932,.079,.080),
           (.428,-.087,.948,.069,.070)]
    cuffs=[
        [(-.391,.008,.942,.087,.082),(-.392,.012,.939,.096,.090),
         (-.404,.021,.923,.100,.091),(-.409,.027,.913,.096,.091),
         (-.407,.036,.905,.088,.085),(-.404,.039,.901,.086,.084),
         (-.406,.043,.894,.090,.085),(-.407,.050,.881,.086,.081),
         (-.402,.054,.876,.076,.073)],
        [(.383,-.061,.913,.084,.086),(.385,-.063,.915,.093,.095),
         (.395,-.070,.919,.096,.095),(.404,-.080,.926,.093,.092),
         (.408,-.081,.932,.087,.083),(.412,-.085,.936,.091,.089),
         (.425,-.092,.947,.088,.088),(.431,-.096,.951,.082,.080),
         (.430,-.096,.953,.073,.074)]]
    for i,stations in enumerate((left,right)):
        a.sweep("Gathered linen sleeve "+str(i),stations,"shirt",folds=.0018,n=52,cloth=True)
        a.sweep("Double rolled sleeve "+str(i),cuffs[i],"shirt",folds=.0022,n=42)
    # The arms are bare from the rolled cuffs. The bent hand rests behind the apron.
    hidden=[(-.405,.044,.910,.065,.067),(-.401,.056,.879,.065,.066),
            (-.391,.074,.851,.061,.061),(-.365,.094,.821,.055,.057),(-.336,.111,.794,.049,.050),
            (-.300,.129,.766,.041,.043),(-.281,.143,.744,.037,.039),(-.275,.147,.735,.034,.037)]
    open_arm=[(.398,-.080,.928,.061,.064),(.424,-.091,.947,.068,.066),
              (.449,-.103,.963,.061,.059),(.473,-.117,.984,.055,.053),
              (.497,-.128,1.011,.047,.045),(.518,-.139,1.037,.039,.037),
              (.534,-.146,1.051,.034,.034),(.551,-.151,1.060,.033,.031),(.565,-.152,1.064,.029,.025),(.574,-.153,1.066,.017,.015)]
    return [a.sweep("Resting forearm",hidden,"skin",n=32),a.sweep("Welcoming forearm",open_arm,"skin",n=32)]


def fuse_sculpt(objects, name, resolution):
    # Fuse intersecting volumes into one continuous sculpt without an internal seam.
    bpy.ops.object.select_all(action="DESELECT")
    for obj in objects:
        bpy.context.view_layer.objects.active=obj
        for mod in list(obj.modifiers):
            bpy.ops.object.modifier_apply(modifier=mod.name)
        obj.select_set(True)
    bpy.context.view_layer.objects.active=objects[0]
    bpy.ops.object.join()
    obj=bpy.context.object
    obj.name="GEP · "+name
    mod=obj.modifiers.new("Unified hand volume","REMESH")
    mod.mode="VOXEL"
    mod.voxel_size=resolution
    mod.use_smooth_shade=True
    bpy.ops.object.modifier_apply(modifier=mod.name)
    mod=obj.modifiers.new("Hand sculpt polish","SMOOTH")
    mod.factor=.68
    mod.iterations=3
    bpy.ops.object.modifier_apply(modifier=mod.name)
    for p in obj.data.polygons:
        p.use_smooth=True
    obj.select_set(False)


def hands(a,arms):
    origin=Vector((.537,-.146,1.054))
    axis=Vector((.954,-.034,.298)).normalized()
    palm_normal=Vector((-.26,-.56,.80))
    lateral=palm_normal.cross(axis).normalized()
    normal=axis.cross(lateral).normalized()
    def world(x,v,n):
        return origin+axis*(1.21*x)+lateral*(v*(1.1+.32*min(1,x/.056)))+normal*(n*1.12)
    def palm_mesh(label,stations):
        rows=[]
        for x,vc,nc,width,height in stations:
            ring=[]
            for i in range(40):
                t=TAU*i/40
                # Thenar and hypothenar pads frame a shallow, cupped centre.
                pad=(.008*math.exp(-((x-.051)/.026)**2)*max(0,cos(t))+
                     .005*math.exp(-((x-.061)/.038)**2)*max(0,-cos(t)))
                ring.append(world(x,vc+width*cos(t),nc+height*sin(t)+pad*max(0,sin(t))))
            rows.append(ring)
        return a.grid(label,rows,"skin",sub=2)
    palm=palm_mesh("Outstretched palm",[(-.010,0,0,.024,.023),(.018,.002,0,.034,.028),(.041,.006,0,.046,.029),
        (.064,.005,.001,.052,.025),(.086,.001,.002,.050,.023),(.099,-.003,.002,.045,.019),
        (.113,-.005,.004,.032,.013)])
    parts=[arms[1],palm]
    fingers=[(.034,.081,.0130),(.011,.097,.0135),(-.014,.090,.0124),(-.038,.070,.0107)]
    for i,(v,length,radius) in enumerate(fingers):
        stations=[]
        def finger_center(f):
            arch=.023*sin(pi*f*.73)-.012*f*f
            curl=(i-1.1)*.0025*f+.006*max(0,i-1.6)*f*f
            return world(.087+length*f,v*(1+.21*f),.001+arch+curl)
        for f,rs in ((0,1.12),(.16,1.0),(.39,.99),(.53,.88),(.68,.88),(.86,.79),(.96,.65),(1,.18)):
            p=finger_center(f)
            stations.append((*p,radius*1.23*rs,radius*1.06*rs))
        parts.append(a.sweep("Outstretched digit "+str(i),stations,"skin",n=16,ref=tuple(normal)))
        nail=[]
        for f,w,depth in ((.72,.30,.88),(.76,.56,.83),(.84,.65,.81),(.92,.58,.74),(.955,.27,.67)):
            row=[]
            for u in (-1,-.6,0,.6,1):
                row.append(finger_center(f)+lateral*(u*w*radius)-normal*((depth-.18*u*u)*radius))
            nail.append(row)
        a.grid("Natural nail "+str(i),nail,"nail",False,False,2,.00065)
    thumb=[]
    for xyzr in ((.030,.024,.007,.025),(.043,.045,.016,.023),(.044,.065,.031,.018),
                 (.049,.082,.040,.016),(.057,.094,.046,.014),(.065,.100,.045,.012),
                 (.069,.102,.042,.006)):
        p=world(*xyzr[:3])
        thumb.append((*p,xyzr[3]*1.18,xyzr[3]*1.02))
    parts.append(a.sweep("Extended thumb",thumb,"skin",n=20,ref=tuple(normal)))
    fuse_sculpt(parts,"Open hand and forearm · joined sculpt",.0021)
    a.traces("Open palm creases",[[world(.036,.020,.024),world(.051,.012,.029),world(.062,-.012,.025)],
            [world(.068,-.031,.018),world(.074,-.007,.025),world(.079,.015,.024)]],"crease",.0008)
    # Resting palm rests in the hollow behind the hip, fingertips bent toward the back.
    parts=[arms[0],a.sweep("Tucked palm",[
        (-.288,.139,.755,.037,.038),(-.273,.152,.734,.045,.034),(-.264,.160,.713,.049,.030),
        (-.256,.162,.691,.045,.025),(-.251,.163,.680,.035,.022)],"skin",n=30)]
    for i in range(4):
        x=-.280+.019*i
        z=.691+abs(i-1)*.004
        length=.063-abs(i-1)*.008
        parts.append(a.sweep("Tucked finger "+str(i),[(x,.16,z,.013,.014),(x+.003,.166,z-.018,.012,.013),
            (x+.005,.180,z-length*.69,.011,.012),(x+.007,.197,z-length,.010,.012),
            (x+.009,.208,z-length+.003,.006,.008)],"skin",n=16,ref=(1,0,0)))
    parts.append(a.sweep("Tucked thumb",[(-.287,.150,.729,.022,.020),(-.301,.143,.709,.018,.017),
                (-.299,.133,.686,.015,.015),(-.291,.134,.675,.010,.012)],"skin",n=16))
    fuse_sculpt(parts,"Resting hand and forearm · joined sculpt",.0021)


def build_body():
    atelier=Atelier()
    trousers_and_boots(atelier)
    shirt(atelier)
    apron(atelier)
    waistcoat(atelier)
    hands(atelier,sleeves(atelier))
    return atelier.collection
