"""Lay out the native Blender stills alongside the one approved illustration."""
import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

PAPER = '#F5F0E7'
INK = '#202C2A'
MUTED = '#545E55'
GREEN = '#27554B'
LINE = '#CBC9B9'
SANS = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
BOLD = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'


def font(size, bold=False):
    return ImageFont.truetype(BOLD if bold else SANS, size, index=1)


def text(board, xy, value, size, color=INK, bold=False):
    ImageDraw.Draw(board).text(xy,value,font=font(size,bold),fill=color,anchor='lt')


def fill(board, box, color):
    ImageDraw.Draw(board).rectangle(box,fill=color)


def paste(board, image, box, crop=False):
    x,y,w,h=box
    if not isinstance(image,Image.Image):
        image=Image.open(image)
    image=image.convert('RGB')
    if crop:
        # Central crop, only used on the explanatory art crop and lettering-free frames.
        factor=max(w/image.width,h/image.height)
        image=image.resize((round(image.width*factor),round(image.height*factor)),Image.Resampling.LANCZOS)
        l=(image.width-w)//2; t=(image.height-h)//2
        image=image.crop((l,t,l+w,t+h))
    else:
        factor=min(w/image.width,h/image.height)
        image=image.resize((round(image.width*factor),round(image.height*factor)),Image.Resampling.LANCZOS)
    board.paste(image,(x+(w-image.width)//2,y+(h-image.height)//2))


def header(board, title, subtitle):
    text(board,(48,33),'윤수 피노키오   /   S01',22,GREEN,True)
    text(board,(48,79),title,46,INK,True)
    text(board,(50,150),subtitle,22,MUTED)
    fill(board,(48,200,board.width-48,202),LINE)


def foot(board,msg):
    y=board.height-72
    fill(board,(48,y-16,board.width-48,y-15),LINE)
    text(board,(48,y+4),msg,20,MUTED)


def build(root, reference):
    renders=root/'renders'
    art=Image.open(reference).convert('RGB')
    board=Image.new('RGB',(1560,1320),PAPER)
    header(board,'제페토  ·  얼굴과 전신','승인 원화의 표정, 은빛 머리와 낮은 안경, 앞치마를 두 차례의 3D 시안과 비교합니다.')
    for i,(title,small) in enumerate([('승인 원화','CHAR_GEP'),('이전 모델','9830e6b'),('개선 시안','사용자 검토용')]):
        x=48+494*i
        text(board,(x,228),title,31,GREEN if i==2 else INK,True)
        text(board,(x,279),small,18,MUTED)
        if i==0:
            paste(board,art,(x,323,472,512))
            paste(board,art.crop((132,2,345,173)),(x,847,472,365))
        else:
            prefix=['','old','new'][i]
            paste(board,renders/f'{prefix}_quarter.png',(x,323,472,512))
            im=Image.open(renders/f'{prefix}_face.png')
            paste(board,im.crop((35,62,657,717)),(x,847,472,365))
    foot(board,'전신은 동일한 조명·정사영 카메라에서 키를 맞춰 렌더했습니다. 실제 작업실 크기는 별도 배치도에서 검토합니다.')
    board.save(root/'D1_CHAR_COMPARE.png')

    board=Image.new('RGB',(1560,1110),PAPER)
    header(board,'제페토  ·  얼굴 확대','세 이미지에서 이마와 볼의 연결, 눈꺼풀, 콧수염 아래의 미소를 확인할 수 있습니다.')
    for i,title in enumerate(['승인 원화에서 발췌','이전 모델','개선 시안']):
        x=48+i*494
        text(board,(x,234),title,28,GREEN if i==2 else INK,True)
        if i==0:
            paste(board,art.crop((128,1,343,188)),(x,305,472,650))
        else:
            paste(board,renders/('old_face.png' if i==1 else 'new_face.png'),(x,305,472,650))
    foot(board,'원화에는 한 시점만 있습니다. 귀 뒤와 뒷머리의 깊이, 안경다리와 수염의 측면 실루엣은 이번 시안의 해석입니다.')
    board.save(root/'D1_FACE_CLOSEUPS.png')

    board=Image.new('RGB',(1560,1320),PAPER)
    header(board,'제페토  ·  실루엣과 옷의 두께','정면, 3/4, 측면의 같은 카메라 조건에서 몸통과 소매의 부피, 발의 지지를 비교합니다.')
    for col,(view,title) in enumerate([('front','정면'),('quarter','3/4'),('profile','측면')]):
        x=176+col*452
        text(board,(x,226),title,25,INK,True)
        for row,prefix in enumerate(['old','new']):
            paste(board,renders/f'{prefix}_{view}.png',(x,279+467*row,415,454))
    for i,t in enumerate(['이전','개선 시안']):
        text(board,(48,311+467*i),t,24,GREEN,True)
    foot(board,'카메라를 수평으로 0°, 35°, 89° 이동했습니다. 몸의 위치와 조명은 고정했습니다.')
    board.save(root/'D1_GEPPETTO_TURNAROUND.png')

    board=Image.new('RGB',(1300,990),PAPER)
    header(board,'제페토  ·  조명 비교','같은 메시와 노출에서 보조광 중심과 따뜻한 주광 중심의 입체감을 비교합니다.')
    for i,(p,t) in enumerate([('fill_face.png','A   보조광 중심'),('new_face.png','B   창 쪽 주광과 윤곽광')]):
        x=48+610*i
        text(board,(x,228),t,27,INK,True)
        paste(board,renders/p,(x,285,596,590))
    foot(board,'두 컷 모두 같은 스튜디오 HDRI와 Cycles CPU를 사용했습니다.')
    board.save(root/'D1_LIGHTING_A_B.png')


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('root',type=Path);p.add_argument('reference',type=Path)
    a=p.parse_args();build(a.root,a.reference)
