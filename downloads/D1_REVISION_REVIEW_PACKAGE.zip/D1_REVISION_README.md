# S01 D1 수정본 검토

판정은 REVIEW_REQUIRED다. 같은 3D 작업실에서 C06·C07의 정지 상태를 렌더링했고 자동 정적 검증을 수행했다. 캐릭터 외형과 두 포즈의 시각 판정은 사용자가 확인한다.

- 캐릭터 마스터 보드는 승인 원화와 수정한 모델 각도 9장을 비교한다.
- 작업실 배치 보드와 세계 접촉 보드는 동일 메인 카메라의 두 상태와 접촉 확인 카메라의 두 상태를 보여준다. 상판, 바닥, 창·커튼의 외형은 검토용 프록시다.
- Blender의 씬 메뉴에서 C06_STATIC_SLEEP와 C07_STATIC_STAND를 선택한다. 두 씬이 작업실 컬렉션과 카메라를 공유한다. 접촉 카메라만 따로 렌더한 PNG도 제공한다.
- D1_BEFORE_AFTER.md는 항목별 전후 비교와 PASS / FAIL / NOT_RUN 범위를 기록한다. D1_WORLD_QA.log는 새 Blender 프로세스에서 실행한 검증이다.
- 제페토의 발은 같은 자리에서 유지된다. 제페토 손의 기하학적 도달 범위를 확인했고 손뻗기 궤적 검증은 NOT_RUN이다. 피노키오 기상과 D2 리깅은 NOT_RUN이다.

## 재현 명령

작업 브랜치의 저장소 루트에서 Blender 4.3.2, Python 3, Pillow, Noto CJK 글꼴을 사용한다. 환경의 읽기 전용 보관 경로를 사용하고 출력은 매번 새 디렉터리에 둔다.

~~~bash
root=/workspace/scratch/yoonsu-s01-d1
out=$(mktemp -d /tmp/s01-d1-revision.XXXXXX)
export PYTHONDONTWRITEBYTECODE=1
blender -b --factory-startup --disable-autoexec -t 4 --python-exit-code 1 \
  --python production/s01/d1/revise_layout.py -- "$root/locked_source" "$out"
python3 production/s01/d1/build_revision_boards.py "$root/locked_source" "$out"
blender -b --disable-autoexec "$out/D1_LAYOUT_PREVIEW.blend" -t 2 --python-exit-code 1 \
  --python production/s01/d1/verify_revision.py -- "$out/D1_LAYOUT_COORDINATES.json"
~~~

ZIP을 푼 디렉터리에서 D1_REVISION_SHA256SUMS.txt로 각 인계 파일을 검증할 수 있다. Blend에는 승인 배경의 바이트가 패킹되어 있다. 원본 대본과 음원은 인계 ZIP 외부의 잠금 저장소에서 관리한다.
