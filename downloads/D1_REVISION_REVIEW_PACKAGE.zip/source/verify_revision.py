"""Reopen the D1 blend and check its static support geometry and shared world."""

import hashlib
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Vector, geometry
from mathutils.bvhtree import BVHTree

sys.path.insert(0, str(Path(__file__).resolve().parent))
import revise_layout as revision


FAILURES = []


def check(label, result, detail=""):
    print(f"{'PASS' if result else 'FAIL'} {label} {detail}", flush=True)
    if not result:
        FAILURES.append(label)


def level(points, height, tolerance=0.006):
    return abs(min(p.z for p in points) - height) < tolerance


def hit_object_top(obj, x, y, depsgraph):
    inverse = obj.matrix_world.inverted()
    origin = inverse @ Vector((x,y,6))
    direction = inverse.to_3x3() @ Vector((0,0,-1))
    location, *_ = BVHTree.FromObject(obj,depsgraph).ray_cast(origin, direction)
    return None if location is None else (obj.matrix_world @ location).z


def enclosure(points, x, y):
    return min(min(p.x-x[0] for p in points),min(x[1]-p.x for p in points),
               min(p.y-y[0] for p in points),min(y[1]-p.y for p in points))


def support_polygon(points, center):
    outline = [Vector((p.x,p.y)) for p in points]
    hull = geometry.convex_hull_2d(outline)
    start_to_center = []
    for left,right in zip(hull,hull[1:] + hull[:1]):
        a,b = outline[left],outline[right]
        edge = b-a
        offset = center-a
        start_to_center.append(edge.x*offset.y-edge.y*offset.x)
    return min(start_to_center) >= -1e-5 or max(start_to_center) <= 1e-5


def actor(scene, name):
    return next(obj for obj in scene.objects if obj.name.split(".", 1)[0] == name)




data = json.loads(Path(sys.argv[sys.argv.index("--")+1]).read_text())
a,b = [bpy.data.scenes[name] for name in ("C06_STATIC_SLEEP","C07_STATIC_STAND")]
set_name = "S01 • shared physical workshop"
common = a.collection.children[set_name]
check("shared set, camera and no animation on static poses",
      common == b.collection.children[set_name] and a.camera == b.camera
      and all(obj.animation_data is None and obj.type != "ARMATURE" for scene in (a,b) for obj in scene.objects))
check("alternate camera exists in the shared set",
      sum(o.type=="CAMERA" for o in common.objects)==2)
bg = bpy.data.images["APPROVED_BG_WORKSHOP_02"]
check("packed background SHA-256",
      bool(bg.packed_file) and hashlib.sha256(bg.packed_file.data).hexdigest()==revision.base.BACKGROUND_SHA)
top = common.objects["WORKTOP_SUPPORT"]
table = data["tabletop"]
scales = []
for pose,scene in (("C06",a),("C07",b)):
    bpy.context.window.scene = scene
    scene.frame_set(1)
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    pin,gep = actor(scene,"PIN_ROOT"),actor(scene,"GEP_ROOT")
    scales.append(tuple(obj.evaluated_get(depsgraph).matrix_world.to_scale() for obj in (pin,gep)))
    pin_parts = revision.instance_mesh_points(pin,depsgraph)
    gep_parts = revision.instance_mesh_points(gep,depsgraph)
    points = [p for mesh in pin_parts.values() for p in mesh]
    space = enclosure(points, *[table[k] for k in ("x","y")])
    check(f"{pose} complete static Pinocchio footprint inside worktop",
          space>=.075, f"min clearance {space:.4f}")
    checked_gap = abs(pin.location.y-gep.location.y)
    check(f"{pose} depth gap", checked_gap<1.25 and abs(checked_gap-data["states"][pose]["depth_gap"])<1e-5,
          f"{checked_gap:.4f} vs prior {data['previous_depth_gap']:.4f}")
    gep_soles = [name for name in gep_parts if "boot sole" in name]
    for sole in gep_soles:
        corners = gep_parts[sole]
        contacts = [p for p in corners if abs(p.z)<.004]
        hits = 0
        for contact in contacts:
            cast = scene.ray_cast(depsgraph,Vector((contact.x,contact.y,-.22)),Vector((0,0,1)),distance=.225)
            if cast[0] and cast[4].name.startswith("FLOOR_PLANK"):
                surface = hit_object_top(cast[4],contact.x,contact.y,depsgraph)
                hits += surface is not None and abs(surface-contact.z)<.006
        check(f"{pose} {sole} meets physical floor", level(corners,0) and hits>=3,
              f"{hits} supported sole vertices")
    check(f"{pose} floor evidence covers two soles", len(gep_soles)==2)
    state = data["states"][pose]
    shoulder = Vector(state["gep_shoulder"])
    target = min((p for p in points if p.z>1.49),key=lambda p:(p-shoulder).length)
    reach_distance = (target-shoulder).length
    check(f"{pose} reach envelope", reach_distance <= state["reach_limit"] and
          abs(reach_distance-state["shoulder_target_distance"])<1e-4,
          f"{reach_distance:.4f} / {state['reach_limit']:.4f}; static geometry only")
    check(f"{pose} clearance ahead of tools", max(p.y for p in points) <
          min(prop["near_y"] for prop in data["props"])-.12)

    if pose=="C06":
        for name, xyz in state["sleep_contact_points"].items():
            x,y,z = xyz
            support = scene.objects[f"SUPPORT_{name}"]
            surface = hit_object_top(support,x,y,depsgraph)
            wood = hit_object_top(top,x,y,depsgraph)
            check(f"C06 {name} support", surface is not None and wood is not None
                  and abs(surface-z)<.006 and abs(wood-table["z"])<.006
                  and min((p-Vector(xyz)).length for p in points)<.002,
                  f"cloth Z {surface}, tabletop Z {wood}")
        check("C06 whole figure stays above wood", min(p.z for p in points)>table["z"]+.025)
        check("C06 eyes closed and two eyelid shapes",
              sum("closed eyelid volume" in obj.name for obj in pin.instance_collection.objects)==2
              and not any("Ivory oval eye" in obj.name for obj in pin.instance_collection.objects))
    else:
        soles = [name for name in pin_parts if "boot / outsole" in name]
        polygon = []
        for sole in soles:
            sole_pts = pin_parts[sole]
            contact = min(sole_pts,key=lambda p:p.z)
            wood = hit_object_top(top,contact.x,contact.y,depsgraph)
            polygon.extend(p for p in sole_pts if abs(p.z-table["z"])<.009)
            check(f"C07 {sole} meets physical worktop",
                  level(sole_pts,table["z"]) and wood is not None and abs(wood-contact.z)<.006)
        check("C07 two soles and vertical hip projection within their static footprint",
              len(soles)==2 and len(polygon)>=6 and support_polygon(polygon,Vector(pin.location.xy)))
        check("C07 no mesh penetrates worktop", min(p.z for p in points)>=table["z"]-.006)
        for side in ("Right","Left"):
            names = [o.name for o in pin.instance_collection.objects if f"{side} hand /" in o.name]
            check(f"C05 structural digit inventory {side}", all(
                any(f"/ {digit} {part}" in name for name in names)
                for digit in ("thumb","index","middle","ring","little")
                for part in ("proximal","distal")))

check("both characters have fixed scale across static poses",
      all((x-y).length<1e-6 for x,y in zip(*scales)))
check("Geppetto expression changes from observation to raised brows and open mouth",
      any("smiling mouth volume" in o.name for o in actor(a,"GEP_ROOT").instance_collection.objects)
      and any("surprised open mouth" in o.name for o in actor(b,"GEP_ROOT").instance_collection.objects)
      and not any("smiling mouth volume" in o.name for o in actor(b,"GEP_ROOT").instance_collection.objects))
check("Geppetto feet root fixed across poses",
      (actor(a,"GEP_ROOT").location-actor(b,"GEP_ROOT").location).length<1e-6)

fairy = actor(b,"FAI_WINDOW_POSE")
points = [p for mesh in revision.instance_mesh_points(fairy,bpy.context.evaluated_depsgraph_get()).values() for p in mesh]
opening = data["window_opening"]
xmin,xmax = opening["x"]
zmin,zmax = opening["z"]
spring = opening["spring_z"]
center = (xmin+xmax)/2
radius = (xmax-xmin)/2
trim = .035
limits = [(p.x, p.z) for p in points]
def inside_arch(x,z):
    ratio = (x-center)/(radius-trim)
    return abs(ratio)<1 and zmin+trim<z<spring+(zmax-spring-trim)*math.sqrt(1-ratio**2)

check("fairy geometry envelope fits physical open arch with 0.035 margin",
      all(inside_arch(x,z) for x,z in limits)
      and min(p[1] for p in data["fairy_entry_path"])<opening["y"]<max(p[1] for p in data["fairy_entry_path"]))
def obstacle_bvh(collection, depsgraph):
    vertices, faces = [], []
    for obj in collection.objects:
        if not obj.name.startswith(("WINDOW_", "CURTAIN_")):
            continue
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        offset = len(vertices)
        vertices.extend(evaluated.matrix_world @ v.co for v in mesh.vertices)
        faces.extend(tuple(offset+i for i in poly.vertices) for poly in mesh.polygons)
        evaluated.to_mesh_clear()
    return BVHTree.FromPolygons(vertices,faces)


obstacles = obstacle_bvh(common,bpy.context.evaluated_depsgraph_get())
path = data["fairy_entry_path"]
travel = path[0][1]-path[-1][1]
sweep_direction = Vector((0,1,0))
collisions = sum(obstacles.ray_cast(p,sweep_direction,travel)[0] is not None for p in points)
check("fairy mesh vertex sweep past actual frame and curtain meshes",
      collisions == 0, f"{len(points)} vertices over {travel:.3f} units, {collisions} hits")
check("curtain and real tool objects exist",
      sum(o.name.startswith("CURTAIN_PANEL_FOLD") for o in common.objects)==10
      and common.objects.get("TOOL_MALLET_HEAD") is not None)

# Same horizontal ray from opposite ends tests which real surface is in front.
bpy.context.window.scene = a
context = bpy.context.evaluated_depsgraph_get()
overlap = None
for xi in range(19):
    for zi in range(10):
        x,z = -2.52+xi*.024, 1.367+zi*.019
        near = a.ray_cast(context, Vector((x,-.36,z)),Vector((0,1,0)),distance=1.7)
        far = a.ray_cast(context, Vector((x,1.48,z)),Vector((0,-1,0)),distance=1.7)
        if near[0] and far[0] and near[4].name.startswith("PIN |") and far[4].name.startswith("TOOL_MALLET"):
            overlap = (x,z,near[4].name,far[4].name)
            break
    if overlap:
        break
check("tool/character real ray ordering from two sides", overlap is not None, str(overlap))
print("NOT_RUN dynamic C05 bend, full reach/contact motion, C07 wake-up, C06-C07 moving camera, D2 rig, mobile download on device")
if FAILURES:
    raise SystemExit(f"{len(FAILURES)} failed checks: {', '.join(FAILURES)}")
