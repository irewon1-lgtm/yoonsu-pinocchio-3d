"""D1 full-volume Pinocchio silhouette and material proposal."""


_CIRCLE = (
    (1.0, 0.0), (.966, .259), (.866, .5), (.707, .707),
    (.5, .866), (.259, .966), (0.0, 1.0), (-.259, .966),
    (-.5, .866), (-.707, .707), (-.866, .5), (-.966, .259),
    (-1.0, 0.0), (-.966, -.259), (-.866, -.5), (-.707, -.707),
    (-.5, -.866), (-.259, -.966), (0.0, -1.0), (.259, -.966),
    (.5, -.866), (.707, -.707), (.866, -.5), (.966, -.259),
)


def _ring_mesh(api, name, rings, material, slope=(0.0, 0.0), height_offset=None):
    vertices = []
    for x, y, z, radius_x, radius_y in rings:
        for u, v in _CIRCLE:
            dx, dy = u * radius_x, v * radius_y
            height = z + dx * slope[0] + dy * slope[1]
            if height_offset is not None:
                height += height_offset(dx, dy)
            vertices.append((x + dx, y + dy, height))
    size = len(_CIRCLE)
    faces = [tuple(reversed(range(size)))]
    for index in range(len(rings) - 1):
        first = index * size
        for j in range(size):
            k = (j + 1) % size
            faces.append((first + j, first + k, first + size + k, first + size + j))
    faces.append(tuple(range(len(vertices) - size, len(vertices))))
    return api.mesh(name, vertices, faces, material, smooth=True)


def _panel(api, name, outline, material, depth=.008):
    vertices = list(outline) + [(x, y + depth, z) for x, y, z in outline]
    size = len(outline)
    faces = [tuple(range(size)), tuple(reversed(range(size, 2 * size)))]
    for j in range(size):
        k = (j + 1) % size
        faces.append((j, size + j, size + k, k))
    return api.mesh(name, vertices, faces, material)


def _brim_curve(x, y):
    return .28 * x * x - .13 * y * y + .24 * x * y - .029


def build(api):
    mat, ell, link, tube, capsule = api.mat, api.ell, api.link, api.tube, api.capsule
    wood = mat("PIN | Honey maple", "#EABA74", .60)
    maple = mat("PIN | Maple end grain", "#B9743E", .71)
    grain = mat("PIN | Wood grain", "#C68A50", .74)
    nose = mat("PIN | Amber carved nose", "#E5994F", .58)
    ear = mat("PIN | Ear and cheek warmth", "#DE945D", .68)
    blush = mat("PIN | Warm cheek finish", "#EFB47A", .67)
    hair_dark = mat("PIN | Chestnut hair shadow", "#46291C", .69)
    hair = mat("PIN | Chestnut hair", "#66422B", .65)
    hair_light = mat("PIN | Chestnut ridges", "#8B603C", .73)
    felt = mat("PIN | Rust-red felt hat", "#B74D32", .83)
    felt_edge = mat("PIN | Hat binding", "#D26E4B", .82)
    hat_band = mat("PIN | Terracotta hat band", "#80382A", .78)
    feather = mat("PIN | Golden feather", "#DAA04F", .74)
    vane = mat("PIN | Feather vane face", "#E9BD72", .73)
    quill = mat("PIN | Feather shaft", "#F4D48D", .67)
    linen = mat("PIN | Unbleached linen", "#F1D6AB", .87)
    cuff_mat = mat("PIN | Cream rolled cuff", "#FBE6BC", .86)
    linen_seam = mat("PIN | linen stitching", "#CCA779", .86)
    denim = mat("PIN | Deep teal shorts", "#315755", .83)
    denim_edge = mat("PIN | Teal seam binding", "#3C6661", .84)
    denim_stitch = mat("PIN | Teal stitching", "#739087", .86)
    button = mat("PIN | Brass fasteners", "#D99A43", .45, .20)
    button_center = mat("PIN | Brass fastener centers", "#EEB85A", .48, .16)
    bow = mat("PIN | Vermilion bow", "#B83F2F", .72)
    bow_light = mat("PIN | Bow knot", "#D2533D", .68)
    bow_fold = mat("PIN | Bow folds", "#802B24", .76)
    leather = mat("PIN | Chestnut boot leather", "#855137", .72)
    leather_light = mat("PIN | Boot cuff leather", "#A16743", .72)
    sole = mat("PIN | Boot soles", "#523523", .88)
    welt = mat("PIN | Boot welt stitching", "#C69760", .81)
    sclera = mat("PIN | Eye ivory", "#FFF4DD", .38)
    iris = mat("PIN | Umber irises", "#68391D", .39)
    pupil = mat("PIN | Pupils", "#281712", .31)
    eye_shine = mat("PIN | Eye catchlights", "#FFFDF1", .28)
    mouth = mat("PIN | Mouth cavity", "#6C2B21", .73)
    tongue = mat("PIN | Tongue", "#D4785D", .61)

    # Short boot shafts, molded toe caps and visible welt edges.
    for side in (-1, 1):
        anatomical_side = "Right" if side < 0 else "Left"
        boot_name = f"PIN | {anatomical_side} boot"
        leg_name = f"PIN | {anatomical_side} leg"
        foot_x = side * .235
        toe_x = foot_x + side * .042
        turn = (0.0, 0.0, side * .21)
        ell(boot_name + " / outsole", (toe_x, -.105, .061), (.170, .287, .061), sole, turn)
        ell(boot_name + " / vamp", (toe_x, -.098, .122), (.166, .267, .107), leather, turn)
        ell(boot_name + " / toe box", (toe_x + side * .021, -.209, .126),
            (.151, .166, .106), leather, turn)
        ell(boot_name + " / shaft", (foot_x, .045, .176), (.137, .157, .143), leather)
        _ring_mesh(api, boot_name + " / cuff", [
            (foot_x, .049, .212, .127, .132), (foot_x, .051, .231, .148, .143),
            (foot_x, .046, .277, .154, .149), (foot_x, .044, .288, .145, .141),
            (foot_x, .043, .284, .126, .122),
        ], leather_light, (side * .09, .12))
        tube(boot_name + " / toe seam", [
            (toe_x - .112, -.225, .142), (toe_x - .092, -.255, .181),
            (toe_x, -.280, .213), (toe_x + .092, -.254, .181),
            (toe_x + .122, -.202, .134),
        ], .005, leather_light)
        tube(boot_name + " / welt", [
            (toe_x - .136, -.194, .087), (toe_x - .100, -.314, .079),
            (toe_x, -.366, .074), (toe_x + .101, -.325, .078),
            (toe_x + .148, -.206, .087),
        ], .005, welt)

        ankle = (foot_x, .046, .260)
        knee = (side * .172, -.016, .625)
        thigh = (side * .133, .006, 1.036)
        link(leg_name + " / shin", ankle, knee, .069, .078, wood)
        link(leg_name + " / thigh", knee, thigh, .088, .104, wood)
        ell(leg_name + " / knee joint", knee, (.092, .082, .091), wood)
        ell(leg_name + " / knee hinge ring", (knee[0], -.089, knee[2]), (.063, .018, .063), maple)
        ell(leg_name + " / knee inlay", (knee[0], -.104, knee[2]), (.046, .012, .046), wood)
        ell(leg_name + " / knee pin", (knee[0], -.115, knee[2]), (.016, .007, .016), maple)
        for grain_index, offset in enumerate((-.032, .035), start=1):
            tube(f"{leg_name} / shin grain {grain_index}", [
                (ankle[0] + offset, -.008, .316),
                ((ankle[0] + knee[0]) * .5 + offset + side * .005, -.053, .425),
                (knee[0] + offset, -.076, .545),
            ], .003, grain)

        cuff_x = side * .163
        _ring_mesh(api, "PIN | Full teal shorts leg", [
            (cuff_x, .020, .866, .152, .164),
            (cuff_x, .021, .900, .161, .171),
            (side * .155, .014, 1.015, .155, .177),
            (side * .142, .008, 1.119, .165, .184),
            (side * .125, .002, 1.168, .169, .173),
        ], denim, (side * .19, .04))
        _ring_mesh(api, "PIN | Shorts hem binding", [
            (cuff_x, .020, .871, .153, .167),
            (cuff_x, .021, .887, .159, .172),
            (cuff_x, .021, .902, .162, .173),
        ], denim_edge, (side * .19, .04))
        tube("PIN | Outseam topstitch", [
            (side * .290, -.066, 1.143), (side * .296, -.079, 1.037),
            (side * .307, -.057, .924),
        ], .004, denim_stitch)

    _ring_mesh(api, "PIN | Gathered shorts waist", [
        (0, .015, 1.032, .247, .166), (0, .018, 1.090, .311, .182),
        (0, .008, 1.200, .270, .187), (0, -.006, 1.273, .237, .161),
    ], denim)
    _ring_mesh(api, "PIN | linen shirt body", [
        (0, .001, 1.192, .195, .133), (0, .008, 1.239, .229, .160),
        (0, .011, 1.375, .222, .141), (0, .012, 1.522, .246, .143),
        (0, .016, 1.599, .215, .132), (0, .017, 1.645, .102, .089),
    ], linen)
    _ring_mesh(api, "PIN | Teal waistband", [
        (0, .001, 1.185, .257, .190), (0, .001, 1.218, .258, .189),
        (0, -.005, 1.262, .239, .169), (0, -.007, 1.277, .228, .162),
    ], denim_edge)
    _panel(api, "PIN | Teal bib", [
        (-.150, -.169, 1.211), (-.150, -.163, 1.373), (-.112, -.160, 1.447),
        (.115, -.160, 1.447), (.153, -.164, 1.369), (.152, -.172, 1.211),
    ], denim, .042)
    tube("PIN | Shirt button placket", [(.000, -.143, 1.407), (.001, -.146, 1.479),
         (.002, -.135, 1.556)], .018, cuff_mat)
    for side in (-1, 1):
        tube("PIN | Suspender", [
            (side * .141, -.169, 1.268), (side * .125, -.155, 1.405),
            (side * .118, -.139, 1.544), (side * .111, -.105, 1.610),
            (side * .108, -.022, 1.632), (side * .104, .080, 1.615),
            (side * .089, .132, 1.489), (side * .064, .150, 1.320),
        ], .037, denim)
        tube("PIN | Bib topstitch", [
            (side * .132, -.174, 1.296), (side * .130, -.175, 1.352),
            (side * .109, -.173, 1.423),
        ], .0035, denim_stitch)
        ell("PIN | Brass suspender button", (side * .142, -.201, 1.278),
            (.037, .014, .038), button)
        ell("PIN | Brass stamped center", (side * .142, -.213, 1.278),
            (.023, .006, .023), button_center)
        _panel(api, "PIN | Folded linen collar", [
            (side * .034, -.115, 1.646), (side * .116, -.118, 1.637),
            (side * .148, -.145, 1.590), (side * .106, -.171, 1.539),
            (side * .028, -.173, 1.603),
        ], cuff_mat, .024)

    for index, side in enumerate((-1, 1)):
        anatomical_side = "Right" if side < 0 else "Left"
        upper_name = f"PIN | {anatomical_side} upper arm"
        fore_name = f"PIN | {anatomical_side} forearm"
        hand_name = f"PIN | {anatomical_side} hand"
        shoulder_z = 1.531 + index * .025
        elbow_z = 1.405 + index * .102
        wrist_z = 1.399 + index * .180
        shoulder = (side * .208, .015, shoulder_z)
        elbow = (side * .611, -.008, elbow_z)
        wrist = (side * .946, -.073, wrist_z)
        sleeve_end = (side * .460, .004, shoulder_z - .061 + index * .025)
        link(upper_name + " / wood", shoulder, elbow, .067, .055, wood)
        link(fore_name + " / wood", elbow, wrist, .060, .041, wood)
        capsule(upper_name + " / shirt sleeve", shoulder, sleeve_end, .119, linen)
        sleeve_in = (sleeve_end[0] - side * .029, sleeve_end[1], sleeve_end[2] + .007)
        sleeve_out = (sleeve_end[0] + side * .056, sleeve_end[1], sleeve_end[2] - .009)
        link(upper_name + " / rolled cuff", sleeve_in, sleeve_out, .111, .101, cuff_mat)
        cuff_line = (sleeve_out[0] - side * .028, sleeve_out[1], sleeve_out[2] + .006)
        link(upper_name + " / cuff edge", cuff_line, sleeve_out, .106, .102, linen)
        for fold_index, (y, z) in enumerate(((-.083, -.037), (-.106, .017), (-.082, .065)), start=1):
            tube(f"{upper_name} / sleeve gathering {fold_index}", [
                (shoulder[0] + side * .067, y + .030, shoulder[2] + z),
                (shoulder[0] + side * .145, y, shoulder[2] + z - .029),
                (sleeve_in[0], y + .012, sleeve_in[2] + z),
            ], .005, linen_seam)

        ell(fore_name + " / elbow joint", elbow, (.065, .063, .068), wood)
        for joint_name, point, radius in ((fore_name + " / elbow", elbow, .041),
                                          (hand_name + " / wrist", wrist, .031)):
            ell(joint_name + " hinge ring", (point[0], point[1] - .052, point[2]),
                (radius, .015, radius), maple)
            ell(joint_name + " hinge center", (point[0], point[1] - .063, point[2] + .001),
                (radius * .65, .009, radius * .66), wood)
            ell(joint_name + " hinge pin", (point[0], point[1] - .072, point[2] + .001),
                (.009, .004, .009), maple)
        for grain_index, offset in enumerate((-.018, .020), start=1):
            tube(f"{fore_name} / wood grain {grain_index}", [
                (elbow[0] + side * .073, -.066, elbow_z + offset),
                (elbow[0] + side * .168, -.078, (elbow_z + wrist_z) * .5 + offset + .006),
                (wrist[0] - side * .049, -.107, wrist_z + offset),
            ], .0035, grain)

        palm = (wrist[0] + side * .082, -.094, wrist_z - .030)
        ell(hand_name + " / palm", palm, (.100, .042, .073), wood, (0, side * .22, 0))
        for digit, length, height, tip_rise in (
            ("index", .112, .027, .021),
            ("middle", .139, .002, .013),
            ("ring", .123, -.025, .003),
            ("little", .095, -.049, -.006),
        ):
            digit_name = f"{hand_name} / {digit}"
            root = (palm[0] + side * .052, -.099, palm[2] + height)
            knuckle = (root[0] + side * length * .59, -.108, root[2] + tip_rise * .42)
            tip = (root[0] + side * length, -.123, root[2] + tip_rise)
            thickness = .014 if digit == "little" else .016
            capsule(digit_name + " proximal", root, knuckle, thickness, wood)
            capsule(digit_name + " distal", knuckle, tip, thickness * .88, wood)
            tube(digit_name + " hinge crease", [
                (knuckle[0], -.121, knuckle[2] - .010),
                (knuckle[0] + side * .004, -.124, knuckle[2]),
                (knuckle[0], -.121, knuckle[2] + .010),
            ], .0024, grain)

        thumb_root = (palm[0] - side * .028, -.110, palm[2] + .011)
        thumb_joint = (palm[0] - side * .008, -.113, palm[2] + .071)
        thumb_tip = (palm[0] - side * .038, -.105, palm[2] + .125)
        capsule(hand_name + " / thumb proximal", thumb_root, thumb_joint, .028, wood)
        capsule(hand_name + " / thumb distal", thumb_joint, thumb_tip, .022, wood)
        tube(hand_name + " / thumb hinge crease", [
            (thumb_joint[0] - .010, -.132, thumb_joint[2] - .002),
            (thumb_joint[0], -.135, thumb_joint[2] + .002),
            (thumb_joint[0] + .010, -.132, thumb_joint[2] + .004),
        ], .0025, grain)
        tube(hand_name + " / palm crease", [
            (palm[0] - side * .052, -.128, palm[2] - .023),
            (palm[0] - side * .006, -.139, palm[2] - .014),
            (palm[0] + side * .016, -.136, palm[2] + .025),
        ], .0035, grain)

    link("PIN | Neck post", (0, .026, 1.596), (0, .023, 1.847), .066, .073, wood)
    _ring_mesh(api, "PIN | Neck seam", [
        (0, .025, 1.653, .069, .067), (0, .025, 1.664, .070, .069),
    ], maple)
    for side in (-1, 1):
        ell("PIN | Wide red bow loop", (side * .107, -.187, 1.578),
            (.105, .052, .099), bow, (0, side * -.39, 0))
        tube("PIN | Bow pinch crease", [
            (side * .026, -.230, 1.572), (side * .077, -.237, 1.589),
            (side * .106, -.231, 1.619),
        ], .007, bow_fold)
        tube("PIN | Bow lower crease", [
            (side * .026, -.230, 1.566), (side * .072, -.237, 1.557),
            (side * .102, -.232, 1.548),
        ], .005, bow_fold)
    ell("PIN | Bow knot", (0, -.228, 1.576), (.057, .043, .059), bow_light)
    for z in (1.458, 1.510):
        ell("PIN | Shirt button", (0, -.166, z), (.013, .009, .015), button_center)

    # Soft carved head with a wide temple, full cheeks and a tapered jaw.
    _ring_mesh(api, "PIN | Carved maple head", [
        (0, -.027, 1.752, .057, .058), (0, -.043, 1.783, .137, .106),
        (.002, -.047, 1.835, .222, .165), (.004, -.034, 1.908, .287, .220),
        (.007, -.021, 1.988, .324, .251), (.004, -.008, 2.080, .323, .271),
        (0, .010, 2.169, .317, .277), (-.006, .022, 2.256, .293, .264),
        (-.013, .032, 2.329, .237, .214), (-.017, .036, 2.383, .143, .139),
        (-.019, .033, 2.409, .049, .055),
    ], wood)
    ell("PIN | Head / Carved crown of hair", (-.019, .067, 2.292), (.305, .243, .186), hair_dark)
    ell("PIN | Head / Rounded hair at nape", (-.014, .140, 2.088), (.303, .196, .266), hair)
    for side in (-1, 1):
        ell("PIN | Head / Carved ear", (side * .304, -.003, 1.958),
            (.087, .059, .100), wood, (0, side * -.29, 0))
        ell("PIN | Head / Ear bowl", (side * .328, -.052, 1.962), (.055, .020, .065), ear)
        tube("PIN | Head / Ear fold", [
            (side * .360, -.066, 1.947), (side * .346, -.071, 1.985),
            (side * .321, -.072, 1.983), (side * .310, -.070, 1.954),
        ], .009, nose)
        ell("PIN | Head / Sculpted side hair", (side * .267, .045, 2.123),
            (.081, .157, .207), hair)
        capsule("PIN | Head / Tapered sideburn", (side * .273, -.105, 2.167),
                (side * .278, -.114, 2.017), .044, hair_dark)
        tube("PIN | Head / Side hair grain", [
            (side * .253, -.106, 2.344), (side * .299, -.095, 2.242),
            (side * .300, -.104, 2.111), (side * .282, -.111, 2.066),
        ], .007, hair_light)
        for index in range(3):
            x = side * (.110 + index * .058)
            capsule("PIN | Head / Small carved nape curl", (x, .180, 1.960),
                    (x + side * .058, .205, 1.850 + index * .022), .039, hair_dark)
        ell("PIN | Head / Warm carved cheek", (side * .191, -.222, 1.989),
            (.082, .016, .049), blush, (0, side * .07, side * -.52))

        eye_x = side * .117
        ell("PIN | Head / Eye socket rim", (eye_x, -.241, 2.132), (.082, .028, .092),
            ear, (0, side * .10, side * -.24))
        ell("PIN | Head / Ivory oval eye", (eye_x, -.255, 2.136), (.072, .035, .080),
            sclera, (0, side * .10, side * -.21))
        ell("PIN | Head / Brown iris", (eye_x + .010, -.286, 2.140), (.041, .014, .056), iris)
        ell("PIN | Head / Deep pupil", (eye_x + .011, -.297, 2.141), (.028, .009, .043), pupil)
        ell("PIN | Head / Eye main gleam", (eye_x + .001, -.306, 2.163), (.012, .004, .015), eye_shine)
        ell("PIN | Head / Eye lower gleam", (eye_x + .025, -.305, 2.120), (.006, .004, .007), eye_shine)
        tube("PIN | Head / Upper eyelid", [
            (eye_x - .070, -.257, 2.145), (eye_x - .049, -.275, 2.190),
            (eye_x + .001, -.281, 2.213), (eye_x + .046, -.268, 2.191),
            (eye_x + .066, -.253, 2.154),
        ], .007, hair_dark)
        tube("PIN | Head / Curved eyebrow", [
            (eye_x - .057, -.228, 2.245 + (.007 if side < 0 else 0)),
            (eye_x - .023, -.242, 2.268 + (.007 if side < 0 else 0)),
            (eye_x + .013, -.242, 2.273),
            (eye_x + .055, -.223, 2.255),
        ], .014, hair_dark)

    for index, (x, z, length, lean) in enumerate((
        (-.205, 2.317, .180, -.44), (-.143, 2.352, .201, -.55),
        (-.066, 2.365, .171, -.48), (.017, 2.366, .143, -.34),
        (.099, 2.361, .118, -.16), (.174, 2.335, .142, .59),
        (.218, 2.281, .135, .46),
    )):
        ell("PIN | Head / Swept chestnut fringe", (x, -.174 - (.023 if index < 5 else 0), z),
            (.061, .076, length * .59), hair, (0, lean, 0))
        tube("PIN | Head / Carved fringe ridge", [
            (x - lean * .052, -.215, z + length * .39),
            (x, -.244 if index < 5 else -.224, z + .013),
            (x + lean * .078, -.217, z - length * .42),
        ], .007, hair_light)

    ell("PIN | Head / Nose root", (.005, -.264, 2.074), (.066, .039, .052), wood)
    nose_base = (.018, -.269, 2.068)
    nose_tip = (.064, -.502, 2.157)
    link("PIN | Head / Signature carved nose", nose_base, nose_tip, .056, .041, nose)
    ell("PIN | Head / Rounded amber nose tip", nose_tip, (.043, .046, .043), nose)
    tube("PIN | Head / Single shallow nose grain", [
        (.062, -.313, 2.113), (.081, -.393, 2.141), (.093, -.471, 2.172),
    ], .004, grain)

    _panel(api, "PIN | Head / Open smile", [
        (-.123, -.245, 1.995), (-.079, -.266, 1.978), (-.019, -.279, 1.969),
        (.047, -.277, 1.979), (.117, -.247, 2.004), (.102, -.253, 1.951),
        (.063, -.258, 1.912), (.019, -.263, 1.887), (-.029, -.262, 1.889),
        (-.075, -.255, 1.920), (-.105, -.251, 1.959),
    ], mouth, .022)
    _panel(api, "PIN | Head / Smile upper teeth", [
        (-.099, -.261, 1.984), (-.049, -.277, 1.973), (.000, -.282, 1.969),
        (.056, -.275, 1.980), (.101, -.259, 1.993), (.072, -.273, 1.963),
        (.024, -.282, 1.953), (-.026, -.282, 1.953), (-.071, -.272, 1.965),
    ], sclera)
    ell("PIN | Head / Smile tongue", (.008, -.257, 1.913), (.053, .016, .022), tongue,
        (0, -.08, 0))
    tube("PIN | Head / Carved lower lip", [
        (-.120, -.244, 1.993), (-.096, -.253, 1.949), (-.053, -.258, 1.907),
        (-.006, -.268, 1.889), (.044, -.263, 1.902), (.094, -.253, 1.951),
        (.117, -.246, 2.003),
    ], .005, ear)

    # Slanted felt brim and soft, drooping crown.
    hat_tilt = (.220, -.085)
    _ring_mesh(api, "PIN | Head / Round slanted hat brim", [
        (-.036, .009, 2.383, .319, .284), (-.040, .005, 2.366, .427, .335),
        (-.042, .002, 2.374, .465, .354), (-.044, .000, 2.405, .462, .349),
        (-.050, .001, 2.409, .422, .327), (-.052, .013, 2.412, .322, .265),
    ], felt, hat_tilt, _brim_curve)
    ring = [(-.043 + u * .463, .003 + v * .350,
             2.399 + u * .463 * hat_tilt[0] + v * .350 * hat_tilt[1]
             + _brim_curve(u * .463, v * .350)) for u, v in _CIRCLE]
    tube("PIN | Head / Felt brim piping", ring, .010, felt_edge, cyclic=True)
    _ring_mesh(api, "PIN | Head / Sloped felt crown", [
        (-.048, .023, 2.399, .345, .281), (-.066, .045, 2.460, .335, .258),
        (-.111, .069, 2.549, .314, .232), (-.163, .085, 2.607, .250, .188),
        (-.229, .112, 2.642, .168, .139), (-.282, .119, 2.644, .099, .093),
        (-.330, .122, 2.628, .053, .059), (-.360, .122, 2.604, .022, .030),
        (-.365, .120, 2.594, .009, .013),
    ], felt, hat_tilt)
    _ring_mesh(api, "PIN | Head / Dark felt hatband", [
        (-.048, .022, 2.413, .352, .286), (-.059, .034, 2.434, .350, .280),
        (-.068, .041, 2.473, .338, .260),
    ], hat_band, hat_tilt)

    feather_outline = [
        (-.301, -.200, 2.415), (-.352, -.211, 2.492), (-.455, -.212, 2.528),
        (-.541, -.213, 2.582), (-.560, -.214, 2.608), (-.511, -.217, 2.615),
        (-.584, -.218, 2.642), (-.632, -.221, 2.708), (-.580, -.226, 2.713),
        (-.505, -.226, 2.702), (-.529, -.225, 2.731), (-.456, -.224, 2.714),
        (-.418, -.220, 2.674), (-.394, -.219, 2.682), (-.351, -.214, 2.625),
        (-.319, -.207, 2.534),
    ]
    _panel(api, "PIN | Head / Notched feather silhouette", feather_outline, feather, .029)
    _panel(api, "PIN | Head / Lit feather vane", [
        (-.315, -.213, 2.459), (-.375, -.230, 2.562), (-.459, -.237, 2.632),
        (-.623, -.226, 2.706), (-.523, -.232, 2.705), (-.456, -.232, 2.711),
        (-.418, -.232, 2.671), (-.386, -.227, 2.663), (-.349, -.223, 2.606),
    ], vane)
    tube("PIN | Head / Feather quill", [
        (-.287, -.212, 2.423), (-.347, -.224, 2.528), (-.441, -.235, 2.618),
        (-.547, -.236, 2.680), (-.620, -.232, 2.707),
    ], .008, quill)
    for points in (
        [(-.340, -.227, 2.522), (-.342, -.232, 2.556), (-.360, -.229, 2.598)],
        [(-.382, -.235, 2.568), (-.386, -.235, 2.620), (-.414, -.235, 2.670)],
        [(-.428, -.240, 2.608), (-.445, -.241, 2.654), (-.477, -.239, 2.700)],
        [(-.388, -.234, 2.569), (-.455, -.233, 2.560), (-.503, -.225, 2.572)],
        [(-.449, -.240, 2.622), (-.498, -.236, 2.605), (-.549, -.231, 2.608)],
        [(-.510, -.241, 2.659), (-.558, -.238, 2.653), (-.596, -.231, 2.660)],
    ):
        tube("PIN | Head / Feather barbs", points, .003, quill)
