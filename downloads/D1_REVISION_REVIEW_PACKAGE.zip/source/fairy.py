"""Provisional D1 Blue Fairy volume based on CHAR_FAI_APPROVED_REFERENCE.png."""

from math import cos, pi, sin, sqrt, tau


def _grid(api, name, rows, material, cyclic=False):
    width = len(rows[0])
    faces = []
    for row in range(len(rows) - 1):
        for column in range(width if cyclic else width - 1):
            first = row * width
            second = first + width
            adjacent = (column + 1) % width
            faces.append((first + column, first + adjacent, second + adjacent, second + column))
    return api.mesh(name, [point for row in rows for point in row], faces, material, smooth=True)


def _shell(api, name, outline, center, material, depth, smooth=True):
    projected_area = sum(
        x * outline[(i + 1) % len(outline)][2] - z * outline[(i + 1) % len(outline)][0]
        for i, (x, _, z) in enumerate(outline)
    )
    if projected_area < 0:
        outline = list(reversed(outline))
    vertices = [center]
    for radius in (0.36, 0.70, 1.0):
        for point in outline:
            vertices.append(tuple(
                center[axis] + radius * (point[axis] - center[axis]) for axis in range(3)
            ))
    count = len(outline)
    faces = [(0, 1 + index, 1 + (index + 1) % count) for index in range(count)]
    for ring in range(2):
        start = 1 + ring * count
        for index in range(count):
            adjacent = (index + 1) % count
            faces.append((start + index, start + count + index, start + count + adjacent, start + adjacent))
    face_count = len(vertices)
    back = [(x, y + depth, z) for x, y, z in vertices]
    front_faces = tuple(faces)
    faces.extend(tuple(face_count + index for index in reversed(face)) for face in front_faces)
    outside = face_count - count
    for index in range(count):
        point = outside + index
        next_point = outside + (index + 1) % count
        faces.append((next_point, point, face_count + point, face_count + next_point))
    return api.mesh(name, vertices + back, faces, material, smooth=smooth)


def _tapered_hair(api, name, path, material):
    rows = []
    for i, (x, y, z, width, depth) in enumerate(path):
        before = path[max(0, i - 1)]
        after = path[min(len(path) - 1, i + 1)]
        dx, dz = after[0] - before[0], after[2] - before[2]
        length = sqrt(dx * dx + dz * dz)
        rows.append([
            (x + dz / length * width * cos(a), y + depth * sin(a), z - dx / length * width * cos(a))
            for a in (tau * side / 12 for side in range(12))
        ])
    return _grid(api, name, rows, material, cyclic=True)


def _wing_glaze(api, name, color, clarity):
    material = api.mat(name, color, roughness=0.38)
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    surface = nodes.get("Principled BSDF")
    output = nodes.get("Material Output")
    surface.inputs["Specular IOR Level"].default_value = 0.30

    backlight = nodes.new("ShaderNodeBsdfTranslucent")
    backlight.label = "Colored light through the membrane"
    backlight.inputs["Color"].default_value = surface.inputs["Base Color"].default_value
    glow = nodes.new("ShaderNodeMixShader")
    glow.inputs[0].default_value = 0.30
    links.new(surface.outputs["BSDF"], glow.inputs[1])
    links.new(backlight.outputs["BSDF"], glow.inputs[2])

    clear = nodes.new("ShaderNodeBsdfTransparent")
    clear.inputs["Color"].default_value = (0.91, 0.95, 1.0, 1.0)
    blend = nodes.new("ShaderNodeMixShader")
    blend.label = "Background visible through the wing"
    blend.inputs[0].default_value = clarity
    links.new(glow.outputs[0], blend.inputs[1])
    links.new(clear.outputs["BSDF"], blend.inputs[2])
    links.new(blend.outputs[0], output.inputs["Surface"])
    return material


def build(api):
    skin = api.mat("Fairy porcelain peach", "#F5BC91")
    cheek = api.mat("Fairy cheek glaze", "#F2A185")
    lips = api.mat("Fairy lip rose", "#AD513E")
    mouth = api.mat("Fairy smile shadow", "#623131")
    eye_white = api.mat("Fairy eye whites", "#FFF8EB", roughness=0.3)
    iris = api.mat("Fairy blue iris", "#427CA5", roughness=0.25)
    iris_rim = api.mat("Fairy iris limbal ring", "#2B4F70", roughness=0.25)
    pupil = api.mat("Fairy lashes and pupils", "#302630", roughness=0.22)
    brows = api.mat("Fairy brows", "#96572D")
    honey = api.mat("Fairy honey-blonde hair", "#C2864B")
    hair_shadow = api.mat("Fairy hair underlayers", "#986134")
    hair_mid = api.mat("Fairy curled honey locks", "#D39B5E")
    shine = api.mat("Fairy pale gold hair ribbons", "#EAB777")
    flower_white = api.mat("Fairy ivory petals", "#FFF6DF")
    flower_blue = api.mat("Fairy blue petals", "#ADCBE0")
    flower_leaf = api.mat("Fairy blue-green foliage", "#648E9D")
    gilt = api.mat("Fairy gold embroidery", "#E4BD75", roughness=0.49, metallic=0.18)
    gold = api.mat("Fairy wand brushed gold", "#CB9550", roughness=0.32, metallic=0.38)
    star_gold = api.mat("Fairy star pale gold", "#FFE19A", roughness=0.3, metallic=0.21)
    underskirt = api.mat("Fairy warm ivory silk", "#F2E5D8")
    ivory = api.mat("Fairy ivory lace trim", "#FFEDD1")
    silk = api.mat("Fairy pale blue overskirt", "#7DABC9")
    shaded_silk = api.mat("Fairy shadow blue overskirt", "#678FAF")
    light_silk = api.mat("Fairy sky blue cape petals", "#AFCCDD")
    accent_silk = api.mat("Fairy pearl blue scallops", "#C9DCDF")
    wing_blue = _wing_glaze(api, "Fairy petal blue wings", "#AED4F5", 0.73)
    wing_lilac = _wing_glaze(api, "Fairy petal periwinkle wings", "#A5BDF3", 0.68)
    wing_tip = _wing_glaze(api, "Fairy pale blue wing edge", "#CFDAEB", 0.28)
    veins = _wing_glaze(api, "Fairy wing vein ivory", "#E6DBCB", 0.22)

    def encircle(name, rings, material):
        rows = []
        for height, radius_x, radius_y, center_y in rings:
            rows.append([
                (radius_x * sin(a), center_y - radius_y * cos(a), height)
                for a in (tau * section / 64 for section in range(64))
            ])
        return _grid(api, name, rows, material, cyclic=True)

    # Petal wings radiate from the shoulder blades into three lengths on each side.
    wing_outlines = (
        ((0.13, 1.96), (0.30, 2.22), (0.52, 2.48), (0.81, 2.69), (1.14, 2.87),
         (1.40, 2.93), (1.53, 2.89), (1.56, 2.76), (1.44, 2.48), (1.22, 2.24),
         (0.88, 2.04), (0.52, 1.94)),
        ((0.14, 1.91), (0.46, 2.00), (0.77, 2.00), (1.11, 1.94), (1.32, 1.79),
         (1.35, 1.67), (1.25, 1.59), (1.02, 1.58), (0.70, 1.68), (0.47, 1.77)),
        ((0.14, 1.84), (0.43, 1.79), (0.76, 1.67), (1.08, 1.47), (1.27, 1.27),
         (1.27, 1.15), (1.16, 1.13), (0.94, 1.22), (0.69, 1.43), (0.42, 1.65)),
    )
    centers = ((0.87, 2.44), (0.81, 1.80), (0.79, 1.49))
    for side in (-1, 1):
        label = "Left" if side == -1 else "Right"
        for number, outline in enumerate(wing_outlines):
            def wing_point(x, z, bulge=0):
                return (side * x, 0.26 + x * 0.27 + number * 0.025 - bulge, z)

            wing_name = f"Fairy {label} wing petal {number + 1}"
            edge = [wing_point(x, z) for x, z in outline]
            center_x, center_z = centers[number]
            center = wing_point(center_x, center_z, 0.13)
            _shell(api, wing_name, edge, center, (wing_lilac, wing_blue, wing_blue)[number], 0.048)
            api.tube(wing_name + " rim", edge, 0.008, wing_tip, cyclic=True)
            end_index = (6, 5, 5)[number]
            x0, z0 = outline[0]
            x1, z1 = outline[end_index]
            halfway = wing_point(center_x, center_z, 0.142)
            halfway_back = (halfway[0], halfway[1] + 0.072, halfway[2])
            root = wing_point(x0, z0, 0.011)
            tip = wing_point(x1, z1, 0.011)
            api.tube(wing_name + " main vein", [root, halfway, tip], 0.010, veins)
            api.tube(wing_name + " reverse vein",
                     [(root[0], root[1] + 0.080, root[2]), halfway_back,
                      (tip[0], tip[1] + 0.080, tip[2])], 0.007, wing_tip)
            outskirts = (2, 4, 8, 10) if number == 0 else (2, 3, 7, 8)
            for branch, edge_index in enumerate(outskirts):
                edge_x, edge_z = outline[edge_index]
                start_x = center_x + (0.12 if branch in (1, 2) else -0.18)
                fraction = (start_x - center_x) / (x1 - center_x)
                start_z = center_z + (z1 - center_z) * fraction * 0.58
                start = wing_point(start_x, start_z, 0.12)
                mid = wing_point((start_x + edge_x) / 2, (start_z + edge_z) / 2, 0.085)
                end = wing_point(edge_x, edge_z, 0.013)
                api.tube(f"{wing_name} vein {branch + 1}", [start, mid, end], 0.006, veins)
            for index, (ox, oz) in enumerate(((0.12, 0.10), (-0.16, 0.12), (0.20, -0.07), (-0.08, -0.09))):
                dot = wing_point(center_x + ox, center_z + oz, 0.116)
                api.ell(f"{wing_name} pearl speck {index + 1}", dot, (0.019, 0.007, 0.020), flower_white)

    # A full silk bell and open, scalloped overskirts create the cream front opening.
    inner_rings = []
    for ring in range(29):
        t = ring / 28
        row = []
        for section in range(100):
            a = tau * section / 100
            flare = (1 - t) ** 1.30
            fluting = (0.034 * cos(9 * a + 0.32 * sin(3 * a)) + 0.012 * sin(13 * a)) * (1 - t)
            radius_x = 0.255 + 0.735 * flare + fluting
            radius_y = 0.185 + 0.451 * flare + fluting
            hem_wave = 0.016 * (1 + sin(8 * a + 0.38 * cos(3 * a)))
            z = 0.041 + 1.54 * t + hem_wave * flare
            row.append((radius_x * sin(a) - 0.035 * flare, 0.035 - radius_y * cos(a), z))
        inner_rings.append(row)
    _grid(api, "Fairy fluted ivory underskirt", inner_rings, underskirt, cyclic=True)
    api.tube("Fairy ivory underskirt bound hem", inner_rings[0][::2], 0.010, ivory, cyclic=True)
    for side in (-1, 1):
        api.ell(f"Fairy cream slipper {side}", (side * 0.159, -0.512, 0.037),
                (0.105, 0.130, 0.037), underskirt, (0, 0, side * 0.055))

    def skirt_point(t, u):
        start = 0.29 + 0.19 * (1 - t)
        angle = start + (tau - 2 * start) * u - 0.080 * (1 - t) * sin(pi * u)
        flare = (1 - t) ** 1.45
        fold = (0.042 * cos(9 * angle + 0.55 * sin(2 * angle)) + 0.018 * sin(5 * angle)) * flare
        radius_x = 0.27 + 0.84 * flare + fold
        radius_y = 0.20 + 0.49 * flare + fold
        hem_wave = 0.061 + 0.026 * cos(8 * angle + 0.52 * sin(3 * angle))
        hem_wave += 0.026 * cos(2 * angle) - 0.020 * sin(angle)
        height = 0.092 + 1.46 * t + hem_wave * flare
        return (radius_x * sin(angle) - 0.080 * flare, 0.03 - radius_y * cos(angle), height)

    overskirt = [[skirt_point(i / 30, j / 112) for j in range(113)] for i in range(31)]
    _grid(api, "Fairy blue open overskirt", overskirt, shaded_silk)
    api.tube("Fairy blue train rolled hem", overskirt[0][::2], 0.011, silk)
    for side in (0, 112):
        api.tube(f"Fairy open front piping {side}", [row[side] for row in overskirt[::2]], 0.009, light_silk)

    def outer_petal_point(index, t, across):
        start = 0.29 + 0.26 * (1 - t)
        span = 0.074 + 0.025 * (1 - t)
        if (index == 0 and across < 0) or (index == 7 and across > 0):
            span = 0.0625
        a = start + (tau - 2 * start) * ((index + 0.5) / 8 + across * span)
        flare = (1 - t) ** 1.24
        radius_x = 0.28 + (0.75 + 0.074 * cos(index * 1.35)) * flare
        radius_y = 0.208 + (0.49 + 0.039 * cos(index * 1.1)) * flare
        length = (1.23, 1.04, 1.18, 1.07, 1.26, 1.10, 1.04, 1.21)[index]
        rounded_hem = 0.14 * across ** 2 + 0.040 * across * sin(index * 1.22)
        rounded_hem += 0.018 * sin(4 * across + index)
        z = 1.54 - length * (1 - t) + rounded_hem * flare
        petal_raise = (0.033 * cos(across * 2.15) + 0.017 * sin(across * 3.4 + index)) * flare
        return ((radius_x + petal_raise) * sin(a) - 0.078 * flare,
                0.028 - (radius_y + petal_raise) * cos(a), z)

    for panel in range(8):
        rows = [[outer_petal_point(panel, step / 23, (span - 10) / 10) for span in range(21)]
                for step in range(24)]
        _grid(api, f"Fairy overlapping skirt petal {panel + 1}", rows, silk if panel % 3 else light_silk)
        api.tube(f"Fairy skirt petal {panel + 1} trim", rows[0][::2], 0.008, light_silk)
        for side in (0, 20):
            api.tube(f"Fairy skirt petal {panel + 1} seam {side}", [row[side] for row in rows[::2]], 0.006,
                     silk)

    # The pearl motif spans the cream opening and follows the fluted textile.
    for band, ring in enumerate((3, 5, 7)):
        for section in range(-6, 7, 2):
            x, y, z = inner_rings[ring][section]
            api.ell(f"Fairy underskirt pearl {band + 1}.{section}", (x, y - 0.010, z),
                    (0.014, 0.009, 0.012), ivory)

    # Surface-following embroidered stems and gold leaves.
    for i, (panel, side) in enumerate(((0, 1), (1, -1), (6, 1), (7, -1))):
        def embroidery(t, across):
            x, y, z = outer_petal_point(panel, t, across)
            return (x + side * 0.004, y - 0.023, z)

        api.tube(f"Fairy embroidered stem {i + 1}",
                 [embroidery(t, side * (0.61 - t)) for t in (0.10, 0.20, 0.33, 0.46, 0.58, 0.69)],
                 0.0075, gilt)
        for j in range(5):
            t = 0.17 + j * 0.098
            center = side * (0.61 - t)
            for leaf_side in (-1, 1):
                points = [embroidery(t, center), embroidery(t + 0.021, center + leaf_side * 0.28),
                          embroidery(t + 0.077, center + leaf_side * 0.47),
                          embroidery(t + 0.058, center + leaf_side * 0.21)]
                api.mesh(f"Fairy embroidered leaf {i + 1}.{j + 1}.{leaf_side}", points, [(0, 1, 2, 3)], gilt)

    encircle("Fairy shaped blue bodice", (
        (1.47, 0.250, 0.182, 0.020), (1.56, 0.259, 0.194, 0.018), (1.70, 0.281, 0.226, 0.018),
        (1.86, 0.340, 0.238, 0.024), (2.02, 0.373, 0.183, 0.035), (2.13, 0.180, 0.145, 0.046),
        (2.15, 0.119, 0.117, 0.046),
    ), silk)
    encircle("Fairy pale ribbon belt", (
        (1.54, 0.263, 0.199, 0.018), (1.60, 0.263, 0.203, 0.018),
        (1.63, 0.266, 0.206, 0.018),
    ), accent_silk)
    api.ell("Fairy satin belt knot", (0.035, -0.205, 1.585), (0.059, 0.030, 0.057), ivory)
    for side in (-1, 1):
        end_x = 0.035 + side * 0.11
        api.mesh(f"Fairy belt sash tail {side}",
                 [(0.022, -0.224, 1.60), (0.062, -0.224, 1.60), (end_x + 0.036, -0.345, 1.17),
                  (end_x - 0.019, -0.358, 1.11)], [(0, 1, 2, 3)], ivory)
    api.ell("Fairy neck", (0, 0.040, 2.194), (0.126, 0.130, 0.221), skin, (-0.10, 0.0, 0.0))
    api.ell("Fairy warm décolletage", (0, -0.137, 2.043), (0.174, 0.069, 0.143), skin)
    api.tube("Fairy V-shaped lace collar",
             [(-0.242, -0.123, 2.073), (-0.172, -0.197, 2.022), (0.009, -0.233, 1.786),
              (0.141, -0.199, 2.008), (0.241, -0.126, 2.079)], 0.026, ivory)
    api.ell("Fairy collar pearl", (0.010, -0.267, 1.833), (0.028, 0.018, 0.038), star_gold)

    arm_points = (
        ((-0.295, -0.005, 2.035), (-0.531, -0.061, 1.645), (-0.858, -0.184, 1.511)),
        ((0.292, 0.012, 2.036), (0.641, -0.060, 1.851), (0.846, -0.130, 2.282)),
    )
    for side, (shoulder, elbow, wrist) in zip((-1, 1), arm_points):
        api.ell(f"Fairy shoulder cap {side}", shoulder, (0.166, 0.164, 0.130), light_silk,
                (0.04, side * 0.27, 0.02))
        api.capsule(f"Fairy upper arm {side}", shoulder, elbow, 0.084, skin)
        api.capsule(f"Fairy forearm {side}", elbow, wrist, 0.065, skin)
        api.ell(f"Fairy elbow {side}", elbow, (0.076, 0.073, 0.081), skin)
        for tier in range(3):
            x = shoulder[0] + side * (0.012 + 0.060 * tier)
            z = 2.05 - 0.144 * tier
            edge = [(x - side * 0.084, -0.125, z + 0.087), (x + side * 0.125, -0.105, z + 0.048),
                    (x + side * 0.267, -0.099, z - 0.137), (x + side * 0.253, -0.147, z - 0.246),
                    (x + side * 0.186, -0.180, z - 0.282), (x + side * 0.128, -0.178, z - 0.256),
                    (x + side * 0.063, -0.173, z - 0.277), (x - side * 0.043, -0.156, z - 0.164)]
            center = (x + side * 0.096, -0.192, z - 0.110)
            _shell(api, f"Fairy scalloped sleeve {side}.{tier + 1}", edge, center,
                   (light_silk, accent_silk, silk)[tier], 0.070)
            api.tube(f"Fairy sleeve scallop trim {side}.{tier + 1}", edge[2:7], 0.012, ivory)

    api.ell("Fairy open palm", (-0.891, -0.190, 1.510), (0.101, 0.045, 0.048), skin, (0, 0.14, 0))
    for i, (x, z) in enumerate(((-1.015, 1.547), (-1.044, 1.523), (-1.036, 1.499), (-1.009, 1.480))):
        api.capsule(f"Fairy open finger {i + 1}", (-0.922, -0.194, 1.535 - i * 0.013),
                    (x, -0.209, z), 0.014, skin)
    api.capsule("Fairy open thumb", (-0.876, -0.198, 1.500), (-0.908, -0.225, 1.455), 0.019, skin)
    api.ell("Fairy wand palm", (0.858, -0.132, 2.331), (0.066, 0.048, 0.087), skin,
            (0.0, -0.39, 0.0))
    for i in range(4):
        z = 2.293 + i * 0.036
        api.tube(f"Fairy wand grip finger {i + 1}", [(0.859, -0.160, z), (0.910, -0.186, z + 0.012),
                 (0.928, -0.142, z + 0.015)], 0.018, skin)
    api.capsule("Fairy wand grip thumb", (0.837, -0.159, 2.338), (0.905, -0.188, 2.398), 0.024, skin)
    wand_tip = (1.135, -0.145, 3.125)
    api.link("Fairy wand tapered shaft", (0.810, -0.135, 2.125), wand_tip, 0.021, 0.014, gold, vertices=24)
    star = []
    for i in range(10):
        a = -0.18 + pi * i / 5
        radius = 0.208 if i % 2 == 0 else 0.097
        star.append((wand_tip[0] + radius * sin(a), wand_tip[1] - 0.004, wand_tip[2] + radius * cos(a)))
    _shell(api, "Fairy sculpted five-point wand star", star, (wand_tip[0], -0.208, wand_tip[2]),
           star_gold, 0.082, smooth=False)

    # The head is turned a little toward the raised wand.
    face_yaw = 0.15
    def h(x, y, z):
        return (x * cos(face_yaw) - y * sin(face_yaw), x * sin(face_yaw) + y * cos(face_yaw), z)

    head_rings = (
        (2.264, 0.018, 0.045, -0.075), (2.277, 0.104, 0.129, -0.074),
        (2.309, 0.190, 0.188, -0.047), (2.36, 0.256, 0.237, -0.010),
        (2.425, 0.307, 0.272, 0.003), (2.505, 0.341, 0.304, 0.013),
        (2.60, 0.365, 0.316, 0.026), (2.70, 0.384, 0.331, 0.039),
        (2.81, 0.392, 0.348, 0.054), (2.91, 0.379, 0.342, 0.055),
        (3.005, 0.331, 0.302, 0.055), (3.081, 0.250, 0.245, 0.059),
        (3.122, 0.146, 0.149, 0.059), (3.142, 0.014, 0.030, 0.060),
    )
    head_rows = [[h(rx * sin(angle), y - ry * cos(angle), z)
                  for angle in (tau * section / 72 for section in range(72))]
                 for z, rx, ry, y in head_rings]
    _grid(api, "Fairy sculpted peach face", head_rows, skin, cyclic=True)
    for side in (-1, 1):
        eye_x = side * 0.155
        tilt = -0.19 * side
        api.ell(f"Fairy ear {side}", h(side * 0.370, -0.023, 2.529), (0.077, 0.065, 0.106), skin,
                (0, side * 0.16, face_yaw))
        api.ell(f"Fairy ear inner {side}", h(side * 0.397, -0.073, 2.525), (0.035, 0.012, 0.055), cheek,
                (0, side * 0.30, face_yaw))
        api.ell(f"Fairy ear gold stud {side}", h(side * 0.393, -0.089, 2.468), (0.021, 0.016, 0.022), gilt)
        api.ell(f"Fairy porcelain eye {side}", h(eye_x, -0.267, 2.707),
                (0.115, 0.055, 0.121), eye_white, (0, tilt, face_yaw))
        iris_x = eye_x + 0.020
        api.ell(f"Fairy blue iris rim {side}", h(iris_x, -0.314, 2.711), (0.064, 0.023, 0.091), iris_rim,
                (0, tilt, face_yaw))
        api.ell(f"Fairy blue iris {side}", h(iris_x + 0.004, -0.332, 2.712), (0.052, 0.013, 0.075), iris,
                (0, tilt, face_yaw))
        api.ell(f"Fairy pupil {side}", h(iris_x + 0.010, -0.344, 2.719), (0.029, 0.012, 0.056), pupil,
                (0, tilt, face_yaw))
        api.ell(f"Fairy eye window light {side}", h(iris_x - 0.004, -0.357, 2.751),
                (0.017, 0.007, 0.021), eye_white)
        api.ell(f"Fairy eye glint {side}", h(iris_x + 0.027, -0.355, 2.694),
                (0.008, 0.006, 0.010), eye_white)
        upper = [h(side * 0.062, -0.302, 2.718), h(side * 0.101, -0.315, 2.802),
                 h(side * 0.161, -0.315, 2.827), h(side * 0.229, -0.276, 2.797),
                 h(side * 0.269, -0.241, 2.744)]
        api.tube(f"Fairy upper eyelid {side}", upper, 0.013, pupil)
        api.tube(f"Fairy outer lash {side}", [upper[3], upper[4], h(side * 0.284, -0.246, 2.769)],
                 0.011, pupil)
        api.tube(f"Fairy arched brow {side}",
                 [h(side * 0.067, -0.289, 2.863), h(side * 0.121, -0.294, 2.905),
                  h(side * 0.188, -0.277, 2.917), h(side * 0.239, -0.243, 2.890)], 0.018, brows)
    api.ell("Fairy soft nose tip", h(0.005, -0.312, 2.588), (0.059, 0.070, 0.050), skin, (0.27, 0.0, face_yaw))
    api.ell("Fairy nose bridge", h(0.002, -0.289, 2.634), (0.043, 0.040, 0.074), skin)
    smile = [h(-0.101, -0.269, 2.479), h(-0.049, -0.297, 2.472), h(0.022, -0.307, 2.476),
             h(0.087, -0.300, 2.501), h(0.111, -0.275, 2.533), h(0.097, -0.286, 2.477),
             h(0.058, -0.305, 2.425), h(0.003, -0.308, 2.411), h(-0.054, -0.292, 2.433)]
    _shell(api, "Fairy smiling mouth", smile, h(0.010, -0.310, 2.462), mouth, 0.028)
    api.tube("Fairy lit lower lip", smile[5:] + [smile[0]], 0.012, lips)
    api.mesh("Fairy small visible smile teeth",
             [h(-0.068, -0.300, 2.477), h(0.022, -0.321, 2.478), h(0.087, -0.309, 2.503),
              h(0.064, -0.317, 2.473), h(0.012, -0.322, 2.454), h(-0.043, -0.310, 2.459)],
             [(0, 1, 4, 5), (1, 2, 3, 4)], eye_white, smooth=True)
    for side in (-1, 1):
        for i in range(3):
            api.ell(f"Fairy cheek freckles {side}.{i + 1}", h(side * (0.17 + 0.035 * i),
                    -0.267 + 0.021 * i, 2.541 + (0.010 if i == 1 else 0)),
                    (0.011, 0.006, 0.008), cheek)

    # Honey curls wrap an asymmetric, swept braid and fall behind the shoulders.
    api.ell("Fairy nape hair volume", h(-0.086, 0.208, 2.741), (0.402, 0.309, 0.444), hair_shadow,
            (0.07, -0.16, face_yaw))
    api.ell("Fairy hair crown volume", h(-0.053, 0.114, 3.011), (0.390, 0.289, 0.264), honey,
            (0.03, -0.18, face_yaw))
    locks = (
        ((0.145, -0.190, 3.188, 0.043, 0.038), (0.058, -0.254, 3.212, 0.077, 0.054),
         (-0.055, -0.268, 3.139, 0.097, 0.061), (-0.166, -0.269, 2.998, 0.106, 0.057),
         (-0.268, -0.221, 2.873, 0.091, 0.054), (-0.342, -0.169, 2.769, 0.075, 0.044),
         (-0.413, -0.132, 2.737, 0.046, 0.029), (-0.457, -0.125, 2.780, 0.008, 0.009)),
        ((0.160, -0.142, 3.216, 0.029, 0.032), (0.241, -0.199, 3.205, 0.068, 0.058),
         (0.315, -0.184, 3.133, 0.077, 0.055), (0.372, -0.146, 3.032, 0.063, 0.052),
         (0.412, -0.090, 2.927, 0.047, 0.041), (0.411, -0.110, 2.811, 0.042, 0.036),
         (0.394, -0.119, 2.730, 0.030, 0.023), (0.425, -0.133, 2.672, 0.023, 0.019),
         (0.440, -0.151, 2.630, 0.007, 0.007)),
        ((-0.278, 0.112, 2.727, 0.050, 0.082), (-0.399, 0.154, 2.589, 0.089, 0.076),
         (-0.346, 0.134, 2.445, 0.103, 0.090), (-0.353, 0.105, 2.301, 0.085, 0.067),
         (-0.521, 0.087, 2.170, 0.091, 0.068), (-0.618, 0.055, 2.038, 0.069, 0.058),
         (-0.588, -0.013, 1.930, 0.044, 0.034), (-0.650, -0.051, 1.856, 0.013, 0.013),
         (-0.714, -0.053, 1.887, 0.005, 0.005)),
        ((-0.133, 0.294, 2.635, 0.062, 0.076), (-0.212, 0.259, 2.483, 0.109, 0.108),
         (-0.244, 0.219, 2.342, 0.108, 0.108), (-0.331, 0.170, 2.200, 0.097, 0.072),
         (-0.485, 0.155, 2.108, 0.085, 0.058), (-0.535, 0.146, 2.012, 0.064, 0.043),
         (-0.463, 0.102, 1.919, 0.039, 0.032), (-0.490, 0.072, 1.850, 0.008, 0.008)),
        ((0.170, 0.241, 2.743, 0.114, 0.114), (0.286, 0.229, 2.606, 0.130, 0.106),
         (0.250, 0.232, 2.474, 0.127, 0.094), (0.289, 0.272, 2.341, 0.102, 0.083),
         (0.425, 0.212, 2.239, 0.077, 0.069), (0.466, 0.156, 2.120, 0.050, 0.042),
         (0.414, 0.101, 2.066, 0.007, 0.008)),
        ((-0.049, 0.351, 2.851, 0.141, 0.151), (-0.036, 0.386, 2.692, 0.189, 0.141),
         (0.020, 0.373, 2.501, 0.191, 0.135), (-0.039, 0.349, 2.312, 0.137, 0.097),
         (-0.172, 0.358, 2.173, 0.108, 0.070), (-0.208, 0.321, 2.042, 0.072, 0.049),
         (-0.165, 0.244, 1.932, 0.008, 0.009)),
        ((0.115, 0.269, 3.211, 0.062, 0.024), (0.001, 0.362, 3.171, 0.119, 0.053),
         (-0.129, 0.404, 3.072, 0.130, 0.070), (-0.235, 0.430, 2.963, 0.116, 0.076),
         (-0.282, 0.428, 2.836, 0.098, 0.070), (-0.290, 0.415, 2.687, 0.091, 0.059),
         (-0.389, 0.382, 2.563, 0.065, 0.037), (-0.424, 0.332, 2.478, 0.009, 0.010)),
        ((0.063, 0.333, 3.177, 0.050, 0.035), (0.140, 0.400, 3.093, 0.124, 0.068),
         (0.175, 0.439, 2.963, 0.144, 0.073), (0.113, 0.449, 2.809, 0.139, 0.078),
         (0.083, 0.461, 2.649, 0.104, 0.066), (0.143, 0.434, 2.489, 0.091, 0.054),
         (0.211, 0.376, 2.344, 0.064, 0.040), (0.196, 0.316, 2.263, 0.010, 0.010)),
    )
    for i, path in enumerate(locks):
        points = [(*h(x, y, z), width, depth) for x, y, z, width, depth in path]
        shade = (hair_mid, honey, honey, hair_mid, honey, hair_mid, hair_mid, honey)[i]
        _tapered_hair(api, f"Fairy sculpted curl {i + 1}", points, shade)
        for line, shift in enumerate((-0.30, 0.30)):
            strand_side = 1 if i >= 6 else -1
            api.tube(f"Fairy strand detail {i + 1}.{line + 1}",
                     [h(x + width * shift, y + strand_side * (depth * 0.96 + 0.006), z)
                      for x, y, z, width, depth in path],
                     0.011 if i < 2 else 0.009, shine if line == 0 else hair_mid)
    for i, (x, y, z, slant) in enumerate((
        (-0.197, -0.043, 3.184, -0.66), (-0.261, -0.083, 3.142, -0.65), (-0.319, -0.090, 3.077, -0.52),
        (-0.366, -0.095, 3.006, -0.54), (-0.403, -0.096, 2.939, -0.40), (-0.423, -0.103, 2.867, -0.36),
        (-0.423, -0.092, 2.801, -0.27), (-0.397, -0.043, 2.738, 0.07),
    )):
        api.ell(f"Fairy woven braid lobe {i + 1}", h(x, y, z), (0.088, 0.096, 0.059),
                honey if i % 2 else hair_mid, (0.10, slant, face_yaw))
        api.tube(f"Fairy braid filament {i + 1}",
                 [h(x - 0.061, y - 0.064, z - 0.035), h(x, y - 0.101, z), h(x + 0.060, y - 0.060, z + 0.035)],
                 0.009, shine)

    flower_centers = ((-0.315, -0.256, 2.998, 0.074, flower_white), (-0.409, -0.211, 3.081, 0.053, flower_blue),
                      (-0.445, -0.211, 2.964, 0.046, flower_white))
    for i, (x, y, z, size, material) in enumerate(flower_centers):
        for j in range(5):
            a = tau * j / 5 + 0.33 * i
            api.ell(f"Fairy hair flower {i + 1} petal {j + 1}",
                    h(x + sin(a) * size * 0.79, y, z + cos(a) * size * 0.79),
                    (size * 0.45, size * 0.27, size * 0.67), material, (0.02, a, face_yaw))
        api.ell(f"Fairy hair flower {i + 1} center", h(x, y - 0.020, z), (0.023, 0.013, 0.025), gilt)
    for i, (x, y, z, slant) in enumerate(((-0.461, -0.194, 3.135, -0.65), (-0.383, -0.216, 3.154, 0.29),
                                          (-0.473, -0.171, 3.020, -0.69), (-0.258, -0.235, 3.086, 0.50))):
        api.ell(f"Fairy flower crown leaf {i + 1}", h(x, y, z), (0.019, 0.019, 0.052), flower_leaf,
                (0.07, slant, face_yaw))
