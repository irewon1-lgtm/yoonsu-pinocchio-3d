"""Lay out Korean D1 review boards from the locked PNGs and Blender renders."""

import argparse
from pathlib import Path
from typing import NamedTuple

from PIL import Image, ImageDraw, ImageFont


PAPER = "#f3eee3"
CARD = "#fffcf4"
INK = "#243b37"
MUTED = "#566863"
LINE = "#d8d2c1"
TEAL = "#20685e"
GOLD = "#a36340"
FONT_DIR = Path("/usr/share/fonts/opentype/noto")
BG_NAME = "image-gen-2(20261116-125801).png"

SPEC = {
    "PIN": ("피노키오", "#9c4a36",
            ("호박빛 목각 얼굴 · 길쭉한 코", "붉은 깃 모자 · 리본 · 크림색 셔츠",
             "청록 멜빵 반바지 · 갈색 부츠", "큰 머리 · 가는 관절 · 짧은 상체"),
            ("#cf944c", "#a34332", "#3a635d", "#754936")),
    "GEP": ("제페토", "#805839",
            ("흰 곱슬머리와 수염 · 둥근 안경", "웃는 입 · 둥근 코 · 크림색 셔츠",
             "갈색 조끼 · 공구 주머니 앞치마", "넓은 체구 · 낮은 무게중심"),
            ("#d9d0bf", "#b58a4c", "#875a38", "#4b372a")),
    "FAI": ("파란 요정", "#3b6387",
            ("금빛 웨이브 헤어 · 흰 꽃 · 푸른 눈", "연청 망토와 아이보리 안감", "꽃잎형 날개 · 별 지팡이",
             "가느다란 상체 · 넓은 치맛단"),
            ("#b58a56", "#7b99b6", "#b4c9dd", "#e6e2d7")),
}


class Landmark(NamedTuple):
    uv: tuple[float, float]
    name: str
    detail: str
    color: str


LANDMARKS = (
    Landmark((.368, .528), "작업대", "왼쪽 상판 · 피노키오 지지면", "#4e7760"),
    Landmark((.758, .137), "창문", "오른쪽 아치 · 요정 진입 기준", "#335977"),
    Landmark((.837, .303), "커튼", "창 양옆 · 가림 관계 기준", "#a14744"),
    Landmark((.612, .853), "바닥", "앞쪽 보행 및 발 접지 기준", "#8d623a"),
    Landmark((.287, .444), "램프 · 장난감 선반", "램프는 왼쪽 주광 기준", "#a26538"),
    Landmark((.266, .920), "제페토", "왼쪽 전경 · 바닥 발 기준", "#9f4a34"),
    Landmark((.334, .541), "피노키오", "작업대 중심 · 발 접촉 기준", "#256856"),
    Landmark((.746, .454), "파란 요정", "오른쪽 창에서 실내로 진입", "#385e92"),
)


def font(size, bold=False, serif=False):
    family = "NotoSerifCJK" if serif else "NotoSansCJK"
    weight = "Bold" if bold else "Regular"
    return ImageFont.truetype(str(FONT_DIR / f"{family}-{weight}.ttc"), size, index=1)


def label(draw, xy, value, size, fill=INK, bold=False, serif=False, anchor="lt"):
    draw.text(xy, value, fill=fill, font=font(size, bold, serif), anchor=anchor)


def fitted(image, path, rectangle, fill="#ede3cf"):
    x, y, width, height = rectangle
    with Image.open(path) as source:
        thumbnail = source.convert("RGB")
        thumbnail.thumbnail((width, height), Image.Resampling.LANCZOS)
    ImageDraw.Draw(image).rectangle((x, y, x + width, y + height), fill=fill)
    image.paste(thumbnail, (x + (width - thumbnail.width) // 2, y + (height - thumbnail.height) // 2))


def head(draw, title, subtitle, issue):
    label(draw, (66, 48), "윤수 피노키오  /  S01  /  D1 검토용", 24, TEAL, True)
    label(draw, (61, 91), title, 64, INK, True, True)
    label(draw, (66, 181), subtitle, 26, MUTED)
    label(draw, (2204, 54), issue, 19, GOLD, True, anchor="rt")
    draw.line((66, 228, 2204, 228), fill=LINE, width=2)


def master(locked, output):
    image = Image.new("RGB", (2270, 1598), PAPER)
    draw = ImageDraw.Draw(image)
    head(draw, "캐릭터 마스터 시트",
         "왼쪽 승인 참고 원화 · 가운데 Blender 3D 시안 · 오른쪽 외형 검토 기준", "CHARACTER REVIEW")
    columns = (86, 452, 780, 1108)
    widths = (324, 285, 285, 285)
    names = ("승인 참고 원화", "정면", "3/4 시점", "측면")
    view_ids = ("front", "three_quarter", "profile")
    for i, key in enumerate(("PIN", "GEP", "FAI")):
        title, accent, features, palette = SPEC[key]
        y = 254 + 421 * i
        draw.rounded_rectangle((66, y, 2204, y + 401), radius=19, fill=CARD, outline=LINE, width=2)
        for index, (left, width, name) in enumerate(zip(columns, widths, names)):
            label(draw, (left, y + 23), name, 21, accent if index == 0 else MUTED, True)
            filename = (
                locked / "APPROVED_CHARACTER_REFERENCE" / f"CHAR_{key}_APPROVED_REFERENCE.png"
                if index == 0 else output / "views" / f"{key}_{view_ids[index - 1]}.png"
            )
            fitted(image, filename, (left, y + 60, width, 318))
        x = 1451
        draw.line((1421, y + 22, 1421, y + 372), fill=LINE, width=2)
        label(draw, (x, y + 24), title, 45, INK, True, True)
        label(draw, (2166, y + 42), f"CHAR_{key}", 20, accent, True, anchor="rt")
        for j, text in enumerate(features):
            draw.ellipse((x, y + 106 + 44 * j, x + 8, y + 114 + 44 * j), fill=accent)
            label(draw, (x + 24, y + 98 + 44 * j), text, 25)
        for j, color in enumerate(palette):
            left = x + j * 176
            draw.rounded_rectangle((left, y + 288, left + 155, y + 328), radius=7, fill=color)
            label(draw, (left, y + 337), color.upper(), 19, MUTED)
    label(draw, (66, 1547),
          "각 캐릭터는 개별 프레이밍입니다. 측면 두께, 뒷면 연결과 인물 간 실제 크기는 검토 대상입니다.", 24, MUTED)
    image.save(output / "D1_MASTER_APPROVAL_BOARD.png", optimize=True)


def marker(draw, x, y, number, color):
    r = 21
    draw.ellipse((x - r, y - r, x + r, y + r), fill=color, outline="#fff5db", width=3)
    label(draw, (x, y - 1), f"{number:02}", 17, "#ffffff", True, anchor="mm")


def blocking(locked, output):
    image = Image.new("RGB", (2270, 1260), PAPER)
    draw = ImageDraw.Draw(image)
    head(draw, "작업실 공간 블로킹",
         "승인 2번 배경을 기준으로 좌측 제페토 · 작업대의 피노키오 · 오른쪽 창의 요정을 배치했습니다.",
         "WORKSHOP LAYOUT")
    x, y, w, h = 66, 290, 1036, 583
    right = 1168
    label(draw, (x, 252), "01  승인 원본  /  랜드마크와 배치 기준점", 24, INK, True)
    label(draw, (right, 252), "02  Blender 렌더  /  세 인물의 월드 배치", 24, INK, True)
    fitted(image, locked / "APPROVED_BG" / BG_NAME, (x, y, w, h))
    fitted(image, output / "D1_WORKSHOP_PREVIEW.png", (right, y, w, h))
    for i, item in enumerate(LANDMARKS, start=1):
        mark_x, mark_y = (x + int(item.uv[0] * w), y + int(item.uv[1] * h))
        if i in (1, 7):
            offset = (35, -25) if i == 1 else (-5, 35)
            draw.line((mark_x, mark_y, mark_x + offset[0], mark_y + offset[1]),
                      fill="#fff5db", width=3)
            draw.ellipse((mark_x - 4, mark_y - 4, mark_x + 4, mark_y + 4), fill="#fff5db")
            mark_x += offset[0]
            mark_y += offset[1]
        marker(draw, mark_x, mark_y, i, item.color)
    for i, item in enumerate(LANDMARKS, start=1):
        col, row = divmod(i - 1, 2)
        lx, ly = 66 + col * 543, 908 + row * 112
        draw.rounded_rectangle((lx, ly, lx + 510, ly + 91), radius=12, fill=CARD, outline=LINE)
        marker(draw, lx + 33, ly + 43, i, item.color)
        label(draw, (lx + 71, ly + 13), item.name, 22, INK, True)
        label(draw, (lx + 71, ly + 49), item.detail, 21, MUTED)
    label(draw, (66, 1172), "피노키오의 발 기준은 작업대 상판입니다. 창문 개방과 커튼 가림은 이후 시연에서 확인합니다.",
          24, MUTED)
    image.save(output / "D1_SPACE_BLOCKING_BOARD.png", optimize=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("locked_source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    master(args.locked_source, args.output)
    blocking(args.locked_source, args.output)


if __name__ == "__main__":
    main()
