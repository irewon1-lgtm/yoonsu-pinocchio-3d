"""D1 Geppetto volume study based on CHAR_GEP_APPROVED_REFERENCE.png."""

from math import cos, pi, sin


def _tailoring(api, name, rings, material, count=32):
    """Join elliptical cross-sections to give garments continuous volume."""
    vertices = []
    for z, x, y, width, depth in rings:
        for step in range(count):
            angle = 2 * pi * step / count
            vertices.append((x + width * cos(angle), y + depth * sin(angle), z))
    faces = [tuple(reversed(range(count)))]
    for index in range(len(rings) - 1):
        bottom = index * count
        top = bottom + count
        for step in range(count):
            following = (step + 1) % count
            faces.append((bottom + step, bottom + following, top + following, top + step))
    faces.append(tuple(range(len(vertices) - count, len(vertices))))
    return api.mesh(name, vertices, faces, material, smooth=True)


def _panel(api, name, outline, material, depth=.018):
    projected_area = sum(
        x * next_z - next_x * z
        for (x, _, z), (next_x, _, next_z) in zip(outline, outline[1:] + outline[:1])
    )
    if projected_area < 0:
        outline = list(reversed(outline))
    front = [(x, y - depth, z) for x, y, z in outline]
    vertices = front + outline
    count = len(outline)
    faces = [tuple(range(count)), tuple(reversed(range(count, count * 2)))]
    for index in range(count):
        following = (index + 1) % count
        faces.append((index, index + count, following + count, following))
    return api.mesh(name, vertices, faces, material)


def build(api):
    skin = api.mat("GEP | warm skin", "#D49062")
    cheeks = api.mat("GEP | nose and cheek blush", "#CF8059")
    inner_ear = api.mat("GEP | inner ear", "#AD603E")
    hair = api.mat("GEP | silver hair", "#DDD0BD")
    hair_light = api.mat("GEP | silver highlights", "#F0E4D0")
    hair_shadow = api.mat("GEP | silver shadows", "#A79D91")
    ivory = api.mat("GEP | eye whites", "#FFF2D7", .34)
    iris = api.mat("GEP | warm hazel iris", "#5D321E", .43)
    ink = api.mat("GEP | pupil", "#251B17", .31)
    bronze = api.mat("GEP | spectacles", "#76533B", .42, .55)
    mouth = api.mat("GEP | mouth interior", "#47231E")
    tongue = api.mat("GEP | tongue", "#B96E58")
    linen = api.mat("GEP | warm linen", "#E6D2AA")
    linen_light = api.mat("GEP | turned linen", "#F0DDB6")
    linen_shadow = api.mat("GEP | linen seams", "#BBA477")
    vest = api.mat("GEP | chestnut vest", "#754323")
    leather = api.mat("GEP | leather trim", "#9A5F32")
    thread = api.mat("GEP | saddle stitching", "#BB8A57")
    pants = api.mat("GEP | umber trousers", "#544032")
    cuffs = api.mat("GEP | trouser cuffs", "#694F3B")
    boot = api.mat("GEP | aged boot leather", "#755039")
    sole = api.mat("GEP | boot soles", "#4B3226")
    apron = api.mat("GEP | ochre canvas apron", "#9F773E")
    pocket = api.mat("GEP | ochre pocket", "#B08649")
    patina = api.mat("GEP | workshop wear", "#78603A")
    wood = api.mat("GEP | tool handles", "#C08A47")
    ferrule = api.mat("GEP | dark steel ferrules", "#465052", .5, .55)

    for side in (-1, 1):
        x = .255 * side
        _tailoring(api, f"GEP | boot sole {side}", [
            (.000, x, -.095, .224, .309), (.055, x, -.11, .228, .319),
            (.104, x, -.115, .224, .311), (.118, x, -.108, .209, .291),
        ], sole)
        api.ell(f"GEP | boot toe {side}", (x, -.181, .167), (.219, .247, .135), boot)
        api.ell(f"GEP | boot quarter {side}", (x, .033, .229), (.186, .188, .190), boot)
        api.tube(f"GEP | toe welt {side}", [
            (x - .179, -.220, .160), (x - .106, -.386, .146), (x, -.421, .143),
            (x + .106, -.385, .147), (x + .180, -.216, .163),
        ], .010, thread)
        for row in range(3):
            y = -.194 + .036 * row
            z = .282 + .018 * row
            api.tube(f"GEP | boot lace {side} {row}", [
                (x - .066, y, z), (x, y - .011, z + .019), (x + .066, y + .014, z),
            ], .011, sole)
        _tailoring(api, f"GEP | trouser leg {side}", [
            (.322, x, .018, .175, .158), (.397, x, .018, .210, .180),
            (.510, x - .014 * side, .006, .206, .177),
            (.701, x + .005 * side, .024, .215, .195),
            (.928, x - .018 * side, .016, .249, .224),
            (1.151, x - .030 * side, .024, .253, .243),
            (1.301, x - .052 * side, .046, .232, .223),
        ], pants)
        _tailoring(api, f"GEP | turned trouser cuff {side}", [
            (.360, x, .016, .186, .173), (.385, x, .015, .214, .184),
            (.472, x, .014, .217, .194), (.497, x, .009, .206, .184),
        ], cuffs)
        api.tube(f"GEP | cuff stitch {side}", [
            (x - .151, -.098, .410), (x, -.174, .399), (x + .154, -.108, .413),
        ], .007, thread)
        api.tube(f"GEP | trouser seam {side}", [
            (x + .180 * side, -.058, .480), (x + .196 * side, -.062, .711),
            (x + .216 * side, -.069, .987), (x + .164 * side, -.093, 1.178),
        ], .009, cuffs)
        api.tube(f"GEP | trouser knee fold {side}", [
            (x - .095, -.151, .623), (x + .029, -.174, .650), (x + .098, -.151, .675),
        ], .011, cuffs)

    _tailoring(api, "GEP | linen shirt body", [
        (1.000, 0, .024, .376, .205), (1.123, 0, .020, .414, .241),
        (1.348, 0, .031, .473, .303), (1.597, 0, .047, .484, .298),
        (1.868, 0, .049, .487, .280), (2.057, 0, .022, .450, .238),
        (2.194, 0, -.004, .347, .205), (2.262, 0, -.035, .213, .172),
    ], linen)

    for side in (-1, 1):
        # Broad vest volume wraps each shoulder and the flanks.
        _tailoring(api, f"GEP | chestnut vest side {side}", [
            (1.170, .303 * side, .054, .115, .176),
            (1.274, .327 * side, .039, .165, .245),
            (1.473, .341 * side, .053, .174, .290),
            (1.780, .337 * side, .043, .169, .281),
            (2.001, .317 * side, .030, .158, .223),
            (2.166, .288 * side, .018, .130, .174),
            (2.247, .245 * side, -.010, .095, .125),
        ], vest)
        points = [
            (.176 * side, -.135, 2.242), (.183 * side, -.189, 2.086),
            (.200 * side, -.239, 1.874), (.187 * side, -.264, 1.620),
            (.184 * side, -.262, 1.377), (.217 * side, -.216, 1.200),
            (.320 * side, -.188, 1.203), (.432 * side, -.133, 1.264),
        ]
        api.tube(f"GEP | vest edge binding {side}", points, .017, leather)
        for index in range(15):
            z = 1.296 + .042 * index
            x = (.205 + .025 * abs(z - 1.62)) * side
            y = -.277 + .077 * ((z - 1.60) / .65) ** 2
            api.capsule(f"GEP | vest edge stitch {side} {index}",
                        (x, y, z), (x + .003 * side, y, z + .019), .0046, thread)

    for index, z in enumerate((1.316, 1.443, 1.581, 1.741)):
        x = -.225
        api.ell(f"GEP | brass vest button {index}", (x, -.273, z), (.029, .015, .029), leather)
        api.ell(f"GEP | button center {index}", (x, -.288, z), (.010, .004, .010), vest)
    _panel(api, "GEP | vest patch pocket", [
        (-.444, -.196, 1.506), (-.368, -.251, 1.478), (-.288, -.277, 1.459),
        (-.306, -.274, 1.354), (-.366, -.251, 1.343), (-.432, -.211, 1.380),
    ], leather)
    api.tube("GEP | vest pocket binding", [
        (-.444, -.225, 1.507), (-.375, -.275, 1.483), (-.288, -.297, 1.460),
    ], .013, thread)

    api.ell("GEP | neck", (0, -.024, 2.285), (.179, .162, .206), skin,
            (.23, 0, 0))
    for side in (-1, 1):
        _panel(api, f"GEP | linen collar {side}", [
            (.142 * side, -.138, 2.297), (.232 * side, -.182, 2.170),
            (.142 * side, -.223, 2.020), (.090 * side, -.232, 2.109),
            (.017 * side, -.174, 2.190),
        ], linen_light, .027)
        api.tube(f"GEP | collar seam {side}", [
            (.046 * side, -.198, 2.183), (.093 * side, -.255, 2.117),
            (.141 * side, -.253, 2.038),
        ], .006, linen_shadow)
        for index in range(2):
            z = 1.972 - .085 * index
            api.ell(f"GEP | linen button {side} {index}",
                    (.025 * side, -.264, z), (.011, .007, .011), linen_shadow)
        api.tube(f"GEP | canvas neck strap {side}", [
            (.145 * side, -.027, 2.235), (.227 * side, -.173, 2.164),
            (.239 * side, -.244, 1.969), (.238 * side, -.295, 1.783),
        ], .019, apron)

    _tailoring(api, "GEP | canvas apron", [
        (.814, 0, -.204, .360, .073), (.851, 0, -.208, .399, .086),
        (1.083, 0, -.210, .388, .094), (1.318, 0, -.225, .350, .105),
        (1.552, 0, -.243, .290, .094), (1.730, 0, -.252, .262, .082),
        (1.786, 0, -.249, .247, .073),
    ], apron)
    api.tube("GEP | apron hem", [
        (-.373, -.241, .862), (-.235, -.272, .833), (0, -.291, .824),
        (.235, -.272, .833), (.373, -.241, .862),
    ], .011, pocket)
    api.tube("GEP | apron bib binding", [
        (-.246, -.266, 1.784), (-.149, -.310, 1.777), (0, -.326, 1.771),
        (.145, -.310, 1.777), (.246, -.266, 1.784),
    ], .013, pocket)
    api.tube("GEP | canvas waist tie", [
        (-.358, -.075, 1.321), (-.365, .097, 1.325), (-.199, .198, 1.320),
        (.099, .217, 1.315), (.353, .100, 1.305), (.346, -.092, 1.300),
    ], .026, apron)
    _panel(api, "GEP | knotted apron tie", [
        (-.345, .130, 1.333), (-.315, .160, 1.293), (-.463, .118, 1.065),
        (-.520, .097, 1.104),
    ], apron)
    _tailoring(api, "GEP | canvas tool pocket", [
        (.985, .085, -.289, .086, .032), (1.002, .085, -.303, .157, .050),
        (1.058, .088, -.319, .186, .070), (1.264, .089, -.332, .195, .085),
        (1.292, .088, -.333, .193, .080),
    ], pocket)
    api.tube("GEP | reinforced pocket opening", [
        (-.105, -.349, 1.282), (-.046, -.397, 1.272), (.091, -.418, 1.263),
        (.222, -.393, 1.271), (.281, -.346, 1.284),
    ], .015, apron)
    for index in range(10):
        x = -.080 + .037 * index
        y = -.429 + 1.76 * (x - .085) ** 2
        api.capsule(f"GEP | pocket stitch {index}", (x, y, 1.248), (x + .019, y, 1.249),
                    .0038, thread)
    for index, (x, y, z, tilt, size) in enumerate((
        (-.032, -.354, 1.278, -.042, .256),
        (.093, -.355, 1.269, .064, .300),
        (.183, -.353, 1.265, .102, .246),
    )):
        api.link(f"GEP | tool ferrule {index}", (x, y, z - .019),
                 (x + tilt * .37, y, z + size * .37), .037, .031, ferrule)
        api.link(f"GEP | tapered wood handle {index}", (x + tilt * .34, y, z + size * .34),
                 (x + tilt, y + .011, z + size), .025, .031, wood)
        api.ell(f"GEP | rounded handle end {index}", (x + tilt, y + .011, z + size),
                (.031, .031, .030), wood)
    for index, (x, y, z, sx, sz) in enumerate((
        (-.231, -.285, 1.027, .035, .044), (-.164, -.299, .945, .014, .025),
        (-.171, -.315, 1.413, .028, .017), (.208, -.388, 1.113, .022, .029),
        (.067, -.391, 1.072, .029, .017), (.141, -.353, 1.217, .018, .019),
    )):
        api.ell(f"GEP | subtle apron wear {index}", (x, y, z), (sx, .004, sz), patina)

    _arms(api, skin, cheeks, linen, linen_light, linen_shadow)
    _face(api, skin, cheeks, inner_ear, hair, hair_light, hair_shadow,
          ivory, iris, ink, bronze, mouth, tongue)


def _arms(api, skin, cheeks, linen, linen_light, linen_shadow):
    # His resting hand sits behind his hip and the other hand opens upward.
    api.ell("GEP | resting sleeve shoulder", (-.466, -.014, 2.021), (.269, .247, .271),
            linen, (.20, -.49, -.05))
    api.capsule("GEP | resting sleeve", (-.455, -.005, 2.063), (-.705, .051, 1.783),
                .198, linen)
    api.capsule("GEP | resting rolled cuff", (-.659, .070, 1.814), (-.725, .107, 1.704),
                .169, linen_light)
    api.capsule("GEP | resting forearm", (-.730, .107, 1.695), (-.573, .242, 1.439),
                .095, skin)
    api.ell("GEP | resting hand", (-.501, .236, 1.402), (.093, .064, .125), skin,
            (0, -.48, -.08))
    for index, (side_y, z_shift) in enumerate(((-.151, .029), (-.115, -.034))):
        api.tube(f"GEP | folded resting sleeve {index}", [
            (-.565, side_y + .052, 1.901 + z_shift),
            (-.661, side_y, 1.836 + z_shift), (-.760, side_y + .062, 1.813 + z_shift),
        ], .013, linen_shadow)

    api.ell("GEP | open sleeve shoulder", (.474, -.026, 2.030), (.261, .229, .271),
            linen, (.20, -.53, .06))
    api.capsule("GEP | open sleeve", (.484, -.010, 2.013), (.758, -.015, 1.793),
                .187, linen)
    api.capsule("GEP | open rolled cuff", (.710, -.035, 1.784), (.850, -.070, 1.821),
                .171, linen_light)
    for index, (x, z) in enumerate(((.739, 1.760), (.807, 1.782))):
        api.tube(f"GEP | turned cuff fold {index}", [
            (x - .036, -.002, z + .172), (x - .015, -.154, z + .133),
            (x, -.220, z + .041), (x + .018, -.179, z - .083),
            (x + .027, -.065, z - .133),
        ], .016, linen_shadow)
    api.capsule("GEP | open forearm", (.828, -.067, 1.823), (1.113, -.117, 2.028),
                .110, skin)
    api.capsule("GEP | open wrist", (1.064, -.116, 1.973), (1.199, -.119, 2.059),
                .076, skin)
    api.ell("GEP | open palm", (1.225, -.123, 2.071), (.139, .066, .092), skin,
            (.22, -.37, .03))
    finger_shapes = (
        ((1.299, -.132, 2.127), (1.407, -.153, 2.158), (1.491, -.165, 2.180), .030),
        ((1.322, -.145, 2.101), (1.443, -.171, 2.118), (1.534, -.177, 2.150), .030),
        ((1.323, -.157, 2.072), (1.430, -.182, 2.082), (1.507, -.191, 2.112), .026),
        ((1.302, -.170, 2.052), (1.394, -.197, 2.052), (1.454, -.205, 2.080), .023),
    )
    for index, (base, knuckle, tip, width) in enumerate(finger_shapes):
        api.capsule(f"GEP | open finger {index} base", base, knuckle, width, skin)
        api.capsule(f"GEP | open finger {index} tip", knuckle, tip, width * .86, skin)
    api.capsule("GEP | open thumb base", (1.150, -.128, 2.085),
                (1.171, -.142, 2.218), .048, skin)
    api.capsule("GEP | open thumb tip", (1.171, -.142, 2.211),
                (1.216, -.157, 2.297), .040, skin)
    api.tube("GEP | palm crease", [
        (1.144, -.175, 2.103), (1.212, -.193, 2.125), (1.277, -.183, 2.121),
    ], .006, cheeks)


def _face(api, skin, cheeks, inner_ear, hair, hair_light, hair_shadow,
          ivory, iris, ink, bronze, mouth, tongue):
    # Move the whole head into the stoop while preserving the facial fit.
    def lowered(point):
        x, y, z = point
        return x, y - .062, z - .144

    def ell(name, location, scale, material, rotation=(0, 0, 0)):
        return api.ell(name, lowered(location), scale, material, rotation)

    def tube(name, points, radius, material, cyclic=False):
        return api.tube(name, [lowered(point) for point in points], radius, material, cyclic)

    ell("GEP | head", (.021, .009, 2.968), (.350, .301, .409), skin,
            (0, -.057, 0))
    ell("GEP | lower face", (.023, -.040, 2.760), (.294, .250, .252), skin)
    ell("GEP | silver hair cap", (.000, .093, 3.092), (.368, .269, .350), hair_shadow)
    ell("GEP | swept silver crown", (-.026, .004, 3.282), (.344, .276, .170), hair,
            (.12, -.20, -.10))
    ell("GEP | silver forelock volume", (-.092, -.183, 3.340),
            (.236, .104, .106), hair, (-.08, -.50, .01))
    ell("GEP | lifted crown curl", (-.036, -.097, 3.413),
            (.130, .124, .107), hair, (-.12, -.41, .26))
    ell("GEP | parted crown lock", (.124, -.077, 3.360),
            (.152, .178, .083), hair, (-.09, .44, -.10))

    crown_strands = (
        ((-.292, -.174, 3.256), (-.190, -.258, 3.294), (-.114, -.260, 3.373),
         (-.045, -.216, 3.465), (.043, -.152, 3.477), (.093, -.141, 3.422)),
        ((-.323, -.143, 3.235), (-.252, -.235, 3.249), (-.146, -.278, 3.324),
         (-.083, -.248, 3.410), (-.015, -.197, 3.465), (.063, -.169, 3.455)),
        ((-.292, -.114, 3.337), (-.223, -.180, 3.387), (-.176, -.163, 3.432),
         (-.092, -.125, 3.466), (-.007, -.094, 3.490), (.075, -.059, 3.463)),
        ((.070, -.169, 3.416), (.149, -.167, 3.428), (.227, -.145, 3.397),
         (.260, -.165, 3.359), (.271, -.200, 3.327)),
        ((.106, -.121, 3.429), (.184, -.111, 3.433), (.270, -.110, 3.384),
         (.298, -.118, 3.331)),
    )
    for index, strand in enumerate(crown_strands):
        tube(f"GEP | swept crown strand {index}", strand,
                 .024 if index in (0, 3) else .017, hair_light if index % 2 == 0 else hair)

    ell("GEP | smiling cheek left", (-.208, -.224, 2.870), (.111, .098, .094), cheeks)
    ell("GEP | smiling cheek right", (.245, -.218, 2.887), (.106, .082, .096), cheeks)
    tube("GEP | soft forehead crease 0", [
        (-.069, -.230, 3.206), (-.006, -.237, 3.217),
        (.052, -.235, 3.216), (.104, -.225, 3.205),
    ], .0048, cheeks)
    tube("GEP | soft forehead crease 1", [
        (-.050, -.208, 3.247), (.001, -.214, 3.252),
        (.047, -.213, 3.252), (.089, -.204, 3.245),
    ], .0041, cheeks)
    for side in (-1, 1):
        x = .350 * side + .017
        ell(f"GEP | outer ear {side}", (x, -.028, 2.885),
                (.103, .093, .125), skin, (0, .22 * side, .02))
        ell(f"GEP | ear hollow {side}", (x + .017 * side, -.107, 2.892),
                (.058, .020, .070), inner_ear, (0, .24 * side, 0))
        tube(f"GEP | outer ear rim {side}", [
            (x + .054 * side, -.099, 2.814), (x + .086 * side, -.100, 2.893),
            (x + .046 * side, -.104, 2.967), (x - .016 * side, -.106, 2.957),
        ], .019, skin)
        ell(f"GEP | silver temple lock {side}", (x - .024 * side, .037, 3.068),
                (.110, .178, .140), hair, (.20, .16 * side, -.40 * side))
        for curl in range(3):
            z = 3.003 + .068 * curl
            tube(f"GEP | swept temple curl {side} {curl}", [
                ((.299 - .017 * curl) * side, -.160, z + .076),
                ((.360 - .006 * curl) * side, -.133, z + .026),
                ((.418 + .012 * curl) * side, -.044, z + .015),
                ((.405 + .012 * curl) * side, .070, z + .088),
            ], .035 - .004 * curl, hair_light if curl == 2 else hair)
        ell(f"GEP | back wave {side}", (.237 * side, .236, 2.922),
                (.148, .126, .160), hair, (.26, .29 * side, 0))
        tube(f"GEP | back wave crest {side}", [
            (.144 * side, .309, 3.192), (.230 * side, .342, 3.099),
            (.295 * side, .325, 3.005), (.315 * side, .282, 2.919),
            (.279 * side, .278, 2.858),
        ], .025, hair_light)

    ell("GEP | smiling mouth volume", (.035, -.272, 2.727),
            (.156, .063, .100), mouth, (.11, .045, -.04))
    ell("GEP | tongue inside smile", (.038, -.323, 2.680),
            (.091, .021, .028), tongue, (.07, -.01, 0))
    tube("GEP | lower lip", [
        (-.100, -.298, 2.726), (-.046, -.329, 2.667), (.047, -.336, 2.653),
        (.135, -.310, 2.690), (.183, -.264, 2.756),
    ], .014, cheeks)
    ell("GEP | beard foundation", (.020, -.075, 2.641),
            (.297, .209, .151), hair_shadow)
    beard_locks = (
        (-.259, -.174, 2.791, .091, .092, .106, -.35),
        (-.226, -.201, 2.694, .093, .092, .121, -.53),
        (-.157, -.241, 2.622, .093, .098, .092, -.51),
        (-.080, -.258, 2.593, .082, .085, .083, -.39),
        (.000, -.259, 2.579, .083, .093, .081, -.19),
        (.079, -.253, 2.581, .082, .088, .083, .19),
        (.148, -.235, 2.608, .089, .092, .093, .32),
        (.216, -.213, 2.672, .093, .097, .123, .49),
        (.275, -.169, 2.756, .090, .100, .121, .45),
        (.285, -.164, 2.824, .058, .073, .084, .50),
    )
    for index, (x, y, z, sx, sy, sz, tilt) in enumerate(beard_locks):
        ell(f"GEP | curled beard lock {index}", (x, y, z), (sx, sy, sz), hair,
                (.25, tilt, .1))
        tube(f"GEP | beard wave {index}", [
            (x + tilt * .035, y - sy * .73, z + sz * .73),
            (x - tilt * .016, y - sy * .98, z + sz * .18),
            (x - tilt * .057, y - sy * .92, z - sz * .39),
            (x - tilt * .053 + .012, y - sy * .76, z - sz * .50),
        ], .012, hair_light)
    for side in (-1, 1):
        ell(f"GEP | curly moustache base {side}", (.099 * side + .026, -.308, 2.808),
                (.141, .073, .050), hair_light, (.12, .13 * side, -.30 * side))
        for row in range(3):
            z = 2.780 + row * .022
            tube(f"GEP | curled moustache strand {side} {row}", [
                (.015 * side + .025, -.358, z + .020),
                (.093 * side + .026, -.380, z + .004),
                (.184 * side + .026, -.351, z + .023),
                (.220 * side + .026, -.299, z + .052),
            ], .014, hair if row == 0 else hair_light)

    ell("GEP | nose bridge", (.035, -.271, 2.997), (.071, .084, .134), skin,
            (-.18, -.13, 0))
    ell("GEP | soft round nose", (.052, -.338, 2.911), (.104, .111, .083), cheeks,
            (-.15, -.10, .02))
    ell("GEP | nose base left", (-.006, -.340, 2.872), (.051, .069, .039), skin)
    ell("GEP | nose base right", (.102, -.331, 2.876), (.059, .061, .039), cheeks)

    for side in (-1, 1):
        x = .137 * side + .026
        y = -.275 + .016 * side
        z = 3.007 + .013 * side
        ell(f"GEP | eye white {side}", (x, y, z), (.076, .046, .088), ivory,
                (.03, -.18 * side, -.10 * side))
        ell(f"GEP | aged lower lid {side}", (x + .009 * side, y - .016, z - .070),
                (.074, .026, .027), skin, (0, -.17 * side, .09 * side))
        tube(f"GEP | under-eye crease {side}", [
            (x - .044 * side, y - .024, z - .085),
            (x + .009 * side, y - .039, z - .097),
            (x + .066 * side, y - .026, z - .081),
        ], .005, cheeks)
        for row in range(2):
            tube(f"GEP | temple smile line {side} {row}", [
                (x + .073 * side, y + .009, z - .011 - .020 * row),
                (x + .100 * side, y + .018, z - .018 - .025 * row),
                (x + .119 * side, y + .032, z - .008 - .032 * row),
            ], .0045, cheeks)
        ell(f"GEP | hazel iris {side}", (x + .017, y - .042, z + .006),
                (.043, .020, .057), iris, (0, -.07, .05))
        ell(f"GEP | pupil {side}", (x + .021, y - .058, z + .006),
                (.026, .010, .038), ink)
        ell(f"GEP | catchlight {side}", (x + .008, y - .067, z + .025),
                (.011, .006, .013), ivory)
        tube(f"GEP | upper eyelid {side}", [
            (x - .071, y - .015, z + .016), (x - .042, y - .027, z + .073),
            (x + .011, y - .030, z + .094), (x + .057, y - .015, z + .055),
        ], .010, inner_ear)
        tube(f"GEP | raised silver eyebrow {side}", [
            (x - .073 * side, y - .005, z + .130),
            (x - .009 * side, y - .008, z + .152),
            (x + .054 * side, y + .014, z + .119),
            (x + .086 * side, y + .040, z + .086),
        ], .024, hair)
        tube(f"GEP | upper forehead brow strands {side}", [
            (x - .064 * side, y - .020, z + .138),
            (x - .002 * side, y - .026, z + .162),
            (x + .061 * side, y - .007, z + .120),
        ], .008, hair_light)
        # The lenses are open to keep the expression legible in a clay preview.
        rim_x = x + .016
        rim_z = z - .054
        rim_y = y - .099
        rim = []
        for step in range(24):
            angle = 2 * pi * step / 24
            rim.append((rim_x + .085 * cos(angle),
                        rim_y + .021 * side * cos(angle),
                        rim_z + .085 * sin(angle)))
        tube(f"GEP | round spectacle rim {side}", rim, .009, bronze, cyclic=True)
        tube(f"GEP | spectacle temple {side}", [
            (rim_x + .080 * side, rim_y + .021, rim_z + .020),
            (rim_x + .152 * side, rim_y + .091, rim_z + .008),
            (.357 * side + .015, -.100, 2.945),
        ], .008, bronze)
        tube(f"GEP | smile crease {side}", [
            (.214 * side + .034, -.282, 2.914),
            (.239 * side + .034, -.288, 2.871),
            (.215 * side + .034, -.287, 2.840),
        ], .006, inner_ear)
    tube("GEP | spectacle bridge", [
        (-.017, -.359, 2.968), (.010, -.370, 2.993),
        (.065, -.370, 2.992), (.098, -.347, 2.976),
    ], .008, bronze)
