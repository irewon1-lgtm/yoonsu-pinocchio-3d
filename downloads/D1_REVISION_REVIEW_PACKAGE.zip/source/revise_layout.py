"""Build two static D1 poses on one measured 3D workshop set."""

import argparse
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Matrix, Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_scene as base


TABLE = {"x": (-4.13, -0.48), "y": (-0.48, 1.48), "z": 1.35}
GEP = (-2.84, -0.73, 0)
PIN_SLEEP = (-1.22, 0.275)
PIN_STAND = (-2.24, 0.02)
WINDOW = {"x": (1.52, 3.65), "z": (1.68, 3.91), "y": 2.32, "spring_z": 2.96}
PATH = [(2.585, 3.03, 1.85), (2.585, 2.32, 1.85), (2.585, 1.55, 1.85)]
SCALE = {"PIN": .57, "GEP": .69, "FAI": .49}
D = math.radians


def box(api, name, location, size, material, bevel=.025):
    x, y, z = (v / 2 for v in size)
    vertices = [(-x,-y,-z), (x,-y,-z), (x,y,-z), (-x,y,-z),
                (-x,-y,z), (x,-y,z), (x,y,z), (-x,y,z)]
    faces = [(0,3,2,1), (4,5,6,7), (0,1,5,4), (1,2,6,5), (2,3,7,6), (3,0,4,7)]
    obj = api.mesh(name, vertices, faces, material)
    obj.location = location
    if bevel:
        shape = obj.modifiers.new("Rounded woodworking edges", "BEVEL")
        shape.width = bevel
        shape.segments = 3
        obj.modifiers.new("Weighted normals", "WEIGHTED_NORMAL")
    return obj


def around(pivot, degrees, axis):
    return Matrix.Translation(pivot) @ Matrix.Rotation(D(degrees), 4, axis) @ Matrix.Translation(-Vector(pivot))


def posed_collection(source, name, transforms, omitted=()):
    coll = bpy.data.collections.new(name)
    for part in source.objects:
        short = part.name.split(" | ", 1)[-1]
        if any(token in short for token in omitted):
            continue
        obj = part.copy()
        coll.objects.link(obj)
        obj.matrix_world = transforms(short) @ part.matrix_world
    return coll


def pin_pose(source, sleeping):
    def transform(name):
        for side, sign, height in (("Right", -1, 1.531), ("Left", 1, 1.556)):
            if name.startswith((f"{side} upper arm", f"{side} forearm", f"{side} hand")):
                degrees = 73 if sleeping else 32
                return around((sign * .208, .015, height), sign * degrees, "Y")
        return Matrix.Identity(4)

    omitted = ("Ivory oval eye", "Brown iris", "Deep pupil", "Eye main gleam", "Eye lower gleam",
               "Eye socket rim", "Upper eyelid", "Eye highlight", "Smile opening",
               "Open smile", "Smile upper teeth", "Smile tongue", "Carved lower lip", "Mouth cavity") if sleeping else ()
    coll = posed_collection(source, "PIN • sleeping" if sleeping else "PIN • standing", transform, omitted)
    if sleeping:
        api = base.Geometry(coll)
        wood = bpy.data.materials["PIN | Warm cheek finish"]
        ink = api.mat("Closed eyelid line", "5B3222")
        for x in (-.116, .116):
            api.ell("PIN | closed eyelid volume", (x, -.255, 2.134), (.084,.052,.077), wood)
            api.tube("PIN | closed eyelid curve", [(x-.061,-.287,2.144), (x,-.308,2.126),
                                                   (x+.06,-.283,2.145)], .008, ink)
        api.tube("PIN | closed mouth", [(-.085,-.248,1.980), (0,-.277,1.966),
                                         (.085,-.249,1.981)], .008, ink)
    return coll


def geppetto_pose(source, sleeping):
    arm_prefixes = ("open ", "turned cuff", "palm crease")
    shoulder = (.474, -.026, 2.030)
    lean = around((0, 0, 1.10), 6 if sleeping else -8, "X")
    fixed = ("boot ", "toe welt", "trouser ", "turned trouser cuff", "cuff stitch")
    def transform(name):
        if name.startswith(fixed):
            return Matrix.Identity(4)
        if name.startswith(arm_prefixes):
            return lean @ around(shoulder, -3 if sleeping else -25, "Y")
        if not sleeping and name.startswith("raised silver eyebrow"):
            return lean @ Matrix.Translation((0, -.008, .055))
        return lean

    omitted = () if sleeping else ("smiling mouth volume", "tongue inside smile", "lower lip")
    coll = posed_collection(source, "GEP • observing" if sleeping else "GEP • reacting", transform, omitted)
    if not sleeping:
        api = base.Geometry(coll)
        api.ell("GEP | surprised open mouth", lean @ Vector((.035,-.337,2.587)),
                (.078,.055,.096), bpy.data.materials["GEP | mouth interior"])
    return coll


def rotation(roll, yaw, pitch=0):
    return Matrix.Rotation(D(yaw), 4, "Z") @ Matrix.Rotation(D(roll), 4, "X") @ Matrix.Rotation(D(pitch), 4, "Y")


def point_cloud(coll, transform):
    # D1 support checks use vertices from actual modeled meshes.
    return [transform @ obj.matrix_world @ vertex.co
            for obj in coll.objects if obj.type == "MESH"
            for vertex in obj.data.vertices]


def instance_mesh_points(root, depsgraph):
    """Read evaluated mesh vertices at their collection-instance transforms."""
    parts = {}
    for item in depsgraph.object_instances:
        if item.is_instance and item.parent.original == root and item.object.type == "MESH":
            matrix = item.matrix_world.copy()
            parts[item.object.name] = [matrix @ vertex.co for vertex in item.object.data.vertices]
    return parts


def instance(scene, name, coll, location, orientation, scale):
    obj = bpy.data.objects.new(name, None)
    obj.instance_type = "COLLECTION"
    obj.instance_collection = coll
    scene.collection.objects.link(obj)
    obj.matrix_world = Matrix.Translation(location) @ orientation @ Matrix.Scale(scale, 4)
    return obj


def room_geometry(set_collection):
    api = base.Geometry(set_collection)
    edge = api.mat("Workshop amber oak edge", "92572C")
    table = api.mat("Workshop lacquered walnut tabletop", "BA8044")
    beam = api.mat("Workshop joinery", "664024")
    plank = [api.mat("Floor plank " + str(i), color)
             for i,color in enumerate(("A36A42","AB7147","A06840","A97047"))]
    iron = api.mat("Forged tool head", "465158", .47, .36)
    grip = api.mat("Turned tool grip", "955926")
    window = api.mat("Window painted dark blue", "414350")
    curtain = [api.mat("Curtain fold " + str(i), c)
               for i,c in enumerate(("792D35","A63B41","B24B4C"))]
    ribbon = api.mat("Curtain tie", "C28A48")

    for i in range(23):
        box(api, f"FLOOR_PLANK_{i:02}", (0, -8.2 + i*.55, -.075),
            (18,.547,.15), plank[i % len(plank)], .004)
    xmin, xmax = TABLE["x"]
    ymin, ymax = TABLE["y"]
    box(api, "WORKTOP_SUPPORT", ((xmin+xmax)/2,(ymin+ymax)/2,1.275),
        (xmax-xmin,ymax-ymin,.15), table, .009)
    box(api, "WORKTOP_FRONT_EDGE", ((xmin+xmax)/2,ymin+.023,1.267),
        (xmax-xmin,.047,.152), edge, .008)
    for x in (xmin+.19, xmax-.19):
        for y in (ymin+.17,ymax-.17):
            box(api, "TABLE_LEG", (x,y,.59), (.25,.25,1.18), beam)
    box(api,"TABLE_FRONT_APRON",((xmin+xmax)/2,ymin+.09,1.10),
        (xmax-xmin-.15,.135,.19), edge)
    box(api,"TABLE_LOWER_STRETCHER",((xmin+xmax)/2,ymax-.24,.34),
        (xmax-xmin-.25,.18,.20), beam)
    tool_boxes = []
    for x, y, label in ((-2.30,1.14,"MALLET"),(-1.45,1.13,"CHISEL")):
        if label == "MALLET":
            size = (.48,.15,.21)
            box(api, "TOOL_MALLET_HEAD", (x,y,1.45), size, grip)
            api.link("TOOL_MALLET_HANDLE", (x,y+.03,1.395), (x,y+.28,1.395), .039,.04, beam)
        else:
            size = (.44,.07,.075)
            box(api, "TOOL_CHISEL_BLADE", (x,y,1.3875), size, iron,.008)
            api.link("TOOL_CHISEL_GRIP", (x-.20,y,1.395),(x-.47,y,1.395), .042,.035,grip)
        tool_boxes.append({"name": label, "center_x": x, "near_y": y - size[1]/2})

    x0,x1 = WINDOW["x"]
    z0,z1 = WINDOW["z"]
    spring = WINDOW["spring_z"]
    y = WINDOW["y"]
    for x in (x0-.075,x1+.075):
        box(api,"WINDOW_JAMB",(x,y,(z0+spring)/2),(.15,.22,spring-z0+.14),window)
    center_x = (x0+x1)/2
    radius_x = (x1-x0)/2 + .075
    arch = [(center_x+radius_x*math.cos(math.pi*i/12),y,
             spring+(z1-spring+.075)*math.sin(math.pi*i/12)) for i in range(13)]
    api.tube("WINDOW_ARCH",arch,.07,window)
    box(api,"WINDOW_SILL",(center_x,y,z0-.075),(x1-x0+.3,.26,.15),window)
    api.link("CURTAIN_ROD",(x0-.70,y-.13,z1+.18),(x1+.70,y-.13,z1+.18),.041,.041,beam)
    for flank, sign in ((x0,-1),(x1,1)):
        for fold in range(5):
            x=flank+sign*(.138+.082*fold)
            api.tube("CURTAIN_PANEL_FOLD", [(x,y-.20,z1+.13),(x+sign*.06,y-.29,2.95),
                                            (x+sign*.10,y-.23,2.13),(x+sign*.12,y-.22,1.61)],
                     .061,curtain[fold % 3])
        box(api,"CURTAIN_TIE",(flank+sign*.349,y-.29,2.54),(.45,.105,.075),ribbon,.016)
    guide = api.tube("FAI_ENTRY_PATH_GUIDE",PATH,.012,iron)
    guide.hide_render = True
    return tool_boxes


def add_sleep_supports(scene, clouds):
    api = base.Geometry(scene.collection)
    linen = api.mat("S01 folded workcloth", "5E737C")
    marks = {}
    for name, cloud in clouds.items():
        contact = min(cloud, key=lambda p: p.z)
        height = contact.z - TABLE["z"]
        width, depth = (.39,.36) if name == "head" else (.32,.43)
        box(api, f"SUPPORT_{name}", (contact.x,contact.y,TABLE["z"]+height/2),
            (width,depth,height), linen,.018)
        marks[name] = list(contact)
    return marks


def construct_pose(scene, collections, sleeping):
    base.configure(scene, 1440, 810, 28)
    pin = pin_pose(collections["PIN"], sleeping)
    gep = geppetto_pose(collections["GEP"], sleeping)
    for coll in (pin, gep):
        scene.collection.children.link(coll)
    bpy.context.view_layer.update()
    phi = Matrix.Rotation(D(8),4,"Y") @ rotation(-90,90) if sleeping else rotation(0,-34)
    x, y = PIN_SLEEP if sleeping else PIN_STAND
    raw = point_cloud(pin, Matrix.Translation((x,y,0)) @ phi @ Matrix.Scale(SCALE["PIN"],4))
    minimum = min(p.z for p in raw)
    z = TABLE["z"] - minimum + (.04 if sleeping else 0)
    pin_root = instance(scene, "PIN_ROOT", pin, (x,y,z), phi, SCALE["PIN"])

    gep_orientation = rotation(0, 68)
    gep_pre = Matrix.Translation(GEP) @ gep_orientation @ Matrix.Scale(SCALE["GEP"],4)
    gep_raw = point_cloud(gep, gep_pre)
    gep_z = -min(p.z for p in gep_raw)
    gep_root = instance(scene, "GEP_ROOT", gep, (GEP[0],GEP[1],gep_z),
                        gep_orientation,SCALE["GEP"])
    instance(scene,"FAI_WINDOW_POSE",collections["FAI"],PATH[-1],rotation(0,-16),SCALE["FAI"])
    for coll in (pin, gep):
        scene.collection.children.unlink(coll)
    scene.frame_set(1)
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    pin_parts = instance_mesh_points(pin_root,depsgraph)
    pin_world = [p for points in pin_parts.values() for p in points]
    gep_world = [p for points in instance_mesh_points(gep_root,depsgraph).values() for p in points]

    sleep_support = {}
    if sleeping:
        clouds = {"head": [p for p in pin_world if p.x < -2.23],
                  "back": [p for p in pin_world if -2.16 < p.x < -1.83],
                  "legs": [p for p in pin_world if -1.63 < p.x < -1.34]}
        sleep_support = add_sleep_supports(scene,clouds)

    lean = around((0, 0, 1.10), 6 if sleeping else -8, "X")
    local_shoulder = Vector((.474,-.026,2.030))
    shoulder = gep_root.matrix_world @ lean @ local_shoulder
    elbow = Vector((.791,-.040,1.809))
    local_palm = Vector((1.225,-.123,2.071))
    reach = ((elbow-local_shoulder).length+(local_palm-elbow).length)*SCALE["GEP"]
    eligible = [p for p in pin_world if p.z > 1.49]
    target = min(eligible,key=lambda p:(p-shoulder).length)
    palm = next(obj for obj in gep.objects if "open palm" in obj.name)
    data = {
        "pin_root": list(pin_root.location), "gep_root": list(gep_root.location),
        "depth_gap": abs(pin_root.location.y-gep_root.location.y),
        "pin_bounds": [[min(p[i] for p in pin_world),max(p[i] for p in pin_world)] for i in range(3)],
        "gep_floor_min": min(p.z for p in gep_world),
        "gep_shoulder": list(shoulder), "gep_palm": list(gep_root.matrix_world @ palm.matrix_world.translation),
        "reach_target": list(target), "shoulder_target_distance": (target - shoulder).length,
        "reach_limit": reach, "sleep_contact_points": sleep_support,
    }
    if not sleeping:
        for side in ("Left","Right"):
            points = next(points for name,points in pin_parts.items() if f"{side} boot / outsole" in name)
            data[f"{side.lower()}_sole_min"] = min(p.z for p in points)
    return data


def stage_lights(scene):
    base.area(scene,"Workshop key",(-5,-4,6),(-2,0,1.4),620,4.5,(1,.79,.56))
    base.area(scene,"Gentle moon fill",(4,-2,6),(2,0,2.2),270,5,(.67,.83,1))
    base.area(scene,"Face fill",(0,-7,5),(-2,0,1.8),440,6,(1,.95,.86))


def render_contacts(scene, stage, backdrop, destination):
    scene.camera = stage
    backdrop.hide_render = True
    base.render(scene,destination)
    backdrop.hide_render = False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("locked_source",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--only-stage",action="store_true")
    parser.add_argument("--save-only",action="store_true")
    args = parser.parse_args(sys.argv[sys.argv.index("--")+1:])
    out = args.output.resolve()
    out.mkdir(parents=True,exist_ok=True)
    (out/"views").mkdir(exist_ok=True)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sleeping = bpy.context.scene
    sleeping.name = "C06_STATIC_SLEEP"
    standing = bpy.data.scenes.new("C07_STATIC_STAND")
    collections, charts = {}, {}
    for key,module in base.CHARACTERS.items():
        coll = bpy.data.collections.new(f"CHAR_{key} • refined design")
        sleeping.collection.children.link(coll)
        module.build(base.Geometry(coll))
        sleeping.collection.children.unlink(coll)
        collections[key] = coll
        charts[key] = base.studio(key,coll)
        bpy.context.window.scene = sleeping

    common = bpy.data.collections.new("S01 • shared physical workshop")
    sleeping.collection.children.link(common)
    standing.collection.children.link(common)
    props = room_geometry(common)
    state = {"C06": construct_pose(sleeping,collections,True),
             "C07": construct_pose(standing,collections,False)}
    bpy.context.window.scene = sleeping
    main_cam = base.camera(sleeping,(.55,-13,6.55),(.43,.1,1.93),9.2)
    alt_cam = base.camera(sleeping,(3.8,-9,7.7),(-1.18,.25,1.52),8.75)
    for obj in (main_cam,alt_cam):
        common.objects.link(obj)
        sleeping.collection.objects.unlink(obj)
    sleeping.camera = main_cam
    standing.camera = main_cam
    bg = args.locked_source/"APPROVED_BG"/base.BACKGROUND_NAME
    base.add_backplate(sleeping, main_cam, bg)
    backdrop = next(obj for obj in sleeping.objects if obj.name.startswith("BG_WORKSHOP_02"))
    common.objects.link(backdrop)
    sleeping.collection.objects.unlink(backdrop)
    for scene in (sleeping,standing):
        stage_lights(scene)
        scene["review_status"] = "REVIEW_REQUIRED"
        scene["D1_only"] = "Static mesh review; stand and sleep are separate poses"
    cloud = point_cloud(collections["FAI"],rotation(0,-16) @ Matrix.Scale(SCALE["FAI"],4))
    coordinates = {
        "previous_depth_gap": 4.821282386779785, "background_sha256": base.BACKGROUND_SHA,
        "world_units": "Blender units", "tabletop": TABLE, "floor_z": 0,
        "window_opening": WINDOW, "fairy_entry_path": PATH, "props": props,
        "fairy_window_clearance": {
            "x": [PATH[1][0]+min(p.x for p in cloud),PATH[1][0]+max(p.x for p in cloud)],
            "z": [PATH[1][2]+min(p.z for p in cloud),PATH[1][2]+max(p.z for p in cloud)],
        },
        "scales": SCALE, "primary_camera": list(main_cam.location), "diagnostic_camera": list(alt_cam.location),
        "states": state,
    }
    (out/"D1_LAYOUT_COORDINATES.json").write_text(json.dumps(coordinates,indent=2)+"\n")
    bpy.context.window.scene = sleeping
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.spaces.active.region_3d.view_perspective = "CAMERA"
                area.spaces.active.shading.color_type = "MATERIAL"
    dest = out/"D1_LAYOUT_PREVIEW.blend"
    if dest.exists():
        raise FileExistsError(dest)
    bpy.ops.wm.save_as_mainfile(filepath=str(dest),compress=True)
    if args.save_only:
        return
    for scene,stem in ((sleeping,"C06"),(standing,"C07")):
        word = "SLEEPING" if stem=="C06" else "STANDING"
        base.render(scene,out/f"D1_{stem}_{word}_PREVIEW.png")
        render_contacts(scene,alt_cam,backdrop,out/f"D1_{stem}_CONTACT_ANGLE.png")
        scene.camera = main_cam
    if not args.only_stage:
        for key,scene in charts.items():
            for angle,frame in (("front",1),("three_quarter",9),("profile",19)):
                scene.frame_set(frame)
                base.render(scene,out/"views"/f"{key}_{angle}.png")


if __name__ == "__main__":
    main()
