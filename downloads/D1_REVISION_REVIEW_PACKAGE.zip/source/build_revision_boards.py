"""Assemble D1 revision boards from the approved background and static Blender renders."""

import argparse
from pathlib import Path

from PIL import Image, ImageDraw

from build_boards import BG_NAME, CARD, INK, LINE, MUTED, PAPER, TEAL, fitted, head, label, master


POSES = ("C06  잠든 자세", "C07  선 자세")
MAIN_PREVIEWS = ("D1_C06_SLEEPING_PREVIEW.png", "D1_C07_STANDING_PREVIEW.png")
CONTACT_PREVIEWS = ("D1_C06_CONTACT_ANGLE.png", "D1_C07_CONTACT_ANGLE.png")
LEFTS = (66, 1168)
VIEW_WIDTH = 1036
VIEW_HEIGHT = 583


def pose_pair(image, draw, output, filenames, top):
    for left, title, filename in zip(LEFTS, POSES, filenames, strict=True):
        label(draw, (left, top), title, 26, INK, True)
        fitted(image, output / filename, (left, top + 46, VIEW_WIDTH, VIEW_HEIGHT))


def blocking(locked, output):
    image = Image.new("RGB", (2270, 1334), PAPER)
    draw = ImageDraw.Draw(image)
    head(
        draw,
        "작업실 공간 블로킹",
        "한 카메라에서 잠든 자세와 선 자세를 비교합니다. 작업대와 바닥은 두 자세에서 같은 3D 구조를 씁니다.",
        "D1 수정 시안",
    )
    pose_pair(image, draw, output, MAIN_PREVIEWS, 259)

    label(draw, (66, 916), "승인 작업실 배경", 24, TEAL, True)
    fitted(image, locked / "APPROVED_BG" / BG_NAME, (66, 959, 592, 333))
    draw.rounded_rectangle((703, 959, 2204, 1292), radius=16, fill=CARD, outline=LINE, width=2)

    notes = (
        ("작업대", "피노키오가 잠든 자세와 선 자세에서 같은 상판에 놓이는지 확인합니다."),
        ("바닥과 공구", "제페토의 발과 바닥, 작업대 위 공구의 깊이와 가림을 확인합니다."),
        ("창문과 커튼", "오른쪽 아치와 커튼의 3D 구조를 승인 배경과 비교합니다."),
    )
    for index, (title, detail) in enumerate(notes):
        y = 1005 + index * 85
        label(draw, (746, y), title, 26, TEAL, True)
        label(draw, (968, y), detail, 26, MUTED)

    image.save(output / "D1_SPACE_BLOCKING_BOARD.png", optimize=True)


def contact(output):
    image = Image.new("RGB", (2270, 1760), PAPER)
    draw = ImageDraw.Draw(image)
    head(
        draw,
        "작업대와 바닥 접촉 검토",
        "같은 작업대 위 C06·C07 정지 포즈를 메인 카메라와 측면 확인 카메라에서 비교합니다.",
        "D1 정지 포즈",
    )
    label(draw, (66, 254), "메인 카메라 · 승인 배경과 합성", 26, TEAL, True)
    pose_pair(image, draw, output, MAIN_PREVIEWS, 304)

    draw.line((66, 955, 2204, 955), fill=LINE, width=2)
    label(draw, (66, 983), "접촉 확인 카메라 · 3D 작업실 구조", 26, TEAL, True)
    pose_pair(image, draw, output, CONTACT_PREVIEWS, 1033)

    label(
        draw,
        (66, 1698),
        "C06은 누운 몸과 상판, C07은 부츠와 상판을 확인합니다. 두 자세에서 제페토의 발과 바닥을 함께 살펴봅니다.",
        24,
        MUTED,
    )
    image.save(output / "D1_WORLD_CONTACT_CHECK.png", optimize=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("locked_source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    master(args.locked_source, args.output)
    blocking(args.locked_source, args.output)
    contact(args.output)


if __name__ == "__main__":
    main()
