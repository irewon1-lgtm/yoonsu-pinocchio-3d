"""Build and render the S01 D1 static review scenes in Blender 4.3."""

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fairy
import geppetto
import pinocchio


BACKGROUND_NAME = "image-gen-2(20261116-125801).png"
BACKGROUND_SHA = "18ebc03242c327d2f262a7e6dfa945917d8ca499abe3233af50b547592cbb1fa"
CHARACTERS = {"PIN": pinocchio, "GEP": geppetto, "FAI": fairy}
ANGLES = {"front": 0, "three_quarter": -42, "profile": -90}
# Normalized original-image coordinates, floor/worktop/entry Z, scale and turn.
POSITIONS = {
    "GEP": ((0.266, 0.920), 0.0, 0.73, 21),
    "PIN": ((0.334, 0.541), 1.25, 0.60, -16),
    "FAI": ((0.746, 0.454), 2.75, 0.55, -18),
}


def linear_channel(channel):
    value = channel / 255
    return value / 12.92 if value < 0.04045 else ((value + 0.055) / 1.055) ** 2.4


class Geometry:
    """Create actual meshes and curves in one character collection."""

    def __init__(self, collection):
        self.collection = collection

    def mat(self, name, color, roughness=0.72, metallic=0.0):
        color = color.lstrip("#")
        rgb = [linear_channel(int(color[i:i + 2], 16)) for i in (0, 2, 4)]
        material = bpy.data.materials.new(name)
        material.diffuse_color = (*rgb, 1)
        material.use_nodes = True
        bsdf = material.node_tree.nodes.get("Principled BSDF")
        bsdf.inputs["Base Color"].default_value = (*rgb, 1)
        bsdf.inputs["Roughness"].default_value = roughness
        bsdf.inputs["Metallic"].default_value = metallic
        bsdf.inputs["Specular IOR Level"].default_value = 0.24
        return material

    def finish(self, obj, name, material, smooth):
        obj.name = name
        for collection in list(obj.users_collection):
            collection.objects.unlink(obj)
        self.collection.objects.link(obj)
        obj.data.materials.append(material)
        if smooth and obj.type == "MESH":
            for polygon in obj.data.polygons:
                polygon.use_smooth = True
        return obj

    def ell(self, name, location, scale, material, rotation=(0, 0, 0)):
        bpy.ops.mesh.primitive_uv_sphere_add(segments=28, ring_count=18, location=location)
        obj = bpy.context.object
        obj.scale = scale
        obj.rotation_euler = rotation
        return self.finish(obj, name, material, True)

    def link(self, name, a, b, r1, r2, material, vertices=32):
        a, b = Vector(a), Vector(b)
        axis = b - a
        bpy.ops.mesh.primitive_cone_add(
            vertices=vertices, radius1=r1, radius2=r2, depth=axis.length, location=(a + b) / 2
        )
        obj = bpy.context.object
        obj.rotation_euler = axis.to_track_quat("Z", "Y").to_euler()
        return self.finish(obj, name, material, True)

    def capsule(self, name, a, b, radius, material):
        a, b = Vector(a), Vector(b)
        axis = b - a
        return self.ell(
            name, (a + b) / 2, (radius, radius, axis.length / 2 + radius * 0.55),
            material, axis.to_track_quat("Z", "Y").to_euler(),
        )

    def tube(self, name, points, radius, material, cyclic=False):
        curve = bpy.data.curves.new(name, "CURVE")
        curve.dimensions = "3D"
        curve.resolution_u = 16
        curve.bevel_depth = radius
        curve.bevel_resolution = 3
        curve.use_fill_caps = True
        spline = curve.splines.new("BEZIER")
        spline.bezier_points.add(len(points) - 1)
        for point, coordinate in zip(spline.bezier_points, points):
            point.co = coordinate
            point.handle_left_type = "AUTO"
            point.handle_right_type = "AUTO"
        spline.use_cyclic_u = cyclic
        obj = bpy.data.objects.new(name, curve)
        return self.finish(obj, name, material, False)

    def mesh(self, name, vertices, faces, material, smooth=False):
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(vertices, [], faces)
        mesh.update()
        return self.finish(bpy.data.objects.new(name, mesh), name, material, smooth)


def aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def configure(scene, width, height, samples):
    bpy.context.window.scene = scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = samples
    scene.cycles.use_denoising = False
    scene.cycles.max_bounces = 4
    scene.render.threads_mode = "FIXED"
    scene.render.threads = 4
    scene.render.resolution_x = width
    scene.render.resolution_y = height
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.render.fps = 24
    scene.view_settings.view_transform = "Standard"
    scene.world = bpy.data.worlds.new(f"{scene.name} Ambient")
    scene.world.use_nodes = True
    background = scene.world.node_tree.nodes.get("Background")
    background.inputs["Color"].default_value = (0.45, 0.51, 0.63, 1)
    background.inputs["Strength"].default_value = 0.33


def camera(scene, location, target, width):
    data = bpy.data.cameras.new(f"{scene.name} Camera")
    data.type = "ORTHO"
    data.sensor_fit = "HORIZONTAL"
    data.ortho_scale = width
    obj = bpy.data.objects.new(data.name, data)
    scene.collection.objects.link(obj)
    obj.location = location
    aim(obj, target)
    scene.camera = obj
    bpy.context.view_layer.update()
    return obj


def area(scene, name, location, target, power, size, color):
    data = bpy.data.lights.new(name, "AREA")
    data.energy, data.shape, data.size, data.color = power, "DISK", size, color
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    obj.location = location
    aim(obj, target)


def studio_lights(scene):
    area(scene, "Warm soft key", (-4, -5, 7), (0, 0, 1.5), 530, 5, (1, 0.88, 0.75))
    area(scene, "Cool fill", (4, -3, 4), (0, 0, 1.5), 320, 4, (0.78, 0.86, 1))
    area(scene, "Top separation", (1, 4, 5), (0, 0, 1.5), 480, 3, (1, 0.92, 0.81))


def studio(key, collection):
    scene = bpy.data.scenes.new(f"TURN_{key}")
    configure(scene, 560, 650, 28)
    scene.collection.children.link(collection)
    bpy.context.view_layer.update()
    bounds = [
        obj.matrix_world @ Vector(corner)
        for obj in collection.objects
        if obj.type in {"MESH", "CURVE"}
        for corner in obj.bound_box
    ]
    assert bounds and any(obj.type == "MESH" for obj in collection.objects)
    x_min = min(p.x for p in bounds)
    x_max = max(p.x for p in bounds)
    z_min = min(p.z for p in bounds)
    z_max = max(p.z for p in bounds)
    target = Vector(((x_min + x_max) / 2, 0, (z_min + z_max) / 2))
    width = max((x_max - x_min) * 1.29, (z_max - z_min) * 560 / 650 * 1.24)
    api = Geometry(scene.collection)
    floor = api.mat("Studio • warm parchment", "C8B49B")
    api.mesh("Matte studio sweep", [(-100, -100, z_min - 0.015), (100, -100, z_min - 0.015),
                                    (100, 100, z_min - 0.015), (-100, 100, z_min - 0.015)],
             [(0, 1, 2, 3)], floor)
    studio_lights(scene)
    cam = camera(scene, (0, -9, target.z + 1.12), target, width)
    scene.frame_start, scene.frame_end = 1, 72
    # Key every orbit position to let the review scene play in the viewport.
    for frame in range(1, 73):
        radians = -(frame - 1) * math.tau / 72
        cam.location = target + Vector((9 * math.sin(radians), -9 * math.cos(radians), 1.12))
        aim(cam, target)
        cam.keyframe_insert("location", frame=frame)
        cam.keyframe_insert("rotation_euler", frame=frame)
    scene.frame_set(1)
    return scene


def camera_frame(scene, cam):
    corners = cam.data.view_frame(scene=scene)
    return max(v.x for v in corners) * 2, max(v.y for v in corners) * 2


def world_point(scene, cam, uv, z):
    width, height = camera_frame(scene, cam)
    rotation = cam.rotation_euler.to_matrix()
    offset = rotation @ Vector(((uv[0] - 0.5) * width, (0.5 - uv[1]) * height, 0))
    start = cam.location + offset
    direction = rotation @ Vector((0, 0, -1))
    return start + direction * ((z - start.z) / direction.z)


def add_backplate(scene, cam, path):
    with path.open("rb") as file:
        if hashlib.file_digest(file, "sha256").hexdigest() != BACKGROUND_SHA:
            raise ValueError("The approved workshop background SHA-256 does not match")
    image = bpy.data.images.load(str(path), check_existing=False)
    image.name = "APPROVED_BG_WORKSHOP_02"
    image.pack()
    data = bpy.data.materials.new("Approved background • camera contribution only")
    data.use_nodes = True
    nodes = data.node_tree.nodes
    links = data.node_tree.links
    nodes.clear()
    texture = nodes.new("ShaderNodeTexImage")
    texture.image = image
    texture.extension = "EXTEND"
    emit = nodes.new("ShaderNodeEmission")
    light_path = nodes.new("ShaderNodeLightPath")
    clear = nodes.new("ShaderNodeBsdfTransparent")
    mix = nodes.new("ShaderNodeMixShader")
    output = nodes.new("ShaderNodeOutputMaterial")
    links.new(texture.outputs["Color"], emit.inputs["Color"])
    links.new(light_path.outputs["Is Camera Ray"], mix.inputs[0])
    links.new(clear.outputs[0], mix.inputs[1])
    links.new(emit.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], output.inputs["Surface"])
    width, height = camera_frame(scene, cam)
    corners = [(-width / 2, -height / 2), (width / 2, -height / 2),
               (width / 2, height / 2), (-width / 2, height / 2)]
    vertices = [cam.matrix_world @ Vector((x, y, -29)) for x, y in corners]
    plane = Geometry(scene.collection).mesh("BG_WORKSHOP_02 • locked composition", vertices, [(0, 1, 2, 3)], data)
    uv = plane.data.uv_layers.new(name="Approved RGB image")
    for index, value in enumerate(((0, 0), (1, 0), (1, 1), (0, 1))):
        uv.data[index].uv = value
    plane.hide_select = True
    plane.display_type = "WIRE"
    plane["source_sha256"] = BACKGROUND_SHA
    cam.data.show_background_images = True
    preview = cam.data.background_images.new()
    preview.image = image
    preview.alpha = 1.0
    preview.frame_method = "FIT"
    return image


def add_contact_guides(scene, placements):
    material = bpy.data.materials.new("D1 soft contact guide • camera only")
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    nodes.clear()
    uv = nodes.new("ShaderNodeTexCoord")
    distance = nodes.new("ShaderNodeVectorMath")
    distance.operation = "DISTANCE"
    distance.inputs[1].default_value = (0.5, 0.5, 0)
    falloff = nodes.new("ShaderNodeMapRange")
    falloff.interpolation_type = "SMOOTHSTEP"
    falloff.inputs["From Min"].default_value = 0.03
    falloff.inputs["From Max"].default_value = 0.49
    falloff.inputs["To Min"].default_value = 0.56
    falloff.inputs["To Max"].default_value = 0
    ray = nodes.new("ShaderNodeLightPath")
    factor = nodes.new("ShaderNodeMath")
    factor.operation = "MULTIPLY"
    tint = nodes.new("ShaderNodeEmission")
    tint.inputs["Color"].default_value = (0.067, 0.032, 0.021, 1.0)
    transparent = nodes.new("ShaderNodeBsdfTransparent")
    mix = nodes.new("ShaderNodeMixShader")
    output = nodes.new("ShaderNodeOutputMaterial")
    links.new(uv.outputs["UV"], distance.inputs[0])
    links.new(distance.outputs["Value"], falloff.inputs["Value"])
    links.new(falloff.outputs["Result"], factor.inputs[0])
    links.new(ray.outputs["Is Camera Ray"], factor.inputs[1])
    links.new(factor.outputs[0], mix.inputs[0])
    links.new(transparent.outputs[0], mix.inputs[1])
    links.new(tint.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], output.inputs["Surface"])
    api = Geometry(scene.collection)
    for key, radius_x, radius_y in (("GEP", 0.53, 0.53), ("PIN", 0.41, 0.37)):
        x, y, z = placements[key]["location"]
        position = Vector((x, y - 0.13, z + 0.004))
        corners = [(-radius_x, -radius_y, 0), (radius_x, -radius_y, 0),
                   (radius_x, radius_y, 0), (-radius_x, radius_y, 0)]
        shadow = api.mesh(f"{key} • provisional contact shadow",
                          [position + Vector(corner) for corner in corners], [(0, 1, 2, 3)], material)
        shadow.display_type = "WIRE"
        shadow.hide_select = True
        layer = shadow.data.uv_layers.new()
        for index, value in enumerate(((0, 0), (1, 0), (1, 1), (0, 1))):
            layer.data[index].uv = value


def workshop(scene, collections, background):
    # Keep the native backplate aspect ratio in the render.
    configure(scene, 1672, 941, 20)
    cam = camera(scene, (0, -17, 7.1), (0, 0, 2.1), 12)
    add_backplate(scene, cam, background)
    area(scene, "Workshop lamp key", (-5, -5, 6.5), (-2, 0, 2), 480, 4, (1, 0.77, 0.51))
    area(scene, "Moonlight from the right", (4, -2, 6), (2, 0, 3), 280, 5, (0.66, 0.79, 1))
    area(scene, "Soft camera fill", (0, -9, 5), (0, 0, 2.3), 390, 7, (1, 0.94, 0.84))

    placements = {}
    for key, (uv, height, scale, yaw) in POSITIONS.items():
        position = world_point(scene, cam, uv, height)
        actor = bpy.data.objects.new(f"{key} • D1 reference placement", None)
        actor.instance_type = "COLLECTION"
        actor.instance_collection = collections[key]
        actor.empty_display_size = 0.32
        actor.location = position
        actor.scale = (scale,) * 3
        actor.rotation_euler.z = math.radians(yaw)
        scene.collection.objects.link(actor)
        projected = world_to_camera_view(scene, cam, position)
        assert abs(projected.x - uv[0]) < 0.0001 and abs(projected.y - (1 - uv[1])) < 0.0001
        placements[key] = {
            "uv_origin_top_left": uv, "location": list(position),
            "scale": scale, "yaw_deg": yaw,
        }
    add_contact_guides(scene, placements)

    helpers = bpy.data.collections.new("BLOCKING • guide volumes")
    scene.collection.children.link(helpers)
    api = Geometry(helpers)
    material = api.mat("Blocking guide", "438D84")
    mapped_table = [world_point(scene, cam, uv, 1.25)
                    for uv in ((0.10, 0.559), (0.38, 0.519), (0.37, 0.559), (0.10, 0.643))]
    top = api.mesh("PIN_WORKTABLE_CONTACT • Z 1.25", mapped_table, [(0, 1, 2, 3)], material)
    top.display_type = "WIRE"
    top.hide_render = True
    floor = api.mesh("GEP_FLOOR_CONTACT • Z 0", [(-6, -7, 0), (6, -7, 0), (6, 5, 0), (-6, 5, 0)],
                     [(0, 1, 2, 3)], material)
    floor.display_type, floor.hide_render = "WIRE", True
    window = bpy.data.objects.new("FAI_WINDOW_ENTRY • guide", None)
    window.location = world_point(scene, cam, (0.748, 0.286), 3.7)
    window.empty_display_type, window.empty_display_size = "CUBE", 0.32
    helpers.objects.link(window)
    scene["approval_state"] = "D1_REVIEW_REQUIRED"
    return placements


def render(scene, destination):
    bpy.context.window.scene = scene
    scene.render.filepath = str(destination)
    bpy.ops.render.render(write_still=True)
    if not destination.is_file():
        raise ValueError(f"Missing render {destination}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("locked_source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--save-only", action="store_true", help="Build an editable .blend without rendering")
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    views = output / "views"
    views.mkdir(exist_ok=True)
    blend = output / "D1_LAYOUT_PREVIEW.blend"
    if blend.exists():
        raise FileExistsError(blend)

    bpy.ops.wm.read_factory_settings(use_empty=True)
    layout = bpy.context.scene
    layout.name = "LAYOUT_WORKSHOP"
    collections = {}
    studios = {}
    for key, module in CHARACTERS.items():
        collection = bpy.data.collections.new(f"CHAR_{key} • review geometry")
        layout.collection.children.link(collection)
        module.build(Geometry(collection))
        layout.collection.children.unlink(collection)
        collections[key] = collection
        studios[key] = studio(key, collection)
        bpy.context.window.scene = layout
    placements = workshop(layout, collections, args.locked_source / "APPROVED_BG" / BACKGROUND_NAME)
    (output / "D1_LAYOUT_COORDINATES.json").write_text(json.dumps({
        "review_status": "REVIEW_REQUIRED", "backplate_sha256": BACKGROUND_SHA,
        "camera_ortho_width": 12, "world_z_up": True, "actors": placements,
    }, indent=2) + "\n", encoding="utf-8")
    for screen in bpy.data.screens:
        for area_ in screen.areas:
            if area_.type == "VIEW_3D":
                area_.spaces.active.region_3d.view_perspective = "CAMERA"
                area_.spaces.active.shading.type = "SOLID"
                area_.spaces.active.shading.color_type = "MATERIAL"
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(blend), compress=True)
    if args.save_only:
        return
    for key, scene in studios.items():
        for angle, degrees in ANGLES.items():
            scene.frame_set(1 + round(abs(degrees) / 5))
            render(scene, views / f"{key}_{angle}.png")
    render(layout, output / "D1_WORKSHOP_PREVIEW.png")


if __name__ == "__main__":
    main()
