"""D1 static, camera-locked workshop scale trials. Run using Blender --background --python."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import bpy
import numpy as np
from mathutils import Matrix, Vector
from scipy.optimize import linprog
from scipy.sparse import csr_matrix

SOURCE_SHA = "665f720858a318ab02ba848a33a0213083984f7cf419cd0648278c8a83b17363"
BG_SHA = "18ebc03242c327d2f262a7e6dfa945917d8ca499abe3233af50b547592cbb1fa"
TOP = 1.35
# Coordinates in the locked, top-left-origin painting. Sill/muntin/curtain
# are excluded from the pane; the bench outline deliberately stays inside the edge.
PANE = (.644, .258, .719, .400)
BENCH = [(0, .566), (.273, .492), (.391, .521), (.108, .635), (0, .606)]
SIZE = (1440, 810)
ACTORS = ("GEP", "PIN", "FAI")


def sha(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def matching(scene, prefix):
    return next(o for o in scene.objects if o.name.startswith(prefix))


def cloud(parts, select=lambda name: True):
    return np.concatenate([pts for name, pts in parts.items() if select(name)])


def bounds(pts):
    return np.stack((pts.min(axis=0), pts.max(axis=0)))


def points_for(roots):
    """Each evaluated mesh/converted curve in the scene, in instance space."""
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    result = {root.name: {} for root in roots}
    for inst in dg.object_instances:
        if not inst.is_instance or inst.parent is None:
            continue
        root = inst.parent.original.name
        obj = inst.object
        if root not in result or obj.type not in ("MESH", "CURVE", "SURFACE", "FONT") or obj.hide_render:
            continue
        mesh = obj.to_mesh()
        try:
            if mesh and len(mesh.vertices):
                coords = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
                mesh.vertices.foreach_get("co", coords)
                matrix = np.array(inst.matrix_world)
                result[root][obj.name] = coords.reshape(-1, 3) @ matrix[:3, :3].T + matrix[:3, 3]
        finally:
            obj.to_mesh_clear()
    return [result[o.name] for o in roots]


def project(camera, scene, pts):
    dg = bpy.context.evaluated_depsgraph_get()
    proj = camera.calc_matrix_camera(dg, x=scene.render.resolution_x, y=scene.render.resolution_y)
    matrix = np.array(proj @ camera.matrix_world.inverted())
    clip = pts @ matrix[:, :3].T + matrix[:, 3]
    xy = clip[:, :2] / clip[:, 3:4]
    return (xy * [.5, -.5] + .5) * SIZE


def ray_at(cam, u, v, plane, value):
    # The original locked workshop camera is orthographic.
    w = cam.data.ortho_scale
    start = cam.matrix_world @ Vector(((u - .5) * w, (.5 - v) * w * SIZE[1] / SIZE[0], 0))
    direction = cam.rotation_euler.to_matrix() @ Vector((0, 0, -1))
    return start + direction * ((value - start[plane]) / direction[plane])


def place_root(root, direction=None, position=None, scale=None):
    if direction is not None:
        root.rotation_euler = (0, 0, math.radians(direction))
    if position is not None:
        root.location = position
    if scale is not None:
        root.scale = (scale,) * 3


def evaluated_floor(root, z):
    pts = cloud(points_for([root])[0])
    root.location.z += z - pts[:, 2].min()


def mesh_object(scene, name, verts, faces):
    data = bpy.data.meshes.new(name)
    data.from_pydata(verts, [], faces)
    data.update()
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    return obj


def matte(scene, name, verts):
    obj = mesh_object(scene, name, verts, [tuple(range(len(verts)))])
    obj.is_shadow_catcher = True
    obj.display_type = "WIRE"
    return obj


def material(name, color):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1)
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (*color, 1)
    shader.inputs["Roughness"].default_value = .91
    return mat


def folded_linen(scene, pts, direction):
    """Fit one continuous linen fold to the underside of the sleeping static mesh."""
    across = np.array([-direction[1], direction[0]])
    xy = pts[:, :2]
    long = xy @ direction
    cross = xy @ across
    center = (cross.max() + cross.min()) / 2
    knots = np.linspace(long.min() - .06, long.max() + .06, 30)
    step = knots[1] - knots[0]
    spans = np.clip(np.searchsorted(knots, long) - 1, 0, len(knots) - 2)
    fraction = (long - knots[spans]) / step
    rows = np.repeat(np.arange(len(pts)), 2)
    cols = np.column_stack((spans, spans + 1)).ravel()
    coefficients = np.column_stack((1 - fraction, fraction)).ravel()
    contacts = csr_matrix((coefficients, (rows, cols)), shape=(len(pts), len(knots)))
    gradient = np.diff(np.eye(len(knots)), axis=0)
    from scipy.sparse import vstack
    constraints = vstack([contacts, gradient, -gradient]).tocsr()
    limits = np.r_[pts[:, 2] - .0005, np.full(2 * len(gradient), .55 * step)]
    fit = linprog(-np.ones(len(knots)), A_ub=constraints, b_ub=limits,
                  bounds=(TOP + .006, TOP + .16), method="highs")
    if not fit.success:
        raise ValueError(fit.message)
    heights = fit.x
    # Keep the contact surface flat across the body and taper only the edges.
    half = (cross.max() - cross.min()) / 2 + .005
    verts = []
    for i, length in enumerate(knots):
        width = half + .035 + .012 * math.sin(1.45 * i)
        for lateral, z in ((-width, TOP + .001), (-half, heights[i]), (half, heights[i]), (width, TOP + .001)):
            u, v = direction * length + across * (center + lateral)
            verts.append((u, v, z))
    faces = [(4*i+j, 4*i+j+4, 4*i+j+5, 4*i+j+1) for i in range(len(knots)-1) for j in range(3)]
    cloth = mesh_object(scene, "C06 folded flax on the painted worktop", verts, faces)
    cloth.data.materials.append(material("Undyed work linen", (.45, .31, .175)))
    cloth.data.materials.append(material("Woven red selvedge", (.25, .095, .052)))
    for i, face in enumerate(cloth.data.polygons):
        face.material_index = int(i // 3 in (2, 4, 24, 26))
        face.use_smooth = True
    return lambda array: array[:, 2] - np.interp(array[:, :2] @ direction, knots, heights)


def stool_matte():
    """Trace the foreground stool in the original 1672 x 941 painting."""
    from PIL import Image, ImageDraw
    from scipy.interpolate import splprep, splev
    import tempfile
    name = "Foreground stool • traced matte"
    if name in bpy.data.images:
        return bpy.data.images[name]
    width,height,ss = 1672,941,3
    img = Image.new("L",(width*ss,height*ss),0)
    painter = ImageDraw.Draw(img)
    def polygon(points):
        painter.polygon([(round(x*ss),round((675+y)*ss)) for x,y in points],fill=255)
    # Full-resolution pixels, measured from a crop starting at y=675.
    polygon([(90,102),(139,114),(106,267),(53,267)])
    polygon([(156,116),(192,120),(177,188),(145,188)])
    polygon([(210,117),(257,115),(280,269),(215,269)])
    polygon([(276,110),(325,95),(366,266),(314,273)])
    polygon([(110,205),(211,218),(215,253),(106,237)])
    polygon([(120,199),(160,179),(166,179),(165,202),(124,209)])
    polygon([(268,204),(309,188),(319,214),(272,236)])
    polygon([(183,174),(210,178),(211,204),(182,200)])
    # Closed periodic curve preserves the rounded top and undercut of the seat.
    seat=[(68,64),(70,57),(83,49),(110,42),(157,34),(207,30),(253,30),(291,35),
          (318,41),(333,47),(338,55),(340,68),(339,91),(337,97),(319,105),
          (291,114),(253,121),(210,125),(167,123),(125,118),(91,110),(73,103),(68,96)]
    curve,_=splprep(np.array(seat+[seat[0]]).T,s=0,per=True)
    polygon(np.array(splev(np.linspace(0,1,350),curve)).T)
    img=img.resize((width,height),Image.Resampling.LANCZOS)
    with tempfile.TemporaryDirectory() as tmp:
        f=Path(tmp)/"painted_stool_coverage.png"
        img.save(f)
        matte=bpy.data.images.load(str(f))
        matte.name=name
        matte.colorspace_settings.name="Non-Color"
        matte.pack()
    return matte


def beauty(scene, cam, room, bg, percent, samples):
    scene.camera = cam
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = samples
    scene.cycles.use_denoising = False
    scene.render.threads_mode = "FIXED"
    scene.render.threads = 2
    scene.render.resolution_x, scene.render.resolution_y = SIZE
    scene.render.resolution_percentage = percent
    scene.render.image_settings.color_mode = "RGB"
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = True
    for o in room.objects:
        if o.type != "CAMERA":
            o.hide_render = True
            o.hide_viewport = True
    for o in scene.collection.objects:
        if o.name.startswith("SUPPORT_"):
            o.hide_render = o.hide_viewport = True
    # Composite the untouched, packed painting as a separate 2D layer.
    scene.use_nodes = True
    nodes = scene.node_tree.nodes
    nodes.clear()
    plate = nodes.new("CompositorNodeImage")
    plate.image = bg
    fit = nodes.new("CompositorNodeScale")
    fit.space = "RENDER_SIZE"
    fit.frame_method = "STRETCH"
    render = nodes.new("CompositorNodeRLayers")
    over = nodes.new("CompositorNodeAlphaOver")
    output = nodes.new("CompositorNodeComposite")
    for sender, receiver in ((plate.outputs["Image"], fit.inputs["Image"]),
                             (fit.outputs["Image"], over.inputs[1]),
                             (render.outputs["Image"], over.inputs[2]),
                             (over.outputs[0], output.inputs[0])):
        scene.node_tree.links.new(sender, receiver)
    for node, position in ((plate, (-500, 130)), (fit, (-250, 130)),
                           (render, (-250, -160)), (over, (5, 50)), (output, (245, 50))):
        node.location = position
    # A small neighborhood filter on the 3D layer leaves the painted plate crisp.
    soften = nodes.new("CompositorNodeBilateralblur")
    soften.sigma_space, soften.sigma_color = 1.5, .12
    scene.node_tree.links.new(render.outputs["Image"], soften.inputs["Determinator"])
    soften.location = (-70, -155)
    scene.node_tree.links.new(render.outputs["Image"], soften.inputs["Image"])
    scene.node_tree.links.new(soften.outputs["Image"], over.inputs[2])
    # Restore original RGB only where the painted foreground stool covers an actor.
    fg = nodes.new("CompositorNodeImage")
    fg.image = stool_matte()
    fg.location = (-260,345)
    fgfit = nodes.new("CompositorNodeScale")
    fgfit.space = "RENDER_SIZE"
    fgfit.frame_method = "STRETCH"
    fgfit.location = (-70,345)
    restore = nodes.new("CompositorNodeMixRGB")
    restore.location = (225,160)
    output.location = (430,160)
    for sender, receiver in ((fg.outputs["Image"], fgfit.inputs["Image"]),
                             (fgfit.outputs["Image"], restore.inputs[0]),
                             (over.outputs["Image"], restore.inputs[1]),
                             (fit.outputs["Image"], restore.inputs[2]),
                             (restore.outputs["Image"],output.inputs[0])):
        scene.node_tree.links.new(sender,receiver)
    # The painted lamp is just above the tabletop, to the left of the adult.
    key = matching(scene, "Workshop key")
    key.location = (-3.6, -.3, 4.3)
    key.rotation_euler = (Vector((-.9, -.45, 1.4)) - key.location).to_track_quat("-Z", "Y").to_euler()
    key.data.energy, key.data.size = 215, 2.4
    key.data.color = (1, .77, .52)
    matching(scene, "Gentle moon fill").data.energy = 130
    matching(scene, "Face fill").data.energy = 215
    matte(scene, "Floor • shadow receiver", [(-8,-8,0),(8,-8,0),(8,6,0),(-8,6,0)])
    tabletop = [ray_at(cam, *uv, 2, TOP) for uv in BENCH]
    matte(scene, "Painted top • traced shadow receiver", tabletop[::-1])
    # A narrow physical linen runner covers the painted tool tops under the boy.
    # Its top is the same documented contact level in both static cuts.
    rear = np.array([ray_at(cam,*uv,2,TOP) for uv in ((.078,.589),(.282,.515))])
    front = np.array([ray_at(cam,*uv,2,TOP) for uv in ((.137,.618),(.341,.540))])
    verts = []
    for i in range(33):
        t = i / 32
        back = rear[0]*(1-t)+rear[1]*t
        edge = front[0]*(1-t)+front[1]*t
        for width in (0,.03,.05,.075,.091,.9,.925,.949,.967,1):
            xy = back*(1-width)+edge*width
            xy[2] += .00035
            verts.append(tuple(xy))
    faces = [(10*i+j,10*i+j+10,10*i+j+11,10*i+j+1) for i in range(32) for j in range(9)]
    linen = mesh_object(scene,"Work linen • shared static contact surface",verts,faces)
    linen.data.materials.append(material("Flax • warm eggshell",(.46,.34,.203)))
    linen.data.materials.append(material("Dyed linen border",(.215,.085,.052)))
    for i,face in enumerate(linen.data.polygons):
        face.material_index = int(i%9 in (1,3,6,8))
    return tabletop


def describe(scene, cameras, pts):
    bb = bounds(pts)
    projections = {}
    for label, cam in cameras.items():
        pixel = bounds(project(cam, scene, pts))
        projections[label] = {"bbox_ltrb_px": pixel.flatten(), "size_wh_px": pixel[1] - pixel[0],
                              "inside_frame": bool(np.all(pixel[0] >= 0) and np.all(pixel[1] <= SIZE))}
    return {"world_min_xyz": bb[0], "world_max_xyz": bb[1], "world_size_xyz": bb[1]-bb[0],
            "evaluated_vertices": len(pts), "projections": projections}


def min_signed_margin(points, polygon):
    # Signed distance from a sample inside this convex polygon to its closest edge.
    polygon = np.array(polygon)[:, :2]
    edge = np.roll(polygon, -1, axis=0) - polygon
    offset = points[:, None, :2] - polygon[None, :, :]
    area = np.sum(polygon[:, 0] * np.roll(polygon[:, 1], -1) -
                  polygon[:, 1] * np.roll(polygon[:, 0], -1))
    signed = (edge[:, 0] * offset[:, :, 1] - edge[:, 1] * offset[:, :, 0]) / np.linalg.norm(edge, axis=1)
    return float(np.min(np.sign(area) * signed))


def paths_and_clearance(scene, cam, fairy):
    # Check the whole evaluated silhouette swept along world Y through the pane.
    p = cloud(fairy)
    wing = cloud(fairy, lambda n: "wing" in n.lower())
    x0, y0, x1, y1 = PANE
    # Camera is slightly off the world Y axis. Four corners give true extents.
    aperture = np.array([ray_at(cam, u, v, 1, 2.32) for u, v in ((x0,y0),(x1,y0),(x1,y1),(x0,y1))])
    xz_polygon = aperture[:, [0, 2]]
    margin = min_signed_margin(p[:, [0, 2]], xz_polygon)
    body = cloud(fairy, lambda n: "wing" not in n.lower() and "wand" not in n.lower())
    projected = bounds(project(cam, scene, p))
    pane_px = np.array(PANE) * [SIZE[0], SIZE[1], SIZE[0], SIZE[1]]
    return {"pane_uv_top_left": PANE, "pane_world_corners_xyz": aperture,
            "pane_clear_width_world": np.linalg.norm(aperture[1] - aperture[0]),
            "full_arch_proxy_width_world": 2.13,
            "wing_width_world": np.ptp(wing[:, 0]),
            "body_height_excluding_wings_and_wand": np.ptp(body[:, 2]),
            "wing_over_clear_pane_world": np.ptp(wing[:, 0])/np.linalg.norm(aperture[1]-aperture[0]),
            "wing_over_full_arch_proxy_world": np.ptp(wing[:, 0])/2.13,
            "screen_full_silhouette_over_clear_pane": (projected[1,0]-projected[0,0])/(pane_px[2]-pane_px[0]),
            "static_frame_clearance_ltrb_px": np.r_[projected[0]-pane_px[:2], pane_px[2:]-projected[1]],
            "straight_y_sweep_min_frame_clearance_world": margin,
            "glass_open_and_wing_motion": "NOT_RUN: painted pane is closed; open sash geometry and articulated wing motion require approval."}


def export(scene, cam, path):
    bpy.context.window.scene = scene
    scene.camera = cam
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)
    if not path.is_file():
        raise RuntimeError(path)


def diagnostic(scene, camera, room, path):
    hidden = [(o, o.hide_render, o.hide_viewport) for o in room.objects]
    catchers = [o for o in scene.objects if o.is_shadow_catcher]
    ambient = scene.world.node_tree.nodes.get("Background").inputs["Strength"]
    saved_ambient, saved_samples = ambient.default_value, scene.cycles.samples
    ambient.default_value = 1.0
    scene.cycles.samples = min(scene.cycles.samples, 28)
    scene.render.film_transparent = False
    scene.render.use_compositing = False
    try:
        for o, _, _ in hidden:
            if o.type not in ("CAMERA", "EMPTY") and not o.name.startswith(("BG_WORKSHOP", "FAI_ENTRY", "TOOL_")):
                o.hide_render = o.hide_viewport = False
        for o in catchers:
            o.hide_render = True
        export(scene, camera, path)
    finally:
        for o, render, viewport in hidden:
            o.hide_render, o.hide_viewport = render, viewport
        for o in catchers:
            o.hide_render = False
        ambient.default_value, scene.cycles.samples = saved_ambient, saved_samples
        scene.render.use_compositing = True
        scene.render.film_transparent = True


def serialize(value):
    if isinstance(value, (np.ndarray, np.generic)):
        return value.tolist()
    raise TypeError(type(value))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("layout", type=Path)
    parser.add_argument("studio", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--percent", default=100, type=int)
    parser.add_argument("--samples", default=64, type=int)
    args = parser.parse_args(sys.argv[sys.argv.index("--")+1:])
    if sha(args.layout) != SOURCE_SHA:
        raise ValueError("Unexpected archive hash")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.open_mainfile(filepath=str(args.layout.resolve()))
    bg = bpy.data.images["APPROVED_BG_WORKSHOP_02"]
    if hashlib.sha256(bg.packed_file.data).hexdigest() != BG_SHA:
        raise ValueError("Packed background mismatch")
    with bpy.data.libraries.load(str(args.studio.resolve()), link=False) as (source, dest):
        if "GEP_LOOKDEV" not in source.collections:
            raise ValueError("GEP_LOOKDEV collection missing from studio")
        dest.collections = ["GEP_LOOKDEV"]
    character = dest.collections[0]
    if not character or not any(o.type == "MESH" for o in character.all_objects):
        raise ValueError("An evaluated character collection is required")
    world = bpy.data.scenes["C06_STATIC_SLEEP"]
    room = bpy.data.collections["S01 • shared physical workshop"]
    maincam = world.camera
    sidecam = next(o for o in room.objects if o.type == "CAMERA" and o != maincam)
    camdata = bpy.data.cameras.new("Eye-level 32 mm")
    camdata.lens = 32
    eyecam = bpy.data.objects.new("Diagnostic • eye-level perspective", camdata)
    room.objects.link(eyecam)
    eyecam.location = (1.6,-6.0,1.95)
    eyecam.rotation_euler = (Vector((-.7,.55,1.68))-eyecam.location).to_track_quat("-Z","Y").to_euler()
    cameras = {"locked": maincam, "diagonal": sidecam, "eye_level": eyecam}
    report = {"status": "VISUAL_REVIEW_REQUIRED", "units": "Blender world units",
              "background_sha256": BG_SHA, "layout_sha256": SOURCE_SHA, "studio_sha256": sha(args.studio),
              "pixel_reference_wh": SIZE, "render_percentage": args.percent,
              "render_settings":{"engine":"Cycles CPU","beauty_samples":args.samples,"diagnostic_samples":min(args.samples,28),"color_transform":"Standard","denoising":False,"compositor":"3D layer bilateral 1.5px, original plate, original-pixel stool foreground matte"},
              "initial_contact_proxies": "Inherited D1 coarse rectangular geometry shown only in technical views",
              "projection": "Evaluated vertices including tessellated curves, unoccluded silhouette envelope; pixels from top left.",
              "cameras": {label: {"type": cam.data.type, "xyz": list(cam.location), "euler": list(cam.rotation_euler),
              "ortho_width": cam.data.ortho_scale if cam.data.type=="ORTHO" else None, "lens_mm": cam.data.lens}
              for label, cam in cameras.items()}, "states": {}}
    scenes = [("C06", world), ("C07", bpy.data.scenes["C07_STATIC_STAND"])]
    archive = bpy.data.collections.new("BLOCKOUT_ARCHIVE • previous workshop adults")
    archive.use_fake_user = True
    for label, scene in scenes:
        bpy.context.window.scene = scene
        bpy.context.view_layer.update()
        pin = matching(scene, "PIN_ROOT")
        fairy = matching(scene, "FAI_WINDOW_POSE")
        prev = matching(scene, "GEP_ROOT")
        old = points_for([prev, pin, fairy])
        before = {k: describe(scene, {"locked":maincam}, cloud(values)) for k, values in zip(ACTORS, old)}
        archive.objects.link(prev)
        scene.collection.objects.unlink(prev)
        gep = bpy.data.objects.new("GEP • adult at bench", None)
        scene.collection.objects.link(gep)
        gep.instance_type, gep.instance_collection = "COLLECTION", character
        feet = ray_at(maincam,.123,.887,2,0)
        place_root(gep, 62, feet)
        adult = cloud(points_for([gep])[0])
        target_height = 2.50
        place_root(gep, scale=target_height/np.ptp(adult[:, 2]))
        evaluated_floor(gep, 0)
        tabletop = beauty(scene, maincam, room, bg, args.percent, args.samples)
        if label == "C06":
            rise = Matrix.Rotation(math.radians(20), 4, "Z") @ Matrix.Rotation(math.radians(70), 4, "X")
            old_rotation = pin.rotation_euler.to_matrix().to_4x4()
            pin.rotation_euler = (rise @ old_rotation).to_euler()
            pin.location = ray_at(maincam,.332,.530,2,TOP)
            evaluated_floor(pin, TOP + .019)
        else:
            pin.location = ray_at(maincam,.210,.561,2,TOP)
            evaluated_floor(pin, TOP + .00035)
        # Keep the collection geometry intact. Both scale and translation belong to its scene instance.
        fairy.scale = tuple(v*.308 for v in fairy.scale)
        p = cloud(points_for([fairy])[0])
        center = bounds(p).mean(axis=0)
        target = ray_at(maincam,(PANE[0]+PANE[2])/2,(PANE[1]+PANE[3])/2,1,2.32)
        fairy.location += target - Vector(center)
        for root in (pin, fairy, gep):
            root["layout_review"] = "STATIC_SCALE_CANDIDATE_REVIEW_REQUIRED"
        actual = points_for([gep, pin, fairy])
        pts = {k: cloud(parts) for k, parts in zip(ACTORS, actual)}
        stats = {k: describe(scene, cameras, p) for k,p in pts.items()}
        state = {"original_locked_layout": before, "candidate": stats, "table_z": TOP,
                 "painted_worktop_world_polygon": [list(v) for v in tabletop],
                 "roots_xyz": {k:list(root.location) for k,root in zip(ACTORS,(gep,pin,fairy))},
                 "new_gep_floor_min": pts["GEP"][:,2].min(),
                 "top_over_adult_height": TOP/np.ptp(pts["GEP"][:,2]),
                 "fairy_window": paths_and_clearance(scene,maincam,actual[2])}
        if label=="C06":
            angle = math.radians(20)
            gap = folded_linen(scene,pts["PIN"],np.array([math.cos(angle),math.sin(angle)]))
            # Anatomical support groups include their worn layers.
            for region, terms in (("head",("head","hair","cap","hat")),
                                  ("back",("shirt body","suspender","waist","shorts")),
                                  ("legs",("leg /","boot /"))):
                region_points=cloud(actual[1],lambda n: any(t in n.lower() for t in terms))
                separation = gap(region_points)
                state.setdefault("linen_contact",{})[region] = {"minimum_gap_bu":separation.min(),
                    "closest_world_xyz":region_points[separation.argmin()],
                    "traced_worktop_edge_margin_bu":min_signed_margin(region_points[[separation.argmin()]],tabletop)}
            state["cloth_vertex_penetration_min_gap_bu"]=gap(pts["PIN"]).min()
        else:
            for side in ("Left","Right"):
                sole=cloud(actual[1],lambda n: f"{side} boot / outsole" in n)
                state.setdefault("standing_contacts",{})[side]={"sole_gap_to_painted_table_bu":sole[:,2].min()-TOP,
                      "sole_gap_to_linen_bu":sole[:,2].min()-(TOP+.00035),
                      "traced_worktop_edge_margin_bu":min_signed_margin(sole, tabletop)}
            state["adult_over_standing_pin_world"]=np.ptp(pts["GEP"][:,2])/np.ptp(pts["PIN"][:,2])
            fw=state["fairy_window"]
            state["fairy_body_over_standing_pin_world"]=fw["body_height_excluding_wings_and_wand"]/np.ptp(pts["PIN"][:,2])
            for cam in cameras:
                heights=[stats[k]["projections"][cam]["size_wh_px"][1] for k in ("GEP","PIN")]
                state.setdefault("adult_over_standing_pin_projected",{})[cam]=heights[0]/heights[1]
        screen_bounds=[np.array(stats[k]["projections"]["locked"]["bbox_ltrb_px"]) for k in ("GEP","PIN")]
        a,b=screen_bounds
        overlap=np.maximum(0,np.minimum(a[2:],b[2:])-np.maximum(a[:2],b[:2]))
        state["gep_pin_projected_bbox_overlap_sq_px"]=float(np.prod(overlap))
        # Restrict the fused offered forearm/hand to its distal portion (local +X).
        from scipy.spatial import cKDTree
        open_hand = cloud(actual[0],lambda n: "open hand and forearm" in n.lower())
        inverse = np.array(gep.matrix_world.inverted())
        local_x = open_hand @ inverse[0,:3] + inverse[0,3]
        distal = open_hand[local_x >= np.quantile(local_x,.77)]
        distances, nearest = cKDTree(pts["PIN"]).query(distal)
        i = distances.argmin()
        state["offering_hand_to_pin"] = {"minimum_sampled_vertex_distance_bu":distances[i],
             "hand_point":distal[i],"pin_point":pts["PIN"][nearest[i]],
             "measure":"Distal 23% of fused reaching-hand vertices along local +X versus evaluated Pin; static gesture only."}
        face = cloud(actual[1],lambda n:"eyelid" in n.lower() or "carved maple head" in n.lower())
        facebb=bounds(project(maincam,scene,face)).flatten()
        state["pin_face_bbox_ltrb_px"]=facebb
        gepbb=screen_bounds[0]
        state["horizontal_gep_to_pin_face_bbox_gap_px"]=facebb[0]-gepbb[2]
        # Sample two face landmarks separately from the coarse face/head envelope.
        # Report GEP occlusion and direct hits on that same landmark independently.
        forward=maincam.matrix_world.to_quaternion() @ Vector((0,0,1))
        dg=bpy.context.evaluated_depsgraph_get()
        landmark_tests = (("closed_eyelids",("closed eyelid curve",)),("sleeping_mouth",("closed mouth",))) if label=="C06" else (("pupils",("deep pupil",)),("mouth",("mouth cavity","smile tongue")))
        for region,tokens in landmark_tests:
            subset={n:v for n,v in actual[1].items() if any(t in n.lower() for t in tokens)}
            if not subset:
                continue
            sample=cloud(subset)[::max(1,len(cloud(subset))//128)]
            foreign=0
            direct=0
            for pt in sample:
                origin=Vector(pt)+forward*20
                hit,loc,norm,index,ob,matrix=scene.ray_cast(dg,origin,-forward,distance=20.001)
                if hit:
                    foreign+=int(ob.name in character.all_objects)
                    direct+=int(ob.name in subset)
            state.setdefault("pin_face_camera_rays",{})[region]={"sample_count":len(sample),"hit_geppetto_first":foreign,
                 "hit_this_landmark_first":direct,"other_hits_include_pin_self_occlusion":True}
        state["picture_occlusion"]="Original-pixel stool matte restores foreground overlap. The folded linen covers painted tools under Pin. Other painted prop depths are unevaluated."

        scene["review_status"]="REVIEW_REQUIRED • adult sculpt and companion scales"
        report["states"][label]=state
    scene = scenes[1][1]
    report["continuity"]={"C08_proposed_static_start":report["states"]["C07"]["roots_xyz"],
                          "C08_render_and_motion":"NOT_RUN"}
    bpy.context.window.scene = world
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(out/"GEPPETTO_WORKSHOP.blend"),compress=True)
    (out/"WORLD_MEASUREMENTS.json").write_text(json.dumps(report,indent=2,default=serialize)+"\n")
    for label, scene in scenes:
        export(scene,maincam,out/("D1_C06_SLEEPING.png" if label=="C06" else "D1_C07_STANDING.png"))
    diagnostic(scenes[1][1],sidecam,room,out/"DIAGNOSTIC_DIAGONAL.png")
    diagnostic(scenes[1][1],eyecam,room,out/"DIAGNOSTIC_EYE_LEVEL.png")


if __name__ == "__main__":
    main()
