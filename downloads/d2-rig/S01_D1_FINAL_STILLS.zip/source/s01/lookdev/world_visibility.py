"""Measure the two locked frames again using opaque character-ID renders and the actual foreground matte."""
import argparse
import io
import json
from pathlib import Path
import sys
import tempfile

import bpy
import numpy as np
from PIL import Image


def flat(name, rgb):
    mat=bpy.data.materials.new("Diagnostic • "+name)
    mat.use_nodes=True
    nodes=mat.node_tree.nodes
    nodes.clear()
    light=nodes.new("ShaderNodeEmission")
    light.inputs["Color"].default_value=(*rgb,1)
    out=nodes.new("ShaderNodeOutputMaterial")
    mat.node_tree.links.new(light.outputs[0],out.inputs["Surface"])
    return mat


def assign(objs,mat):
    for o in objs:
        if o.type in ("MESH","CURVE","SURFACE","FONT"):
            o.data.materials.clear()
            o.data.materials.append(mat)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("output",type=Path)
    args=parser.parse_args(sys.argv[sys.argv.index("--")+1:])
    report={"method":"Cycles CPU one-sample opaque actor-ID in the approved camera. Occupied pixels have dominant ID above 50%; the packed foreground stool coverage above 50% removes covered pixels. Translucent fairy wing material is counted as geometry.",
            "cutouts":"Unoccluded comparison excludes the painted foreground stool but retains all scene geometry and mutual occlusion.",
            "states":{}}
    mats={k:flat(k,rgb) for k,rgb in (("GEP",(1,0,0)),("PIN",(0,1,0)),("FAI",(0,0,1)),("other",(0,0,0)))}
    matte=bpy.data.images["Foreground stool • traced matte"]
    stool=Image.open(io.BytesIO(matte.packed_file.data)).convert("L")
    for label,scene_name in (("C06","C06_STATIC_SLEEP"),("C07","C07_STATIC_STAND")):
        sc=bpy.data.scenes[scene_name]
        bpy.context.window.scene=sc
        sc.cycles.samples=1
        sc.render.threads=1
        sc.render.use_compositing=False
        sc.render.film_transparent=False
        sc.render.dither_intensity=0
        sc.view_settings.view_transform="Standard"
        sc.world.node_tree.nodes.get("Background").inputs["Strength"].default_value=0
        for obj in sc.objects:
            if obj.is_shadow_catcher:
                obj.hide_render=True
        assign(sc.objects,mats["other"])
        for obj in sc.objects:
            if obj.instance_type=="COLLECTION":
                k=obj.name[:3]
                if k in mats:
                    assign(obj.instance_collection.all_objects,mats[k])
        with tempfile.TemporaryDirectory() as tmp:
            imagefile=Path(tmp)/"ids.png"
            sc.render.filepath=str(imagefile)
            bpy.ops.render.render(write_still=True)
            pixels=np.array(Image.open(imagefile).convert("RGB"))
        # ID edges are rendered in sRGB. 188 corresponds to half the linear value.
        blocked=np.array(stool.resize((pixels.shape[1],pixels.shape[0]),Image.Resampling.LANCZOS))>=128
        records={}
        for i,k in enumerate(("GEP","PIN","FAI")):
            actor=(pixels[:,:,i]>=188)&(pixels.argmax(axis=2)==i)
            visible=actor & ~blocked
            y,x=np.where(visible)
            records[k]={"visible_pixels":int(visible.sum()),"before_stool_pixels":int(actor.sum()),
                        "fraction_remaining_after_stool":float(visible.sum()/actor.sum()),
                        "visible_bbox_ltrb_exclusive_px":[int(x.min()),int(y.min()),int(x.max())+1,int(y.max())+1],
                        "visible_height_px":int(y.max()-y.min()+1)}
        records["visible_gep_over_pin_height"]=records["GEP"]["visible_height_px"]/records["PIN"]["visible_height_px"]
        report["states"][label]=records
    args.output.write_text(json.dumps(report,indent=2)+"\n")


if __name__=="__main__":
    main()
