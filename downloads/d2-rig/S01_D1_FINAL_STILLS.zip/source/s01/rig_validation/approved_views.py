"""Compare evaluated views directly with the signatures in the reviewed ZIP."""
import hashlib
import json
from pathlib import Path
import sys

import bpy
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"story_shots"))
from shots import actor, digest_points, points_for
from check_gaze import examine

baseline_path, output_path = map(Path, sys.argv[sys.argv.index("--")+1:])
baseline = json.loads(baseline_path.read_text())
report = {}
for name, earlier in baseline.items():
    scene = bpy.data.scenes[name]
    bpy.context.window.scene = scene
    scene.frame_set(1)
    dg = bpy.context.evaluated_depsgraph_get()
    cam = scene.camera.evaluated_get(dg)
    actual = np.asarray(cam.matrix_world)
    equiv = np.max(np.abs(actual-np.array(earlier["camera"][0])))
    lens = abs(cam.data.ortho_scale-earlier["camera"][1])
    ok = bool(equiv < 1e-6 and lens < 1e-6)
    actors = ("GEP","PIN","FAI")
    sampled = points_for([actor(scene, key) for key in actors])
    changes = [key for key, parts in zip(actors,sampled) if
               digest_points(parts) != earlier["actors"][key]]
    expected = ["PIN"] if name.startswith("C06") else (["GEP"] if name=="C07_JOY" else [])
    lights = {}
    for key,values in earlier["lights"].items():
        obj=scene.objects[key].evaluated_get(dg)
        lights[key]=bool(np.allclose(np.asarray(obj.matrix_world),values[0],atol=1e-6,rtol=0)
                  and np.isclose(obj.data.energy,values[1])
                  and np.allclose(tuple(obj.data.color),values[2]) and np.isclose(obj.data.size,values[3]))
    gaze = examine(scene)
    images = {}
    for suffix, field in (("_workshop_plate","plate_sha256"),("_stool_matte","matte_sha256")):
        images[field]=hashlib.sha256(bpy.data.images[name+suffix].packed_file.data).hexdigest()==earlier[field]
    passed = ok and changes==expected and all(lights.values()) and all(images.values()) and all(g["towards_target_halfplane"] for g in gaze)
    report[name]={"result":"PASS" if passed else "FAIL","camera_max_world_matrix_delta":float(equiv),
                  "ortho_scale_delta":float(lens),"role":scene.get("camera_role"),"lights":lights,
                  "images":images,"changed_actors":changes,"expected":expected,"gaze":gaze}
output_path.write_text(json.dumps(report,indent=2)+"\n")
assert all(r["result"]=="PASS" for r in report.values()), report
print("PASS evaluated five optical transforms, lens, light sources, backgrounds, changed-actor scope and gaze")
