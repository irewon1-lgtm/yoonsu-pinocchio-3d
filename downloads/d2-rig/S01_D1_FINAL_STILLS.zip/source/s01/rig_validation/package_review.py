"""Lossless store of native scenes, proofs and logs with an independently read-back ledger."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

from PIL import Image


def digest_stream(stream):
    digest = hashlib.sha256()
    for block in iter(lambda:stream.read(1 << 20), b""):
        digest.update(block)
    return digest.hexdigest()


def verify_media(path):
    if path.suffix.lower() == ".png":
        with Image.open(path) as image:
            image.load()
            extrema = image.convert("RGB").getextrema()
            assert max(high-low for low, high in extrema) > 16, path.name
            return {"path": path.name, "dimensions": list(image.size)}
    if path.suffix.lower() == ".mp4":
        info = subprocess.check_output([
            "ffprobe", "-v","error", "-select_streams","v:0", "-count_frames",
            "-show_entries","stream=codec_name,width,height,r_frame_rate,nb_read_frames,duration,pix_fmt",
            "-of","json", str(path)
        ])
        subprocess.run(["ffmpeg","-v","error","-xerror","-i",str(path),"-f","null","-"],check=True)
        return {"path":path.name,"full_decode":"PASS",**json.loads(info)["streams"][0]}


def package(root, destination):
    root = root.resolve()
    destination = destination.resolve()
    assert not destination.is_relative_to(root)
    files = [p for p in sorted(root.rglob("*")) if p.is_file() and
             p.name not in {"SHA256SUMS.txt", "MEDIA_READBACK.json"}]
    assert files and all(not p.is_symlink() for p in files)
    media = [result for p in files if (result := verify_media(p)) is not None]
    check = root/"QA"/"MEDIA_READBACK.json"
    check.parent.mkdir(exist_ok=True)
    check.write_text(json.dumps(media, ensure_ascii=False, indent=2)+"\n")
    files.append(check)
    manifest = {}
    for p in sorted(files):
        with p.open("rb") as f:
            manifest[p.relative_to(root).as_posix()] = digest_stream(f)
    ledger = root/"SHA256SUMS.txt"
    ledger.write_text("".join(f"{v}  {k}\n" for k,v in manifest.items()))
    files.append(ledger)
    temp = destination.with_suffix(".zip.partial")
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for p in sorted(files):
            archive.write(p, p.relative_to(root).as_posix())
    with zipfile.ZipFile(temp) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
        assert archive.testzip() is None
        for name, expected in manifest.items():
            with archive.open(name) as f:
                assert digest_stream(f) == expected, name
    temp.replace(destination)
    with destination.open("rb") as f:
        print(f"PASS {len(manifest)} item hashes + CRC, {len(media)} media reads; "
              f"{destination.name} {destination.stat().st_size} bytes {digest_stream(f)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("zip", type=Path)
    args = parser.parse_args()
    package(args.input, args.zip)
