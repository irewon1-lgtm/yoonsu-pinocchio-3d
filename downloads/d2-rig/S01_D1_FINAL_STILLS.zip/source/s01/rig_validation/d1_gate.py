"""Independent D1 still-scene audit. Run each mode in a fresh Blender background process.

blender -b -t 2 --python-exit-code 1 --python d1_gate.py -- snapshot OLD.blend QA/baseline.json
blender -b -t 2 --python-exit-code 1 --python d1_gate.py -- snapshot NEW.blend QA/final.json
blender -b -t 2 --python-exit-code 1 --python d1_gate.py -- optics NEW.blend QA/final_views
blender -b -t 2 --python-exit-code 1 --python d1_gate.py -- compare QA/baseline.json QA/final.json QA/check.json
"""
import csv
import hashlib
import io
import json
from pathlib import Path
import sys

import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from PIL import Image
from scipy.spatial import cKDTree

S01 = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(S01 / 'lookdev'))
from world_study import points_for
from world_visibility import assign, flat

BG = "18ebc03242c327d2f262a7e6dfa945917d8ca499abe3233af50b547592cbb1fa"
OLD = "cb76ced0ee98fde756f28e7b5315f1d191a6568017d049ffcf0b78aa14b01a01"
SHOTS = ('C06_A', 'C06_B', 'C07_A', 'C07_B', 'C07_JOY')
TYPES = ('MESH', 'CURVE', 'FONT', 'SURFACE')


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def graph(tree):
    if not tree:
        return None
    nodes = {}
    for node in tree.nodes:
        inputs = []
        for port in node.inputs:
            v = getattr(port, 'default_value', None)
            if isinstance(v, (bool, float, str, int)):
                inputs.append((port.name, v))
            elif hasattr(v, '__len__'):
                inputs.append((port.name,list(v)))
        opts = {k:getattr(node,k) for k in ('operation','blend_type','use_clamp','mute','interpolation','data_type','projection','extension') if hasattr(node,k)}
        image = getattr(node,'image',None)
        nodes[node.name] = [node.bl_idname,inputs,opts,image.name if image else None]
    links = sorted((l.from_node.name,l.from_socket.identifier,l.to_node.name,l.to_socket.identifier) for l in tree.links)
    return digest([nodes, links])


def roots(scene):
    return {k:next(o for o in scene.objects if o.name.startswith(k) and o.instance_collection)
            for k in ('PIN','GEP','FAI')}


def active(scene):
    bpy.context.window.scene=scene
    scene.frame_set(scene.frame_start)
    bpy.context.view_layer.update()
    return bpy.context.evaluated_depsgraph_get()


def record(obj, matrix):
    """Exact evaluated local geometry, topology, material slots and world transform."""
    mesh=obj.to_mesh()
    try:
        verts=np.empty(len(mesh.vertices)*3, dtype='<f4')
        mesh.vertices.foreach_get('co',verts)
        topo=np.empty(len(mesh.loops),dtype='<i4')
        mesh.loops.foreach_get('vertex_index',topo)
        polygons=np.empty(len(mesh.polygons)*2,dtype='<i4').reshape(2,-1)
        mesh.polygons.foreach_get('loop_total',polygons[0])
        mesh.polygons.foreach_get('material_index',polygons[1])
        shape=hashlib.sha256(verts.tobytes()).hexdigest()
        topology=hashlib.sha256(topo.tobytes()+polygons.tobytes()).hexdigest()
        result=[len(mesh.vertices),shape,topology,[s.material.name if s.material else None for s in obj.material_slots]]
    finally:
        obj.to_mesh_clear()
    return [*result,np.asarray(matrix).tolist()]


def surfaces(scene, dg):
    surfaces={}
    for o in scene.objects:
        if o.name.startswith(('C06 folded flax','Work linen','Painted top','Floor • shadow receiver')):
            ev=o.evaluated_get(dg)
            mesh=ev.to_mesh()
            try:
                surfaces[o.name]=BVHTree.FromPolygons([ev.matrix_world@v.co for v in mesh.vertices],
                                                       [p.vertices[:] for p in mesh.polygons])
            finally:
                ev.to_mesh_clear()
    return surfaces


def closest_support(points, tables):
    """Test all candidate vertices in ascending Z; report the nearest vertical separation.

    Painted tabletop is tested as well as the narrow runner. Prefer fabric on
    coincident surfaces. Negative samples expose penetrations separately.
    """
    best=None
    lowest=None
    for pt in points:
        hits=[]
        for name,tree in tables.items():
            hit=tree.ray_cast(Vector((pt[0],pt[1],3.9)),Vector((0,0,-1)),6)[0]
            if hit is not None:
                hits.append((float(hit.z),name))
        if not hits:
            continue
        z, surface=max(hits)
        gap=float(pt[2]-z)
        if lowest is None or gap<lowest:
            lowest=gap
        if best is None or abs(gap)<abs(best['gap_bu']):
            best={'surface':surface,'xyz':np.asarray(pt).tolist(),'gap_bu':gap}
    if best:
        best['deepest_signed_gap_bu']=lowest
    return best


def contact(scene,parts,dg):
    tables=surfaces(scene,dg)
    work={n:t for n,t in tables.items() if not n.startswith('Floor')}
    floor={n:t for n,t in tables.items() if n.startswith('Floor')}
    sleep=scene.name.startswith(('C05','C06'))
    names = {'head':['head','hair','hat','cap'],
             'back':['shirt body','suspender','waist','shorts'],
             'lower_legs':['leg / shin','boot / outsole','boot / vamp','boot / shaft']} if sleep else {}
    for side in ('left','right'):
        if sleep:
            names.update({side+'_forearm':[side+' forearm / wood'], side+'_hand':[side+' hand /'],
                          side+'_shin_boot':[side+' leg / shin',side+' boot /']})
        else:
            names[side+'_sole']=[side+' boot / outsole']
    tests={}
    for key,things in names.items():
        group=[v for n,v in parts['PIN'].items() if any(t in n.lower() for t in things)]
        if group:
            tests[key]=closest_support(np.concatenate(group),work)
    for s in ('-1','1'):
        pts=next(v for n,v in parts['GEP'].items() if 'boot ground sole '+s in n.lower())
        tests['adult_sole_'+s]=closest_support(pts,floor)
    return tests


def snapshot(path,output):
    bpy.ops.wm.open_mainfile(filepath=str(path))
    data={'file_sha256':file_sha(path),'approved_bg':None,'images':{},'materials':{},'scenes':{},
          'armatures':len(bpy.data.armatures),'actions':len(bpy.data.actions)}
    for im in bpy.data.images:
        if im.packed_file:
            data['images'][im.name]=hashlib.sha256(im.packed_file.data).hexdigest()
    data['approved_bg']=data['images'].get('APPROVED_BG_WORKSHOP_02')
    data['materials']={m.name:graph(m.node_tree) for m in bpy.data.materials}
    for sc in bpy.data.scenes:
        if sc.name not in SHOTS and not sc.name.startswith('C05'):
            continue
        dg=active(sc)
        objects=roots(sc)
        actors={k:{} for k in objects}
        root_names={o.name:k for k,o in objects.items()}
        for inst in dg.object_instances:
            o=inst.object
            if not (inst.is_instance and inst.parent and inst.parent.original.name in root_names and o.type in TYPES and not o.hide_render):
                continue
            actor=root_names[inst.parent.original.name]
            actors[actor][o.name]=record(o,inst.matrix_world)
        props={}
        for o in sc.objects:
            if o.type in TYPES:
                ev=o.evaluated_get(dg)
                props[o.name]=[o.hide_render,o.is_shadow_catcher,record(ev,ev.matrix_world)]
        lights={o.name:[np.asarray(o.evaluated_get(dg).matrix_world).tolist(),o.data.type,list(o.data.color),
                        o.data.energy,o.data.size,graph(o.data.node_tree)] for o in sc.objects if o.type=='LIGHT'}
        cam=sc.camera.evaluated_get(dg)
        pts=dict(zip(objects,points_for(list(objects.values()))))
        bounds={k:[np.concatenate(list(p.values())).min(axis=0).tolist(),np.concatenate(list(p.values())).max(axis=0).tolist()] for k,p in pts.items()}
        data['scenes'][sc.name]={'roots':{k:np.asarray(o.evaluated_get(dg).matrix_world).tolist() for k,o in objects.items()},
            'actors':actors,'bounds':bounds,'props':props,'camera':[cam.name,np.asarray(cam.matrix_world).tolist(),cam.data.type,
                    cam.data.ortho_scale,cam.data.lens,cam.data.shift_x,cam.data.shift_y,cam.data.clip_start,cam.data.clip_end],
            'lights':lights,'world':graph(sc.world.node_tree),'compositor':graph(sc.node_tree),
            'settings':[sc.render.resolution_x,sc.render.resolution_y,sc.render.resolution_percentage,
                        sc.render.engine, sc.cycles.samples, sc.view_settings.view_transform,sc.view_settings.exposure],
            'contacts':contact(sc,pts,dg)}
    save(output,data)
    print('Sampled',path,','.join(data['scenes']))


def compare(baseline,final,out):
    a=json.loads(baseline.read_text()); b=json.loads(final.read_text())
    checks={}; differences={}
    def test(k,condition): checks[k]='PASS' if condition else 'FAIL'
    test('preserved baseline SHA256',a['file_sha256']==OLD)
    test('approved packed plate',a['approved_bg']==b['approved_bg']==BG)
    test('all previously packed images',all(b['images'].get(k)==v for k,v in a['images'].items()))
    test('all previously used material node graphs',all(b['materials'].get(k)==v for k,v in a['materials'].items()))
    test('static files',not b['actions'] and not b['armatures'])
    for name in SHOTS:
        before=a['scenes'][name]; after=b['scenes'][name]
        for field in ('roots','props','camera','lights','world','compositor','settings'):
            test(name+' '+field, before[field]==after[field])
        for who in ('PIN','GEP','FAI'):
            first,second=before['actors'][who],after['actors'][who]
            changed=[n for n in sorted(first.keys()|second.keys()) if first.get(n)!=second.get(n)]
            differences[name+' '+who]=changed
            test(name+' '+who+' inventory',set(first)==set(second))
            allowed=[]
            if who=='PIN' and name.startswith('C06'):
                allowed=['left upper arm','left forearm','left hand','left leg','left boot','right hand / middle distal']
            if who=='GEP' and name=='C07_JOY':
                allowed=['open hand and forearm','gathered linen sleeve 1','double rolled sleeve 1','natural nail','open palm creases']
            test(name+' '+who+' expected local changes only',all(any(t in n.lower() for t in allowed) for n in changed))
            if allowed:
                test(name+' '+who+' correction detected',bool(changed))
        test(name+' size fairy',before['bounds']['FAI']==after['bounds']['FAI'])
        for side in ('-1','1'):
            key='adult_sole_'+side
            test(name+' static adult foot '+side,before['contacts'][key]==after['contacts'][key] and abs(after['contacts'][key]['gap_bu'])<.002)
        if name.startswith('C06'):
            for key in ('left_hand','left_shin_boot','right_hand','right_shin_boot'):
                val=after['contacts'][key]
                test(name+' corrected couch contact '+key,val is not None and abs(val['gap_bu'])<.002 and val['deepest_signed_gap_bu']>-.002)
        else:
            for key in ('left_sole','right_sole'):
                test(name+' no static foot displacement '+key,before['contacts'][key]==after['contacts'][key])
        for key in ('head','back','lower_legs') if name.startswith('C06') else ('left_sole','right_sole'):
            q=after['contacts'][key]
            test(name+' actual '+key+' support',q is not None and abs(q['gap_bu'])<.002)
    c05=[n for n in b['scenes'] if n.startswith('C05')]
    for n in c05:
        s=b['scenes'][n]; ref=b['scenes']['C06_B']
        test(n+' to C06 complete resting doll and root equality',s['actors']['PIN']==ref['actors']['PIN'] and s['roots']['PIN']==ref['roots']['PIN'])
    test('C05 held endpoint present in final file','C05_END_HOLD' in c05)
    save(out,{'checks':checks,'differences':differences,'baseline_sha':a['file_sha256'],'final_sha':b['file_sha256']})
    failed=[k for k in checks if checks[k]=='FAIL']
    print('FAILED',failed) if failed else print('PASS regression comparisons')
    if failed: raise ValueError(failed)

def beauty(scene,output):
    scene.cycles.samples=4
    scene.cycles.use_denoising=False
    # Packed compositor plates are authored at 1280x720; rendering at their actual
    # size avoids compositor resampling shifts and corresponding mask mismatches.
    scene.render.filepath=str(output)
    bpy.ops.render.render(write_still=True)


def labels(objects, who, sleeping):
    eyes=sorted([o.name for o in objects if ('closed eyelid curve' if sleeping else 'deep pupil') in o.name.lower()]) if who=='PIN' else sorted([o.name for o in objects if 'gep · pupil' in o.name.lower()])
    if len(eyes)!=2:
        raise ValueError((who,eyes))
    result={}
    for o in objects:
        n=o.name.lower()
        label=who
        if o.name in eyes:
            label=f'{who}_eye_{eyes.index(o.name)+1}'
        elif who=='GEP' and any(v in n for v in ('open hand and forearm','natural nail','open palm creases')):
            label='GEP_reach'
        elif who=='PIN' and ('leg / shin' in n or 'boot /' in n):
            label='PIN_lower_leg'
        elif who=='PIN' and ('forearm / wood' in n or 'hand / palm' in n):
            label='PIN_forearm'
        result[o.name]=label
    return result


COLORS={'GEP':(1,0,0),'PIN':(0,1,0),'GEP_eye_1':(1,1,0),'GEP_eye_2':(1,0,1),
        'PIN_eye_1':(0,1,1),'PIN_eye_2':(1,1,1),'GEP_reach':(.33,0,0),
        'PIN_lower_leg':(0,.33,0),'PIN_forearm':(0,0,1)}


def encode_labels(path):
    with Image.open(path) as im:
        pixels=np.asarray(im.convert('RGB'),dtype=float)/255
    linear=np.where(pixels>.04045,((pixels+.055)/1.055)**2.4,pixels/12.92)
    # Reject antialiased boundaries and retain pixels close to a pure flat ID.
    return {k:np.sqrt(((linear-rgb)**2).sum(axis=2))<.08 for k,rgb in COLORS.items()}


def id_render(scene, output):
    scene.render.filepath=str(output)
    bpy.ops.render.render(write_still=True)
    return encode_labels(output)


def eye_rays(scene,dg,pos,connected):
    vectors={}
    direction=scene.camera.evaluated_get(dg).matrix_world.copy().to_quaternion()@Vector((0,0,1))
    for who,gr in connected.items():
        other='GEP' if who=='PIN' else 'PIN'
        for name,kind in gr.items():
            if '_eye_' not in kind: continue
            near=pos[who][name]
            rays={'mesh':name,'samples':0,'first_hit_same_feature':0,'blocked_by_other_character':0}
            for pt in near[::max(1,len(near)//160)]:
                hit,_,_,_,obj,_=scene.ray_cast(dg,Vector(pt)+direction*12,-direction,distance=12.0001)
                rays['samples']+=1
                if hit:
                    rays['first_hit_same_feature']+=int(obj.name==name)
                    rays['blocked_by_other_character']+=int(obj.name in pos[other])
            vectors[kind]=rays
    return vectors


def retrace(path,output):
    report=json.loads(output.read_text())
    bpy.ops.wm.open_mainfile(filepath=str(path))
    for shot in report:
        scene=bpy.data.scenes[shot]; dg=active(scene); root=roots(scene)
        pos=dict(zip(root,points_for(list(root.values()))))
        connected={who:labels(root[who].instance_collection.all_objects,who,shot.startswith("C06")) for who in ("GEP","PIN")}
        report[shot]["camera_to_surface_rays"]=eye_rays(scene,dg,pos,connected)
    save(output,report)


def optics(path,output):
    output.mkdir(parents=True,exist_ok=True)
    report={}
    for shot in ('C06_B','C07_JOY'):
        bpy.ops.wm.open_mainfile(filepath=str(path))
        scene=bpy.data.scenes[shot]
        dg=active(scene)
        root=roots(scene)
        pos=dict(zip(root,points_for(list(root.values()))))
        connected={}
        for who in ('PIN','GEP'):
            gr=labels(root[who].instance_collection.all_objects,who,shot.startswith('C06'))
            connected[who]=gr
        vectors=eye_rays(scene,dg,pos,connected)
        beauty(scene,output/(shot+'_CHECK.png'))
        scene.render.use_compositing=False
        scene.render.film_transparent=False
        scene.render.dither_intensity=0
        scene.view_settings.view_transform='Standard'
        scene.view_settings.look='None'
        scene.view_settings.exposure=0
        scene.view_settings.gamma=1
        scene.cycles.samples=1
        scene.cycles.use_denoising=False
        scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=0
        for o in scene.objects:
            if o.is_shadow_catcher:
                o.hide_render=True
        black=flat('occluder',(0,0,0))
        mats={k:flat(k,v) for k,v in COLORS.items()}
        assign(scene.objects,black)
        assign(root['FAI'].instance_collection.all_objects,black)
        for who,gr in connected.items():
            for o in root[who].instance_collection.all_objects:
                assign([o],mats[gr[o.name]])
        ids=id_render(scene,output/(shot+'_ID.png'))
        stool=Image.open(io.BytesIO(bpy.data.images[shot+'_stool_matte'].packed_file.data)).convert('L')
        stool=np.asarray(stool)>=128
        stats={}
        for label,mask in ids.items():
            if 'eye_' in label or label in ('PIN_forearm','PIN_lower_leg','GEP_reach'):
                yy,xx=np.where(mask & ~stool)
                stats[label]={'visible_pixels':len(yy),'bounds':None if not len(yy) else [int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]}
        for who,gr in connected.items():
            matte=np.logical_or.reduce([ids[k] for k in set(gr.values())])
            stats[who]={'visible_pixels':int((matte&~stool).sum()),'stool_blocked':int((matte&stool).sum())}
        record={'detail_id':stats,'camera_to_surface_rays':vectors}
        if shot=='C07_JOY':
            root['PIN'].hide_render=True
            hand=id_render(scene,output/(shot+'_HAND_ID.png'))['GEP_reach']
            root['PIN'].hide_render=False
            root['GEP'].hide_render=True
            leg=id_render(scene,output/(shot+'_SHINS_ID.png'))['PIN_lower_leg']
            hand_yx=np.column_stack(np.where(hand)); leg_yx=np.column_stack(np.where(leg))
            distances=cKDTree(leg_yx).query(hand_yx)[0]
            record['joy_hand_to_shins']={'hand_visible_pixels':len(hand_yx),'shin_visible_pixels':len(leg_yx),
                                       'overlap_px':int((hand&leg).sum()),'min_center_to_center_px':float(distances.min())}
        report[shot]=record
        save(output/'ID_REPORT.json',report)



def reach(path,output):
    """Bidirectional closest vertex to triangular surface and intersecting BVH triangles in Joy."""
    bpy.ops.wm.open_mainfile(filepath=str(path))
    sc=bpy.data.scenes['C07_JOY']
    dg=active(sc)
    actors=roots(sc)
    clouds={k:[] for k in ('GEP_open','PIN_left_hand','PIN_right_hand','PIN_shins_boots')}
    polygons={k:[] for k in clouds}
    for inst in dg.object_instances:
        if not inst.is_instance or not inst.parent or inst.object.type not in TYPES:
            continue
        o=inst.object
        if o.hide_render: continue
        root=inst.parent.original.name
        name=o.name.lower()
        if root==actors['GEP'].name and 'open hand and forearm' in name: key='GEP_open'
        elif root==actors['PIN'].name and 'left hand /' in name: key='PIN_left_hand'
        elif root==actors['PIN'].name and 'right hand /' in name: key='PIN_right_hand'
        elif root==actors['PIN'].name and ('leg / shin' in name or 'boot /' in name): key='PIN_shins_boots'
        else: continue
        mesh=o.to_mesh()
        try:
            offset=len(clouds[key]); mat=inst.matrix_world
            clouds[key].extend(mat@v.co for v in mesh.vertices)
            polygons[key].extend([offset+i for i in face.vertices] for face in mesh.polygons)
        finally:
            o.to_mesh_clear()
    trees={k:BVHTree.FromPolygons(clouds[k],polygons[k]) for k in clouds}
    result={}
    for partner in ('PIN_left_hand','PIN_right_hand','PIN_shins_boots'):
        best=None
        for origin,destination in (('GEP_open',partner),(partner,'GEP_open')):
            for pt in clouds[origin]:
                near,_,_,distance=trees[destination].find_nearest(pt)
                if near is not None and (best is None or distance<best[0]):
                    best=(distance,pt.copy(),near.copy()) if origin=='GEP_open' else (distance,near.copy(),pt.copy())
        gap,g,p=best
        facing=sc.camera.evaluated_get(dg).matrix_world.copy().to_quaternion()@Vector((0,0,1))
        result[partner]={'closest_vertex_to_surface_bu':gap,'gep_witness':list(g),'pin_witness':list(p),
            'gep_minus_pin_depth_toward_lens_bu':(g-p).dot(facing),'intersecting_bound_pairs':len(trees['GEP_open'].overlap(trees[partner]))}
    save(output,result)




def sleep_intersections(path,output):
    bpy.ops.wm.open_mainfile(filepath=str(path))
    sc=bpy.data.scenes['C06_B']; dg=active(sc); pin=roots(sc)['PIN']
    candidates={g:{} for g in ('forearm','hand','right lower leg','left lower leg','torso')}
    for inst in dg.object_instances:
        obj=inst.object
        if not (inst.is_instance and inst.parent and inst.parent.original==pin and obj.type in TYPES and not obj.hide_render):
            continue
        name=obj.name.lower()
        if 'left forearm /' in name: kind='forearm'
        elif 'left hand /' in name: kind='hand'
        elif 'right leg /' in name or 'right boot /' in name: kind='right lower leg'
        elif 'left leg /' in name or 'left boot /' in name: kind='left lower leg'
        elif any(word in name for word in ('shirt body','waist','shorts','topstitch','bib')): kind='torso'
        else: continue
        mesh=obj.to_mesh()
        try:
            candidates[kind][obj.name]=BVHTree.FromPolygons([inst.matrix_world@v.co for v in mesh.vertices],[f.vertices[:] for f in mesh.polygons])
        finally:
            obj.to_mesh_clear()
    hits={}
    for g,h in (('forearm','torso'),('hand','torso'),('left lower leg','right lower leg'),
                ('hand','left lower leg'),('hand','right lower leg')):
        pairs=[]
        for obj,tree in candidates[g].items():
            for other,tree2 in candidates[h].items():
                count=len(tree.overlap(tree2))
                if count: pairs.append([obj,other,count])
        hits[g+' / '+h]=pairs
    save(output,hits)




def final_report(qa):
    def read(name):
        return json.loads((qa/name).read_text())
    compare_data=read('D1_REGRESSION.json')
    base=read('D1_BASELINE_SNAPSHOT.json')['scenes']
    final=read('D1_FINAL_SNAPSHOT.json')['scenes']
    source=read('D1_LOCKED_SOURCES.json')
    old_ids=read('d1_baseline_views/ID_REPORT.json')
    ids=read('d1_final_views/ID_REPORT.json')
    reach_final=read('D1_FINAL_REACH.json')
    old_intersections=read('D1_BASELINE_SELF_INTERSECTIONS.json')
    intersects=read('D1_FINAL_SELF_INTERSECTIONS.json')
    checks=dict(compare_data['checks'])
    def test(k,passed):
        checks[k]='PASS' if passed else 'FAIL'
    test('Recomputed immutable sources',len(source)==35 and all(r['same_as_registry'] for r in source))
    for name,groups in ids.items():
        for k,v in groups['detail_id'].items():
            test(name+' ID visibility '+k,v['visible_pixels']>0)
            if k in ('GEP','PIN'): test(name+' stool on '+k,v['stool_blocked']==0)
        for k,rec in groups['camera_to_surface_rays'].items():
            test(name+' other character blocks no sampled rays to '+k,rec['blocked_by_other_character']==0)
    before_overlap=old_ids['C07_JOY']['joy_hand_to_shins']
    after_overlap=ids['C07_JOY']['joy_hand_to_shins']
    test('Joy reaches clear of puppet shins and shoes',before_overlap['overlap_px']>0 and after_overlap['overlap_px']==0)
    hand=reach_final['PIN_right_hand']
    test('Joy adjacent right hand separated in 3D',0<hand['closest_vertex_to_surface_bu']<.15 and not hand['intersecting_bound_pairs'])
    test('No crossing opposite leg, torso or hand in the tested sleep surfaces',all(not v for v in intersects.values()))
    checks['Animated slip, finger motion or foot transition']='NOT_RUN'
    summary={'baseline_sha':compare_data['baseline_sha'],'final_sha':compare_data['final_sha'],'checks':checks,
             'screen_space':ids,'joy_hand_clearance_change':{'before':before_overlap,'after':after_overlap},
             'joy_3D_surfaces':reach_final,'sleep_supports':{k:v['contacts'] for k,v in final.items() if k in ('C06_B','C05_END_HOLD')},
             'standing_supports':final['C07_JOY']['contacts'],'previous_sleep_intersections':{k:len(v) for k,v in old_intersections.items()},
             'final_sleep_intersections':{k:len(v) for k,v in intersects.items()}}
    save(qa/'D1_INDEPENDENT_GATE.json',summary)
    issues=[k for k,v in checks.items() if v=='FAIL']
    lines=['D1 INDEPENDENT STATIC CHECK  '+('FAIL' if issues else 'PASS'), 'Blender '+bpy.app.version_string,
        'Baseline SHA256 '+compare_data['baseline_sha'],'Final SHA256 '+compare_data['final_sha'],
        '35 approved locked source files and packed original BG '+BG+'.',
        'All original shot cameras, lights, stage meshes, support receivers, world, shader, compositing and packed art checked.',
        'Geometry, evaluated transform and topology compared by named object. See D1_REGRESSION.json for every changed part.',
        'C05_END_HOLD and C06_B closed-eye doll and root compared at their saved static initial frames.',
        'Sleep world vertical separation in Blender units:']
    for key in final['C06_B']['contacts']:
        prior=base['C06_B']['contacts'][key]; cur=final['C06_B']['contacts'][key]
        lines.append(f"  {key}: {prior['gap_bu']:.6f} -> {cur['gap_bu']:.6f} at {cur['surface']}")
    lines+=['Single-sample native-resolution opaque ID pixels after testing the packed stool mask:']
    for shot,r in ids.items():
        terms=[f"{k} {v['visible_pixels']}" for k,v in r['detail_id'].items() if 'eye' in k]
        lines.append(shot+' '+', '.join(terms)+f". Stool: GEP {r['detail_id']['GEP']['stool_blocked']}, PIN {r['detail_id']['PIN']['stool_blocked']} px.")
    lines.append(f"Joy hand/forearm vs shins/boots overlap {before_overlap['overlap_px']} -> {after_overlap['overlap_px']} px; closest pixel centers {after_overlap['min_center_to_center_px']:.2f} px.")
    lines.append(f"Joy closest vertex-to-surface separation from the offered Pin right hand {hand['closest_vertex_to_surface_bu']:.5f} BU. Intersecting pairs {hand['intersecting_bound_pairs']}.")
    lines.extend(f"{v} {k}" for k,v in checks.items())
    (qa/'D1_INDEPENDENT_GATE.log').write_text('\n'.join(lines)+'\n')
    print(lines[0], 'failures',issues)
    if issues: raise ValueError(issues)




def pixels(old_dir,new_dir,out):
    report={}
    for shot in ('C06_A','C06_B','C07_JOY'):
        before=old_dir/(shot+'.png'); after=new_dir/(shot+'.png')
        with Image.open(before) as im:
            a=np.array(im.convert('RGB'),dtype=np.int16)
        with Image.open(after) as im:
            b=np.array(im.convert('RGB'),dtype=np.int16)
        if a.shape!=b.shape or a.shape!=(720,1280,3):
            raise ValueError((shot,a.shape,b.shape))
        delta=np.abs(a-b)
        any_channel=delta.max(axis=2)
        regions={}
        for threshold in (4,16,64):
            yy,xx=np.where(any_channel>=threshold)
            regions[str(threshold)]={'pixels':len(xx),'pixel_ltrb':None if not len(xx) else
                                      [int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]}
        report[shot]={'before_sha':file_sha(before),'after_sha':file_sha(after),
                      'exactly_equal_pixels':int((any_channel==0).sum()),'total_pixels':int(any_channel.size),
                      'max_srgb_channel_change_at_least':regions}
        assert regions['64']['pixels']>0
    save(out,report)



def sources(ledger,locked,out):
    rows=[]
    with ledger.open() as stream:
        for row in csv.DictReader(stream,delimiter='\t'):
            f=locked/row['locked_relative_path']
            actual=file_sha(f)
            rows.append({'source':row['locked_relative_path'],'sha256':actual,'same_as_registry':actual==row['sha256']})
    save(out,rows)
    if not all(r['same_as_registry'] for r in rows):
        raise ValueError('Locked source hash mismatch')
    print('PASS',len(rows),'approved source hashes')


if __name__=='__main__':
    mode,*paths=sys.argv[sys.argv.index('--')+1:]
    funcs={'snapshot':snapshot,'compare':compare,'optics':optics,'sources':sources,'reach':reach,'sleep_intersections':sleep_intersections,'final_report':final_report,'retrace':retrace,'pixels':pixels}
    funcs[mode](*[Path(s).resolve() for s in paths])
