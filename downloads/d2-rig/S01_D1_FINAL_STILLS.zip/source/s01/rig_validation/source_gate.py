"""Check the recovered inputs and three historical D1 review packages before D2.

Run from any directory with Python 3.11+, Pillow, git, ffmpeg and ffprobe.
--workspace points to the workspace containing scratch/, shared/ and the repo.
"""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

from PIL import Image


REPO = Path(__file__).resolve().parents[3]
SOURCE_COMMIT = 'a3f2a65796651dc601f45ffbb56ae759dd92dedd'
LAYOUT_COMMIT = '9830e6b7c8fbb6b86bd172ef6951f0bc0de0843b'
ARCHIVES = {
    'revision': ('ef7265d224547934704aa43549204cedaa0b39cc', 'downloads/D1_REVISION_REVIEW_PACKAGE.zip', 'D1_REVISION_SHA256SUMS.txt', None),
    'lookdev': ('2e7f7f4e2e0642a6c3bd9efe85167eda0eaac1e8', 'downloads/geppetto-d1/D1_GEPPETTO_LOOKDEV_REVIEW.zip', 'SHA256SUMS.txt', 'gep-look/review'),
    'story': ('344a320c77a8614fd554ffb62d85c84b1d926f92', 'downloads/story-camera/D1_STORY_CAMERA_REVIEW.zip', 'SHA256SUMS.txt', 'gep-shots/delivery'),
}
SHOTS = {'C06_A': 'WARM', 'C06_B': 'WARM', 'C07_A': 'SHOCK', 'C07_B': 'SHOCK', 'C07_JOY': 'JOY'}
SHEETS = ['D1_CHAR_COMPARE.png', 'D1_FACE_CLOSEUPS.png', 'D1_WORLD_SCALE.png', 'D1_FAIRY_WINDOW.png',
          'D1_LIGHTING_A_B.png', 'D1_C06_SLEEPING.png', 'D1_C07_STANDING.png']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git_bytes(revision, path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', f'{revision}:{path}'])


def audit_archive(workspace, key):
    commit, member, manifest_name, prior_stage = ARCHIVES[key]
    source = workspace / 'shared/downloads' / Path(member).name
    digest = file_sha(source)
    require(digest == sha(git_bytes(commit, member)), f'{key} ZIP differs from Git release {commit}')
    with ZipFile(source) as archive:
        names = [n for n in archive.namelist() if not n.endswith('/')]
        require(len(set(names)) == len(names), f'{key} ZIP duplicate member')
        manifest = dict(line.split('  ', 1)[::-1] for line in archive.read(manifest_name).decode().splitlines() if line)
        require(set(manifest) == set(names) - {manifest_name}, f'{key} manifest coverage')
        entries = {}
        for item in names:
            data = archive.read(item)  # zipfile checks the CRC at EOF for every member
            actual = sha(data)
            if item != manifest_name:
                require(manifest[item] == actual, f'{key} SHA mismatch {item}')
            if prior_stage:
                require(actual == file_sha(workspace / 'scratch' / prior_stage / item), f'{key} stage mismatch {item}')
            record = {'sha256': actual, 'zip_crc32': f'{archive.getinfo(item).CRC:08x}', 'bytes': len(data)}
            if item.lower().endswith('.png'):
                with Image.open(io.BytesIO(data)) as im:
                    im.verify()
                with Image.open(io.BytesIO(data)) as im:
                    im.load()
                    require(im.format == 'PNG', item)
                    record['decoded_png_wh'] = list(im.size)
            entries[item] = record
    return {'archive': source.name, 'sha256': digest, 'git_release_commit': commit, 'git_release_path': member,
            'verified_crc_members': len(entries), 'internal_sha_members': len(manifest),
            'stage_matching_members': len(entries) if prior_stage else None, 'members': entries}


def decode_mp3(path):
    stream = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'a:0',
        '-show_entries', 'stream=codec_name,channels,sample_rate', '-of', 'json', str(path)]))['streams'][0]
    require(stream['codec_name'] == 'mp3', f'{path.name} codec')
    samples = subprocess.check_output(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-err_detect', 'explode',
        '-i', str(path), '-map', '0:a:0', '-c:a', 'pcm_s16le', '-f', 's16le', 'pipe:1'])
    frames, remainder = divmod(len(samples), 2 * stream['channels'])
    require(frames > 0 and remainder == 0, f'{path.name} incomplete PCM frames')
    return {'codec': stream['codec_name'], 'sample_rate': int(stream['sample_rate']), 'channels': stream['channels'],
            'pcm_frames': frames, 'pcm_s16le_sha256': sha(samples), 'decoded_seconds': frames / int(stream['sample_rate'])}


def locked_inputs(workspace, archives):
    root = workspace / 'scratch/yoonsu-s01-d1'
    locked = root / 'locked_source'
    registry_path = 'production/s01/d0/D0_SHA256_REGISTRY_UPDATED.tsv'
    registry = git_bytes(LAYOUT_COMMIT, registry_path)
    require(registry == (REPO / registry_path).read_bytes(), 'D0 ledger changed')
    require(sha(registry) == archives['revision']['members']['D0_SHA256_REGISTRY_UPDATED.tsv']['sha256'], 'revision ledger')
    lines = list(csv.DictReader(io.StringIO(registry.decode()), delimiter='\t'))
    require(len({r['locked_relative_path'] for r in lines}) == len(lines) == 35, 'expected 35 unique locked files')
    records = {}
    for row in lines:
        name = row['locked_relative_path']
        source = locked / name
        digest = file_sha(source)
        require(digest == row['sha256'] == file_sha(root / 'intake' / row['recovery_zip_entry']), f'locked mismatch {name}')
        require(source.stat().st_size == int(row['bytes']), f'locked size {name}')
        records[name] = {'sha256': digest, 'bytes': source.stat().st_size}
    story = (locked / '01_STORY_MASTER_V1_1.md').read_text()
    voice = json.loads((locked / 'V7_manifest.json').read_text())
    selection = json.loads((locked / 'V7_VOICE_LOCK_MANIFEST.json').read_text())['approved_choices']
    require(selection == 'A/C/A/A', 'voice lock selection')
    expected = [f'S01-U{i:03d}' for i in range(1, 27)]
    require([i['id'] for i in voice['items']] == expected, 'utterance sequence')
    decoded = {}
    for item in voice['items']:
        name = f"V7_AUDIO_MP3/{item['id']}.mp3"
        require(item['sha256'] == records[name]['sha256'] and item['text'] in story, f'voice manifest / story {name}')
        decoded[name] = decode_mp3(locked / name)
    return {'registry_sha256': sha(registry), 'historical_registry_commit': LAYOUT_COMMIT,
            'locked_and_recovery_copy_count': len(records), 'locked_files': records, 'approved_voice_pattern': selection,
            'ffmpeg_version': subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0],
            'matched_story_text_and_voice_manifest_rows': len(decoded), 'audio': decoded, 'audio_model_terms_from_manifest': voice['license']}


def reconcile(workspace, archives, sources):
    lookdir = workspace / 'scratch/gep-look/review'
    story = workspace / 'scratch/gep-shots/delivery'
    look = archives['lookdev']['members']
    recent = archives['story']['members']
    history = json.loads((story / 'QA/SOURCE_AUDIT.json').read_text())
    expected_history = {k:v['sha256'] for k,v in look.items() if k != 'SHA256SUMS.txt'}
    expected_history.update({k:v['sha256'] for k,v in sources['locked_files'].items()})
    expected_history[archives['lookdev']['archive']] = archives['lookdev']['sha256']
    observed_history = {r['source']:r['sha256'] for r in history}
    require(len(history) == len(observed_history) and expected_history == observed_history, 'story audit lineage')
    raw = json.loads((story / 'QA/SCENE_READBACK.json').read_text())
    require(raw['file_sha256'] == recent['D1_STORY_SHOTS.blend']['sha256'], 'story Blender digest')
    frame_hashes = {n:r['sha256'] for n,r in recent.items() if n.startswith('frames/')}
    require(len(set(frame_hashes.values())) == len(frame_hashes) == len(SHOTS), 'distinct five story frames')
    layout = json.loads((lookdir / 'WORLD_MEASUREMENTS.json').read_text())['states']['C07']
    contacts = json.loads((story / 'QA/FINAL_CONTACT.json').read_text())
    visibility = json.loads((story / 'QA/SHOT_VISIBLE_ID.json').read_text())['shots']
    records = {}
    for name, pose in SHOTS.items():
        scene = raw['scenes'][name]
        ref, shot = contacts['source'][name[:3]], contacts['shots'][name]
        for field in ['pin_evaluated_sha256', 'pin_matrix', 'gep_instance_matrix']:
            require(ref[field] == shot[field], f'{name} baseline {field}')
        require(scene['acting'] == pose and scene['resolution'] == recent[f'frames/{name}.png']['decoded_png_wh'], f'{name} scene acting/resolution')
        require(set(ref['samples']) == set(shot['samples']), f'{name} contact sample set')
        for point, sample in shot['samples'].items():
            require(sample['xyz'] == ref['samples'][point]['xyz'] and sample['in_frame'], f'{name} support {point}')
        records[name] = {'approved_still_acting': pose, 'preserved_pin_world_geometry_sha256': shot['pin_evaluated_sha256'],
                         'contact_gaps_bu': {p:s['vertical_separation_bu'] for p,s in shot['samples'].items()},
                         'gep_occlusion_by_stool_fraction': visibility[name]['GEP']['fraction_occluded_by_stool']}
    angles = [f'views/{who}_{view}.png' for who in ('PIN','GEP','FAI') for view in ('front','three_quarter','profile')]
    revision = archives['revision']['members']
    return {'crosslinked_prior_sha_rows': len(history), 'source_scene_sha256': raw['file_sha256'],
            'lookdev_mandatory_sheets': {n:look[n] for n in SHEETS},
            'layout_view_grid_sources': {n:revision[n] for n in angles},
            'prior_contact_sheets': {n:revision[n] for n in ['D1_C06_CONTACT_ANGLE.png','D1_C07_CONTACT_ANGLE.png','D1_WORLD_CONTACT_CHECK.png']},
            'camera_and_acting_boards': {n:r for n,r in recent.items() if n.startswith('boards/')}, 'story_shots': records,
            'inherited_scale': {k:layout[k] for k in ['adult_over_standing_pin_world','adult_over_standing_pin_projected','fairy_body_over_standing_pin_world','fairy_window']},
            'scope': 'The lookdev sheets preserve three-character views, scale, light and fairy clearance. Five reviewed story stills supersede the C06/C07 compositions and Geppetto static reactions. Earlier QA described Pinocchio and Fairy high-quality resculpts as NOT_RUN. Archived static measurements do not demonstrate animated clearance or deformation.'}


def rights(workspace, archives):
    releases = [('lookdev','lookdev'), ('story','story_shots')]
    for key, subdir in releases:
        require(archives[key]['members']['SOURCE_LICENSES.tsv']['sha256'] == sha(git_bytes(SOURCE_COMMIT, f'production/s01/{subdir}/SOURCE_LICENSES.tsv')), f'{key} license ledger differs')
    rows = list(csv.DictReader((workspace / 'scratch/gep-shots/delivery/SOURCE_LICENSES.tsv').open(),delimiter='\t'))
    return {'source_ledgers': {k:archives[k]['members']['SOURCE_LICENSES.tsv']['sha256'] for k,_ in releases},
            'inherited_credits': rows, 'new_work': 'D2 adds project-authored rig controls, weights, test poses and validation outputs. The inherited projects, approved characters, reference art, voice and scenery retain their recorded terms. The original project grants review distribution; a general reuse license is unspecified.',
            'external_sources': 'Greg Zaal / Poly Haven studio HDRI, Lennart Demes / ambientCG Fabric026 weave: CC0. MPFB2 software: GPL-3.0-or-later; bundled generated base geometry: CC0. Earlier lookdev records distinguish the evaluated MPFB base from the custom rendered face. D2 uses the reviewed scene as input.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=REPO.parent)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    report = {'status':'FAIL'}
    try:
        report['archives'] = {key:audit_archive(args.workspace,key) for key in ARCHIVES}
        report['sources'] = locked_inputs(args.workspace, report['archives'])
        report['d1_history'] = reconcile(args.workspace, report['archives'], report['sources'])
        report['rights'] = rights(args.workspace, report['archives'])
        report['status'] = 'STRUCTURE_PASS'
    except Exception as error:
        report['error'] = str(error)
        raise
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')


if __name__ == '__main__':
    main()
