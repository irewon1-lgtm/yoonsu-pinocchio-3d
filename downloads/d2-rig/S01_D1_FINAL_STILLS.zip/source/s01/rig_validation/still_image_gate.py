"""Read full rendered frames and compare unchanged cameras with released pixels."""
import json
import sys
from pathlib import Path
import numpy as np
from PIL import Image

def pixels(path):
    with Image.open(path) as image:
        image.load()
        assert image.size == (1280,720), path
        return np.asarray(image.convert("RGB")).astype(np.int16)

def main(previous, current, output):
    reports = {}
    for shot in ("C06_A","C06_B","C07_A","C07_B","C07_JOY"):
        before = pixels(previous/(shot+".png"))
        after = pixels(current/(shot+".png"))
        difference = np.abs(after-before)
        altered = np.max(difference, axis=2) > 12
        yy, xx = np.where(altered)
        exact = bool(np.array_equal(before, after))
        unchanged = shot in ("C07_A","C07_B")
        good = exact if unchanged else len(yy)>150
        reports[shot] = {"check":"PASS" if good else "FAIL","width":1280,"height":720,
                         "all_rgb_pixels_equal":exact, "average_absolute_rgb_delta":float(difference.mean()),
                         "changed_pixels_over_12":len(yy), "reviewed_frame_unchanged":unchanged,
                         "difference_box_including_changed_shadow": None if not len(yy) else
                             [int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]}
    hold = pixels(current/"C05_END_HOLD.png")
    next_pose = pixels(current/"C06_B.png")
    same_hold = bool(np.array_equal(hold, next_pose))
    reports["C05_END_HOLD_to_C06_B"] = {"check":"PASS" if same_hold else "FAIL",
                    "all_rgb_pixels_equal":same_hold, "purpose":"Static doll continuity across cut"}
    output.write_text(json.dumps(reports,indent=2)+"\n")
    assert all(r["check"]=="PASS" for r in reports.values()), reports
    print("PASS six reopened 1280x720 beauty images, two unchanged surprise views and continuous hold")

if __name__=="__main__":
    main(*(Path(arg) for arg in sys.argv[1:]))
