"""Apply the D1 sleeping-doll correction to an open copy of D1_STORY_SHOTS.blend.

This module changes only matrices in the shared C06 sleeping Pinocchio
collection. The caller owns saving, rendering, and the original story file.
"""

import hashlib
import math
import struct

import bpy
from mathutils import Euler, Matrix, Vector
from mathutils.bvhtree import BVHTree


# Vertical separation in Blender world units, measured against evaluated surfaces.
CONTACT_LIMIT = .006
PENETRATION_LIMIT = .0015
_REST_ANGLE = math.radians(73)
# Bearing and elevation of each segment in the bench plane, followed by the
# independent foot/hand orientation. These are fitted to the existing cloth mesh.
_LEG_POSE = (24.859137, -21.278339, 5.156162, -15.080217, 68.360477, -15.215417, 61.066251)
_ARM_POSE = (77.336549, -41.251262, -0.841087, -31.556521, -40.601026, -25.218869, 14.022247)
_MARKER = "D1 supported sleep and C05 endpoint"


def _target():
    scenes = [bpy.data.scenes[name] for name in ("C06_A", "C06_B")]
    root = scenes[0].objects.get("PIN_ROOT")
    if root is None or scenes[1].objects.get("PIN_ROOT") != root:
        raise ValueError("C06_A and C06_B must share PIN_ROOT")
    collection = root.instance_collection
    if collection is None or collection.name != "PIN • sleeping":
        raise ValueError("Unexpected C06 sleeping collection")
    for scene in bpy.data.scenes:
        if scene not in scenes and any(obj.instance_collection == collection for obj in scene.objects):
            raise ValueError(f"Sleeping collection is unexpectedly linked to {scene.name}")
    return scenes, root, collection


def _point_rotation(pivot, rotation, target=None):
    if target is None:
        target = pivot
    return Matrix.Translation(target) @ rotation.to_4x4() @ Matrix.Translation(-pivot)


def _bearing(azimuth, elevation, bench):
    a, e = map(math.radians, (azimuth, elevation))
    return bench @ Vector((math.cos(a) * math.cos(e), math.sin(a) * math.cos(e), math.sin(e)))


def _joint_pose(joints, pose, bench):
    upper, middle, tip = joints
    upper_dir = middle - upper
    lower_dir = tip - middle
    new_upper = _bearing(*pose[:2], bench) * upper_dir.length
    new_lower = _bearing(*pose[2:4], bench) * lower_dir.length
    r1 = upper_dir.rotation_difference(new_upper).to_matrix()
    r2 = (r1 @ lower_dir).rotation_difference(new_lower).to_matrix() @ r1
    twist = Euler(tuple(map(math.radians, pose[4:])), "XYZ").to_matrix()
    r3 = bench @ twist @ bench.transposed() @ r2
    new_middle = upper + new_upper
    new_tip = new_middle + new_lower
    return (
        _point_rotation(upper, r1),
        _point_rotation(middle, r2, new_middle),
        _point_rotation(tip, r3, new_tip),
    )


def _deltas(root):
    theta = math.radians(20)
    bench = Matrix.Rotation(theta, 3, "Z")
    matrix = root.matrix_world
    shoulder = Vector((.208, .015, 1.556))
    rest_arm = _point_rotation(shoulder, Matrix.Rotation(_REST_ANGLE, 3, "Y"))
    arm = tuple(matrix @ rest_arm @ Vector(joint) for joint in (
        (.208, .015, 1.556), (.611, -.008, 1.507), (.946, -.073, 1.579),
    ))
    leg = tuple(matrix @ Vector(joint) for joint in (
        (.133, .006, 1.036), (.172, -.016, .625), (.235, .046, .260),
    ))
    upper, forearm, hand = _joint_pose(arm, _ARM_POSE, bench)
    thigh, shin, boot = _joint_pose(leg, _LEG_POSE, bench)
    inv = matrix.inverted()

    # C05-P03 ends with the right index extended and the middle digit slightly
    # curled. Pitch just its distal segment toward the palm. C06 keeps this
    # static angle through I01, with the same right palm, eyelids and root.
    right_rest = _point_rotation(Vector((-.208, .015, 1.531)),
                                 Matrix.Rotation(-_REST_ANGLE, 3, "Y"))
    middle_knuckle = Vector((-1.16201, -.108, 1.37646))
    middle_axis = Matrix.Rotation(math.radians(8), 3, "Z")
    middle_tip = right_rest @ _point_rotation(middle_knuckle, middle_axis) @ right_rest.inverted()
    return (
        ("PIN | Left upper arm / ", inv @ upper @ matrix),
        ("PIN | Left forearm / ", inv @ forearm @ matrix),
        ("PIN | Left hand / ", inv @ hand @ matrix),
        ("PIN | Left leg / thigh", inv @ thigh @ matrix),
        ("PIN | Left leg / ", inv @ shin @ matrix),
        ("PIN | Left boot / ", inv @ boot @ matrix),
        ("PIN | Right hand / middle distal", middle_tip),
    )


def _meshes(root):
    """Return Blender-evaluated geometry with collection instance transforms."""
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for instance in depsgraph.object_instances:
        obj = instance.object
        if (not instance.is_instance or instance.parent is None
                or instance.parent.original != root or obj.hide_render
                or obj.type not in {"MESH", "CURVE"}):
            continue
        mesh = obj.to_mesh()
        try:
            matrix = instance.matrix_world.copy()
            points = [matrix @ vert.co for vert in mesh.vertices]
            obj_name = obj.name
            if points:
                yield obj_name, points, [tuple(face.vertices) for face in mesh.polygons]
        finally:
            obj.to_mesh_clear()


def _support(scene):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    linen = scene.objects["C06 folded flax on the painted worktop"]
    bench = scene.objects["Painted top • traced shadow receiver"]
    result = []
    for obj in (linen, bench):
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            bvh = BVHTree.FromPolygons([evaluated.matrix_world @ v.co for v in mesh.vertices],
                                       [tuple(face.vertices) for face in mesh.polygons])
        finally:
            evaluated.to_mesh_clear()
        result.append((obj.name, bvh))
    return result


def _region(name):
    short = name.split(" | ", 1)[-1].lower()
    if short.startswith(("head / ", "carved maple head", "closed eyelid", "closed mouth")):
        return "head"
    for side in ("Left", "Right"):
        for segment, label in (("upper arm", "upper_arm"), ("forearm", "forearm"),
                               ("hand / palm", "palm"), ("hand / wrist", "wrist"),
                               ("hand", "hand"), ("leg", "leg"), ("boot", "boot")):
            if short.startswith(f"{side.lower()} {segment}"):
                return f"{side}_{label}"
    return "back"


def _pose_digest(meshes, predicate=lambda _: True):
    digest = hashlib.sha256()
    for name, points, _ in sorted(meshes):
        if predicate(name):
            digest.update(name.encode())
            digest.update(b"\0")
            digest.update(b"".join(struct.pack("<3f", *point) for point in points))
    return digest.hexdigest()


def measure_sleep_pose(scene):
    """Measure the sleeping doll by downward rays at all evaluated vertices."""
    _, root, _ = _target()
    old_scene = bpy.context.window.scene
    try:
        bpy.context.window.scene = scene
        bpy.context.view_layer.update()
        surfaces = _support(scene)
        meshes = list(_meshes(root))
        regions = {}
        misses = 0
        down = Vector((0, 0, -1))
        for name, points, _ in meshes:
            main = _region(name)
            if main.endswith(("_palm", "_wrist")):
                labels = (main, main.rsplit("_", 1)[0] + "_hand")
            else:
                labels = (main,)
            for point in points:
                origin = Vector((point.x, point.y, 3))
                hit = None
                for surface, bvh in surfaces:
                    hit, _, _, _ = bvh.ray_cast(origin, down, 3)
                    if hit is not None:
                        break
                if hit is None:
                    misses += 1
                    continue
                gap = float(point.z - hit.z)
                for label in labels:
                    stats = regions.setdefault(label, {"vertices_tested": 0, "within_contact_band": 0,
                                                       "minimum_gap_bu": float("inf")})
                    stats["vertices_tested"] += 1
                    if -PENETRATION_LIMIT <= gap <= CONTACT_LIMIT:
                        stats["within_contact_band"] += 1
                    if gap < stats["minimum_gap_bu"]:
                        stats.update(minimum_gap_bu=gap, sample_xyz=list(point),
                                     support_xyz=list(hit), object=name, surface=surface)
        return {
            "scene": scene.name,
            "vertices_without_support_surface_below": misses,
            "regions": regions,
            "pin_geometry_sha256": _pose_digest(meshes),
            "closed_eyelid_sha256": _pose_digest(meshes, lambda n: "closed eyelid" in n),
            "right_hand_sha256": _pose_digest(meshes, lambda n: "Right hand / " in n),
            "right_index_sha256": _pose_digest(meshes, lambda n: "Right hand / index " in n),
            "right_middle_sha256": _pose_digest(meshes, lambda n: "Right hand / middle " in n),
        }
    finally:
        bpy.context.window.scene = old_scene


def _contact_checks(report):
    regions = report["regions"]
    errors = []
    if report["vertices_without_support_surface_below"]:
        errors.append("doll has vertices outside both support surfaces")
    for name, stats in regions.items():
        if stats["minimum_gap_bu"] < -PENETRATION_LIMIT:
            errors.append(f"{name} intersects {stats['surface']} by {-stats['minimum_gap_bu']:.5f} BU")
    for name in ("head", "back", "Left_hand", "Left_palm", "Left_boot", "Right_hand", "Right_boot"):
        if regions[name]["minimum_gap_bu"] > CONTACT_LIMIT:
            errors.append(f"{name} remains {regions[name]['minimum_gap_bu']:.5f} BU above support")
    return errors


def apply_sleep_fix():
    """Apply once and return measured A/B contact and continuity data. No save."""
    scenes, root, collection = _target()
    current_scene = bpy.context.window.scene
    bpy.context.window.scene = scenes[0]
    bpy.context.view_layer.update()
    original = {}
    try:
        if not collection.get(_MARKER):
            deltas = _deltas(root)
            used = set()
            for obj in collection.all_objects:
                for prefix, matrix in deltas:
                    if obj.name.startswith(prefix):
                        original[obj] = obj.matrix_world.copy()
                        obj.matrix_world = matrix @ original[obj]
                        used.add(prefix)
                        break
            missing = {prefix for prefix, _ in deltas} - used
            if missing:
                raise ValueError("Missing sleeping limb geometry: " + ", ".join(sorted(missing)))
        measurements = [measure_sleep_pose(scene) for scene in scenes]
        for report in measurements:
            errors = _contact_checks(report)
            if errors:
                raise ValueError(f"{report['scene']} contact: " + "; ".join(errors))
        if measurements[0]["pin_geometry_sha256"] != measurements[1]["pin_geometry_sha256"]:
            raise ValueError("A/B sleeping pose differs")
        collection[_MARKER] = True
        return {"moved_parts": sorted(obj.name for obj in original), "shots": measurements}
    except Exception:
        for obj, matrix in original.items():
            obj.matrix_world = matrix
        bpy.context.view_layer.update()
        raise
    finally:
        bpy.context.window.scene = current_scene
