"""A static reach correction for the approved C07 Joy scene, in original body metres."""
import math
import bpy
import numpy as np
from mathutils import Matrix


def apply_joy_fix():
    """Turn Geppetto's open hand toward Pinocchio's anatomical right hand.

    The B camera sees that hand on the left of the puppet. The shoulder-side
    edge of the gathered shirt stays sewn to the same waistcoat armscye.
    """
    scene=bpy.data.scenes["C07_JOY"]
    root=next(o for o in scene.objects if o.name.startswith("GEP") and o.instance_type=="COLLECTION")
    parts=root.instance_collection.all_objects
    palm=next(o for o in parts if "Open hand and forearm" in o.name)
    if palm.get("d1_offered_hand"):
        return
    # These are the shoulder and elbow of the frozen, already posed D1 sculpt.
    shoulder=np.array((.304311,-.051149,1.059698))
    elbow=np.array((.477177,-.177204,1.126433))
    upper_axis=(elbow-shoulder)/np.linalg.norm(elbow-shoulder)
    turn=Matrix.Rotation(math.radians(11),3,"Y") @ Matrix.Rotation(math.radians(59),3,"Z")
    quat=turn.to_quaternion()
    axis=np.array(quat.axis)
    extension=np.array((.047,.018,.012))

    # Supinate from mid-forearm so the palm and separated fingers remain visible.
    wrist=np.array((.672962,-.320693,1.237897))
    forearm_axis=(wrist-elbow)/np.linalg.norm(wrist-elbow)
    turn_matrix=np.array(turn)
    wrist_end=shoulder+turn_matrix@(wrist-shoulder)+extension
    direction=np.array((.83218439,.45595817,.31554918))
    twist=math.radians(-39)

    def shift(points,keep_shoulder=False,turn_palm=False):
        vec=points-shoulder
        blend=np.ones(len(points))
        if keep_shoulder:
            blend=np.clip((vec@upper_axis-.013)/.157,0,1)
            blend=blend*blend*(3-2*blend)
        t=(quat.angle*blend)[:,None]
        posed=(shoulder+vec*np.cos(t)+np.cross(axis,vec)*np.sin(t)+
                np.outer(vec@axis,axis)*(1-np.cos(t))+blend[:,None]*extension)
        if turn_palm:
            u=np.clip(((points-wrist)@forearm_axis+.113)/.119,0,1)
            theta=(twist*u*u*(3-2*u))[:,None]
            relative=posed-wrist_end
            posed=(wrist_end+relative*np.cos(theta)+np.cross(direction,relative)*np.sin(theta)+
                   np.outer(relative@direction,direction)*(1-np.cos(theta)))
        return posed

    for obj in parts:
        n=obj.name
        if not any(k in n for k in ("Open hand and forearm","Natural nail","Open palm creases",
                                    "Gathered linen sleeve 1","Double rolled sleeve 1")):
            continue
        if obj.type=="MESH":
            coords=np.empty((len(obj.data.vertices),3),dtype=np.float32)
            obj.data.vertices.foreach_get("co",coords.ravel())
            coords=shift(coords,"Gathered linen sleeve 1" in n, "sleeve" not in n).astype(np.float32)
            obj.data.vertices.foreach_set("co",coords.ravel())
            obj.data.update()
        elif obj.type=="CURVE":
            for s in obj.data.splines:
                points=s.bezier_points
                coords=np.array([list(p.co) for p in points])
                handles=np.array([[list(p.handle_left),list(p.handle_right)] for p in points])
                for p,target,new_handles in zip(points,shift(coords,turn_palm=True),shift(handles.reshape(-1,3),turn_palm=True).reshape(-1,2,3)):
                    p.co=target
                    if p.handle_left_type not in ("AUTO","VECTOR"):
                        p.handle_left=new_handles[0]
                    if p.handle_right_type not in ("AUTO","VECTOR"):
                        p.handle_right=new_handles[1]
    palm["d1_offered_hand"]="Near Pinocchio's right hand, with an open gap"
    bpy.context.view_layer.update()
