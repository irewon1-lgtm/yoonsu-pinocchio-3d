"""Run inside Blender on a copy of the reviewed story scene."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import bpy

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
BASE_SHA = "cb76ced0ee98fde756f28e7b5315f1d191a6568017d049ffcf0b78aa14b01a01"


def finalize(source, output):
    from joy_fix import apply_joy_fix
    from sleep_fix import apply_sleep_fix

    assert hashlib.sha256(source.read_bytes()).hexdigest() == BASE_SHA
    assert source.resolve() != output.resolve()
    bpy.ops.wm.open_mainfile(filepath=str(source.resolve()))
    local_measurements = {"C06": apply_sleep_fix(), "C07_JOY": apply_joy_fix()}
    output.with_name("D1_LOCAL_CORRECTIONS.json").write_text(
        json.dumps(local_measurements, indent=2, ensure_ascii=False, default=str)+"\n")
    hold = bpy.data.scenes["C06_B"].copy()
    hold.name = "C05_END_HOLD"
    hold["shot_id"] = hold.name
    hold["purpose"] = "Static hold after the two finger cues; continuous with C06 before the eye opens."
    hold.use_fake_user = True
    for shot in ("C06", "C07"):
        bpy.data.scenes[shot+"_A"]["camera_role"] = "Retained alternate"
        bpy.data.scenes[shot+"_B"]["camera_role"] = "User-selected primary"
    bpy.data.scenes["C07_JOY"]["camera_role"] = "Static joy gesture, same approved B lens"
    bpy.context.window.scene = bpy.data.scenes["C06_B"]
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(output.resolve()), compress=True)
    bpy.ops.wm.open_mainfile(filepath=str(output.resolve()))
    assert set(bpy.data.scenes.keys()) == {"C05_END_HOLD","C06_A","C06_B","C07_A","C07_B","C07_JOY"}
    assert not bpy.data.armatures and not bpy.data.actions
    print("PASS D1 write and reopen", output.name, flush=True)


def render(scene_name, destination, samples, percent):
    scene = bpy.data.scenes[scene_name]
    bpy.context.window.scene = scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = samples
    scene.render.resolution_percentage = percent
    scene.render.image_settings.file_format = "PNG"
    scene.render.filepath = str(destination.resolve())
    bpy.ops.render.render(write_still=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    cmds = parser.add_subparsers(dest="mode", required=True)
    new = cmds.add_parser("finalize")
    new.add_argument("source", type=Path)
    new.add_argument("output", type=Path)
    rnd = cmds.add_parser("render")
    rnd.add_argument("scene")
    rnd.add_argument("destination", type=Path)
    rnd.add_argument("--samples", type=int, default=40)
    rnd.add_argument("--percent", type=int, default=100)
    args = parser.parse_args(sys.argv[sys.argv.index("--")+1:])
    if args.mode == "finalize":
        finalize(args.source, args.output)
    else:
        render(args.scene, args.destination, args.samples, args.percent)
