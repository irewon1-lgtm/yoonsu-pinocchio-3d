"""Build mobile review boards using only rendered frames and shared comparison crops."""

import argparse
from dataclasses import dataclass
import math
from pathlib import Path
import sys

from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from story_shots.review_boards import GREEN, INK, LINE, MUTED, lettering, photo, sheet


WIDTH = 1036
MARGIN = 42
CONTENT_WIDTH = WIDTH - 2 * MARGIN
GAP = 20
PAIR_WIDTH = (CONTENT_WIDTH - GAP) // 2

# Crop coordinates on the approved 1280×720 camera frames. Apply each
# rectangle to the same part of both images, independent of render resolution.
CROP_SIZE = (1280, 720)
SHOTS = {
    "C06_B": (
        "C06 B  ·  잠든 자세 수정",
        (
            ("피노키오의 얼굴과 베개", (555, 151, 866, 462)),
            ("팔·다리와 작업대 받침", (698, 103, 1254, 438)),
            ("피노키오의 손과 팔 주변", (842, 104, 1231, 386)),
        ),
    ),
    "C07_JOY": (
        "C07  ·  기쁨 연기 수정",
        (
            ("제페토의 얼굴과 미소", (177, 280, 457, 602)),
            ("어깨·팔과 두 인물의 위치", (107, 217, 831, 674)),
            ("제페토의 손과 피노키오의 앞쪽 간격", (299, 360, 805, 720)),
        ),
    ),
}


def open_frame(path):
    with Image.open(path) as image:
        return image.convert("RGB")


def scaled_crop(image, bounds):
    left, top, right, bottom = bounds
    base_width, base_height = CROP_SIZE
    return image.crop((
        round(left * image.width / base_width),
        round(top * image.height / base_height),
        round(right * image.width / base_width),
        round(bottom * image.height / base_height),
    ))


def d1_board(shot, before_dir, after_dir, output):
    title, details = SHOTS[shot]
    before = open_frame(before_dir / f"{shot}.png")
    after = open_frame(after_dir / f"{shot}.png")
    for frame in (before, after):
        if frame.width * CROP_SIZE[1] != frame.height * CROP_SIZE[0]:
            raise ValueError(f"{shot} must use the original 16:9 framing, got {frame.size}")

    full_height = round(CONTENT_WIDTH * before.height / before.width)
    full_row = full_height + 60
    detail_top = 236 + 2 * full_row + 17
    detail_height = 284
    detail_row = detail_height + 98
    canvas = sheet(
        title, "수정 전후의 전체 프레임과 동일 좌표로 자른 확대 화면입니다.",
        WIDTH, detail_top + len(details) * detail_row + 20,
    )
    for index, (frame, label) in enumerate(((before, "수정 전"), (after, "수정 후"))):
        top = 210 + index * full_row
        lettering(canvas, (MARGIN, top), f"{label}  ·  전체 프레임", 32, True, GREEN)
        photo(canvas, frame, (MARGIN, top + 47), CONTENT_WIDTH, full_height)

    draw = ImageDraw.Draw(canvas)
    draw.line((MARGIN, detail_top - 21, WIDTH - MARGIN, detail_top - 21), fill=LINE, width=2)
    for index, (label, bounds) in enumerate(details):
        top = detail_top + index * detail_row
        lettering(canvas, (MARGIN, top), label, 32, True, INK)
        for column, (frame, phase) in enumerate(((before, "수정 전"), (after, "수정 후"))):
            left = MARGIN + column * (PAIR_WIDTH + GAP)
            lettering(canvas, (left, top + 44), phase, 26, True, GREEN if column else MUTED)
            photo(canvas, scaled_crop(frame, bounds), (left, top + 80), PAIR_WIDTH, detail_height)
    canvas.save(output / f"D1_{shot}_BEFORE_AFTER.png", optimize=True)


@dataclass(frozen=True)
class MotionFrame:
    number: int
    label: str
    path: Path


def frame_arg(value):
    key, separator, path = value.partition("=")
    number, _, label = key.partition(":")
    if not separator or not number.isdecimal() or not path:
        raise argparse.ArgumentTypeError("use FRAME[:LABEL]=PATH")
    return MotionFrame(int(number), label, Path(path))


def d2_sheet(output, frames, fps, start_frame, columns):
    ordered = sorted(frames, key=lambda frame: frame.number)
    width = CONTENT_WIDTH if columns == 1 else PAIR_WIDTH
    height = round(width * 9 / 16)
    row_height = height + 101
    rows = math.ceil(len(ordered) / columns)
    canvas = sheet(
        "D2  ·  주요 동작 프레임",
        f"실제 렌더에서 고른 프레임 · {fps:g} fps · {start_frame}번 프레임이 0초입니다.",
        WIDTH, 221 + rows * row_height,
    )
    for index, keyframe in enumerate(ordered):
        row, column = divmod(index, columns)
        x, y = MARGIN + column * (width + GAP), 210 + row * row_height
        timestamp = (keyframe.number - start_frame) / fps
        lettering(canvas, (x, y), f"프레임 {keyframe.number:03d}  ·  {timestamp:.3f}초", 29, True, GREEN)
        if keyframe.label:
            lettering(canvas, (x, y + 38), keyframe.label, 26, True)
        photo(canvas, open_frame(keyframe.path), (x, y + 72), width, height)
    canvas.save(output / "D2_MOTION_CONTACT_SHEET.png", optimize=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="mode", required=True)
    still = commands.add_parser("d1", help="compare matching C06_B and C07_JOY camera renders")
    still.add_argument("before", type=Path)
    still.add_argument("after", type=Path)
    still.add_argument("output", type=Path)
    motion = commands.add_parser("d2", help="assemble an ordered sheet of rendered motion frames")
    motion.add_argument("output", type=Path)
    motion.add_argument("--fps", type=float, default=24)
    motion.add_argument("--start-frame", type=int, default=1)
    motion.add_argument("--columns", type=int, choices=(1, 2), default=2)
    motion.add_argument("--frame", type=frame_arg, action="append", required=True, metavar="FRAME[:LABEL]=PATH")
    args = parser.parse_args()

    if args.mode == "d1":
        args.output.mkdir(parents=True, exist_ok=True)
        for shot in SHOTS:
            d1_board(shot, args.before, args.after, args.output)
    else:
        if not math.isfinite(args.fps) or args.fps <= 0:
            parser.error("--fps must be finite and greater than zero")
        numbers = [frame.number for frame in args.frame]
        if len(set(numbers)) != len(numbers) or min(numbers) < args.start_frame:
            parser.error("--frame numbers must be unique and at or after --start-frame")
        args.output.mkdir(parents=True, exist_ok=True)
        d2_sheet(args.output, args.frame, args.fps, args.start_frame, args.columns)


if __name__ == "__main__":
    main()
