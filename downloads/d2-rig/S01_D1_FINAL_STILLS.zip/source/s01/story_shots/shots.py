"""Author four camera alternatives and a static joyful follow-on from the packed D1 workshop and acting library.

blender -b --python-exit-code 1 --python shots.py -- build WORKSHOP.blend ACTING.blend OUTPUT
blender -b --python-exit-code 1 --python shots.py -- render OUTPUT [--shots C06_A ...]
blender -b --python-exit-code 1 --python shots.py -- verify OUTPUT
"""
import argparse
import hashlib
import io
import math
import json
from pathlib import Path
import sys
import tempfile

import bpy
import numpy as np
from mathutils import Matrix, Vector
from PIL import Image, ImageFilter

sys.path.insert(0,str(Path(__file__).resolve().parent.parent/"lookdev"))
from world_study import bounds, cloud, diagnostic, mesh_object, points_for, serialize
from world_visibility import assign, flat

WIDE_SHA = "e3652e7f81daf6f41445ea2c538dbe6cb2f7a7230042e4ed9b3a2f3aa973eaaf"
PLATE_SHA = "18ebc03242c327d2f262a7e6dfa945917d8ca499abe3233af50b547592cbb1fa"
SIZE=(1280,720)
# Source 1440x810 projector coordinates (left, top, width). All aspects are 16:9.
SHOTS={
    "C06_A":("WARM",15,275,580,2.1),
    "C06_B":("WARM",45,304,495,2.5),
    "C07_A":("SHOCK",0,170,665,2.3),
    "C07_B":("SHOCK",18,184,577,2.35),
    "C07_JOY":("JOY",18,184,577,2.35),
}


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def image_from_packed(name,mode):
    image=bpy.data.images[name]
    return Image.open(io.BytesIO(image.packed_file.data)).convert(mode)


def packed_image(image,name,data=False):
    with tempfile.TemporaryDirectory() as tmp:
        f=Path(tmp)/(name+".png")
        image.save(f)
        datablock=bpy.data.images.load(str(f))
        datablock.name=name
        if data:
            datablock.colorspace_settings.name="Non-Color"
        datablock.pack()
        datablock.filepath="//"+name+".png"
    return datablock


def crop_plate(image,left,top,width):
    w,h=image.size
    rect=(left*w/1440,top*h/810,(left+width)*w/1440,(top+width*9/16)*h/810)
    return image.transform(SIZE,Image.Transform.EXTENT,rect,Image.Resampling.BICUBIC)


def background_focus(image,radius):
    # Manual depth cue on the wall, which has a different focus plane from the bench.
    # Preserve painted colour and keep the original packed artwork in the derived file.
    w,h=image.size
    u=np.arange(w)/w
    rear=np.interp(u,[0,.10,.275,.4,1],[.553,.533,.483,.518,.60])
    v=(np.arange(h)/h)[:,None]
    mix=np.clip((rear[None,:]+.012-v)/.055,0,1)
    mix=mix*mix*(3-2*mix)
    mask=Image.fromarray(np.uint8(np.rint(mix*255)))
    blurred=np.array(image.filter(ImageFilter.GaussianBlur(radius))).astype(np.float32)/255
    # Optical exposure roll-off on the distant practical, keeping its amber colour.
    brightness=np.max(blurred,axis=2)
    highlights=np.clip((brightness-.56)/.43,0,1)
    gain=.94-.19*highlights
    far=Image.fromarray(np.uint8(np.clip(blurred*gain[:,:,None]*255,0,255)))
    return Image.composite(far, image, mask)


def camera_for(sc,wide,shot,left,top,width,angle):
    cam=wide.copy()
    cam.data=wide.data.copy()
    cam.name=shot+" • story camera"
    cam.data.name=cam.name
    sc.collection.objects.link(cam)
    scale=wide.data.ortho_scale
    dx=((left+width/2)/1440-.5)*scale
    dy=(.5-(top+width*9/32)/810)*scale*9/16
    cam.location=wide.location+wide.rotation_euler.to_matrix() @ Vector((dx,dy,0))
    cam.data.ortho_scale=scale*width/1440
    direction=cam.rotation_euler.to_matrix() @ Vector((0,0,-1))
    pivot=cam.location+direction*((.45-cam.location.y)/direction.y)
    orbit=Matrix.Rotation(math.radians(angle),3,"Z")
    cam.location=pivot+orbit @ (cam.location-pivot)
    cam.rotation_euler=(orbit @ wide.rotation_euler.to_matrix()).to_euler()
    cam.data.background_images.clear()
    sc.camera=cam
    return cam


def ray_samples(wide,cam,x,y,w,angle):
    """Inverse warp of a hand-traced tabletop, its fascia, and the back wall.

    Each region uses an orthographic plane homography. Edge bands interpolate
    their coordinates to avoid missing pixels from an unpainted second angle.
    """
    if not angle:
        return None
    from scipy.ndimage import map_coordinates
    # Use authored local transforms, all cameras here are unparented.
    rot=np.array(cam.rotation_euler.to_matrix())
    old=np.array(wide.rotation_euler.to_matrix())
    location=np.array(cam.location)
    original=np.array(wide.location)
    px=(np.arange(SIZE[0])+.5)/SIZE[0]
    py=(np.arange(SIZE[1])+.5)/SIZE[1]
    local_x=(px-.5)*cam.data.ortho_scale
    local_y=(.5-py)*cam.data.ortho_scale*9/16
    origin=location+local_x[None,:,None]*rot[:,0]+local_y[:,None,None]*rot[:,1]
    dr=-rot[:,2]
    def plane(normal,point):
        normal=np.asarray(normal); point=np.asarray(point)
        t=((point-origin)@normal)/(dr@normal)
        at=origin+t[:,:,None]*dr-original
        return np.stack((.5+at@old[:,0]/wide.data.ortho_scale,.5-at@old[:,1]/(wide.data.ortho_scale*9/16)),axis=2)
    tabletop=plane((0,0,1),(0,0,1.35))
    back_a=np.array((-4.175464,.675529,1.35)); back_b=np.array((-1.674517,1.849934,1.35))
    wall=plane((back_b[1]-back_a[1],back_a[0]-back_b[0],0),back_a)
    # Front painted bench edge in actual world coordinates, inherited from the archive trace.
    a=np.array((-3.172072,-.388969,1.35)); b=np.array((-.584830,1.408654,1.35))
    fascia=plane((b[1]-a[1],a[0]-b[0],0),a)
    def smooth(values):
        t=np.clip(values,0,1)
        return t*t*(3-2*t)
    u,v=tabletop[:,:,0],tabletop[:,:,1]
    rear=.566+(.492-.566)*u/.273
    front=np.interp(u,[0,.108,.391,1],[.606,.635,.521,.419])
    far_weight=smooth((rear+.004-v)/.009)[:,:,None]
    below=smooth((v-front-.001)/.028)[:,:,None]
    uv=(tabletop*(1-below)+fascia*below)*(1-far_weight)+wall*far_weight
    def sample(image):
        a=np.asarray(image)
        coords=[uv[:,:,1]*a.shape[0]-.5,uv[:,:,0]*a.shape[1]-.5]
        channels=[a] if a.ndim==2 else [a[:,:,i] for i in range(3)]
        values=[map_coordinates(channel,coords,order=1,mode="nearest",prefilter=False) for channel in channels]
        return Image.fromarray(values[0] if len(values)==1 else np.stack(values,axis=2))
    # Painted background may be extrapolated only outside the full source. Reject this case.
    if np.min(uv)<-.001 or np.max(uv)>1.001:
        raise ValueError(f"Camera requires off-plate points {uv.min()}…{uv.max()}")
    sample.uv_map=uv
    return sample


def finish_linen(sc):
    """Add a narrow woven return to the existing runner, below the sole contact level."""
    runner=next(o for o in sc.objects if o.name.startswith("Work linen •"))
    verts=[]
    for i in range(33):
        t=i/32
        at=runner.data.vertices[10*i+9].co.copy()
        width=.091+.018*math.sin(10*t)+.01*math.cos(23*t)
        drop=.039+.018*math.sin(15*t+.5)**2
        for j in range(5):
            fac=j/4
            verts.append((at.x+.013*fac, at.y-width*fac,
                          at.z-.0015-drop*fac**3))
    faces=[(5*i+j,5*i+j+5,5*i+j+6,5*i+j+1) for i in range(32) for j in range(4)]
    edge=mesh_object(sc,"Woven selvedge folded over table",verts,faces)
    for m in runner.data.materials:
        edge.data.materials.append(m)
    for i,face in enumerate(edge.data.polygons):
        face.use_smooth=True
        face.material_index=int(i%4==2)


def composite(sc,bg,mask):
    sc.use_nodes=True
    nodes=sc.node_tree.nodes
    nodes.clear()
    render=nodes.new("CompositorNodeRLayers")
    render.location=(-620,-120)
    soften=nodes.new("CompositorNodeBilateralblur")
    soften.sigma_space,soften.sigma_color=1.45,.115
    soften.location=(-375,-120)
    bg_input=nodes.new("CompositorNodeImage")
    bg_input.image=bg
    bg_input.location=(-640,240)
    bg_fit=nodes.new("CompositorNodeScale")
    bg_fit.space="RENDER_SIZE"
    bg_fit.frame_method="STRETCH"
    bg_fit.location=(-430,240)
    over=nodes.new("CompositorNodeAlphaOver")
    over.location=(-100,50)
    matte=nodes.new("CompositorNodeImage")
    matte.image=mask
    matte.location=(-420,520)
    matte_fit=nodes.new("CompositorNodeScale")
    matte_fit.space="RENDER_SIZE"
    matte_fit.frame_method="STRETCH"
    matte_fit.location=(-190,520)
    restore=nodes.new("CompositorNodeMixRGB")
    restore.label="Original stool, if it enters this shot"
    restore.location=(135,160)
    output=nodes.new("CompositorNodeComposite")
    output.location=(380,160)
    for sender,receiver in ((render.outputs[0],soften.inputs[0]),(render.outputs[0],soften.inputs[1]),
            (bg_input.outputs[0],bg_fit.inputs[0]),(bg_fit.outputs[0],over.inputs[1]),
            (soften.outputs[0],over.inputs[2]),(matte.outputs[0],matte_fit.inputs[0]),
            (matte_fit.outputs[0],restore.inputs[0]),(over.outputs[0],restore.inputs[1]),
            (bg_fit.outputs[0],restore.inputs[2]),(restore.outputs[0],output.inputs[0])):
        sc.node_tree.links.new(sender,receiver)


def actor(sc,key):
    return next(o for o in sc.objects if o.instance_type=="COLLECTION" and o.name.startswith(key))


def project(sc,cam,pts):
    dg=bpy.context.evaluated_depsgraph_get()
    cam=cam.evaluated_get(dg)
    projection=cam.calc_matrix_camera(dg,x=SIZE[0],y=SIZE[1]) @ cam.matrix_world.inverted()
    mat=np.array(projection)
    transformed=pts @ mat[:,:3].T+mat[:,3]
    return (transformed[:,:2]/transformed[:,3,None]*[.5,-.5]+.5)*SIZE


def landmark(sc,parts,terms):
    pts=cloud(parts,lambda n:any(t in n.lower() for t in terms))
    pixels=bounds(project(sc,sc.camera,pts))
    return {"world_minmax":bounds(pts),"pixel_ltrb":pixels.flatten(),"size_px":pixels[1]-pixels[0],
            "inside":bool(np.all(pixels[0]>=0) and np.all(pixels[1]<=SIZE))}


def digest_points(parts):
    digest=hashlib.sha256()
    for name in sorted(parts):
        digest.update(name.encode())
        digest.update(np.round(parts[name],5).astype("<f4").tobytes())
    return digest.hexdigest()


def shot_data(sc,pin,gep,reference,rect):
    dg=bpy.context.evaluated_depsgraph_get()
    g,p=points_for([gep,pin])
    if digest_points(p)!=reference["pin_vertex_digest"]:
        raise ValueError(sc.name+" Pin evaluated positions changed")
    detail={"gep_face":landmark(sc,g,["continuous face sculpt"]),
            "gep_expression":landmark(sc,g,["upper eyelid","lower eyelid","moustache","upper lip","lower lip"]),
            "pin_face":landmark(sc,p,["carved maple head"]),
            "pin_face_features":landmark(sc,p,["closed eyelid curve","closed mouth"] if "06" in sc.name else ["deep pupil","smile tongue"]),
            "gep_offering_hand":landmark(sc,g,["open hand and forearm"]),
            "pin_full":landmark(sc,p,[""])}
    # The plaster skin contains the back of the skull. Eyelids + mouth give a tighter acting window.
    rays={}
    direction=sc.camera.rotation_euler.to_quaternion() @ Vector((0,0,1))
    for label,parts,terms,other in (("pin_eyes",p,["closed eyelid curve","deep pupil"],g),
            ("pin_mouth",p,["closed mouth","smile tongue"],g),
            ("geppetto_eyes",g,["upper eyelid","lower eyelid"],p),("geppetto_mouth",g,["lower lip","upper lip","oral","cavity"],p)):
        subset={n:v for n,v in parts.items() if any(t in n.lower() for t in terms)}
        if not subset:
            continue
        arr=cloud(subset)
        samples=arr[::max(1,len(arr)//100)]
        counts={"samples":len(samples),"first_hit_same_feature":0,"blocked_by_other_actor":0,"outside_frame":0}
        px=project(sc,sc.camera,samples)
        for pt,uv in zip(samples,px):
            if not (0<=uv[0]<SIZE[0] and 0<=uv[1]<SIZE[1]):
                counts["outside_frame"]+=1
                continue
            hit,_,_,_,o,_=sc.ray_cast(dg,Vector(pt)+direction*20,-direction,distance=20.002)
            if hit:
                counts["first_hit_same_feature"]+=int(o.name in subset)
                counts["blocked_by_other_actor"]+=int(o.name in other)
        rays[label]=counts
    return {"source_crop_ltrb":rect,"camera_world":np.array(sc.camera.evaluated_get(dg).matrix_world),
            "ortho_scale":sc.camera.data.ortho_scale,"same_pin_evaluated_geometry":True,
            "pin_vertex_digest":reference["pin_vertex_digest"],"pin_root_matrix":np.array(pin.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world),
            "gep_root_matrix":np.array(gep.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world),"world_xyz_limits":{"GEP":bounds(cloud(g)),"PIN":bounds(cloud(p))},
            "landmarks":detail,"feature_visibility_rays":rays}


def build(args):
    base,library,out=args.base.resolve(),args.library.resolve(),args.out.resolve()
    if file_hash(base)!=WIDE_SHA:
        raise ValueError("Unrecognized wide workshop")
    out.mkdir(exist_ok=True,parents=True)
    (out/"frames").mkdir(exist_ok=True)
    (out/"qa").mkdir(exist_ok=True)
    bpy.ops.wm.open_mainfile(filepath=str(base))
    plate=bpy.data.images["APPROVED_BG_WORKSHOP_02"]
    if hashlib.sha256(plate.packed_file.data).hexdigest()!=PLATE_SHA:
        raise ValueError("Unexpected packed painting")
    plate.use_fake_user=True
    original=image_from_packed(plate.name,"RGB")
    orig_mask=image_from_packed("Foreground stool • traced matte","L")
    sources={k:bpy.data.scenes[n] for k,n in (("C06","C06_STATIC_SLEEP"),("C07","C07_STATIC_STAND"))}
    old_scenes=list(bpy.data.scenes)
    report={"status":"REVIEW_REQUIRED","base_sha256":WIDE_SHA,"background_sha256":PLATE_SHA,
        "resolution":SIZE,"method":"Orthographic medium A on the original axis. B is panned and refocused. Its camera orbits a documented world-Y pivot with the tabletop and its fascia homographies and a vertical painted plane hung from the table rear edge. A distant-wall optical focus and highlight rolloff apply only to the derived plate. Geometry is rerendered at shot resolution.",
        "library_sha256":None if args.rehearsal else file_hash(library),"sources":{},"shots":{}}
    if args.rehearsal:
        variants={k:bpy.data.collections["GEP_LOOKDEV"] for k in ("WARM","SHOCK","JOY")}
    else:
        names=["GEP_"+v for v in ("WARM","SHOCK","JOY")]
        with bpy.data.libraries.load(str(library),link=False) as (src,dest):
            if not set(names).issubset(src.collections):
                raise ValueError("Three static actor collections are required")
            dest.collections=names
        variants={c.name.split("_")[-1]:c for c in dest.collections}
    for key,sc in sources.items():
        bpy.context.window.scene=sc
        finish_linen(sc)
        pin=actor(sc,"PIN")
        gep=actor(sc,"GEP")
        p=points_for([pin])[0]
        report["sources"][key]={"pin_vertex_digest":digest_points(p),"pin_root_matrix":np.array(pin.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world),
                                "gep_root_matrix":np.array(gep.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world),"pin_world_limits":bounds(cloud(p))}
    for name,(state,x,y,w,radius) in SHOTS.items():
        source=sources[name[:3]]
        sc=source.copy()
        sc.name=name
        sc.use_fake_user=True
        bpy.context.window.scene=sc
        sc["shot_id"]=name
        sc["acting_state"]=state
        sc["story_purpose"]={"C06_A":"Warm observation, medium two-shot","C06_B":"Warm face and offering hand, close two-shot",
                              "C07_A":"Shock on seeing the standing boy","C07_B":"Shock on seeing the standing boy, tighter camera","C07_JOY":"Joy after surprise; additional static beat using camera B"}[name]
        old=actor(sc,"GEP")
        gep=old.copy()
        gep.name="GEP "+name+" "+state
        gep.instance_collection=variants[state]
        sc.collection.objects.link(gep)
        sc.collection.objects.unlink(old)
        angle=0 if name.endswith("_A") else args.angle
        cam=camera_for(sc,source.camera,name,x,y,w,angle)
        warp=ray_samples(source.camera,cam,x,y,w,angle)
        def frame(im):
            return warp(im) if warp else crop_plate(im,x,y,w)
        background=packed_image(frame(background_focus(original,radius)),name+"_workshop_plate")
        stool=frame(orig_mask)
        mask=packed_image(stool,name+"_stool_matte",True)
        preview=cam.data.background_images.new()
        preview.image=background
        preview.alpha=1
        preview.frame_method="FIT"
        cam.data.show_background_images=True
        composite(sc,background,mask)
        sc.render.resolution_x,sc.render.resolution_y=SIZE
        sc.render.resolution_percentage=100
        sc.render.image_settings.file_format="PNG"
        sc.render.image_settings.color_mode="RGB"
        sc.render.image_settings.color_depth="8"
        sc.render.threads_mode="FIXED"
        sc.render.threads=2
        sc.cycles.samples=40
        sc.cycles.use_adaptive_sampling=True
        sc.cycles.adaptive_threshold=.045
        sc.cycles.use_denoising=False
        sc.render.filepath="//frames/"+name+".png"
        # Keep the shot file static even if opened on the timeline.
        sc.frame_start=sc.frame_end=1
        sc.frame_set(1)
        bpy.context.view_layer.update()
        ref=report["sources"][name[:3]]
        info=shot_data(sc,actor(sc,"PIN"),gep,ref,(x,y,x+w,y+w*9/16))
        for field,root in (("pin_root_matrix",actor(sc,"PIN")),("gep_root_matrix",gep)):
            if not np.allclose(root.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world,ref[field],rtol=0,atol=1e-6):
                raise ValueError(name+" actor root mismatch")
        info["backdrop_wall_blur_source_px"]=radius
        info["azimuth_offset_degrees"]=angle
        info["state"]=state
        info["mask_nonzero_pixels"]=int(np.count_nonzero(np.array(stool)>127))
        report["shots"][name]=info
    bpy.context.window.scene=bpy.data.scenes["C06_A"]
    for sc in old_scenes:
        bpy.data.scenes.remove(sc)
    for c in bpy.data.collections:
        if c.name.startswith("BLOCKOUT_ARCHIVE"):
            c.use_fake_user=False
    bpy.data.orphans_purge(do_recursive=True)
    assert len(bpy.data.scenes)==5 and not bpy.data.actions and not bpy.data.armatures
    for img in bpy.data.images:
        if img.source=="FILE" and not img.packed_file:
            raise ValueError("Unpacked image "+img.name)
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(out/"D1_STORY_SHOTS.blend"),compress=True)
    bpy.ops.wm.open_mainfile(filepath=str(out/"D1_STORY_SHOTS.blend"))
    assert set(bpy.data.scenes.keys())==set(SHOTS)
    report["reopened"]={sc.name:{"shot_id":sc["shot_id"],"camera":sc.camera.name,"fake_user":sc.use_fake_user}
                        for sc in bpy.data.scenes}
    assert hashlib.sha256(bpy.data.images["APPROVED_BG_WORKSHOP_02"].packed_file.data).hexdigest()==PLATE_SHA
    (out/"qa"/"SHOT_GEOMETRY.json").write_text(json.dumps(report,indent=2,default=serialize)+"\n")


def render(args):
    out=args.out.resolve()
    bpy.ops.wm.open_mainfile(filepath=str(out/"D1_STORY_SHOTS.blend"))
    destination=args.frame_dir.resolve() if args.frame_dir else out/"frames"
    destination.mkdir(exist_ok=True,parents=True)
    for k in args.shots:
        scene=bpy.data.scenes[k]
        bpy.context.window.scene=scene
        scene.render.resolution_percentage=args.percent
        scene.cycles.samples=args.samples
        scene.render.filepath=str(destination/(k+".png"))
        bpy.ops.render.render(write_still=True)


def verify(args):
    out=args.out.resolve()
    bpy.ops.wm.open_mainfile(filepath=str(out/"D1_STORY_SHOTS.blend"))
    aud={"method":"Single-sample opaque object-ID pass from each selected camera. Pixel coverage threshold is 50% linear. Apply the corresponding packed stool matte to the ID pass. Fairies outside the shot have zero occupied pixels.","shots":{}}
    mats={k:flat(k,rgb) for k,rgb in (("GEP",(1,0,0)),("PIN",(0,1,0)),("FAI",(0,0,1)),("other",(0,0,0)))}
    for k in SHOTS:
        sc=bpy.data.scenes[k]
        bpy.context.window.scene=sc
        sc.cycles.samples=1
        sc.render.use_compositing=False
        sc.render.film_transparent=False
        sc.render.dither_intensity=0
        sc.world.node_tree.nodes["Background"].inputs["Strength"].default_value=0
        for o in sc.objects:
            if o.is_shadow_catcher:
                o.hide_render=True
        assign(sc.objects,mats["other"])
        for who in ("GEP","PIN","FAI"):
            assign(actor(sc,who).instance_collection.all_objects,mats[who])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"id.png"
            sc.render.filepath=str(path)
            bpy.ops.render.render(write_still=True)
            pix=np.array(Image.open(path).convert("RGB"))
        stool=np.array(image_from_packed(k+"_stool_matte","L"))>=128
        stat={}
        for channel,who in enumerate(("GEP","PIN","FAI")):
            before=(pix[:,:,channel]>=188)&(pix.argmax(axis=2)==channel)
            visible=before & ~stool
            yy,xx=np.where(visible)
            stat[who]={"before_stool":int(before.sum()),"visible_pixels":len(yy),
                "fraction_occluded_by_stool":None if not before.any() else float(1-visible.sum()/before.sum()),
                "visible_pixel_ltrb":None if not len(yy) else [int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]}
        aud["shots"][k]=stat
    (out/"qa"/"SHOT_VISIBLE_ID.json").write_text(json.dumps(aud,indent=2)+"\n")


def render_signatures(args):
    """Compare actual evaluated scene ingredients before reusing an unaffected frame."""
    bpy.ops.wm.open_mainfile(filepath=str(args.blend.resolve()))
    data={}
    def rounded(x):
        return np.round(np.array(x,dtype=float),7).tolist()
    def mats_digest(mats):
        graph={}
        for m in mats:
            if m is None:
                continue
            sockets=[]
            for node in m.node_tree.nodes if m.use_nodes else []:
                settings=[]
                for port in node.inputs:
                    if not hasattr(port,"default_value"):
                        continue
                    value=port.default_value
                    if isinstance(value,(int,float,bool,str)):
                        val=value
                    elif hasattr(value,"__len__"):
                        val=list(value)
                    else:
                        continue
                    settings.append((port.name,val))
                sockets.append((node.name,node.bl_idname,settings))
            graph[m.name]=[sockets,sorted((l.from_node.name,l.from_socket.name,l.to_node.name,l.to_socket.name) for l in m.node_tree.links) if m.use_nodes else []]
        return hashlib.sha256(json.dumps(graph,sort_keys=True).encode()).hexdigest()
    for sc in bpy.data.scenes:
        bpy.context.window.scene=sc
        sc.frame_set(1)
        bpy.context.view_layer.update()
        dg=bpy.context.evaluated_depsgraph_get()
        source=[actor(sc,k) for k in ("GEP","PIN","FAI")]
        records=points_for(source)
        props=[o for o in sc.objects if o.type=="MESH" and not o.hide_render]
        positions={}
        actor_mats=set()
        for o in props:
            ev=o.evaluated_get(dg)
            mesh=ev.to_mesh()
            try:
                coords=np.empty(len(mesh.vertices)*3,dtype=np.float32)
                mesh.vertices.foreach_get("co",coords)
                mat=np.array(ev.matrix_world)
                positions[o.name]=coords.reshape(-1,3)@mat[:3,:3].T+mat[:3,3]
            finally:
                ev.to_mesh_clear()
            actor_mats.update(slot.material for slot in o.material_slots if slot.material)
        for root in source:
            for o in root.instance_collection.all_objects:
                actor_mats.update(slot.material for slot in o.material_slots if slot.material)
        lights={o.name:[rounded(o.evaluated_get(dg).matrix_world),o.data.energy,rounded(o.data.color),o.data.size]
                for o in sc.objects if o.type=="LIGHT"}
        cam=sc.camera.evaluated_get(dg)
        data[sc.name]={"actors":{k:digest_points(parts) for k,parts in zip(("GEP","PIN","FAI"),records)},
            "camera":[rounded(cam.matrix_world),cam.data.ortho_scale],"lights":lights,
            "visible_props":digest_points(positions),"materials":mats_digest(actor_mats),
            "plate_sha256":hashlib.sha256(bpy.data.images[sc.name+"_workshop_plate"].packed_file.data).hexdigest(),
            "matte_sha256":hashlib.sha256(bpy.data.images[sc.name+"_stool_matte"].packed_file.data).hexdigest(),
            "fabric_sha256":hashlib.sha256(next(im for im in bpy.data.images if im.name.startswith("Fabric026_weave")).packed_file.data).hexdigest(),
            "render_settings":[sc.cycles.samples,sc.cycles.adaptive_threshold,sc.view_settings.view_transform,
                               sc.view_settings.exposure,sc.render.resolution_x,sc.render.resolution_y]}
    args.output.write_text(json.dumps(data,indent=2)+"\n")


def optic_audit(args):
    from scipy.ndimage import map_coordinates
    out=args.out.resolve()
    bpy.ops.wm.open_mainfile(filepath=str(out/"D1_STORY_SHOTS.blend"))
    prior=json.loads(args.measurements.read_text())["states"]
    geo=json.loads((out/"qa"/"SHOT_GEOMETRY.json").read_text())
    audit={"method":"Project support XY on z=1.35 through each reopened story camera, sample that shot's actual painting coordinate map at sub-pixel precision, and compare to original wide-camera projection. Distances reported in 1440x810 source pixels; checks concern the support plane only.","shots":{}}
    wide=bpy.data.objects["C06_STATIC_SLEEP Camera"]
    for key,(_,left,top,width,radius) in SHOTS.items():
        sc=bpy.data.scenes[key]
        bpy.context.window.scene=sc
        sc.frame_set(1)
        bpy.context.view_layer.update()
        cam=sc.camera
        angle=geo["shots"][key]["azimuth_offset_degrees"]
        mapping=ray_samples(wide,cam,left,top,width,angle)
        if key.startswith("C06"):
            markers={k:v["closest_world_xyz"] for k,v in prior["C06"]["linen_contact"].items()}
        else:
            pin=points_for([actor(sc,"PIN")])[0]
            markers={}
            for side in ("Left","Right"):
                bottom=cloud(pin,lambda n:f"{side} boot / outsole" in n)
                markers[side]=bottom[bottom[:,2]<=bottom[:,2].min()+.0001].mean(axis=0)
        names=list(markers)
        pts=np.array([markers[n] for n in names],dtype=float)
        pts[:,2]=1.35
        story_px=project(sc,cam,pts)
        expected=project(sc,wide,pts)/SIZE
        if mapping:
            coords=[story_px[:,1]-.5,story_px[:,0]-.5]
            uv=np.column_stack([map_coordinates(mapping.uv_map[:,:,axis],coords,order=1,prefilter=False) for axis in range(2)])
        else:
            uv=np.column_stack(((left+story_px[:,0]*width/SIZE[0])/1440,(top+story_px[:,1]*width/SIZE[0])/810))
        errors=np.linalg.norm((uv-expected)*[1440,810],axis=1)
        audit["shots"][key]={n:{"registered_source_pixel_error":float(error),"story_pixel_xy":xy.tolist()} for n,error,xy in zip(names,errors,story_px)}
    (out/"qa"/"SHOT_PLATE_REGISTRATION.json").write_text(json.dumps(audit,indent=2)+"\n")


def spatial(args):
    out=args.out.resolve()
    bpy.ops.wm.open_mainfile(filepath=str(out/"D1_STORY_SHOTS.blend"))
    room=bpy.data.collections["S01 • shared physical workshop"]
    camera=next(o for o in room.objects if o.type=="CAMERA" and "eye-level" in o.name)
    for k in ("C06_A","C07_A","C07_JOY"):
        sc=bpy.data.scenes[k]
        bpy.context.window.scene=sc
        sc.render.resolution_percentage=70
        sc.cycles.samples=16
        diagnostic(sc,camera,room,out/"qa"/(k+"_SPATIAL.png"))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    commands=parser.add_subparsers(dest="command",required=True)
    cmd=commands.add_parser("build")
    cmd.add_argument("base",type=Path)
    cmd.add_argument("library",type=Path)
    cmd.add_argument("out",type=Path)
    cmd.add_argument("--rehearsal",action="store_true")
    cmd.add_argument("--angle",type=float,default=8)
    cmd=commands.add_parser("render")
    cmd.add_argument("out",type=Path)
    cmd.add_argument("--shots",choices=tuple(SHOTS),nargs="+",default=list(SHOTS))
    cmd.add_argument("--frame-dir",type=Path)
    cmd.add_argument("--percent",type=int,default=100)
    cmd.add_argument("--samples",type=int,default=40)
    cmd=commands.add_parser("signatures")
    cmd.add_argument("blend",type=Path)
    cmd.add_argument("output",type=Path)
    cmd=commands.add_parser("optics")
    cmd.add_argument("out",type=Path)
    cmd.add_argument("measurements",type=Path)
    for operation in ("verify","spatial"):
        commands.add_parser(operation).add_argument("out",type=Path)
    args=parser.parse_args(sys.argv[sys.argv.index("--")+1:])
    {"build":build,"render":render,"verify":verify,"spatial":spatial,"optics":optic_audit,"signatures":render_signatures}[args.command](args)
