"""Compose mobile review boards from the delivered PNG files and the approved drawing."""
import argparse
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

PAPER='#f4f0e7'
INK='#252c28'
GREEN='#29574a'
MUTED='#535d54'
LINE='#c9c9b9'
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-{}.ttc'


def lettering(canvas,xy,words,size,bold=False,color=INK):
    f=ImageFont.truetype(FONT.format('Bold' if bold else 'Regular'),size,index=1)
    ImageDraw.Draw(canvas).text(xy,words,font=f,fill=color,anchor='lt')


def sheet(title,subtitle,w,h):
    im=Image.new('RGB',(w,h),PAPER)
    lettering(im,(42,30),'윤수 피노키오   /   S01',20,True,GREEN)
    lettering(im,(42,72),title,43,True)
    lettering(im,(44,138),subtitle,21,False,MUTED)
    ImageDraw.Draw(im).line((42,180,w-42,180),fill=LINE,width=2)
    return im


def photo(im,p,xy,width,height=None):
    if not isinstance(p,Image.Image):
        p=Image.open(p)
    if height is None:height=round(width*p.height/p.width)
    fac=min(width/p.width,height/p.height)
    size=[round(p.width*fac),round(p.height*fac)]
    im.paste(p.convert('RGB').resize(size,Image.Resampling.LANCZOS),
             (xy[0]+(width-size[0])//2,xy[1]+(height-size[1])//2))


def boards(root,previous,approved):
    out=root/'boards';out.mkdir(exist_ok=True)
    frames=root/'frames';portraits=root/'portraits'
    for cut,desc in [('C06','잠든 피노키오를 바라보는 제페토'),('C07','기립한 피노키오를 보고 놀라는 제페토')]:
        im=sheet(cut+'  ·  구도 A와 B',desc+'  |  같은 자세와 같은 작업대에서 촬영',1116,1510)
        for i,(letter,lab) in enumerate([('A','A   작업대와 두 사람'),('B','B   얼굴과 손을 가까이')]):
            y=210+i*640
            lettering(im,(44,y),lab,27,True,GREEN)
            photo(im,frames/f'{cut}_{letter}.png',(44,y+47),1028)
        im.save(out/f'{cut}_CAMERA_AB.png')
    im=sheet('제페토  ·  세 가지 반응','같은 렌즈와 조명에서 얼굴·어깨·양손의 변화를 비교합니다.',1540,1200)
    for i,(v,label) in enumerate([('warm','인형을 살피는 미소'),('shock','깜짝 놀라 물러섬'),('joy','반기며 다가감')]):
        x=44+489*i
        lettering(im,(x,211),label,27,True,GREEN)
        photo(im,portraits/(v+'_face.png'),(x,266),473)
        photo(im,portraits/(v+'_pose.png'),(x,755),473,406)
    im.save(out/'D1_THREE_REACTIONS.png')

    im=sheet('제페토  ·  백발과 얼굴','승인 원화의 넘긴 앞머리와 귀 옆 곱슬, 턱수염과 미소를 함께 봅니다.',1540,859)
    art=Image.open(approved).crop((124,0,345,181))
    for i,(p,title) in enumerate([(art,'승인 원화'),(portraits/'previous_face.png','이전 제페토'),(portraits/'warm_face.png','국소 보정 후')]):
        x=44+489*i
        lettering(im,(x,217),title,30,True,GREEN if i==2 else INK)
        photo(im,p,(x,280),474,474)
    lettering(im,(44,792),'이전 모델과 보정본은 같은 스튜디오 조명으로 촬영했습니다. 고개 각도와 시선은 현재 자세를 따릅니다.',20,False,MUTED)
    im.save(out/'D1_FACE_REFERENCE.png')

    im=sheet('작업실  ·  수정 전후','각 행의 왼쪽은 이전 검토 화면, 오른쪽은 같은 상태를 담은 새 A 구도입니다.',1730,1310)
    for i,title in enumerate(['이전 전경','새 인물 중심 구도']):
        lettering(im,(44+831*i,205),title,30,True,GREEN if i else INK)
    for j,(cut,n,t) in enumerate([('C06','D1_C06_SLEEPING.png','C06   잠든 인형'),('C07','D1_C07_STANDING.png','C07   기립 직후')]):
        y=265+j*517
        lettering(im,(44,y),t,24,True)
        photo(im,previous/n,(44,y+43),813)
        photo(im,frames/f'{cut}_A.png',(875,y+43),813)
    im.save(out/'D1_SCREEN_BEFORE_AFTER.png')


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('root','previous','approved'):p.add_argument(k,type=Path)
    a=p.parse_args();boards(a.root,a.previous,a.approved)
