"""Measure the drawn pupil offset toward Pinocchio on the final camera plane."""
import itertools
import json
import math
import sys
from pathlib import Path

import bpy
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from shots import actor,project,points_for


def center(pts):
    return (pts.min(axis=0)+pts.max(axis=0))/2


def examine(scene):
    bpy.context.window.scene=scene
    bpy.context.view_layer.update()
    g,p=points_for([actor(scene,'GEP'),actor(scene,'PIN')])
    def locations(parts,term):
        return [center(project(scene,scene.camera,v)) for n,v in parts.items() if term in n.lower()]
    white=locations(g,'almond sclera')
    pupil=locations(g,' · pupil')
    pin=locations(p,'closed eyelid curve' if scene.name.startswith('C06') else 'deep pupil')
    assert len(white)==len(pupil)==2 and pin
    target=np.mean(pin,axis=0)
    pair=min(itertools.permutations(pupil),key=lambda a:sum(np.linalg.norm(w-i) for w,i in zip(white,a)))
    result=[]
    for w,i in zip(white,pair):
        a,b=i-w,target-w
        alignment=np.dot(a,b)/max(1e-8,np.linalg.norm(a)*np.linalg.norm(b))
        result.append(dict(white_center_px=w.tolist(),pupil_center_px=i.tolist(),
                           offset_px=a.tolist(),target_center_px=target.tolist(),
                           towards_target_halfplane=bool(np.dot(a,b)>0),
                           direction_difference_deg=round(math.degrees(math.acos(np.clip(alignment,-1,1))),1)))
    return result


def main():
    root=Path(sys.argv[sys.argv.index('--')+1])
    bpy.ops.wm.open_mainfile(filepath=str(root/'D1_STORY_SHOTS.blend'))
    report={'measure':'Screen-space visual cue: white-aperture bounding centre to pupil bounding centre versus eye-to-Pin face direction. A half-plane agreement is not a physical optical-axis or an emotion test. Occlusion by glasses is visually reviewed.'}
    for name in ('C06_A','C06_B','C07_A','C07_B','C07_JOY'):
        report[name]=examine(bpy.data.scenes[name])
    (root/'qa'/'GAZE_PROJECTION.json').write_text(json.dumps(report,indent=2))
    print({n:[r['direction_difference_deg'] for r in report[n]] for n in report if n!='measure'})

if __name__=='__main__':
    main()
