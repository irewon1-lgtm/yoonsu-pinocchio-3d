"""Three static acting sculpts on independent copies of the preserved D1 Geppetto.

Positions are local metres in his original studio space (+Z up, facing -Y).
The point transforms preserve garment registration, hand anatomy and full
contact at both soles. There are no skeletal or time-dependent scene objects.
"""
import math

import bpy
import numpy as np
from mathutils import Matrix


def vec(a):
    return np.asarray(a, dtype=np.float64)


def unit(a):
    return a / np.linalg.norm(a)


def rotation(axis, degrees):
    x, y, z = unit(vec(axis))
    a = math.radians(degrees)
    c, s = math.cos(a), math.sin(a)
    k = 1-c
    return np.array(((c+x*x*k, x*y*k-z*s, x*z*k+y*s),
                     (y*x*k+z*s, c+y*y*k, y*z*k-x*s),
                     (z*x*k-y*s, z*y*k+x*s, c+z*z*k)))


def euler(x, y, z):
    return rotation((0,0,1), z) @ rotation((0,1,0), y) @ rotation((1,0,0), x)


def align(source, target):
    a, b = unit(vec(source)), unit(vec(target))
    axis = np.cross(a,b)
    if np.linalg.norm(axis) < 1e-7:
        return np.eye(3) if a @ b > 0 else rotation((0,1,0),180)
    return rotation(axis, math.degrees(math.acos(float(np.clip(a@b,-1,1)))))


def frame(forward, normal):
    forward=unit(vec(forward))
    lateral=unit(np.cross(vec(normal),forward))
    return np.column_stack((forward,lateral,np.cross(forward,lateral)))


def smooth(lo, hi, x):
    f=np.clip((x-lo)/(hi-lo),0,1)
    return f*f*(3-2*f)


def move(points, origin, target, rotation_matrix):
    return (points-origin) @ rotation_matrix.T + target


# Elbow and wrist entries are directions, with the preserved segment lengths.
# The final two directions specify the open palm's finger line and palmar normal.
POSES={
    "warm": dict(torso=(4.0,-7.0,-13.0), shift=(-.041,.024,.0),
                 neck=(0.0,1.5,-13.0), weight=.025, step=(.025,-.034,-.012,.012),
                 shoulder=(.010,-.008),
                 opened=((.70,-.63,-.32),(.82,-.24,.52),(.93,-.34,.07),(-.20,-.89,-.42)),
                 tucked=((- .57,.02,-.82),(.14,-.69,-.70))),
    "shock": dict(torso=(-6,-9,-6), shift=(-.051,.022,-.025),
                  neck=(-11,-1,-13), weight=-.037, step=(.058,.058,-.037,-.014),
                  shoulder=(.038,.015),
                  opened=((.68,-.30,-.69),(-.51,-.70,.46),(-.90,.12,.39),(.16,.97,.14)),
                  tucked=((- .90,-.18,-.40),(-.16,-.74,.65))),
    "joy": dict(torso=(1.0,5.5,-6.0), shift=(.026,-.008,.012),
                neck=(-27.0,-2.0,-9.0), weight=.038, step=(.116,-.094,-.045,.045),
                shoulder=(.022,-.025),
                opened=((.59,-.36,-.72),(.64,-.17,.75),(.77,-.32,.55),(-.18,-.80,.64)),
                tucked=((- .72,-.26,-.63),(.51,-.77,.37))),
}


class Posture:
    pivot=vec((0,.030,.651))
    neck=vec((0,-.005,1.174))
    upper=vec((.240,.020,1.098))
    elbow=vec((.343,-.036,.907))
    wrist=vec((.537,-.146,1.054))
    other_upper=vec((-.246,.026,1.098))
    other_elbow=vec((-.404,.048,.885))
    other_wrist=vec((-.278,.147,.744))
    old_hand=frame((.954,-.034,.298),(-.26,-.56,.80))

    def __init__(self,variant):
        self.variant=variant
        self.pose=POSES[variant]
        self.R=euler(*self.pose["torso"])
        self.offset=vec(self.pose["shift"])
        self.arms={}
        for open_side in (True,False):
            s,e,w=(self.upper,self.elbow,self.wrist) if open_side else (self.other_upper,self.other_elbow,self.other_wrist)
            dirs=self.pose["opened" if open_side else "tucked"]
            er=s+unit(vec(dirs[0]))*np.linalg.norm(e-s)
            wr=er+unit(vec(dirs[1]))*np.linalg.norm(w-e)
            if open_side and variant in {"warm","joy"}:
                # Work backwards from the workshop contact: the wrist leads the fingers
                # underneath the sleeping cap, or extends up toward the standing boy.
                wrist_target,elbow_pole={
                    "warm":((.515,.030,.983),(.385,-.147,.805)),
                    "joy":((.698,-.339,1.250),(.404,-.120,.907)),
                }[variant]
                shoulder=self.upper_body(s[None,:])[0]
                wr=s+(vec(wrist_target)-shoulder)@self.R
                pole=s+(vec(elbow_pole)-shoulder)@self.R
                direction=unit(wr-s)
                length_a,length_b=np.linalg.norm(e-s),np.linalg.norm(w-e)
                distance=min(np.linalg.norm(wr-s),length_a+length_b-.001)
                wr=s+direction*distance
                along=(length_a**2-length_b**2+distance**2)/(2*distance)
                outside=unit(pole-s-direction*((pole-s)@direction))
                er=s+direction*along+outside*math.sqrt(max(0,length_a**2-along**2))
            upper_rot=align(e-s,er-s)
            lower_rot=align(upper_rot@(w-e),wr-er) @ upper_rot
            palm_rot=frame(dirs[2],dirs[3])@self.old_hand.T if open_side else lower_rot
            if not open_side and variant=="shock":
                # The resting hand has a smaller, cupped palm with fingers curled toward +Y.
                palm_rot=frame((-.36,-.27,.90),(-.08,-.96,-.31)) @ frame((.10,.09,-.99),(0,1,.10)).T
            if not open_side and variant=="joy":
                palm_rot=frame((.76,-.12,.64),(.12,.99,.05)) @ frame((.10,.09,-.99),(0,1,.10)).T
            quat=Matrix((palm_rot @ lower_rot.T).tolist()).to_quaternion()
            self.arms[open_side]=(s,e,w,er,wr,upper_rot,lower_rot,palm_rot,vec(quat.axis),quat.angle)

    def upper_body(self,p):
        q=move(p,self.pivot,self.pivot+self.offset,self.R)
        # Upper scapulae come forward as the chest rounds. Shrugs differ on each side.
        collar=np.clip(np.abs(p[:,0])/.24,0,1)
        strength=smooth(.84,1.09,p[:,2])*collar
        side=smooth(-.12,.12,p[:,0])
        left,right=self.pose["shoulder"]
        q[:,2]+=(left*(1-side)+right*side)*strength
        q[:,1]-=.026*strength
        return q

    def garment(self,p):
        z=p[:,2]
        result=p.copy()
        upper=smooth(.40,.98,z)[:,None]
        result+=(self.upper_body(p)-p)*upper
        result[:,0]+=self.pose["weight"]*smooth(.21,.65,z)*(1-smooth(.68,.99,z))
        return result

    def leg(self,p):
        z=p[:,2]
        front_x,front_y,back_x,back_y=self.pose["step"]
        side=smooth(-.045,.045,p[:,0])
        footweight=1-smooth(.19,.63,z)
        q=self.garment(p)
        q[:,0]+=(front_x*side+back_x*(1-side))*footweight
        q[:,1]+=(front_y*side+back_y*(1-side))*footweight
        # Both soles stay flat, while the advancing knee moves into the step.
        q[:,1]-=(.022*side+.010*(1-side))*np.sin(np.pi*np.clip((z-.16)/.43,0,1))**2
        return q

    def arm(self,p,open_side,part):
        s,e,w,er,wr,ru,rl,rh,axis,angle=self.arms[open_side]
        if not open_side and part=="forearm" and self.variant in {"shock","joy"}:
            p=p.copy()
            distal=(1-smooth(.675,.713,p[:,2]))*smooth(.152,.199,p[:,1])
            p[:,1]-=.049*distal
            p[:,2]-=.031*distal
            p[:,0]+=.16*(p[:,0]+.253)*distal
        upper=move(p,s,s,ru)
        lower=move(p,e,er,rl)
        hand=move(p,w,wr,rh)
        if part=="sleeve":
            # A signed angular bisector weights the bend across the joint, including compressed folds.
            bisector=unit(unit(e-s)+unit(w-e))
            influence=smooth(-.072,.069,(p-e)@bisector)[:,None]
            posed=upper*(1-influence)+lower*influence
        elif part=="roll":
            posed=lower
        elif part=="forearm":
            along=unit(w-e)
            # Spread pronation along the radius and ulna. Interpolating skin positions
            # directly would collapse the cross section when the palm turns over.
            amount=smooth(-.128,.025,(p-w)@along)[:,None]
            theta=angle*amount
            v=lower-wr
            posed=wr+v*np.cos(theta)+np.cross(axis,v)*np.sin(theta)
            posed+=np.outer(v@axis,axis)*(1-np.cos(theta))
        else:
            posed=hand
        # Carry the entire limb with its clavicle even where the palm passes below the belt.
        anchor=self.upper_body(s[None,:])[0]
        rigid_anchor=move(s,self.pivot,self.pivot+self.offset,self.R)
        return move(posed,self.pivot,self.pivot+self.offset,self.R)+(anchor-rigid_anchor)

    def head_transform(self):
        r=self.R @ euler(*self.pose["neck"])
        t=self.upper_body(self.neck[None,:])[0] - r@self.neck
        matrix=np.eye(4)
        matrix[:3,:3]=r
        matrix[:3,3]=t
        return Matrix(matrix.tolist())

    def deformer(self,name):
        if "Gathered linen sleeve" in name:
            return lambda p:self.arm(p,"sleeve 1" in name,"sleeve")
        if "Double rolled sleeve" in name:
            return lambda p:self.arm(p,"sleeve 1" in name,"roll")
        if "Open hand and forearm" in name:
            return lambda p:self.arm(p,True,"forearm")
        if "Resting hand and forearm" in name:
            return lambda p:self.arm(p,False,"forearm")
        if "Natural nail" in name or "Open palm creases" in name:
            return lambda p:self.arm(p,True,"palm")
        if any(s in name.lower() for s in ("trouser","boot","shoe","oxford")):
            return self.leg
        return self.garment


def transform_mesh(data, change):
    positions=np.empty((len(data.vertices),3),dtype=np.float32)
    data.vertices.foreach_get("co",positions.ravel())
    target=change(positions)
    data.vertices.foreach_set("co",np.asarray(target,dtype=np.float32).ravel())
    data.update()


def transform_curve(data,change):
    for spline in data.splines:
        if spline.type!="BEZIER":
            raise ValueError("Expected the preserved Bezier trim geometry")
        # Transform handles and points as one unit to keep stitches and welt tangents.
        bp=spline.bezier_points
        original=[(vec(p.co),vec(p.handle_left),vec(p.handle_right)) for p in bp]
        transformed=change(np.asarray(original).reshape(-1,3)).reshape(-1,3,3)
        for point,coords in zip(bp,transformed):
            point.co=coords[0]
        for point,coords in zip(bp,transformed):
            if point.handle_left_type not in {"AUTO","VECTOR"}:
                point.handle_left=coords[1]
            if point.handle_right_type not in {"AUTO","VECTOR"}:
                point.handle_right=coords[2]


def apply_body(body_collection, head_collection, variant):
    """Apply one static pose in original Geppetto space to caller-owned copies."""
    if variant not in POSES:
        raise ValueError(f"Unknown Geppetto acting variant {variant!r}")
    posture=Posture(variant)
    for obj in body_collection.all_objects:
        change=posture.deformer(obj.name)
        if obj.type=="MESH":
            transform_mesh(obj.data,change)
        elif obj.type=="CURVE":
            transform_curve(obj.data,change)
    transform=posture.head_transform()
    for obj in head_collection.all_objects:
        if obj.parent is None:
            obj.matrix_world=transform @ obj.matrix_world
    bpy.context.view_layer.update()
