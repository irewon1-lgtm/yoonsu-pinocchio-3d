"""A single skinned Geppetto with registered D1 facial and garment correctives.

build_gep_rig() operates on the open approved D1 file. CLI modes additionally
save an independent test file and reopen it for geometry and contact checks.
"""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import re
import sys

import bpy
import numpy as np
from mathutils import Matrix, Quaternion, Vector

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"story_shots"))
from acting_body import Posture

SCENE="D2_GEP_PERFORMANCE"
RIG="GEP_Performance_Rig"
FRAMES=(1,39,78)
SHOTS=("C06_B","C07_B","C07_JOY")
STATES=("Warm","Shock","Joy")
SWINGS={"L":((14,25),(47,60)),"R":((26,38),(61,77))}
FAMILY={"Eyes":((13,29),(49,69)),"Brows":((12,25),(46,68)),
        "Mouth":((17,32),(52,74)),"Cheeks":((15,33),(50,73)),
        "Body":((15,38),(46,77))}
IDENT=np.eye(4)
WARM_ARM_PARTS=('Gathered linen sleeve 1','Double rolled sleeve 1','Open hand and forearm','Natural nail','Open palm creases')


def adapted_arm(key):
    return any(name in key for name in WARM_ARM_PARTS)



def smooth(a,b,f):
    u=np.clip((f-a)/(b-a),0,1)
    return u*u*(3-2*u)


def act(points,matrix):
    return points@matrix[:3,:3].T+matrix[:3,3]


def mesh_coords(mesh):
    a=np.empty(len(mesh.vertices)*3,np.float32)
    mesh.vertices.foreach_get('co',a)
    return a.reshape(-1,3)


def curve_coords(curve):
    return np.array([[p.handle_left[:],p.co[:],p.handle_right[:]] for s in curve.splines for p in s.bezier_points]).reshape(-1,3)


def coords(ob):
    return mesh_coords(ob.data) if ob.type=='MESH' else curve_coords(ob.data)


def identity(ob):
    if ob.get('study_source_object'):
        return ob['study_source_object']
    stem=re.sub(r'(?:\.\d+)+$','',ob.name)
    if ob.type=='CURVE':return stem
    return stem+'|'+hashlib.sha1(mesh_coords(ob.data).tobytes()).hexdigest()[:12]


def pick(table,word):
    return next(k for k in table if word in k)


def gather(capture_trim=False):
    tables=[]
    worlds=[]
    for shot in SHOTS:
        sc=bpy.data.scenes[shot]
        bpy.context.window.scene=sc
        bpy.context.view_layer.update()
        root=next(o for o in sc.objects if o.name.startswith("GEP") and o.instance_type=='COLLECTION')
        coll=root.instance_collection
        head=next(c for c in coll.children if 'Face' in c.name)
        table={}
        dg=bpy.context.evaluated_depsgraph_get()
        for ob in coll.all_objects:
            key=identity(ob)
            matrix=np.array(ob.evaluated_get(dg).matrix_world)
            # Preserve the physical cross section of the wide rolled cloth
            # edging; its bevel is re-oriented by Blender on the baked D1 cage.
            trim=capture_trim and any(tag in key for tag in ('Waistcoat bound opening','Bib selvage','Leather armscye binding'))
            if trim:
                ev=ob.evaluated_get(dg)
                me=ev.to_mesh()
                vertices=mesh_coords(me)
                data=bpy.data.meshes.new_from_object(ev,depsgraph=dg) if not tables else None
                ev.to_mesh_clear()
                table[key]=(ob,False,matrix,act(vertices,matrix),data)
            else:
                table[key]=(ob,ob in head.objects[:],matrix,act(coords(ob),matrix))
        tables.append(table)
        worlds.append(root.evaluated_get(dg).matrix_world.copy())
    return tables,worlds


def rigid(a,b):
    ac,bc=a.mean(0),b.mean(0)
    u,_,v=np.linalg.svd((a-ac).T@(b-bc))
    r=v.T@u.T
    if np.linalg.det(r)<0:
        v[-1]*=-1
        r=v.T@u.T
    m=np.eye(4);m[:3,:3]=r;m[:3,3]=bc-r@ac
    return m


def unit(v):
    return v/max(1e-9,np.linalg.norm(v))


def make_guides(tables):
    warm=tables[0]
    bones={}
    def add(name,parent,head,tail,keys=None,where=None,exact=None):
        h,t=np.array(head),np.array(tail)
        if exact is None:
            samples=[np.concatenate([db[k][3] for k in keys]) for db in tables]
            mask=where(samples[0]) if where else np.ones(len(samples[0]),bool)
            assert mask.sum()>=3,name
            ds=[IDENT,rigid(samples[0][mask],samples[1][mask]),rigid(samples[0][mask],samples[2][mask])]
        else: ds=exact
        bones[name]=(parent,h,t,ds)
    add("Root",None,(0,0,0),(0,0,.15),exact=[IDENT]*3)
    pants=pick(warm,"Trouser legs")
    shirt=pick(warm,"Ivory gathered")
    head=pick(warm,"Continuous face sculpt")
    add("Pelvis","Root",(0,.01,.55),(-.016,.019,.75),[pants],lambda p:p[:,2]>.53)
    add("Chest","Pelvis",(-.016,.019,.75),(-.03,-.024,1.12),[shirt],lambda p:p[:,2]>.91)
    h0=tables[0][head][2]
    ds=[t[head][2]@np.linalg.inv(h0) for t in tables]
    add("Head","Chest",(-.028,-.012,1.155),(-.04,-.04,1.58),exact=ds)
    posture=Posture('warm')
    for right in (False,True):
        side='R' if right else 'L'
        index=1 if right else 0
        handed=side=='R'
        s,e,w,er,wr,*_=posture.arms[handed]
        shoulder=posture.upper_body(s[None,:])[0]
        elbow=posture.arm(e[None,:],handed,'roll')[0]
        wrist=posture.arm(w[None,:],handed,'palm')[0]
        sl=pick(warm,'Gathered linen sleeve '+str(index))
        palm=pick(warm,'Open hand and forearm' if handed else 'Resting hand and forearm')
        fore=unit(wrist-elbow)
        hum=unit(elbow-shoulder)
        chest=bones['Chest'][3]
        attach=np.array([-.026,-.018,1.103])
        arm_mask=lambda p:((p-shoulder)@hum)<np.linalg.norm(elbow-shoulder)*.74
        add("Clavicle."+side,"Chest",attach,shoulder,[sl],lambda p:((p-shoulder)@hum)<.048)
        add("UpperArm."+side,"Clavicle."+side,shoulder,elbow,[sl],arm_mask)
        add("Forearm."+side,"UpperArm."+side,elbow,wrist,[palm],lambda p:((p-wrist)@fore)<-.061)
        dist=np.linalg.norm(warm[palm][3]-elbow,axis=1)
        hand_keys=[k for k in warm if "Natural nail" in k] if handed else [palm]
        add("Hand."+side,"Forearm."+side,wrist,wrist+unit(warm[palm][3][dist>np.percentile(dist,92)].mean(0)-wrist)*.113,
            hand_keys,None if handed else lambda p:np.linalg.norm(p-elbow,axis=1)>np.percentile(dist,78))
        legside=1 if right else -1
        sole=pick(warm,'Boot ground sole '+str(legside))
        origin=warm[sole][3].mean(0)
        ankle=origin+np.array((0,.038,.09))
        knee=ankle+np.array((-.017*legside,-.033,.237))
        hip=knee+np.array((-.025*legside,.041,.265))
        add("Thigh."+side,"Pelvis",hip,knee,[pants],lambda p:(p[:,0]*legside>.037)&(p[:,2]>.36)&(p[:,2]<.52))
        add("Shin."+side,"Thigh."+side,knee,ankle,[pants],lambda p:(p[:,0]*legside>.045)&(p[:,2]>.17)&(p[:,2]<.31))
        add("Foot."+side,"Root",ankle,origin+np.array((0,-.087,.024)),[sole])
    return bones


def weight_map(key,p,guides):
    # Each row belongs to at most three deform groups. Quantization also lets
    # identical weights be assigned in bulk to large contiguous skin surfaces.
    n=len(p)
    def pack(d):
        d={k:np.broadcast_to(v,(n,)).copy() for k,v in d.items()}
        w=np.stack(list(d.values()),axis=1)
        quant=np.rint(w*32).astype(np.int16)
        quant[np.arange(n),w.argmax(1)]+=32-quant.sum(1)
        return {b:a.astype(float)/32 for b,a in zip(d,quant.T) if a.max()>0}
    if 'hand and forearm' in key or 'sleeve' in key or 'Natural nail' in key or 'Open palm' in key:
        side='R' if ('Open' in key or 'Natural nail' in key or 'sleeve 1' in key) else 'L'
        upper,lower,hand=['%s.%s'%(i,side) for i in ('UpperArm','Forearm','Hand')]
        s,e,w=guides[upper][1],guides[upper][2],guides[lower][2]
        if 'Natural nail' in key or 'Open palm' in key:return pack({hand:1})
        if 'Double rolled' in key:return pack({lower:1})
        if 'Gathered' in key:
            along=(p-e)@unit(unit(e-s)+unit(w-e))
            fl=smooth(-.082,.080,along)
            if side=='R':
                # The proximal sewn edge follows the clavicle during elevation.
                proximal=(1-smooth(.015,.115,(p-s)@unit(e-s)))*(1-fl)
                return pack({'Clavicle.R':proximal,upper:1-fl-proximal,lower:fl})
            return pack({upper:1-fl,lower:fl})
        fh=smooth(-.081,.036,(p-w)@unit(w-e))
        return pack({lower:1-fh,hand:fh})
    if any(k in key.lower() for k in ('boot','shoe','oxford','trouser')):
        side='L' if '-1' in key else 'R'
        if 'Trouser legs' not in key and 'Trouser side seam' not in key:
            return pack({'Foot.'+side:1})
        z=p[:,2]
        pelvis=smooth(.40,.59,z)
        thigh=smooth(.22,.39,z)*(1-pelvis)
        foot=(1-smooth(.12,.19,z))*(1-pelvis-thigh)
        shin=1-pelvis-thigh-foot
        right=smooth(-.020,.020,p[:,0])
        return pack({'Pelvis':pelvis,**{bone+'.'+s:amt*sideweight for s,sideweight in [('R',right),('L',1-right)] for bone,amt in [('Thigh',thigh),('Shin',shin),('Foot',foot)]}})
    upper=smooth(.66,.96,p[:,2])
    return pack({'Chest':upper,'Pelvis':1-upper})


def new_stage():
    base=bpy.data.scenes['C07_B']
    sc=base.copy();sc.name=SCENE
    bpy.context.window.scene=sc
    old=next(o for o in sc.objects if o.name.startswith('GEP') and o.instance_type=='COLLECTION')
    sc.collection.objects.unlink(old)
    # The copied scene's compositor Render Layers node must point at this scene.
    if sc.node_tree:
        for n in sc.node_tree.nodes:
            if n.type=='R_LAYERS':n.scene=sc
    sc.frame_start=1;sc.frame_end=84;sc.render.fps=24;sc.render.fps_base=1
    coll=bpy.data.collections.new('D2 | Geppetto continuous performer')
    sc.collection.children.link(coll)
    return sc,coll


def build_armature(coll,world,guides):
    ad=bpy.data.armatures.new('Geppetto articulated skeleton')
    rig=bpy.data.objects.new(RIG,ad)
    coll.objects.link(rig)
    rig.matrix_world=world
    bpy.context.view_layer.objects.active=rig;rig.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    for name,(parent,h,t,_) in guides.items():
        b=ad.edit_bones.new(name);b.head=h;b.tail=t
        if parent:b.parent=ad.edit_bones[parent]
        b.use_deform=name!='Root'
    bpy.ops.object.mode_set(mode='OBJECT')
    ad.display_type='OCTAHEDRAL'
    rig.show_in_front=True
    return rig


def stages(f,spans):
    return (smooth(*spans[0],f),smooth(*spans[1],f))


def bone_deform(name,guide,f):
    _,pivot,_,ds=guide
    family='Body'
    if name=='Head':spans=((14,31),(49,71))
    elif 'Hand' in name:spans=((17,35),(52,75))
    elif name.startswith(('Forearm','UpperArm','Clavicle')):spans=((16,36),(50,76))
    elif name.startswith(('Foot','Shin','Thigh')):
        spans=SWINGS[name[-1]]
    else:spans=FAMILY[family]
    a,b=stages(f,spans)
    i,j,t=(1,2,b) if b>0 else (0,1,a)
    q1,q2=[Matrix(ds[k][:3,:3].tolist()).to_quaternion() for k in (i,j)]
    rot=np.array(q1.slerp(q2,float(t)).to_matrix())
    pos=(1-t)*act(pivot,ds[i])+t*act(pivot,ds[j])
    if name.startswith(('Foot','Shin','Thigh')):
        u1,u2=spans[1 if b>0 else 0]
        swing=math.sin(math.pi*float(np.clip((f-u1)/(u2-u1),0,1)))**2
        amplitude={'Foot':.030,'Shin':.023,'Thigh':.008}[name.partition('.')[0]]
        pos[2]+=amplitude*swing
        if name.startswith("Shin"):pos[1]-=.018*swing
    m=np.eye(4);m[:3,:3]=rot;m[:3,3]=pos-rot@pivot
    return m


def connected_offering_arm(d,guides,f):
    # Preserve the signed anatomical offsets at the endpoints. Interpolate
    # each joint in its parent's moving space so the wrist cannot cut through
    # the cuff while the forearm swings between very different orientations.
    a,b=stages(f,FAMILY['Body'])
    i,j,t=(1,2,b) if b>0 else (0,1,a)
    for child,parent in [('Forearm.R','UpperArm.R'),('Hand.R','Forearm.R')]:
        h=guides[child][1]
        orig=guides[child][3]
        pg=guides[parent][3]
        offs=[(act(h,orig[k])-act(h,pg[k]))@pg[k][:3,:3] for k in (i,j)]
        joint=act(h,d[parent])+d[parent][:3,:3]@((1-t)*offs[0]+t*offs[1])
        if child=='Hand.R':
            qs=[Matrix((pg[k][:3,:3].T@orig[k][:3,:3]).tolist()).to_quaternion() for k in (i,j)]
            d[child][:3,:3]=d[parent][:3,:3]@np.array(qs[0].slerp(qs[1],float(t)).to_matrix())
        d[child][:3,3]=joint-d[child][:3,:3]@h


def worktop_cloth_modifier(ob):
    # Rounded cloth compression at the front edge of the actual fixed worktop.
    # The half-space also covers the protruding woven selvedge. The sleeve
    # slides out and up only where it would enter the solid tabletop volume.
    group=bpy.data.node_groups.get('GEP | fitted worktop edge')
    if group is None:
        group=bpy.data.node_groups.new('GEP | fitted worktop edge','GeometryNodeTree')
        group.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry')
        group.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
        nodes=group.nodes
        def connect(value,socket):
            if isinstance(value,bpy.types.NodeSocket):group.links.new(value,socket)
            else:socket.default_value=value
        def mathop(op,x,y):
            n=nodes.new('ShaderNodeMath');n.operation=op
            connect(x,n.inputs[0]);connect(y,n.inputs[1]);return n.outputs[0]
        src=nodes.new('NodeGroupInput');dst=nodes.new('NodeGroupOutput')
        pos=nodes.new('GeometryNodeInputPosition').outputs[0]
        sep=nodes.new('ShaderNodeSeparateXYZ');connect(pos,sep.inputs[0])
        dot=nodes.new('ShaderNodeVectorMath');dot.operation='DOT_PRODUCT'
        connect(pos,dot.inputs[0]);dot.inputs[1].default_value=(.457,.889,0)
        inward=mathop('SUBTRACT',dot.outputs['Value'],.064)
        below=mathop('SUBTRACT',.951,sep.outputs['Z'])
        crossing=mathop('MINIMUM',inward,below)
        amount=mathop('MAXIMUM',crossing,0.)
        vec=nodes.new('ShaderNodeVectorMath');vec.operation='SCALE'
        vec.inputs[0].default_value=(-.457,-.889,1.)
        connect(amount,vec.inputs['Scale'])
        move=nodes.new('GeometryNodeSetPosition')
        connect(src.outputs['Geometry'],move.inputs['Geometry'])
        connect(vec.outputs[0],move.inputs['Offset'])
        connect(move.outputs['Geometry'],dst.inputs['Geometry'])
    mod=ob.modifiers.new('Contact with worktop edge','NODES')
    mod.node_group=group


def elevated_arm(d,guides,f):
    # The signed WARM arm was offered beside sleeping Pinocchio in C06. In
    # the standing C07_B stage the cuff would cross the traced worktop there.
    # Rotation is about the shoulder and then the elbow, maintaining limb length.
    strength=1-smooth(22,35,f)
    if strength<=0:return
    def pivot_rotation(pivot,degrees):
        r=np.array(Matrix.Rotation(math.radians(-degrees*strength),3,'Y'))
        m=np.eye(4);m[:3,:3]=r;m[:3,3]=pivot-r@pivot
        return m
    s=act(guides['UpperArm.R'][1],d['UpperArm.R'])
    e=act(guides['Forearm.R'][1],d['Forearm.R'])
    shoulder=pivot_rotation(s,29)
    elbow=pivot_rotation(e,-12)
    d['UpperArm.R']=shoulder@d['UpperArm.R']
    for n in ('Forearm.R','Hand.R'):
        d[n]=shoulder@elbow@d[n]


def action_curve(action,path,index,points):
    fc=action.fcurves.new(path,index=index)
    fc.keyframe_points.add(len(points))
    fc.keyframe_points.foreach_set('co',np.array(points,np.float32).ravel())
    for p in fc.keyframe_points:p.interpolation='LINEAR'
    fc.update()


def animate_rig(rig,guides):
    action=bpy.data.actions.new('GEP | Listen, recoil, welcome')
    rig.animation_data_create().action=action
    frames=range(1,85)
    matrices={f:{k:bone_deform(k,g,f) for k,g in guides.items()} for f in frames}
    for f,d in matrices.items():
        connected_offering_arm(d,guides,f)
        elevated_arm(d,guides,f)
    for name,(parent,*_) in guides.items():
        if not parent:continue
        bone=rig.pose.bones[name]
        rest=np.array(bone.bone.matrix_local)
        values=[]
        prior=None
        for f in frames:
            d=matrices[f]
            local=np.linalg.inv(rest)@np.linalg.inv(d[parent])@d[name]@rest
            loc,rot,_=Matrix(local.tolist()).decompose()
            if prior is not None:rot.make_compatible(prior)
            prior=rot.copy();values.append([*loc,*rot])
        for prop,off,count in [('location',0,3),('rotation_quaternion',3,4)]:
            for k in range(count):
                action_curve(action,bone.path_from_id(prop),k,[(f,values[f-1][off+k]) for f in frames])
    for family,spans in FAMILY.items():
        for i,state in enumerate(STATES[1:]):
            prop=family+'_'+state
            rig[prop]=0.
            rig.id_properties_ui(prop).update(min=0.,max=1.,soft_min=0.,soft_max=1.)
            vals=[]
            for f in frames:
                a,b=stages(f,spans)
                vals.append((f,float(a-b if i==0 else b)))
            action_curve(action,'["'+prop+'"]',0,vals)
    rig['C07_B_worktop_adjustment']='Frames 1–22: offering upper arm +29 degrees elevation around the shoulder, forearm -12 degrees at the elbow; eases out by frame 35. D1 reference scenes remain intact.'
    rig['Performance']='Warm 1–12 · surprise 39–44 · joy 78–84'
    rig['Sole_contacts']='L 14–25/47–60, R 26–38/61–77 are swing intervals; boundaries are planted.'
    return matrices


def family_of(key,is_head):
    if not is_head:return 'Body'
    lower=key.lower()
    if 'eyebrow' in lower or 'forehead crease' in lower:return 'Brows'
    if any(w in lower for w in ('sclera','limbal','iris','pupil','glint','eyelid','lash')):return 'Eyes'
    if any(w in lower for w in ('mouth','smile · upper teeth','tongue',' lip','open smile','moustache','vermilion')):return 'Mouth'
    return 'Cheeks'


def drive(block,rig,prop):
    fc=block.driver_add('value')
    d=fc.driver;d.type='AVERAGE'
    v=d.variables.new();v.name='performance';v.type='SINGLE_PROP'
    v.targets[0].id=rig;v.targets[0].data_path='["'+prop+'"]'


def curve_write(data,arr,shape=False):
    points=data if shape else [p for spline in data.splines for p in spline.bezier_points]
    for point,(lh,co,rh) in zip(points,arr.reshape(-1,3,3)):
        point.co=co
        point.handle_left=lh;point.handle_right=rh


def assign_weights(ob,weights):
    for name,w in weights.items():
        g=ob.vertex_groups.new(name=name)
        for val in np.unique(w[w>0]):
            idx=np.flatnonzero(w==val).tolist()
            g.add(idx,float(val),'REPLACE')


def inverse_skin(target,weights,transforms):
    if len(weights)==1:
        return act(target,np.linalg.inv(transforms[next(iter(weights))]))
    # Blender's ordinary armature skinning blends the affine matrices first.
    mat=sum(w[:,None,None]*transforms[b][None,:3,:] for b,w in weights.items())
    return np.linalg.solve(mat[:,:,:3],(target-mat[:,:,3])[:,:,None])[:,:,0]


def bind_part(key,rows,coll,rig,guides,matrices):
    src,head,native,warm=rows[0][:4]
    if len(rows[0])==5:
        ob=bpy.data.objects.new(src.name+' | tailored edge',rows[0][4])
    else:
        ob=src.copy();ob.data=src.data.copy()
    ob.name='D2 GEP | '+key.split('|')[0].removeprefix('GEP · ')
    ob['D2_source_key']=key;ob['D2_source_type']=src.type
    coll.objects.link(ob)
    ob.parent=rig;ob.matrix_parent_inverse=Matrix.Identity(4);ob.matrix_basis=Matrix.Identity(4)
    w={'Head':np.ones(len(warm))} if head else weight_map(key,warm,guides)
    if ob.type=='MESH':
        ob.data.vertices.foreach_set('co',warm.astype(np.float32).ravel());ob.data.update()
        assign_weights(ob,w)
        mod=ob.modifiers.new('Performance bones','ARMATURE');mod.object=rig
        # Skin the actual control cage before any pre-existing smoothing.
        ob.modifiers.move(len(ob.modifiers)-1,0)
    else:
        # Native Bezier keys preserve handle correspondence across D1 states.
        bone=max(w,key=lambda k:w[k].sum())
        w={bone:np.ones(len(warm))}
        ob.parent_type='BONE';ob.parent_bone=bone
        rest=rig.data.bones[bone]
        tail=rest.matrix_local@Matrix.Translation((0,rest.length,0))
        ob.matrix_parent_inverse=tail.inverted()
        # Keep the source curve's anisotropic cross section (glasses and lids).
        ob.matrix_basis=Matrix(native.tolist())
        curve_write(ob.data,act(warm,np.linalg.inv(native)))
    family=family_of(key,head)
    basis=False
    for j,(state,f) in enumerate(zip(STATES[1:],FRAMES[1:]),1):
        target=inverse_skin(rows[j][3],w,matrices[f])
        if np.max(np.abs(target-warm))<.000015:continue
        if not basis:ob.shape_key_add(name='D1 Warm');basis=True
        bk=ob.shape_key_add(name=family+' '+state,from_mix=False)
        if ob.type=='MESH':bk.data.foreach_set('co',target.astype(np.float32).ravel())
        else:curve_write(bk.data,act(target,np.linalg.inv(native)),True)
        drive(bk,rig,family+'_'+state)
    if any(k in key for k in ('Gathered linen sleeve 1','Double rolled sleeve 1')):worktop_cloth_modifier(ob)
    return ob


def add_shock_lip(key,tables,coll,rig,guides,matrices):
    # The upper lip exists throughout. It rests under the moustache at zero
    # diameter in warm/joy and rolls into its native contour for surprise.
    row=tables[1][key]
    src,_,_,posed=row
    base=act(posed,np.linalg.inv(matrices[39]['Head']))
    rows=[(src,True,np.linalg.inv(matrices[39]['Head'])@row[2],base),row,(src,True,IDENT,act(base,matrices[78]['Head']))]
    ob=bind_part(key,rows,coll,rig,guides,matrices)
    depth=ob.data.bevel_depth
    fc=ob.data.driver_add('bevel_depth')
    d=fc.driver;d.type='SCRIPTED'
    v=d.variables.new();v.name='shock';v.targets[0].id=rig;v.targets[0].data_path='["Mouth_Shock"]'
    d.expression=f'{depth:.9f}*shock'
    return ob


def build_gep_rig():
    """Return the new performance scene. The caller owns save and render paths."""
    if SCENE in bpy.data.scenes:raise ValueError('Open the D1 source before building the Geppetto performer')
    tables,worlds=gather(capture_trim=True)
    guides=make_guides(tables)
    sc,coll=new_stage()
    rig=build_armature(coll,worlds[0],guides)
    matrices=animate_rig(rig,guides)
    for key in tables[0]:
        bind_part(key,[tab[key] for tab in tables],coll,rig,guides,matrices)
    for key in set(tables[1])-set(tables[0]):
        add_shock_lip(key,tables,coll,rig,guides,matrices)
    for f,text in [(1,'Listen'),(14,'Weight shift'),(26,'Second foot'),(39,'Surprised hold'),
                   (47,'Release'),(61,'Step toward Pinocchio'),(78,'Joyful open palm')]:
        sc.timeline_markers.new(text,frame=f)
    sc.frame_set(1);bpy.context.view_layer.update()
    return sc


def inspect_geometry(ob,dg,stage=None):
    ev=ob.evaluated_get(dg)
    me=ev.to_mesh()
    points=mesh_coords(me).astype(float)
    ev.to_mesh_clear()
    m=np.array(ev.matrix_world)
    if stage is not None:m=stage@m
    return act(points,m)


def compare_endpoint(sc,shot,f,performers):
    source=bpy.data.scenes[shot];bpy.context.window.scene=source
    bpy.context.view_layer.update()
    dg=bpy.context.evaluated_depsgraph_get()
    root=next(o for o in source.objects if o.name.startswith('GEP') and o.instance_type=='COLLECTION')
    m=np.array(root.evaluated_get(dg).matrix_world)
    targets={identity(o):inspect_geometry(o,dg,m) for o in root.instance_collection.all_objects}
    bpy.context.window.scene=sc;sc.frame_set(f)
    dg=bpy.context.evaluated_depsgraph_get()
    errors=[];stage_arm=[];cloth=[];all_square=0;total=0
    for k,ref in targets.items():
        ob=performers[k]
        a=inspect_geometry(ob,dg)
        if len(a)!=len(ref):raise RuntimeError(f'{k} evaluated count changed {len(a)}/{len(ref)}')
        if ob.type=='CURVE':
            # Bevel caps can permute triangle/loop order, irrespective of shape.
            # Compare the re-evaluated surfaces in both directions.
            from scipy.spatial import cKDTree
            dist=np.r_[cKDTree(ref).query(a)[0],cKDTree(a).query(ref)[0]] if len(a) else np.array([0.])
        else:dist=np.linalg.norm(a-ref,axis=1)
        if f==FRAMES[0] and adapted_arm(k):
            stage_arm.append({'name':k,'max_world_mm':float(dist.max()*1000),
                              'rms_world_mm':float(np.sqrt(np.mean(dist**2))*1000)})
            continue
        if f==39 and 'Gathered linen sleeve 1' in k:
            cloth.append({'name':k,'max_world_mm':float(dist.max()*1000),
                          'rms_world_mm':float(np.sqrt(np.mean(dist**2))*1000),
                          'corrected_vertices_over_1mm':int((dist>.001).sum()),'vertices':len(dist)})
            continue
        errors.append((float(dist.max()),k,float(np.sqrt(np.mean(dist**2)))))
        all_square+=float((dist**2).sum());total+=len(dist)
    errors.sort(reverse=True)
    return {'source_scene':shot,'frame':f,'matched_parts':len(errors),'evaluated_points':total,'C07_B_offering_arm_differences':stage_arm,'C07_B_worktop_cloth_differences':cloth,
            'rms_world_mm':np.sqrt(all_square/total)*1000,'max_world_mm':errors[0][0]*1000,
            'worst_parts':[{'name':k,'max_world_mm':m*1000,'rms_world_mm':r*1000} for m,k,r in errors[:12]]}


def validate_gep_rig(folder):
    """Read the saved scene and measure actual evaluated geometry in world metres."""
    folder=Path(folder);sc=bpy.data.scenes[SCENE];bpy.context.window.scene=sc
    rig=sc.objects[RIG];parts={o['D2_source_key']:o for o in sc.objects if o.get('D2_source_key')}
    endpoint=[]
    for shot,f in zip(SHOTS,FRAMES):
        row=compare_endpoint(sc,shot,f,parts);endpoint.append(row)
        print('ENDPOINT',shot,row['rms_world_mm'],row['max_world_mm'],row['worst_parts'][:2],flush=True)
    soles={s:parts[pick(parts,'Boot ground sole '+str(sign))] for s,sign in [('L',-1),('R',1)]}
    idx={}
    history={s:[] for s in soles}
    floor=None
    tracks={}
    hs=pick(parts,'Open hand and forearm');iris=pick(parts,'Amber iris')
    mouth=pick(parts,'Open smile')
    for f in range(1,85):
        sc.frame_set(f)
        dg=bpy.context.evaluated_depsgraph_get()
        for side,ob in soles.items():
            pts=inspect_geometry(ob,dg)
            if f==1:
                floor=float(pts[:,2].min());idx[side]=np.flatnonzero(pts[:,2]<floor+.0005)
            history[side].append(pts[idx[side]])
        if f in (1,12,22,28,39,44,57,62,72,78,84):
            tracks[f]={'hand_center':inspect_geometry(parts[hs],dg).mean(0).tolist(),
                       'near_iris_center':inspect_geometry(parts[iris],dg).mean(0).tolist(),
                       'oral_opening_z_span':float(np.ptp(inspect_geometry(parts[mouth],dg)[:,2]))}
    details={};contact=np.zeros(84,dtype=int)
    for side,frames in history.items():
        h=np.stack(frames)
        spans=SWINGS[side]
        holds=[(1,spans[0][0]),(spans[0][1],spans[1][0]),(spans[1][1],84)]
        stat=[]
        for a,b in holds:
            drift=np.linalg.norm(h[a-1:b,:,:2]-h[a-1:a,:,:2],axis=2)
            dz=abs(h[a-1:b,:,2]-floor)
            stat.append({'frames':[a,b],'max_xy_slip_mm':float(drift.max()*1000),'max_floor_error_mm':float(dz.max()*1000)})
            contact[a-1:b]+=1
        swings=[{'frames':[a,b],'peak_minimum_clearance_mm':float((h[a-1:b,:,2].min(1).max()-floor)*1000),
                 'net_step_mm':float(np.linalg.norm(h[b-1,:,:2].mean(0)-h[a-1,:,:2].mean(0))*1000)} for a,b in spans]
        details[side]={'tracked_sole_indices':idx[side].tolist(),'planted_intervals':stat,'steps':swings,'minimum_world_z_m':float(h[:,:,2].min())}
    body=next(o for o in parts.values() if 'Trouser legs' in o.name)
    skinned=[o for o in parts.values() if any(m.type=='ARMATURE' and m.object==rig for m in o.modifiers)]
    controls={o.data.shape_keys for o in parts.values() if o.data.shape_keys}
    peak=max(r['max_world_mm'] for r in endpoint)
    checks={'poses_reconstructed':peak<1.5,
            'WARM_changed_set_matches_offering_arm':len(endpoint[0]['C07_B_offering_arm_differences'])==8,
            'SHOCK_body_and_JOY_all_approved_parts':all(not r['C07_B_offering_arm_differences'] for r in endpoint[1:]) and len(endpoint[1]['C07_B_worktop_cloth_differences'])==1 and not endpoint[2]['C07_B_worktop_cloth_differences'],'one_fixed_foot_every_frame':int(contact.min())>=1,
            'fixed_sole_xy_slip_below_half_mm':all(a['max_xy_slip_mm']<.5 for d in details.values() for a in d['planted_intervals']),
            'fixed_sole_floor_error_below_half_mm':all(a['max_floor_error_mm']<.5 for d in details.values() for a in d['planted_intervals']),
            'positive_step_clearance':all(a['peak_minimum_clearance_mm']>20 for d in details.values() for a in d['steps']),
            'weighted_body':len(body.vertex_groups)>2 and len(skinned)>30,
            'independent_facial_controls':all(p in rig for p in ('Eyes_Shock','Brows_Shock','Mouth_Joy','Cheeks_Joy')),
            'motion_measured':np.linalg.norm(np.array(tracks[39]['hand_center'])-tracks[78]['hand_center'])>.05 and abs(tracks[1]['oral_opening_z_span']-tracks[39]['oral_opening_z_span'])>.007}
    report={'scene':sc.name,'fps':sc.render.fps,'frames':[1,84],'checkpoints':list(FRAMES),'floor_world_z_m':floor,
            'single_actor':{'performer_parts':len(parts),'weighted_meshes':len(skinned),'deforming_bones':sum(b.use_deform for b in rig.data.bones),
                            'objects_with_shape_keys':len(controls),'action':rig.animation_data.action.name,'source_camera':sc.camera.name},
            'endpoints':endpoint,'soles':details,'minimum_number_of_planted_feet_every_frame':int(contact.min()),'sampled_tracks':tracks,
            'checks':checks,'status':'PASS' if all(checks.values()) else 'FAIL'}
    folder.mkdir(exist_ok=True,parents=True)
    (folder/'GEP_RIG_QA.json').write_text(json.dumps(report,indent=2))
    print('GEP QA',checks,flush=True)
    if not all(checks.values()):raise RuntimeError('GEP rig QA failed')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('build','validate','previews'))
    parser.add_argument('output',type=Path)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
    if args.mode=='build':
        build_gep_rig()
        bpy.context.preferences.filepaths.save_version=0
        bpy.ops.wm.save_as_mainfile(filepath=str(args.output.resolve()),compress=True)
    elif args.mode=='validate':
        validate_gep_rig(args.output)
    else:
        args.output.mkdir(parents=True,exist_ok=True)
        sc=bpy.data.scenes[SCENE];bpy.context.window.scene=sc
        sc.render.resolution_percentage=52;sc.cycles.samples=12
        for f in (1,22,39,62,78):
            sc.frame_set(f)
            sc.render.filepath=str(args.output.resolve()/f'GEP_{f:03}.png')
            bpy.ops.render.render(write_still=True,scene=SCENE)


if __name__=='__main__':
    main()
