"""Validate the delivered rigged .blend in an independent Blender process.

blender -b -t 1 --python-exit-code 1 --python d2_gate.py -- sources LOCKED_SOURCE_DIR QA
blender -b -t 1 --python-exit-code 1 --python d2_gate.py -- retained D2.blend QA
blender -b -t 1 --python-exit-code 1 --python d2_gate.py -- pin D2.blend QA
blender -b -t 1 --python-exit-code 1 --python d2_gate.py -- gep D2.blend QA
blender -b -t 1 --python-exit-code 1 --python d2_gate.py -- finish D2.blend QA
"""
from collections import Counter
import hashlib
import re
import json
from pathlib import Path
import sys
import tempfile

import bpy
import numpy as np
from mathutils import Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
import d1_gate

D1_SHA = '546a6b91790b0b4ef78f7a3697892dffe56cfc38c03d0b3c153c05d9af3d3b09'
PIN_SCENE = 'D2_PIN_CONTROLS'
GEP_SCENE = 'D2_GEP_PERFORMANCE'


def compare_retained(path, qa):
    """Prove equality of all retained scene ingredients from freshly evaluated meshes."""
    prior = json.loads((qa / 'D1_FINAL_SNAPSHOT.json').read_text())
    if prior['file_sha256'] != D1_SHA:
        raise ValueError('Unrecognized approved geometry snapshot')
    with tempfile.TemporaryDirectory() as tmp:
        dest = Path(tmp) / 'retained.json'
        d1_gate.snapshot(path, dest)
        new = json.loads(dest.read_text())
    data = {'blend_sha256': new['file_sha256'], 'source_d1_sha256': D1_SHA, 'scenes': {}, 'checks': {}}
    expected = set(d1_gate.SHOTS) | {'C05_END_HOLD'}
    data['checks']['all_six_retained'] = set(new['scenes']) == set(prior['scenes']) == expected
    for scene in sorted(expected):
        original, current = prior['scenes'][scene], new['scenes'][scene]
        if set(current) != set(original):
            raise ValueError((scene, set(current), set(original)))
        diffs = [k for k in current if current[k] != original[k]]
        data['scenes'][scene] = {
            'changed_fields': diffs, 'actor_objects': {k:len(v) for k,v in current['actors'].items()},
            'source_actor_geometry_and_matrices_sha256':d1_gate.digest(original['actors']),
            'live_actor_geometry_and_matrices_sha256':d1_gate.digest(current['actors']),
            'source_root_sha256':d1_gate.digest(original['roots']), 'live_root_sha256':d1_gate.digest(current['roots'])}
        data['checks'][scene + ' all geometry, world matrices, roots, lights, camera, stage, optics and contacts'] = not diffs
    for field in ('images', 'materials'):
        data['checks']['retained '+field] = all(new[field].get(k) == v for k,v in prior[field].items())
    data['checks']['original packed workshop artwork'] = new['approved_bg'] == d1_gate.BG
    data['checks']['two armatures in delivered file'] = new['armatures'] == 2
    data['checks']['portable'] = not bpy.data.libraries and all(im.packed_file or im.source in ('GENERATED','VIEWER')
        for im in bpy.data.images if im.users)
    data['checks']['approved source SHA table'] = all(x['same_as_registry'] for x in json.loads((qa/'D1_LOCKED_SOURCES.json').read_text()))
    d1_gate.save(qa/'D2_RETAINED.json',data)
    print('Retained checks:', data['checks'], flush=True)


def gated(checks, label, value):
    checks[label] = bool(value)


def geometry(obj, dg):
    """World coordinates read after all modifiers, preserving vertex order."""
    ev = obj.evaluated_get(dg)
    mesh = ev.to_mesh()
    try:
        coords = np.empty((len(mesh.vertices),3), dtype=np.float32)
        mesh.vertices.foreach_get('co', coords.ravel())
        matrix = np.asarray(ev.matrix_world)
        return coords @ matrix[:3,:3].T + matrix[:3,3]
    finally:
        ev.to_mesh_clear()


def rigged_parts(scene, rig):
    parts = []
    modes = Counter()
    for obj in scene.objects:
        if obj.type not in d1_gate.TYPES: continue
        mod=any(m.type=='ARMATURE' and m.object==rig for m in obj.modifiers)
        current=obj; bone=False
        while current.parent:
            if current.parent==rig and current.parent_type=='BONE':
                bone=True
                break
            current=current.parent
        if mod or bone:
            parts.append(obj)
            modes['armature_modifier' if mod else 'bone_parent']+=1
    return parts, dict(modes)


def with_words(parts, *words):
    matches = sorted((o for o in parts if all(w in o.name.lower() for w in words)), key=lambda o:o.name)
    if not matches:
        raise ValueError(f'Missing part {words}. Search among {[o.name for o in parts][:12]}')
    return matches[0]


def markers(scene):
    return {m.name:m.frame for m in scene.timeline_markers}


def bound_group(obj,rig):
    names={b.name for b in rig.data.bones}
    return [v.name for v in obj.vertex_groups if v.name in names]


def indices(cloud):
    return np.unique(np.linspace(0,len(cloud)-1,min(57,len(cloud)),dtype=int))


def change(a,b):
    """Maximum Euclidean movement of identical vertex indices."""
    return float(np.linalg.norm(a-b,axis=1).max())


def support_result(points, table):
    low_id=int(points[:,2].argmin())
    p=points[low_id]
    # Cast against the evaluated visible receiver, never infer height from root Z.
    hit=table.ray_cast(Vector((p[0],p[1],7.0)),Vector((0,0,-1)),9.0)[0]
    if hit is None: return None
    return float(p[2]-hit.z)


def planted_metrics(frames, xyz, gaps, intervals):
    """Compare every matched sole vertex XY to its position at each plant onset."""
    tested=[]
    for first,last in intervals:
        fi,li=frames.index(first),frames.index(last)
        witness=xyz[fi]
        drift=[float(np.max(np.linalg.norm(pts[:,:2]-witness[:,:2],axis=1))) for pts in xyz[fi:li+1]]
        tested.append({'first':first,'last':last,'max_paired_sole_xy_drift_bu':max(drift),
                       'max_abs_surface_gap_bu':max(abs(v) for v in gaps[fi:li+1]),'peak_drift_frame':first+int(np.argmax(drift))})
    return tested


def surface_for(scene,dg,who):
    tables=d1_gate.surfaces(scene,dg)
    phrase='Floor • shadow receiver' if who=='gep' else 'Work linen'
    return next((name,tree) for name,tree in tables.items() if name.startswith(phrase))


def action_info(rig):
    anim=rig.animation_data
    action=anim.action if anim else None
    return {'name': action.name if action else None, 'fcurves':len(action.fcurves) if action else 0,
            'key_times':sorted(set(round(k.co.x,5) for f in action.fcurves for k in f.keyframe_points)) if action else []}


def sampled(frames, motion, poses):
    records={}
    for a,b in poses:
        lo=frames.index(a); hi=frames.index(b)
        mid=(a+b)//2; im=frames.index(mid)
        records[f'{a}-{b}']={k:{'peak_vertex_change_bu':max(change(v[lo],p) for p in v[lo:hi+1]),
                                'midframe':mid,'midframe_vertex_change_bu':change(v[lo],v[im]),
                                'endpoint_vertex_change_bu':change(v[lo],v[hi])} for k,v in motion.items()}
    return records


def aligned_to_palm(motion):
    """Map digital landmarks into the palm's first-frame coordinates via matched vertices."""
    palm=motion['right_palm']
    fixed=palm[0]
    corrected={k:[] for k in ('index','middle')}
    for i,current in enumerate(palm):
        x=current-current.mean(axis=0); y=fixed-fixed.mean(axis=0)
        u,_,vh=np.linalg.svd(x.T@y)
        if np.linalg.det(u@vh)<0: u[:,-1]*=-1
        rotation=u@vh
        for key in corrected:
            corrected[key].append((motion[key][i]-current.mean(axis=0))@rotation+fixed.mean(axis=0))
    return corrected



def finger_crossings(sc,parts):
    """Compare evaluated disjoint digit pieces to the accepted neutral overlaps."""
    from itertools import combinations
    from mathutils.bvhtree import BVHTree
    candidates=[]
    for digit in ('index','middle','ring','little','thumb'):
        for link in ('proximal','distal'):
            candidates.append((digit,with_words(parts,'right hand / '+digit+' '+link)))
    baseline=None; exceptions={}; neutral={}
    for half in range(2,51):
        moment=half/2
        sc.frame_set(int(moment),subframe=moment%1)
        dg=bpy.context.evaluated_depsgraph_get(); trees=[]
        for digit,obj in candidates:
            ev=obj.evaluated_get(dg); mesh=ev.to_mesh()
            try:
                tree=BVHTree.FromPolygons([ev.matrix_world@v.co for v in mesh.vertices],[f.vertices[:] for f in mesh.polygons])
            finally:
                ev.to_mesh_clear()
            trees.append((digit,obj.name,tree))
        touched={(a[1],b[1]) for a,b in combinations(trees,2) if a[0]!=b[0] and a[2].overlap(b[2])}
        if baseline is None:
            baseline=touched; neutral=sorted(touched)
        newly=sorted(touched-baseline)
        if newly: exceptions[str(moment)]=newly
    return {'neutral_existing_pairs':neutral,'new_crossing_pairs_by_time':exceptions,
            'sampled_times':'1, 1.5, 2, …, 25','tested_shapes':len(candidates)}



def finger_periods(frames,motion):
    relative=aligned_to_palm(motion)
    values={k:[change(a,b) for a,b in zip(v,v[1:])] for k,v in relative.items()}
    # A nontrivial local movement must be at least fifty times the sibling
    # response. Absolute thresholds separate hinge motion from floating-point noise.
    def isolates(moving,still):
        return [frames[i+1] for i,(x,y) in enumerate(zip(values[moving],values[still]))
                if x>1e-4 and y<max(5e-6,x/50)]
    return {'frame_start':frames[0],'per_step_max_displacement_bu':values,
            'index_only_to_frames':isolates('index','middle'),
            'middle_only_to_frames':isolates('middle','index')}


def perturb(scene,rig,bone_name,watch):
    """Change one pose basis without key insertion, then restore it without saving."""
    from mathutils import Matrix
    from math import radians
    dg=d1_gate.active(scene)
    bone=rig.pose.bones[bone_name]
    action=rig.animation_data.action if rig.animation_data else None
    channels=[] if not action else [fc for fc in action.fcurves if fc.data_path.startswith(bone.path_from_id()+'.')]
    states=[fc.mute for fc in channels]
    initial=bone.matrix_basis.copy()
    before={k:geometry(o,dg) for k,o in watch.items()}
    try:
        for fc in channels: fc.mute=True
        bone.matrix_basis=initial@Matrix.Rotation(radians(12),4,'X')
        bpy.context.view_layer.update()
        after={k:geometry(o,dg) for k,o in watch.items()}
    finally:
        bone.matrix_basis=initial
        for fc,v in zip(channels,states): fc.mute=v
        bpy.context.view_layer.update()
    return {'bone':bone_name,'postmultiplied_local_x_degrees':12,
            'max_displacement_bu':{k:change(before[k],after[k]) for k in watch},
            'restored_max_bu':{k:change(before[k],geometry(o,dg)) for k,o in watch.items()}}


def pin_objects(parts):
    return {
        'sole_L':with_words(parts,'left boot / outsole'),'sole_R':with_words(parts,'right boot / outsole'),
        'index':with_words(parts,'right hand / index distal'),
        'middle':with_words(parts,'right hand / middle distal'),
        'right_palm':with_words(parts,'right hand / palm'),
        'left_palm':with_words(parts,'left hand / palm'),
        'head':with_words(parts,'carved maple head'),'eyes':with_words(parts,'deep pupil'),
        'torso':with_words(parts,'linen shirt body'),'shin':with_words(parts,'right leg / shin'),
        'eyelid':with_words(parts,'ivory oval eye')}


def gep_objects(parts):
    return {'sole_L':with_words(parts,'boot ground sole','-1'),'sole_R':with_words(parts,'boot ground sole 1'),
            'head':with_words(parts,'continuous face sculpt'),'eyes':with_words(parts,'pupil'),
            'offering_hand':with_words(parts,'open hand and forearm'),'resting_hand':with_words(parts,'resting hand and forearm'),
            'torso':with_words(parts,'ivory gathered shirt'),'apron':with_words(parts,'work apron','bib'),
            'mouth':with_words(parts,'open smile'),'brow':with_words(parts,'swept eyebrow'),
            'vest':with_words(parts,'walnut waistcoat','cut armscyes'),
            'sleeve':with_words(parts,'gathered linen sleeve 1'),'cuff':with_words(parts,'double rolled sleeve 1')}




def offer_surfaces(scene,dg,objects):
    from mathutils.bvhtree import BVHTree
    monitors={}
    for k in ('head','torso','apron','vest','resting_hand','offering_hand'):
        obj=objects[k]; ev=obj.evaluated_get(dg); mesh=ev.to_mesh()
        try:
            mesh.calc_loop_triangles()
            triangles=np.empty((len(mesh.loop_triangles),3),dtype=np.int32)
            mesh.loop_triangles.foreach_get('vertices',triangles.ravel())
            if k=='offering_hand':
                group=obj.vertex_groups['Hand.R'].index
                fingers=np.array([any(v.group==group and v.weight>.0 for v in vert.groups) for vert in obj.data.vertices])
                triangles=triangles[np.any(fingers[triangles],axis=1)]
            monitors[k]=triangles.tolist()
        finally:
            ev.to_mesh_clear()
    tables=d1_gate.surfaces(scene,dg)
    tables={k:v for k,v in tables.items() if k.startswith(('Painted top','Work linen'))}
    return monitors,tables


def distance_checks(clouds,monitors,table):
    from mathutils.bvhtree import BVHTree
    all_skin=clouds['offering_hand']
    min_z=float(all_skin[:,2].min())
    closest={}
    # Only geometry below this verified height can be within 4 cm of the
    # painted top (1.35 BU) or the flat standing linen (1.35035 BU).
    for name,tree in table.items():
        min_gap=None; n=0
        whole_region=np.concatenate([all_skin,clouds['sleeve'],clouds['cuff']])
        for p in whole_region[whole_region[:,2]<1.395]:
            hit=tree.ray_cast(Vector((p[0],p[1],4)),Vector((0,0,-1)),6)[0]
            if hit is None: continue
            n+=1
            gap=float(p[2]-hit.z)
            if min_gap is None or gap<min_gap: min_gap=gap
        closest[name]={'vertices_above_footprint_tested_below_z_1_395':n,'min_vertical_gap_if_within_band_bu':min_gap}
    tri=monitors['offering_hand']
    distal=all_skin[np.unique(np.asarray(tri))]
    mi=distal.min(axis=0); ma=distal.max(axis=0)
    hull=None; overlap={}
    for k in ('head','torso','apron','vest','resting_hand'):
        points=clouds[k]
        if np.any(points.min(axis=0)>ma) or np.any(points.max(axis=0)<mi): overlap[k]=0; continue
        if hull is None: hull=BVHTree.FromPolygons(all_skin.tolist(),tri,all_triangles=True)
        body=BVHTree.FromPolygons(points.tolist(),monitors[k],all_triangles=True)
        overlap[k]=len(hull.overlap(body))
    return {'offering_skin_min_z_bu':min_z,'within_bench_band':closest,'distal_skin_self_triangle_overlap':overlap}


def anchors(who,sc,objects):
    tests=[(1,'C07_A')] if who=='pin' else [(1,'C06_B'),(39,'C07_B'),(78,'C07_JOY')]
    report={}
    for f,shot in tests:
        source=bpy.data.scenes[shot]
        d1_gate.active(source)
        root=d1_gate.roots(source)[who.upper()]
        clouds=d1_gate.points_for([root])[0]
        bpy.context.window.scene=sc
        sc.frame_set(f)
        dg=bpy.context.evaluated_depsgraph_get()
        rows={}
        for k,obj in objects.items():
            stem=obj.name.split('| ',1)[-1].split('.')[0].lower()
            pts=geometry(obj,dg)
            exact=obj.get('D1 object')
            matches=[(change(pts,v),n) for n,v in clouds.items() if pts.shape==v.shape and
                      ((exact and n==exact) or (not exact and stem in n.lower()))]
            if not matches: raise ValueError((shot,k,stem,pts.shape))
            error,name=min(matches)
            rows[k]={'source':name,'world_vertex_count':len(pts),'max_world_vertex_error_bu':error}
        report[f'{shot} at {f}']=rows
    return report



def endpoint_parts(sc,parts):
    """Independently recover D1 evaluation from the actual collection instances.

    Curves can reorder bevel cap vertices when their transforms are baked, so
    compare both directions of their evaluated point clouds.
    """
    from scipy.spatial import cKDTree
    performed={o['D2_source_key']:o for o in parts if o.get('D2_source_key')}
    allowed_terms=('open hand and forearm','natural nail','open palm creases','gathered linen sleeve 1','double rolled sleeve 1')
    def key(obj):
        stamp=obj.get('study_source_object')
        if stamp: return stamp
        stem=re.sub(r'(?:\.\d+)+$','',obj.name)
        if obj.type=='CURVE': return stem
        coords=np.empty((len(obj.data.vertices),3),dtype=np.float32)
        obj.data.vertices.foreach_get('co',coords.ravel())
        return stem+'|'+hashlib.sha1(coords.tobytes()).hexdigest()[:12]
    result={}
    for f,name in [(1,'C06_B'),(39,'C07_B'),(78,'C07_JOY')]:
        scene=bpy.data.scenes[name]
        d1_gate.active(scene); root=d1_gate.roots(scene)['GEP']
        by_name=d1_gate.points_for([root])[0]
        source={key(o):(o.name,by_name[o.name]) for o in root.instance_collection.all_objects if o.name in by_name}
        bpy.context.window.scene=sc;sc.frame_set(f)
        dg=bpy.context.evaluated_depsgraph_get()
        rows={}
        for group,(src,v) in source.items():
            obj=performed[group]
            coords=geometry(obj,dg)
            if coords.shape!=v.shape:
                raise ValueError((group,v.shape,coords.shape))
            if obj.type=='CURVE':
                distances=np.concatenate([cKDTree(v).query(coords)[0],cKDTree(coords).query(v)[0]])
            else: distances=np.linalg.norm(v-coords,axis=1)
            allowed=(f==1 and any(t in obj.name.lower() for t in allowed_terms))
            textile=(f==39 and 'gathered linen sleeve 1' in obj.name.lower())
            rows[group]={'source':src,'vertices':len(v),'allowed_warm_arm_adjustment':allowed,
                         'localized_shock_textile':textile,'max_bu':float(distances.max()),'rms_bu':float(np.sqrt(np.mean(distances**2)))}
            if textile:
                displaced=distances>.001
                rows[group]['changed_vertices_over_one_mm']=int(displaced.sum())
                rows[group]['changed_fraction']=float(displaced.mean())
                if np.any(displaced):
                    rows[group]['source_xyz_bounds_changed']=[v[displaced].min(axis=0).tolist(),v[displaced].max(axis=0).tolist()]
                    rows[group]['final_xyz_bounds_changed']=[coords[displaced].min(axis=0).tolist(),coords[displaced].max(axis=0).tolist()]
        result[str(f)]={'shot':name,'parts':rows,'largest_unaffected_delta_bu':max(v['max_bu'] for v in rows.values() if not (v['allowed_warm_arm_adjustment'] or v['localized_shock_textile'])),
              'largest_permitted_warm_arm_delta_bu':max((v['max_bu'] for v in rows.values() if v['allowed_warm_arm_adjustment']),default=0.)}
    return result



def pin_cues(frames,motion):
    def points(k,f): return motion[k][frames.index(f)]
    def delta(k,a,b): return change(points(k,a),points(k,b))
    def radius(k,f): return float(np.ptp(points(k,f),axis=0)[2])
    return {
        'blink_z_extent_before_peak_after':[radius('eyelid',f) for f in (28,31,37)],
        'pupil_excursion_to_left_then_right_bu':[delta('eyes',a,b) for a,b in [(37,40),(40,44)]],
        'head_at_51_bu':delta('head',44,51), 'arm_at_51_bu':{k:delta(k,44,51) for k in ('left_palm','right_palm')},
        'shin_change_at_66_bu':delta('shin',59,66), 'torso_mean_z_drop_at_66_bu':float((points('torso',59)-points('torso',66))[:,2].mean()),
        'return_to_neutral_max_sampled_bu':max(delta(k,1,80) for k in motion)}


def gep_shape_probe(sc,rig,objects):
    dg=d1_gate.active(sc)
    tracked=('mouth','eyes','brow','sole_L')
    initial={k:geometry(objects[k],dg) for k in tracked}
    report={}
    for prop,target in [('Mouth_Shock','mouth'),('Eyes_Shock','eyes'),('Brows_Shock','brow')]:
        value=rig[prop]
        action=rig.animation_data.action
        channel=next(fc for fc in action.fcurves if fc.data_path=='["'+prop+'"]')
        muted=channel.mute
        try:
            channel.mute=True
            rig[prop]=1.0
            rig.update_tag()
            bpy.context.view_layer.update()
            rows={k:change(initial[k],geometry(objects[k],dg)) for k in tracked}
            report[prop]={'target':target,'max_paired_world_displacement_bu':rows}
        finally:
            rig[prop]=value; channel.mute=muted
            rig.update_tag()
            bpy.context.view_layer.update()
    return report




def other_soles(dg,root,who):
    parts={}
    for inst in dg.object_instances:
        if not (inst.is_instance and inst.parent and inst.parent.original==root):
            continue
        obj=inst.object
        name=obj.name.lower()
        if who=='pin' and 'boot / outsole' not in name: continue
        if who=='gep' and 'boot ground sole' not in name: continue
        mesh=obj.to_mesh()
        try:
            v=np.empty((len(mesh.vertices),3),dtype=np.float32)
            mesh.vertices.foreach_get('co',v.ravel())
            matrix=np.asarray(inst.matrix_world)
            parts[obj.name]=v@matrix[:3,:3].T+matrix[:3,3]
        finally:
            obj.to_mesh_clear()
    if len(parts)!=2: raise ValueError(('Missing stationary character soles',root.name,list(parts)))
    return parts


def interframe_support(sc,who,objects,frames,coordinates,plants,checks):
    second='gep' if who=='pin' else 'pin'
    other=next(o for o in sc.objects if o.name.startswith(second.upper()) and o.instance_collection)
    dg=d1_gate.active(sc)
    support_name,surf=surface_for(sc,dg,who)
    name,stationary_surf=surface_for(sc,dg,second)
    ref=other_soles(dg,other,second)
    records=[]
    half={}
    for k in ('sole_L','sole_R'):
        half[k]={'worst_planted_xy_drift_bu':0.,'worst_planted_gap_bu':0.,'min_signed_gap_bu':10.,'max_lift_bu':0.}
    for frame in frames:
        for sub in ((0,.5) if frame<frames[-1] else (0,)):
            when=frame+sub
            sc.frame_set(frame,subframe=sub)
            dg=bpy.context.evaluated_depsgraph_get()
            note={'time':when,'other_character':{}}
            for k,pts in other_soles(dg,other,second).items():
                gap=support_result(pts,stationary_surf)
                note['other_character'][k]={'xy_drift_bu':float(np.linalg.norm((ref[k]-pts)[:,:2],axis=1).max()),'gap_bu':gap}
            if sub:
                note['moving_character']={}
                for k in half:
                    pts=geometry(objects[k],dg)
                    gap=support_result(pts,surf)
                    if gap is None: raise ValueError((k,when))
                    metric=half[k]
                    metric['min_signed_gap_bu']=min(metric['min_signed_gap_bu'],gap)
                    metric['max_lift_bu']=max(metric['max_lift_bu'],gap)
                    planted=any(a<=when<=b for a,b in plants[k])
                    drift=float(np.linalg.norm((pts-coordinates[k][frame-frames[0]])[:,:2],axis=1).max())
                    note['moving_character'][k]={'planted':planted,'xy_from_prior_integer_bu':drift,'gap_bu':gap}
                    if planted:
                        metric['worst_planted_xy_drift_bu']=max(metric['worst_planted_xy_drift_bu'],drift)
                        metric['worst_planted_gap_bu']=max(metric['worst_planted_gap_bu'],abs(gap))
            records.append(note)
    gated(checks,'other character remains planted at every sampled integer and half frame',
          all(v['gap_bu'] is not None and abs(v['gap_bu'])<.002 and v['xy_drift_bu']<.002
              for r in records for v in r['other_character'].values()))
    for k,v in half.items():
        gated(checks,k+' planted half frames and transition clearance',v['worst_planted_xy_drift_bu']<.002 and
              v['worst_planted_gap_bu']<.002 and v['min_signed_gap_bu']>-.002)
    return {'moving_support':support_name,'static_partner_support':name,'static_partner':other.name,
            'moving_sole_half_frame_summary':half,'samples':records}


def live(path,qa,who):
    bpy.ops.wm.open_mainfile(filepath=str(path))
    sc=bpy.data.scenes[GEP_SCENE if who=='gep' else PIN_SCENE]
    dg=d1_gate.active(sc)
    rigs=[o for o in sc.objects if o.type=='ARMATURE']
    if len(rigs)!=1: raise ValueError((sc.name,[o.name for o in rigs]))
    rig=rigs[0]
    parts,bind_modes=rigged_parts(sc,rig)
    objects=gep_objects(parts) if who=='gep' else pin_objects(parts)
    checks={}
    gated(checks,who+' live rig with bound surface geometry', len(parts)>10 and rig.animation_data and rig.animation_data.action)
    data={'blend_sha256':d1_gate.file_sha(path),'scene':sc.name,'rig':rig.name,
          'bounds':bind_modes,'bound_mesh_count':len(parts),'bone_names':list(rig.data.bones.keys()),
          'action':action_info(rig),'markers':markers(sc),'frames':[sc.frame_start,sc.frame_end],
          'tracked_objects':{k:{'name':o.name,'bone_groups':bound_group(o,rig)} for k,o in objects.items()}}
    frames=list(range(sc.frame_start,sc.frame_end+1))
    table_name,table=surface_for(sc,dg,who)
    motion={k:[] for k in objects}; coords_for_soles={k:[] for k in ('sole_L','sole_R')}
    gaps={k:[] for k in coords_for_soles}
    ids={}
    clearance=[]
    if who=='gep': monitors,bench_surfaces=offer_surfaces(sc,dg,objects)
    for f in frames:
        geometry_this_frame={}
        sc.frame_set(f)
        dg=bpy.context.evaluated_depsgraph_get()
        for key,obj in objects.items():
            coords=geometry(obj,dg)
            geometry_this_frame[key]=coords
            if key not in ids: ids[key]=indices(coords)
            motion[key].append(coords[ids[key]].copy())
            if key in coords_for_soles:
                coords_for_soles[key].append(coords.copy())
                gaps[key].append(support_result(coords,table))
        if who=='gep': clearance.append(distance_checks(geometry_this_frame,monitors,bench_surfaces))
    if who=='gep':
        data['offer_clearance_by_frame']=clearance
        signed=[v['min_vertical_gap_if_within_band_bu'] for r in clearance for v in r['within_bench_band'].values()
                if v['min_vertical_gap_if_within_band_bu'] is not None]
        gated(checks,'offering skin and its sleeve/cuff above evaluated tabletop/linen',all(g>0 for g in signed))
        gated(checks,'distal reaching hand clears face, garment bodies and opposite arm during warm compensation',
              all(count==0 for r in clearance[:35] for count in r['distal_skin_self_triangle_overlap'].values()))
    data['paired_vertex_indices']={k:v.tolist() for k,v in ids.items()}
    epoch_ranges=[(frames[0],frames[-1])]
    for a,b in zip(sorted(set(data['markers'].values())),sorted(set(data['markers'].values()))[1:]):
        if a in frames and b in frames and b-a>=2: epoch_ranges.append((a,b))
    data['paired_vertex_motion']=sampled(frames,motion,epoch_ranges)
    data['max_vertex_displacement_from_frame1_bu']={k:max(change(v[0],pts) for pts in v) for k,v in motion.items()}
    for k in ('torso','head','offering_hand') if who=='gep' else ('head','torso','index','middle'):
        gated(checks,'paired evaluated '+k+' movement',data['max_vertex_displacement_from_frame1_bu'][k]>1e-4)
    plants=plant_chart(who,sc,frames,rig,objects)
    data['contacts']={}
    for key,xyz in coords_for_soles.items():
        gs=gaps[key]
        gated(checks,key+' every frame has support surface below',all(v is not None for v in gs))
        if any(v is None for v in gs): raise ValueError((key,gs))
        tested=planted_metrics(frames,xyz,gs,plants[key])
        lifted=[f for f,g in zip(frames,gs) if g>.002]
        grounded=set(f for a,b in plants[key] for f in range(a,b+1))
        data['contacts'][key]={'surface':table_name,'shape':objects[key].name,'gap_bu_by_frame':gs,
            'toe_and_heel_xy_motion_from_start_per_frame':[
                float(np.linalg.norm((arr-xyz[0])[:,:2],axis=1).max()) for arr in xyz],
            'planted_intervals':tested,'lifted_frames':lifted,'most_negative_bu':min(gs),'peak_lift_bu':max(gs)}
        gated(checks, key+' planted position matches contact throughout',
              all(t['max_paired_sole_xy_drift_bu']<.002 and t['max_abs_surface_gap_bu']<.002 for t in tested))
        gated(checks,key+' no unlisted lift or surface penetration',not set(lifted)&grounded and min(gs)>-.002)
    data['interframe_contacts']=interframe_support(sc,who,objects,frames,coords_for_soles,plants,checks)
    if who=='pin':
        data['finger_periods']=finger_periods(frames,motion)
        gated(checks,'independent index movement',data['finger_periods']['index_only_to_frames'])
        gated(checks,'independent middle movement',data['finger_periods']['middle_only_to_frames'])
        for k,other in [('index','middle'),('middle','index')]:
            outcome=perturb(sc,rig,k+'_01.R',{k:objects[k],other:objects[other],'sole':objects['sole_R']})
            data.setdefault('one_control',{})[k]=outcome
            gated(checks,k+' in isolation controls its visible distal geometry',outcome['max_displacement_bu'][k]>.0001 and
                  outcome['max_displacement_bu'][other]<.0001 and outcome['max_displacement_bu']['sole']<.0001)
    else:
        outcome=gep_perturb(sc,rig,objects)
        data['one_control']=outcome
        gated(checks,'one adult control reaches intended visible mesh',outcome['max_displacement_bu']['target']>.0001 and
              outcome['max_displacement_bu']['sole']<.0001)
    data['d1_pose_witnesses']=anchors(who,sc,objects)
    gated(checks,'registered D1 world vertices at designed endpoints',all(row['max_world_vertex_error_bu']<.001
          for shot,rows in data['d1_pose_witnesses'].items() for name,row in rows.items()
          if not (who=='gep' and ((shot=='C06_B at 1' and name in ('offering_hand','sleeve','cuff')) or (shot=='C07_B at 39' and name=='sleeve')))))
    if who=='pin':
        cues=pin_cues(frames,motion)
        data['pin_cues']=cues
        crossings=finger_crossings(sc,parts)
        data['right_digit_surface_crossings']=crossings
        gated(checks,'no new interdigit surface contacts across independent cues',not crossings['new_crossing_pairs_by_time'])
        opened,closed,reopened=cues['blink_z_extent_before_peak_after']
        gated(checks,'closed aperture and reopening',closed<.25*opened and abs(opened-reopened)<.001)
        gated(checks,'left/right pupil excursion',min(cues['pupil_excursion_to_left_then_right_bu'])>.001)
        gated(checks,'head and both arms move at named cue',min([cues['head_at_51_bu'],*cues['arm_at_51_bu'].values()])>.01)
        gated(checks,'supported knee bend and pelvis drop',cues['shin_change_at_66_bu']>.01 and cues['torso_mean_z_drop_at_66_bu']>.01)
        gated(checks,'return to neutral',cues['return_to_neutral_max_sampled_bu']<.001)
    else:
        endpoints=endpoint_parts(sc,parts)
        data['all_adult_endpoint_parts']=endpoints
        gated(checks,'all adult endpoint geometry outside the warm arm and shock contact-cloth corrections within 1 mm',all(row['largest_unaffected_delta_bu']<.001 for row in endpoints.values()))
        controls=gep_shape_probe(sc,rig,objects)
        data['face_control_isolation']=controls
        for prop,exercise in controls.items():
            rows=exercise['max_paired_world_displacement_bu']; target=exercise['target']
            gated(checks,prop+' affects only its own tested landmark',rows[target]>.0001 and
                  all(v<.0001 for k,v in rows.items() if k!=target))
        for key,leg_intervals in plants.items():
            spikes=data['contacts'][key]['lifted_frames']
            gated(checks,key+' actual lift in both declared swings',any(14<f<39 for f in spikes) and any(47<f<78 for f in spikes))
    data['checks']=checks
    d1_gate.save(qa/f'D2_{who.upper()}_MOTION.json',data)
    print(who,'independent failures',[k for k,v in checks.items() if not v],flush=True)


def plant_chart(who,sc,frames,rig,objects):
    start,end=frames[0],frames[-1]
    if who=='pin':
        return {'sole_L':[(start,end)],'sole_R':[(start,end)]}
    return {'sole_L':[(start,14),(25,47),(60,end)],
            'sole_R':[(start,26),(38,61),(77,end)]}


def gep_perturb(sc,rig,objs):
    return perturb(sc,rig,'Head',{'target':objs['head'],'sole':objs['sole_R'],'hand':objs['offering_hand']})


def sources(root,qa):
    ledger=json.loads((qa/'D1_LOCKED_SOURCES.json').read_text())
    rows=[]
    for original in ledger:
        actual=d1_gate.file_sha(root/original['source'])
        rows.append({'path':original['source'],'sha256':actual,'matches':actual==original['sha256']})
    d1_gate.save(qa/'D2_SOURCE_REHASH.json',rows)
    if len(rows)!=35 or not all(x['matches'] for x in rows):
        raise ValueError('D2 immutable source recheck failed')


def finish(path,qa):
    data={k:json.loads((qa/f'{stem}.json').read_text()) for k,stem in [
        ('retained','D2_RETAINED'),('pin','D2_PIN_MOTION'),('gep','D2_GEP_MOTION')]}
    digest=d1_gate.file_sha(path)
    checks={'same delivered file in all tests':all(r['blend_sha256']==digest for r in data.values()),
            'distinct live armatures':data['pin']['rig']!=data['gep']['rig']}
    for k,v in data.items():
        checks.update({k+' '+name:bool(passed) for name,passed in v['checks'].items()})
    original_hashes=json.loads((qa/'D2_SOURCE_REHASH.json').read_text())
    checks['35 immutable original files rehashed']=len(original_hashes)==35 and all(x['matches'] for x in original_hashes)
    checks['D1 native file unchanged']=d1_gate.file_sha(path.parent.parent/'d1'/'D1_FINAL_APPROVED.blend')==D1_SHA
    failures=[k for k,v in checks.items() if not v]
    d1_gate.save(qa/'D2_INDEPENDENT_QA.json',{'status':'FAIL' if failures else 'PASS','sha256':digest,
        'subframe_scope':'Each integer and intervening half frame tested for surface gap and planted XY displacement. Behavior between samples is unverified.',
        'retained_source_sha256':D1_SHA,'failures':failures,'checks':checks,'evidence':data})
    lines=['D2 independent native-scene QA '+('FAIL' if failures else 'PASS'),'Integrated Blender SHA256 '+digest,
           'Approved D1 SHA256 '+D1_SHA, f"Passed checks {sum(checks.values())}/{len(checks)}.",
           'All six retained D1 scene signatures matched. Approved source files were rehashed.']
    for who in ('pin','gep'):
        r=data[who]; half=r['interframe_contacts']
        lines.append(f"{r['scene']}: {r['rig']}, {r['bound_mesh_count']} bound objects, {len(half['samples'])} integer + half-frame contact samples.")
        for k,v in r['contacts'].items():
            lines.append(f"  {k}: peak surface gap {v['peak_lift_bu']:.7f} BU. Plants: "+str([(t['first'],t['last']) for t in v['planted_intervals']])+'.')
        lines.append('  Floor/table: max planted half-frame xy shift '+str(max(v['worst_planted_xy_drift_bu'] for v in half['moving_sole_half_frame_summary'].values()))+' BU.')
    fingers=data['pin']['finger_periods']
    lines.append(f"Right index-only intervals end on frames {fingers['index_only_to_frames']}. Middle-only intervals end on {fingers['middle_only_to_frames']}.")
    lines.append('Neutral interdigit proximal-region touching pairs '+str(len(data['pin']['right_digit_surface_crossings']['neutral_existing_pairs']))+
                 '. New interdigit contacts over 49 integer/half-frame samples '+str(len(data['pin']['right_digit_surface_crossings']['new_crossing_pairs_by_time']))+'.')
    adult=data['gep']['all_adult_endpoint_parts']
    lines.append('D2 warm offering-arm maximum displacement '+f"{adult['1']['largest_permitted_warm_arm_delta_bu']:.6f} BU from the D1 sleep-scene pose.")
    textile=next(row for row in adult['39']['parts'].values() if row['localized_shock_textile'])
    lines.append('D2 shock gathered sleeve: '+f"{textile['changed_vertices_over_one_mm']}/{textile['vertices']} points displaced >1 mm, maximum {textile['max_bu']:.6f} BU.")
    lines.append('GEP all other endpoint geometry max BU '+str({k:v['largest_unaffected_delta_bu'] for k,v in adult.items()})+'.')
    lines.append('Vertex and BVH checks cover evaluated surfaces. Foot contact was sampled at integers and halves. Between-sample contact and subjective acting appeal were not certified.')
    lines.extend('FAIL '+v for v in failures)
    (qa/'D2_INDEPENDENT_QA.log').write_text('\n'.join(lines)+'\n')
    print('Independent D2 on reopened file',digest, 'failures:',failures,flush=True)
    if failures: raise ValueError(failures)


if __name__=='__main__':
    mode,src,dest=sys.argv[sys.argv.index('--')+1:]
    src,dest=Path(src).resolve(),Path(dest).resolve()
    dest.mkdir(parents=True,exist_ok=True)
    if mode=='sources': sources(src,dest)
    elif mode=='retained': compare_retained(src,dest)
    elif mode=='finish': finish(src,dest)
    elif mode in ('pin','gep'): live(src,dest,mode)
    else: raise ValueError(mode)
