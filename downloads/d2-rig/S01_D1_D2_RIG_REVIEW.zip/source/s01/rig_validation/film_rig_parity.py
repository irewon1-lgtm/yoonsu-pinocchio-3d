"""Compare every filmed frame with the integrated file using evaluated renderable meshes."""
import hashlib
import json
import sys
from pathlib import Path
import bpy
import numpy as np

SCENES={"PIN":("D2_PIN_CONTROLS","PIN_D2_RIG"),"GEP":("D2_GEP_PERFORMANCE","GEP_Performance_Rig")}

def file_sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

def sample(actor,dest):
    scene_name,rig_name=SCENES[actor]
    scene=bpy.data.scenes[scene_name]
    bpy.context.window.scene=scene
    rig=scene.objects[rig_name]
    parts=sorted((o for o in scene.objects if o.type in {"MESH","CURVE","SURFACE"} and o.parent==rig),
                 key=lambda o:o.name)
    assert len(parts)>150, len(parts)
    records=[]
    for frame in range(scene.frame_start,scene.frame_end+1):
        scene.frame_set(frame)
        graph=bpy.context.evaluated_depsgraph_get()
        digest=hashlib.sha256()
        vertices=0
        for obj in parts:
            ev=obj.evaluated_get(graph)
            digest.update(obj.name.encode("utf8")+b"\0")
            digest.update(bytes([ev.hide_render]))
            if ev.hide_render: continue
            mesh=ev.to_mesh()
            try:
                coords=np.empty(len(mesh.vertices)*3,np.float32)
                mesh.vertices.foreach_get("co",coords)
                # Finger and eyelid motion are detectable below one hundredth of a millimetre.
                digest.update(np.rint(coords*1e6).astype("<i4").tobytes())
                digest.update(np.rint(np.asarray(ev.matrix_world)*1e6).astype("<i4").tobytes())
                for slot in ev.material_slots:
                    digest.update((slot.material.name if slot.material else "").encode("utf8")+b"\0")
                vertices+=len(mesh.vertices)
            finally:
                ev.to_mesh_clear()
        records.append({"frame":frame,"visible_vertices":vertices,"surface_hash":digest.hexdigest()})
    dest.write_text(json.dumps({"source_sha256":file_sha(bpy.data.filepath),"actor":actor,"parts":len(parts),
                                "frames":records},indent=2)+"\n")
    print("PASS sampled",actor,len(records),"frames,",len(parts),"part surfaces")

def compare(film_source,integrated,dest):
    a,b=[json.loads(p.read_text()) for p in (film_source,integrated)]
    mismatch=[x["frame"] for x,y in zip(a["frames"],b["frames"]) if x!=y]
    same=a["actor"]==b["actor"] and a["parts"]==b["parts"] and len(a["frames"])==len(b["frames"]) and not mismatch
    data={"actor":a["actor"],"film_input_sha256":a["source_sha256"],
          "integrated_sha256":b["source_sha256"],"result":"PASS" if same else "FAIL",
          "parts":a["parts"],"frames_checked":len(a["frames"]),"frames_different":mismatch,"frames":b["frames"]}
    dest.write_text(json.dumps(data,indent=2)+"\n")
    assert same,(a["actor"],mismatch)
    print("PASS filmed and delivered deformation, world transforms and visibility agree",a["actor"])

if __name__=="__main__":
    mode,*args=sys.argv[sys.argv.index("--")+1:]
    if mode=="sample":
        sample(args[0],Path(args[1]))
    else:
        assert mode=="compare"
        compare(*(Path(arg) for arg in args))
