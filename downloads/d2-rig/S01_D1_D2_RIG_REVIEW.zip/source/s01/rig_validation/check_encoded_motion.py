"""Match decoded movie frames with the photographed RGB panels; exclude burn-in labels."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np
from PIL import Image


def verify(root, report):
    records=json.loads((root/"FILM_QA.json").read_text())
    movie=root/"D2_RIG_TEST.mp4"
    media=json.loads(subprocess.check_output(["ffprobe","-v","error","-select_streams","v:0","-show_frames",
        "-show_entries","frame=best_effort_timestamp_time","-of","json",str(movie)]))
    times=np.array([float(row["best_effort_timestamp_time"]) for row in media["frames"]])
    assert len(times)==len(records["frames"]) and np.max(abs(np.diff(times)-1/24)) < 2e-6
    width,height=(records["probe"]["streams"][0][k] for k in ("width","height"))
    ffmpeg=subprocess.Popen(["ffmpeg","-nostdin","-v","error","-xerror","-i",str(movie),
        "-map","0:v:0","-pix_fmt","rgb24","-f","rawvideo","pipe:1"],stdout=subprocess.PIPE)
    previous={}
    changes={k:[] for k in ("GEP","PIN")}
    readback=[]
    try:
        for row in records["frames"]:
            key="GEP" if "GEP" in row["source_scene"] else "PIN"
            path=root/key/f'{row["source_frame"]:04d}.png'
            assert hashlib.sha256(path.read_bytes()).hexdigest()==row["render_sha256"]
            with Image.open(path) as image:
                src=np.asarray(image.convert("RGB"),dtype=np.int16)
            rgb=ffmpeg.stdout.read(width*height*3)
            if len(rgb)!=width*height*3:
                raise ValueError(f"Short decode at {row['film_frame']}")
            dec=np.frombuffer(rgb,np.uint8).reshape(height,width,3).astype(np.int16)
            panel_height=min(width//2,height)
            body=src[:panel_height]
            err=float(abs(dec[:panel_height]-body).mean())
            readback.append(err)
            if key in previous:
                changes[key].append(float(abs(body-previous[key]).mean()))
            previous[key]=body
        assert ffmpeg.stdout.read(1)==b"" and ffmpeg.wait()==0
    finally:
        ffmpeg.stdout.close()
        if ffmpeg.poll() is None:
            ffmpeg.terminate()
            ffmpeg.wait()
    states={}
    for key,values in changes.items():
        states[key]={"adjacent_pairs":len(values),
                     "mean_absolute_deltas_excluding_caption":values,
                     "pairs_above_0_5_rgb_steps":sum(x>.5 for x in values)}
    result={"frames_compared":len(readback),"native_resolution":[width,height],
            "mean_absolute_decoded_vs_render_rgb":float(np.mean(readback)),
            "maximum_frame_mean_absolute_decoded_vs_render_rgb":max(readback),
            "timestamp_increment_seconds":float(np.median(np.diff(times))),
            "per_actor":states}
    passed=max(readback)<10 and all(v["pairs_above_0_5_rgb_steps"]>=8 for v in states.values())
    result["check"]="PASS" if passed else "FAIL"
    report.write_text(json.dumps(result,indent=2)+"\n")
    assert passed, result
    print("PASS",len(readback),"decoded film frames matched their source RGB panels, excluding captions")

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("film_directory",type=Path)
    p.add_argument("report",type=Path)
    args=p.parse_args()
    verify(args.film_directory,args.report)
