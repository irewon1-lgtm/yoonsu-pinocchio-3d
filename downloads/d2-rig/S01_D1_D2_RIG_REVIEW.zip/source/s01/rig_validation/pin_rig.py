"""Build and measure a Pinocchio D2 rig from the approved C07 mesh copies."""

from __future__ import annotations

import argparse
from itertools import combinations
import json
from math import atan2, pi, radians
from pathlib import Path
import re
import sys

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Matrix, Quaternion, Vector
from mathutils.bvhtree import BVHTree


SCENE = "D2_PIN_CONTROLS"
RIG = "PIN_D2_RIG"
END_FRAME = 80
FPS = 24
DIGITS = (
    ("index", .112, .027, .021), ("middle", .139, .002, .013),
    ("ring", .123, -.025, .003), ("little", .095, -.049, -.006),
)
EYE_DETAIL = ("Brown iris", "Deep pupil", "Eye main gleam", "Eye lower gleam")
EYE_APERTURE = ("Ivory oval eye", "Upper eyelid")
SIDES = (("R", "Right", -1), ("L", "Left", 1))


def _source_name(obj):
    return re.sub(r"\.\d{3}$", "", obj.name).removeprefix("PIN | ")


def _toward(a, b, distance):
    return Vector(a) + (Vector(b) - Vector(a)).normalized() * distance


def _anatomy():
    sides = {}
    for index, (side, label, sign) in enumerate(SIDES):
        shoulder = Vector((sign * .208, .015, 1.531 + index * .025))
        rot = Matrix.Rotation(sign * radians(32), 3, "Y")

        def detail(point):
            return shoulder + rot @ (Vector(point) - shoulder)

        elbow_z = 1.405 + index * .102
        wrist_z = 1.399 + index * .180
        wrist = (sign * .946, -.073, wrist_z)
        palm = Vector((wrist[0] + sign * .082, -.094, wrist_z - .030))
        points = {
            "label": label, "shoulder": shoulder,
            "elbow": detail((sign * .611, -.008, elbow_z)), "wrist": detail(wrist),
            "palm": detail(palm), "hip": Vector((sign * .133, .006, 1.036)),
            "knee": Vector((sign * .172, -.016, .625)),
            "ankle": Vector((sign * .235, .046, .260)),
            "eye": Vector((sign * .117, -.255, 2.136)), "digits": {},
        }
        for digit, length, height, rise in DIGITS:
            x, z = palm.x + sign * .052, palm.z + height
            points["digits"][digit] = tuple(map(detail, (
                (x, -.099, z), (x + sign * length * .59, -.108, z + rise * .42),
                (x + sign * length, -.123, z + rise),
            )))
        points["digits"]["thumb"] = tuple(map(detail, (
            (palm.x - sign * .028, -.110, palm.z + .011),
            (palm.x - sign * .008, -.113, palm.z + .071),
            (palm.x - sign * .038, -.105, palm.z + .125),
        )))
        sides[side] = points
    return sides


def _make_armature(collection, world, sides):
    armature = bpy.data.armatures.new(RIG)
    rig = bpy.data.objects.new(RIG, armature)
    collection.objects.link(rig)
    rig.matrix_world = world
    rig.show_in_front = True
    armature.display_type = "STICK"
    bpy.context.view_layer.objects.active = rig
    rig.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")

    def bone(name, head, tail, parent=None, deform=True, roll_axis=(0, 0, 1)):
        item = armature.edit_bones.new(name)
        item.head, item.tail = head, tail
        item.use_deform = deform
        if parent:
            item.parent = armature.edit_bones[parent]
            item.use_connect = (item.parent.tail - item.head).length < 1e-5 and deform
        roll_axis = Vector(roll_axis)
        if abs(item.y_axis.normalized().dot(roll_axis)) < .98:
            item.align_roll(roll_axis)
        return item

    bone("root", (0, 0, 0), (0, .36, 0), deform=False)
    bone("pelvis", (0, .006, 1.036), (0, .008, 1.248), "root")
    bone("spine", (0, .008, 1.248), (0, .017, 1.60), "pelvis")
    bone("neck", (0, .026, 1.596), (0, .023, 1.814), "spine")
    bone("head", (0, .023, 1.814), (0, -.010, 2.260), "neck")

    controls = armature.collections.new("Contact and expression")
    fk = armature.collections.new("Wooden joints")
    for side, points in sides.items():
        shoulder, elbow, wrist = (points[p] for p in ("shoulder", "elbow", "wrist"))
        hip, knee, ankle = (points[p] for p in ("hip", "knee", "ankle"))
        eye = points["eye"]
        pole_normal = knee - hip - (ankle - hip) * (
            (knee - hip).dot(ankle - hip) / (ankle - hip).length_squared
        )
        pole = knee + pole_normal.normalized() * .70
        bone(f"foot_ik.{side}", ankle, ankle + Vector((0, -.22, 0)), "root")
        bone(f"knee_pole.{side}", pole, pole + Vector((0, 0, .15)), "root", False)
        bone(f"thigh.{side}", hip, knee, "pelvis")
        bone(f"shin.{side}", knee, ankle, f"thigh.{side}")
        bone(f"shoulder.{side}", (0, .016, shoulder.z), shoulder, "spine")
        bone(f"upper_arm.{side}", shoulder, elbow, f"shoulder.{side}")
        bone(f"forearm.{side}", elbow, wrist, f"upper_arm.{side}")
        bone(f"hand.{side}", wrist, _toward(wrist, points["palm"], .135), f"forearm.{side}")
        for digit, (start, knuckle, tip) in points["digits"].items():
            bone(f"{digit}_01.{side}", start, knuckle, f"hand.{side}")
            bone(f"{digit}_02.{side}", knuckle, tip, f"{digit}_01.{side}")
        blink = bone(f"blink.{side}", eye, eye + Vector((0, .08, 0)), "head", False)
        blink.inherit_scale = "NONE"
        bone(f"gaze.{side}", eye, eye + Vector((0, .14, 0)), f"blink.{side}", False)

    for item in armature.edit_bones:
        grouping = controls if item.name.startswith(("root", "foot_ik", "knee_pole", "blink", "gaze")) else fk
        grouping.assign(item)
    bpy.ops.object.mode_set(mode="OBJECT")
    rig["description"] = "Rigid carved-wood segments, independent finger hinges, gaze/blink, and non-stretch leg IK."
    for bone_pose in rig.pose.bones:
        bone_pose.rotation_mode = "QUATERNION"
    return rig


def _pose_rot(rig, name, euler, degrees=None):
    pose = rig.pose.bones[name]
    to_object = pose.bone.matrix_local.to_3x3()
    if degrees is not None:
        pose.rotation_quaternion = Quaternion(to_object.inverted() @ Vector(euler), radians(degrees))
    else:
        q = Quaternion()
        for axis, angle in zip(((1, 0, 0), (0, 1, 0), (0, 0, 1)), euler):
            q = Quaternion(to_object.inverted() @ Vector(axis), radians(angle)) @ q
        pose.rotation_quaternion = q
    return pose


def _pose_move(rig, name, vector):
    pose = rig.pose.bones[name]
    pose.location = pose.bone.matrix_local.to_3x3().inverted() @ Vector(vector)
    return pose


def _leg_constraints(rig, sides):
    for side, points in sides.items():
        shin = rig.pose.bones[f"shin.{side}"]
        ik = shin.constraints.new("IK")
        ik.name = f"Planted leg {side}"
        ik.target, ik.subtarget = rig, f"foot_ik.{side}"
        ik.pole_target, ik.pole_subtarget = rig, f"knee_pole.{side}"
        ik.chain_count = 2
        ik.use_stretch = False
        ik.iterations = 96
        hip = points["hip"]
        ankle = points["ankle"]
        axis = (ankle - hip).normalized()

        def radial(point):
            return point - hip - axis * ((point - hip).dot(axis))

        def error(angle):
            ik.pole_angle = angle
            bpy.context.view_layer.update()
            return (shin.head - points["knee"]).length_squared

        # Blender's positive pole-angle direction depends on edit-bone rolls.
        ik.pole_angle = 0
        bpy.context.view_layer.update()
        reference = radial(shin.head)
        desired = radial(points["knee"])
        angle = atan2(axis.dot(reference.cross(desired)), reference.dot(desired))
        closest = min((angle, -angle, 0, pi / 2, -pi / 2, pi), key=error)
        low, high = closest - .025, closest + .025
        for _ in range(18):
            left = (2 * low + high) / 3
            right = (low + 2 * high) / 3
            if error(left) < error(right):
                high = right
            else:
                low = left
        error((low + high) * .5)
        if (shin.head - points["knee"]).length > 3e-5:
            raise AssertionError((side, "neutral knee fit", tuple(shin.head), tuple(points["knee"])))


def _side_of_object(obj, basis):
    if obj.type == "CURVE":
        point = basis @ obj.data.splines[0].bezier_points[0].co
        return "R" if point.x < 0 else "L"
    coords = [basis @ Vector(corner) for corner in obj.bound_box]
    return "R" if sum(p.x for p in coords) < 0 else "L"


def _bone_for(obj, base, basis):
    if base.startswith("Head / ") or base == "Carved maple head":
        if base.startswith("Head / "):
            tail = base[len("Head / "):]
            if tail in EYE_DETAIL + EYE_APERTURE:
                side = _side_of_object(obj, basis)
                return f"{'gaze' if tail in EYE_DETAIL else 'blink'}.{side}"
        return "head"
    if base.startswith("Neck"):
        return "neck"
    for side, label, _ in SIDES:
        if base.startswith(f"{label} boot /"):
            return f"foot_ik.{side}"
        if base.startswith(f"{label} leg /"):
            return f"{'thigh' if base.endswith('/ thigh') else 'shin'}.{side}"
        if base.startswith(f"{label} upper arm /"):
            return f"upper_arm.{side}"
        if base.startswith(f"{label} forearm /"):
            return f"forearm.{side}"
        if base.startswith(f"{label} hand /"):
            suffix = base.split(" / ", 1)[1]
            for digit, *_ in (*DIGITS, ("thumb",)):
                if suffix.startswith(digit):
                    segment = "01" if suffix.endswith(("proximal", "hinge crease")) else "02"
                    return f"{digit}_{segment}.{side}"
            return f"hand.{side}"
    if base in ("Full teal shorts leg", "Shorts hem binding", "Outseam topstitch"):
        return f"thigh.{_side_of_object(obj, basis)}"
    if "waist" in base.lower():
        return "pelvis"
    return "spine"


def _bind(part, collection, rig, channel, basis, name):
    obj = part.copy()
    obj.name = name
    collection.objects.link(obj)
    obj.parent = rig
    obj.parent_type = "BONE"
    obj.parent_bone = channel
    bone = rig.pose.bones[channel]
    parent = bone.bone.matrix_local @ Matrix.Translation((0, bone.bone.length, 0))
    obj.matrix_parent_inverse = parent.inverted()
    obj.matrix_basis = basis
    obj["D2 channel"] = channel
    return obj


def _blink_cover(scene, collection, rig):
    source = next(obj for obj in bpy.data.scenes["C06_A"].objects if obj.name.startswith("PIN_ROOT"))
    for part in source.instance_collection.all_objects:
        name = _source_name(part)
        if not name.startswith("closed eyelid"):
            continue
        basis = part.matrix_basis.copy()
        side = _side_of_object(part, basis)
        obj = _bind(part, collection, rig, "head", basis, f"D2 PIN | {side} {name}")
        driver = obj.driver_add("location", 2).driver
        prop = driver.variables.new()
        prop.name = "amount"
        prop.targets[0].id = rig
        prop.targets[0].data_path = f'pose.bones["blink.{side}"]["closure"]'
        driver.expression = f"{obj.location.z:.9f} + 0.073 * (1-amount)"
        for property_name in ("hide_render", "hide_viewport"):
            driver = obj.driver_add(property_name).driver
            prop = driver.variables.new()
            prop.name = "amount"
            prop.targets[0].id = rig
            prop.targets[0].data_path = f'pose.bones["blink.{side}"]["closure"]'
            driver.expression = "amount < 0.66"


def _key_animation(rig, sides):
    def rotation(name, entries):
        for frame, angles in entries:
            _pose_rot(rig, name, angles).keyframe_insert("rotation_quaternion", frame=frame)

    def movement(name, entries):
        for frame, vector in entries:
            _pose_move(rig, name, vector).keyframe_insert("location", frame=frame)

    for digit, keys in {
        "index": [(1, 0, 0), (5, 5, 2), (9, -21, -15), (13, 0, 0), (25, 0, 0)],
        "middle": [(1, 0, 0), (14, 0, 0), (17, 12, 9), (21, 33, 27), (25, 0, 0)],
    }.items():
        start, knuckle, tip = sides["R"]["digits"][digit]
        for index, (a, b) in enumerate(((start, knuckle), (knuckle, tip)), 1):
            toward_palm = Vector((0, -1, .35 if digit == "middle" else 0))
            axis = (b - a).cross(toward_palm).normalized()
            for frame, *angles in keys:
                pose = _pose_rot(rig, f"{digit}_{index:02d}.R", axis, angles[index - 1])
                pose.keyframe_insert("rotation_quaternion", frame=frame)

    for side in sides:
        blink = rig.pose.bones[f"blink.{side}"]
        blink["closure"] = 0.0
        blink.id_properties_ui("closure").update(min=0, max=1, description="Close and open the carved eyelids")
        # The anchored pivot compresses the original eye aperture and its child gaze.
        driver = blink.driver_add("scale", 2).driver
        value = driver.variables.new()
        value.name = "closure"
        value.targets[0].id = rig
        value.targets[0].data_path = f'pose.bones["blink.{side}"]["closure"]'
        driver.expression = "1.0 - 0.94 * closure"
        for frame, closure in ((1, 0.), (28, 0.), (31, 1.), (33, 1.), (37, 0.), (80, 0.)):
            blink["closure"] = closure
            blink.keyframe_insert(data_path='["closure"]', frame=frame)
        movement(f"gaze.{side}", [
            (1, (0, 0, 0)), (37, (0, 0, 0)), (40, (-.021, .003, .006)),
            (44, (.024, .004, .006)), (48, (0, 0, 0)), (80, (0, 0, 0)),
        ])

    rotation("neck", [(1, (0, 0, 0)), (43, (0, 0, 0)), (51, (-10, 0, 6)),
                      (56, (5, 0, 0)), (60, (0, 0, 0)), (80, (0, 0, 0))])
    rotation("head", [(1, (0, 0, 0)), (45, (0, 0, 0)), (51, (-11, -7, 17)),
                      (56, (11, 5, -9)), (60, (0, 0, 0)), (80, (0, 0, 0))])
    for side, sign in (("R", -1), ("L", 1)):
        for name, angles in (
            ("shoulder", (0, -8 * sign, 0)), ("upper_arm", (8, -27 * sign, 4)),
            ("forearm", (-10, -20 * sign, -24 * sign)), ("hand", (-11, 3 * sign, 12 * sign)),
        ):
            rotation(f"{name}.{side}", [(1, (0, 0, 0)), (44, (0, 0, 0)),
                (51, angles), (56, tuple(-.25 * value for value in angles)), (61, (0, 0, 0)),
                (80, (0, 0, 0))])

    movement("pelvis", [(1, (0, 0, 0)), (59, (0, 0, 0)), (66, (.037, .095, -.172)),
                        (70, (.010, .056, -.107)), (78, (0, 0, 0)), (80, (0, 0, 0))])
    rotation("spine", [(1, (0, 0, 0)), (59, (0, 0, 0)), (66, (15, -4, 3)),
                      (70, (9, -2, 2)), (78, (0, 0, 0)), (80, (0, 0, 0))])


def _camera(scene, rig):
    original = scene.camera
    depsgraph = bpy.context.evaluated_depsgraph_get()
    camera = original.copy()
    camera.data = original.data.copy()
    camera.name = "D2 PIN | character camera"
    scene.collection.objects.link(camera)
    scale = rig.matrix_world.to_scale().z
    center = rig.matrix_world @ Vector((0, 0, 1.38))
    direction = (original.evaluated_get(depsgraph).matrix_world.translation - center).normalized()
    camera.location = center + direction * 8
    camera.rotation_euler = (center - camera.location).to_track_quat("-Z", "Y").to_euler()
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = scale * 3.64
    # Original calibrated camera and background remain active for the composite.
    return camera


def build_pin_rig():
    """Add a diagnostic shot to the open approved file and return the new scene."""
    if SCENE in bpy.data.scenes:
        raise ValueError(f"{SCENE} already exists")
    source = bpy.data.scenes["C07_A"]
    bpy.context.window.scene = source
    bpy.context.view_layer.update()
    instance = next(obj for obj in source.objects if obj.name.startswith("PIN_ROOT"))
    depsgraph = bpy.context.evaluated_depsgraph_get()
    root = instance.evaluated_get(depsgraph).matrix_world.copy()
    part_bases = {part.name: part.evaluated_get(depsgraph).matrix_world.copy()
                  for part in instance.instance_collection.all_objects}
    scene = source.copy()
    scene.name = SCENE
    scene.use_fake_user = True
    bpy.context.window.scene = scene
    if instance.name in scene.collection.objects:
        scene.collection.objects.unlink(instance)
    if instance.name in scene.objects:
        raise ValueError("PIN source must be linked directly to the shot")
    collection = bpy.data.collections.new("D2 PIN • articulated geometry")
    scene.collection.children.link(collection)
    scene.frame_start, scene.frame_end = 1, END_FRAME
    scene.render.fps, scene.render.fps_base = FPS, 1.0
    scene.render.filepath = "//d2_pin_"
    scene["D2 scope"] = "C05 independent finger proof and planted tabletop control exercise."
    sides = _anatomy()
    rig = _make_armature(collection, root, sides)
    for part in instance.instance_collection.all_objects:
        base = _source_name(part)
        basis = part_bases[part.name]
        channel = _bone_for(part, base, basis)
        obj = _bind(part, collection, rig, channel, basis, f"D2 PIN | {part.name.removeprefix('PIN | ')}")
        obj["D1 object"] = part.name
    _leg_constraints(rig, sides)
    _key_animation(rig, sides)
    _blink_cover(scene, collection, rig)
    _camera(scene, rig)
    for frame, name in (
        (1, "Neutral on both soles"), (9, "Right index extends"), (21, "Right middle curls"),
        (31, "Closed eyes"), (40, "Gaze screen left"), (44, "Gaze screen right"),
        (51, "Head and independent arms"), (66, "Loaded knees and pelvis"), (80, "Neutral held"),
    ):
        scene.timeline_markers.new(name, frame=frame)
    scene.frame_set(1)
    bpy.context.view_layer.update()
    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    bpy.context.view_layer.objects.active = rig
    rig.select_set(True)
    return scene


def _evaluated_points(obj, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        return [evaluated.matrix_world @ v.co for v in mesh.vertices]
    finally:
        evaluated.to_mesh_clear()


def _surface(obj, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        return BVHTree.FromPolygons(
            [evaluated.matrix_world @ v.co for v in mesh.vertices],
            [tuple(p.vertices) for p in mesh.polygons],
        )
    finally:
        evaluated.to_mesh_clear()


def _xyz(point):
    return [round(value, 8) for value in point]


def audit_pin_rig():
    """Measure reopened bones, visible digit geometry, and actual bench hits."""
    scene = bpy.data.scenes[SCENE]
    rig = scene.objects[RIG]
    source_scene = bpy.data.scenes["C07_A"]
    source = next(obj for obj in source_scene.objects if obj.name.startswith("PIN_ROOT"))
    bpy.context.window.scene = source_scene
    bpy.context.view_layer.update()
    original_root = source.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world.copy()
    source_depsgraph = bpy.context.evaluated_depsgraph_get()
    approved_parts = {
        obj.name: obj.evaluated_get(source_depsgraph).matrix_world.copy()
        for obj in source.instance_collection.all_objects
    }
    bpy.context.window.scene = scene
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    table = next(obj for obj in scene.objects if obj.name.startswith("Work linen"))
    bench = _surface(table, depsgraph)
    parts = {obj["D1 object"]: obj for obj in scene.objects if "D1 object" in obj}
    assert len(parts) == len(approved_parts)
    assert all(obj.data == source.instance_collection.all_objects[name].data for name, obj in parts.items())

    def part(label, channel=None):
        matches = [obj for name, obj in parts.items()
                   if re.sub(r"\.\d{3}$", "", name).removeprefix("PIN | ") == label
                   and (channel is None or obj["D2 channel"] == channel)]
        assert len(matches) == 1, (label, channel, [obj.name for obj in matches])
        return matches[0]

    def camera_pixel(point):
        uv = world_to_camera_view(scene, scene.camera.evaluated_get(depsgraph), point)
        return Vector((uv.x * scene.render.resolution_x, (1 - uv.y) * scene.render.resolution_y))

    def rig_state():
        return rig.evaluated_get(depsgraph)

    def point_on_bone(name, at_tail=False):
        state = rig_state()
        pose = state.pose.bones[name]
        return state.matrix_world @ (pose.tail if at_tail else pose.head)

    def sole(obj):
        vertices = _evaluated_points(obj, depsgraph)
        return min(vertices, key=lambda v: v.z)

    def distal_vertex(obj, side, digit):
        vertices = _evaluated_points(obj, depsgraph)
        axis = (point_on_bone(f"{digit}_02.{side}", True) -
                point_on_bone(f"{digit}_02.{side}")).normalized()
        return max(vertices, key=lambda point: point.dot(axis))

    scene.frame_set(1)
    bpy.context.view_layer.update()
    transform_delta = max(abs(a - b) for ar, br in zip(rig_state().matrix_world, original_root)
                          for a, b in zip(ar, br))
    assert transform_delta < 1e-7, transform_delta
    rest_displacement = {}
    for name, obj in parts.items():
        rest_matrix = original_root @ approved_parts[name]
        actual = obj.evaluated_get(depsgraph).matrix_world
        rest_displacement[name] = max((actual @ Vector(corner) - rest_matrix @ Vector(corner)).length
                                      for corner in obj.bound_box)
    worst_name = max(rest_displacement, key=rest_displacement.get)
    assert rest_displacement[worst_name] < .00020, (worst_name, rest_displacement[worst_name])

    sole_meshes = {side: part(f"{label} boot / outsole") for side, label, _ in SIDES}
    sole_home = {side: sole(obj) for side, obj in sole_meshes.items()}
    tip_meshes = {digit: part(f"Right hand / {digit} distal") for digit, *_ in DIGITS}
    tip_meshes["thumb"] = part("Right hand / thumb distal")
    tips_home = {digit: distal_vertex(obj, "R", digit) for digit, obj in tip_meshes.items()}
    aperture = part("Head / Ivory oval eye", "blink.R")
    right_iris = part("Head / Brown iris", "gaze.R")
    def aperture_height():
        heights = [point.z for point in _evaluated_points(aperture, depsgraph)]
        return max(heights) - min(heights)

    def mesh_center(obj):
        return obj.evaluated_get(depsgraph).matrix_world.translation.copy()

    def digit_overlaps():
        nodes = [(digit, part(f"Right hand / {digit} {segment}"))
                 for digit in tip_meshes for segment in ("proximal", "distal")]
        hulls = [(digit, obj.name, _surface(obj, depsgraph)) for digit, obj in nodes]
        return {(a_name, b_name) for (a_digit, a_name, a_hull), (b_digit, b_name, b_hull)
                in combinations(hulls, 2) if a_digit != b_digit and a_hull.overlap(b_hull)}

    rest_overlaps = digit_overlaps()
    center_home = mesh_center(right_iris)
    apex_home = aperture_height()
    tracked = ("pelvis", "head", "hand.R", "hand.L", "shin.R", "shin.L")
    home = {name: point_on_bone(name) for name in tracked}
    pegs = {}
    for side, label, _ in SIDES:
        pegs[f"elbow.{side}"] = (f"forearm.{side}", (part(f"{label} upper arm / wood"),
                                                   part(f"{label} forearm / wood"),
                                                   part(f"{label} forearm / elbow joint")))
        pegs[f"knee.{side}"] = (f"shin.{side}", (part(f"{label} leg / thigh"),
                                                part(f"{label} leg / shin"),
                                                part(f"{label} leg / knee joint")))
        pegs[f"wrist.{side}"] = (f"hand.{side}", (part(f"{label} forearm / wood"),
                                                 part(f"{label} hand / palm")))
        for digit in ("index", "middle"):
            pegs[f"{digit}.{side}"] = (f"{digit}_02.{side}", (
                part(f"{label} hand / {digit} proximal"), part(f"{label} hand / {digit} distal"),
            ))

    def peg_gap(name, objs):
        center = point_on_bone(name)
        outside = 0.0
        for obj in objs:
            nearest, normal, _, distance = _surface(obj, depsgraph).find_nearest(center)
            assert nearest is not None
            if normal.dot(center - nearest) > 0:
                outside = max(outside, distance)
        return outside

    def pose_deltas():
        return {name: (point_on_bone(name) - start).length for name, start in home.items()}

    frames = []
    for frame in range(1, END_FRAME + 1):
        scene.frame_set(frame)
        record = {"frame": frame, "feet": {}, "peg_separation_bu": {}, "bone_travel_bu": pose_deltas()}
        current_peg = {key: peg_gap(name, objs) for key, (name, objs) in pegs.items()}
        record["peg_separation_bu"] = current_peg
        assert max(current_peg.values()) < .0020, (frame, current_peg)
        for side, obj in sole_meshes.items():
            support = sole(obj)
            hit, _, _, _ = bench.ray_cast(support + Vector((0, 0, .035)), Vector((0, 0, -1)), .08)
            assert hit is not None, (frame, side, support)
            slip = (support.xy - sole_home[side].xy).length
            gap = support.z - hit.z
            ankle_error = (point_on_bone(f"shin.{side}", True) - point_on_bone(f"foot_ik.{side}")).length
            assert slip < .00005 and abs(gap) < .00010 and ankle_error < .001, (frame, side, slip, gap, ankle_error)
            record["feet"][side] = {
                "sole_world": _xyz(support), "linen_hit_world": _xyz(hit), "slip_bu": slip,
                "gap_bu": gap, "ankle_to_target_bu": ankle_error,
            }
        if frame <= 25:
            assert max(record["bone_travel_bu"].values()) < .00005, frame
            tips = {digit: distal_vertex(obj, "R", digit) for digit, obj in tip_meshes.items()}
            record["right_tip_displacement_bu"] = {
                digit: (point - tips_home[digit]).length for digit, point in tips.items()
            }
            record["right_tip_displacement_px"] = {
                digit: (camera_pixel(point) - camera_pixel(tips_home[digit])).length
                for digit, point in tips.items()
            }
            moving = "index" if frame <= 13 else "middle"
            assert all(value < 1e-5 for digit, value in record["right_tip_displacement_bu"].items()
                       if digit != moving), (frame, record["right_tip_displacement_bu"])
            overlaps = digit_overlaps()
            assert overlaps <= rest_overlaps, (frame, sorted(overlaps - rest_overlaps))
            record["right_interdigit_mesh_pairs_touching"] = len(overlaps)
        if frame in (1, 30, 31, 37, 40, 44, 80):
            record["right_aperture_height_bu"] = aperture_height()
            record["right_iris_world"] = _xyz(mesh_center(right_iris))
        frames.append(record)

    index_frame, middle_frame, crouch_frame = (frames[f - 1] for f in (9, 21, 66))
    for digit, record in (("index", index_frame), ("middle", middle_frame)):
        assert record["right_tip_displacement_px"][digit] > 3, record
    assert max(frames[5]["right_tip_displacement_bu"].values()) > 1e-4
    assert frames[17]["right_tip_displacement_bu"]["middle"] > .01
    assert frames[30]["right_aperture_height_bu"] < apex_home * .12
    assert .10 * apex_home < frames[29]["right_aperture_height_bu"] < .80 * apex_home
    assert abs(frames[36]["right_aperture_height_bu"] - apex_home) < 1e-5
    pupil_home_x = camera_pixel(center_home).x
    gaze_px = {frame: camera_pixel(Vector(frames[frame - 1]["right_iris_world"])).x - pupil_home_x
               for frame in (40, 44)}
    assert gaze_px[40] < -1.5 < 1.5 < gaze_px[44], gaze_px
    assert crouch_frame["bone_travel_bu"]["pelvis"] > .070
    assert min(crouch_frame["bone_travel_bu"][f"shin.{side}"] for side in ("L", "R")) > .050
    assert max(frames[-1]["bone_travel_bu"].values()) < .00005
    assert all((distal_vertex(obj, "R", digit) - tips_home[digit]).length < .00005
               for digit, obj in tip_meshes.items())

    # Change individual user controls in isolation after reopening.
    scene.frame_set(1)
    def intervene(name, change, observe):
        pose = rig.pose.bones[name]
        old = pose.matrix_basis.copy()
        change()
        bpy.context.view_layer.update()
        try:
            return observe()
        finally:
            pose.matrix_basis = old
            bpy.context.view_layer.update()

    gaze_left = part("Head / Brown iris", "gaze.L")
    left_start = mesh_center(gaze_left)
    eye_intervention = intervene("gaze.L", lambda: _pose_move(rig, "gaze.L", (-.027, 0, .006)), lambda: {
        "left_iris_bu": (mesh_center(gaze_left) - left_start).length,
        "right_iris_bu": (mesh_center(right_iris) - center_home).length,
    })
    assert eye_intervention["left_iris_bu"] > .012 and eye_intervention["right_iris_bu"] < 1e-5
    foot_intervention = intervene("foot_ik.R", lambda: _pose_move(rig, "foot_ik.R", (0, 0, .027)), lambda: {
        "right_sole_bu": (sole(sole_meshes["R"]) - sole_home["R"]).length,
        "left_sole_bu": (sole(sole_meshes["L"]) - sole_home["L"]).length,
        "right_chain_follow_error_bu": (point_on_bone("shin.R", True) - point_on_bone("foot_ik.R")).length,
    })
    assert foot_intervention["right_sole_bu"] > .014 and foot_intervention["left_sole_bu"] < 1e-5
    assert foot_intervention["right_chain_follow_error_bu"] < .001
    knuckle, tip = _anatomy()["R"]["digits"]["index"][1:]
    finger_axis = (tip - knuckle).cross(Vector((0, -1, 0))).normalized()
    finger_intervention = intervene(
        "index_02.R", lambda: _pose_rot(rig, "index_02.R", finger_axis, -30),
        lambda: {digit: (distal_vertex(obj, "R", digit) - tips_home[digit]).length
                 for digit, obj in tip_meshes.items()},
    )
    assert finger_intervention["index"] > .01
    assert all(value < 1e-5 for digit, value in finger_intervention.items() if digit != "index")
    shoulder_motion = intervene(
        "shoulder.R", lambda: _pose_rot(rig, "shoulder.R", (0, 1, 0), 16),
        lambda: pose_deltas(),
    )
    assert shoulder_motion["hand.R"] > .09
    assert max(value for name, value in shoulder_motion.items() if name != "hand.R") < 1e-5
    return {
        "result": "PASS", "scene": SCENE, "rig": RIG, "fps": FPS, "frames_audited": len(frames),
        "readback_from": bpy.data.filepath, "blender": bpy.app.version_string,
        "approved_standing_root_world": [list(row) for row in original_root],
        "rest_max_vertex_envelope_difference_bu": rest_displacement[worst_name],
        "rest_max_vertex_envelope_part": worst_name, "approved_geometry_parts": len(parts),
        "cue_peaks_px": {digit: record["right_tip_displacement_px"][digit]
                         for digit, record in (("index", index_frame), ("middle", middle_frame))},
        "cue_measured_from": "Evaluated fingertip extremal vertices, projected through the approved C07_A camera.",
        "approved_interdigit_mesh_pairs_touching_at_rest": sorted(rest_overlaps),
        "new_interdigit_mesh_pairs_touching_during_cue": 0,
        "blink": {"open_aperture_bu": apex_home, "closed_aperture_bu": frames[30]["right_aperture_height_bu"]},
        "gaze_screen_dx_px": gaze_px,
        "interventions": {"left_gaze": eye_intervention, "right_foot_target": foot_intervention,
                          "right_index_knuckle_bu": finger_intervention,
                          "right_shoulder_bu": shoulder_motion},
        "checks": frames,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--audit", action="store_true")
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    if args.audit:
        report = audit_pin_rig()
        args.out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print("PIN D2 evaluated QA PASS", report["cue_peaks_px"], report["interventions"])
    else:
        build_pin_rig()
        bpy.context.preferences.filepaths.save_version = 0
        bpy.ops.wm.save_as_mainfile(filepath=str(args.out), compress=True)


if __name__ == "__main__":
    main()
