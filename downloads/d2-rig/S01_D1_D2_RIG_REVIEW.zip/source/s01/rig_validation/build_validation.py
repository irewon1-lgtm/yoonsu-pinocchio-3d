"""Integrate independent live rigs into a copy of the signed-off static workshop."""
from pathlib import Path
import hashlib
import sys

import bpy

MODULE_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(MODULE_ROOT))
D1_SHA = "546a6b91790b0b4ef78f7a3697892dffe56cfc38c03d0b3c153c05d9af3d3b09"
STAGE = {"C05_END_HOLD", "C06_A", "C06_B", "C07_A", "C07_B", "C07_JOY"}
LIVE = {"D2_GEP_PERFORMANCE", "D2_PIN_CONTROLS"}


def main(input_path, output_path):
    from gep_rig import build_gep_rig
    from pin_rig import build_pin_rig

    assert hashlib.sha256(input_path.read_bytes()).hexdigest() == D1_SHA
    assert input_path.resolve() != output_path.resolve()
    bpy.ops.wm.open_mainfile(filepath=str(input_path.resolve()))
    assert set(bpy.data.scenes.keys()) == STAGE
    build_gep_rig()
    assert "D2_GEP_PERFORMANCE" in bpy.data.scenes
    build_pin_rig()
    assert STAGE | LIVE <= set(bpy.data.scenes.keys())
    for name in LIVE:
        scene = bpy.data.scenes[name]
        scene.use_fake_user = True
        scene.frame_set(scene.frame_start)
        assert scene.camera and scene.frame_end > scene.frame_start
        scene["source_D1_sha256"] = D1_SHA
    bpy.context.window.scene = bpy.data.scenes["D2_GEP_PERFORMANCE"]
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(output_path.resolve()), compress=True)
    bpy.ops.wm.open_mainfile(filepath=str(output_path.resolve()))
    assert STAGE | LIVE <= set(bpy.data.scenes.keys())
    assert len(bpy.data.armatures) >= 2
    assert not bpy.data.libraries, "External blend dependency"
    for name in sorted(LIVE):
        s=bpy.data.scenes[name]
        print("LIVE", name, s.frame_start, s.frame_end, s.camera.name, flush=True)
    print("PASS integrated D2 native scene reopen", flush=True)


if __name__=="__main__":
    main(*(Path(arg) for arg in sys.argv[sys.argv.index("--")+1:]))
