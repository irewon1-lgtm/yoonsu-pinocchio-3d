"""Render and lay out three Geppetto checkpoints from the fixed C07 B camera."""

import argparse
from pathlib import Path
import sys


BEATS = (
    (1, "WARM  ·  다정하게 살핌"),
    (39, "SHOCK  ·  갑작스러운 놀람"),
    (78, "JOY  ·  기뻐하며 손을 엶"),
)
RESOLUTION = (1280, 720)
FPS = 24


def frame_path(directory, frame):
    return directory / f"GEP_{frame:03d}.png"


def standing_partner(scene):
    return next(
        obj for obj in scene.objects
        if obj.instance_type == "COLLECTION" and obj.name.startswith("PIN")
    )


def render(output, samples, threads):
    import bpy

    scene = bpy.data.scenes["D2_GEP_PERFORMANCE"]
    source = bpy.data.scenes["C07_B"]
    pin = standing_partner(scene)
    if scene.camera != source.camera or pin != standing_partner(source):
        raise ValueError("The workshop test must use the retained C07 B camera and standing partner")
    if scene.render.fps / scene.render.fps_base != FPS:
        raise ValueError("The workshop animation must be 24 fps")

    bpy.context.window.scene = scene
    settings = scene.render
    settings.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = samples
    scene.cycles.use_adaptive_sampling = False
    settings.threads_mode = "FIXED"
    settings.threads = threads
    settings.resolution_x, settings.resolution_y = RESOLUTION
    settings.resolution_percentage = 100
    settings.image_settings.file_format = "PNG"
    print(
        f"WORKSHOP {bpy.data.filepath} scene={scene.name} camera={scene.camera.name} "
        f"partner={pin.name} resolution=1280x720 samples={samples} CPU threads={threads}",
        flush=True,
    )

    scene.frame_set(BEATS[0][0])
    depsgraph = bpy.context.evaluated_depsgraph_get()
    fixed_pin = pin.evaluated_get(depsgraph).matrix_world.copy()
    fixed_camera = scene.camera.evaluated_get(depsgraph)
    fixed_camera_matrix = fixed_camera.matrix_world.copy()
    fixed_lens = fixed_camera.data.lens
    for frame, _ in BEATS:
        scene.frame_set(frame)
        depsgraph = bpy.context.evaluated_depsgraph_get()
        camera = scene.camera.evaluated_get(depsgraph)
        if (
            pin.evaluated_get(depsgraph).matrix_world != fixed_pin
            or camera.matrix_world != fixed_camera_matrix
            or camera.data.lens != fixed_lens
        ):
            raise ValueError(f"Workshop camera or standing partner moved at frame {frame}")
        path = frame_path(output, frame)
        settings.filepath = str(path.resolve())
        bpy.ops.render.render(write_still=True)
        if not path.is_file() or not path.stat().st_size:
            raise RuntimeError(f"No rendered file for frame {frame}")
        print(f"WORKSHOP FRAME {frame} {path.name} {path.stat().st_size} bytes", flush=True)


def board(source, output, pilot):
    from PIL import Image

    from review_boards import CONTENT_WIDTH, MARGIN, WIDTH, GREEN, MUTED, lettering, open_frame, photo, sheet

    height = round(CONTENT_WIDTH * RESOLUTION[1] / RESOLUTION[0])
    row = height + 70
    canvas = sheet(
        "D2  ·  작업실 속 제페토",
        "C07 B 카메라 고정 · 피노키오는 같은 기립 자세를 유지합니다.",
        WIDTH, 248 + len(BEATS) * row,
    )
    for index, (frame, label) in enumerate(BEATS):
        path = frame_path(source, frame)
        image = open_frame(path)
        if not pilot and image.size != RESOLUTION:
            raise ValueError(f"{path} must be a {RESOLUTION[0]}×{RESOLUTION[1]} render")
        y = 210 + index * row
        lettering(canvas, (MARGIN, y), label, 34, True, GREEN)
        seconds = (frame - BEATS[0][0]) / FPS
        lettering(canvas, (727, y + 5), f"프레임 {frame:02d}  ·  {seconds:.3f}초", 24, True, MUTED)
        photo(canvas, image, (MARGIN, y + 50), CONTENT_WIDTH, height)
    footer = "시험 렌더 · 보드 배치 확인용" if pilot else "D2 제페토 연기 시험 · 표정과 상체의 변화를 확인합니다."
    lettering(canvas, (MARGIN, 214 + len(BEATS) * row), footer, 24, False, MUTED)
    filename = "D2_WORKSHOP_REACTIONS_PILOT.png" if pilot else "D2_WORKSHOP_REACTIONS.png"
    target = output / filename
    canvas.save(target, optimize=True)
    with Image.open(target) as result:
        result.load()
        if result.format != "PNG" or result.size != canvas.size:
            raise RuntimeError("Workshop board failed readback")
    print(f"WORKSHOP BOARD {target} {canvas.width}x{canvas.height}")


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="mode", required=True)
    renderer = commands.add_parser("render")
    renderer.add_argument("output", type=Path)
    renderer.add_argument("--samples", type=int, default=24)
    renderer.add_argument("--threads", type=int, choices=(1, 2, 3), default=2)
    composer = commands.add_parser("board")
    composer.add_argument("source", type=Path)
    composer.add_argument("output", type=Path)
    composer.add_argument("--pilot", action="store_true")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.mode == "render":
        if args.samples < 24:
            parser.error("--samples must be 24 or greater")
        render(args.output, args.samples, args.threads)
    else:
        board(args.source, args.output, args.pilot)


if __name__ == "__main__":
    main(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:])
