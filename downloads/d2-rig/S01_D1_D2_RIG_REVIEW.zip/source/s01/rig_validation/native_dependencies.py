"""Read native delivery in a new Blender process with scripts disabled."""
from pathlib import Path
import hashlib
import json
import sys

import bpy

def inspect():
    for scene in bpy.data.scenes:
        bpy.context.window.scene=scene
        scene.frame_set((scene.frame_start+scene.frame_end)//2)
        bpy.context.view_layer.update()
    images={}
    for image in bpy.data.images:
        if image.source != "FILE" or image.type=="RENDER_RESULT" or not image.users:
            continue
        if image.packed_file:
            images[image.name]=hashlib.sha256(image.packed_file.data).hexdigest()
        else:
            images[image.name]=None
    drivers=[]
    for group in (bpy.data.objects,bpy.data.shape_keys,bpy.data.curves,bpy.data.materials,bpy.data.armatures):
        for item in group:
            if not item.animation_data:
                continue
            for curve in item.animation_data.drivers:
                drv=curve.driver
                drivers.append((item.name,curve.data_path,drv.type,drv.is_valid,
                                drv.type!="SCRIPTED" or drv.is_simple_expression))
    problems={
        "unpacked_file_textures":[name for name,sha in images.items() if sha is None],
        "external_libraries":[lib.name for lib in bpy.data.libraries],
        "embedded_script_modules":[t.name for t in bpy.data.texts if t.use_module],
        "invalid_or_python_dependent_drivers":[d for d in drivers if not d[3] or not d[4]],
    }
    return {"blender":bpy.app.version_string,"scenes":sorted(bpy.data.scenes.keys()),
            "armature_objects":{o.name:len(o.data.bones) for o in bpy.data.objects if o.type=="ARMATURE"},
            "actions":{a.name:len(a.fcurves) for a in bpy.data.actions},
            "drivers_checked":len(drivers),"image_sha256":images,"problems":problems}

result=inspect()
Path(sys.argv[sys.argv.index("--")+1]).write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
assert not any(result["problems"].values()), result["problems"]
print("PASS native file assets and drivers with auto-execution disabled", bpy.data.filepath)
