"""Measure registered central-palm thickness on the saved performance.

blender -b D2_RIG_VALIDATION.blend -P gep_hand_volume.py -- D2_GEP_PALM_GEOMETRY.json

The performer stays in the original scene. Each frame uses the same dorsal and
volar vertex sets selected on the WARM rest mesh. The test also records the
whole distal hand hull and edge length distribution as diagnostic quantities.
"""
import hashlib
import json
import sys
from pathlib import Path
import bpy
import numpy as np
from scipy.spatial import ConvexHull

sys.path.insert(0,str(Path(__file__).resolve().parent))
from gep_rig import SCENE,RIG,mesh_coords,inspect_geometry,unit,rigid


def measure(path):
    sc=bpy.data.scenes[SCENE];bpy.context.window.scene=sc
    rig=sc.objects[RIG]
    pieces=[o for o in sc.objects if o.parent==rig]
    hand=next(o for o in pieces if 'Open hand and forearm' in o.name)
    nails=sorted([o for o in pieces if 'Natural nail' in o.name],key=lambda o:o.name)
    bone=rig.data.bones['Hand.R']
    w=np.array(bone.head_local)
    h=unit(np.array(bone.tail_local)-w)
    pos=mesh_coords(hand.data)
    # Stable rest-space wrist plane; sample the true distal mesh, not bone points.
    distal=np.where(((pos-w)@h)>.022)[0]
    distal=distal[::4]
    edges=np.array([e.vertices[:] for e in hand.data.edges],int)
    edges=edges[np.all(((pos[edges]-w)@h)>.022,axis=1)][::5]
    # The central slab uses fixed opposing skin patches between wrist and
    # knuckle line; finger fan and the thumb do not determine its thickness.
    knuckles=np.stack([mesh_coords(o.data).mean(0) for o in nails])
    direction=unit(knuckles.mean(0)-w)
    width=knuckles[-1]-knuckles[0]
    lateral=unit(width-direction*(width@direction))
    normal=unit(np.cross(direction,lateral))
    longitudinal=(pos-w)@direction
    reach=np.linalg.norm(knuckles.mean(0)-w)
    core=(longitudinal>.26*reach)&(longitudinal<.60*reach)&(np.abs((pos-w)@lateral)<.028)
    height=(pos-w)@normal
    dorsal=core&(height>=np.percentile(height[core],85))
    volar=core&(height<=np.percentile(height[core],15))
    rows={}
    for f in range(1,85):
        sc.frame_set(f);dg=bpy.context.evaluated_depsgraph_get()
        verts=inspect_geometry(hand,dg)
        p=verts[distal]
        dims=np.sqrt(np.linalg.eigvalsh(np.cov(p.T)))*1000
        h3=ConvexHull(p).volume
        camera_iv=np.array(sc.camera.matrix_world.inverted())
        cam=p@camera_iv[:3,:3].T+camera_iv[:3,3]
        proj=cam[:,:2]/(-cam[:,2,None]) if sc.camera.data.type=='PERSP' else cam[:,:2]
        hull=ConvexHull(proj)
        ed=np.linalg.norm(verts[edges[:,1]]-verts[edges[:,0]],axis=1)
        if f==1:rest_lengths=np.maximum(ed,1e-8)
        centers=np.stack([inspect_geometry(ob,dg).mean(0) for ob in nails])
        sep=np.array([np.linalg.norm(centers[a]-centers[b]) for a in range(4) for b in range(a+1,4)])
        rotation=rigid(pos[core],verts[core])[:3,:3]
        gap=abs((verts[dorsal].mean(0)-verts[volar].mean(0))@(rotation@normal))*1000
        rows[f]={'registered_central_palm_gap_mm':float(gap),'volume_m3':float(h3),'principal_rms_mm':dims.tolist(),'projected_hull_area':float(hull.volume),
            'projected_aspect_ratio':float(np.sqrt(np.linalg.eigvalsh(np.cov(proj.T))).max()/np.sqrt(np.linalg.eigvalsh(np.cov(proj.T))).min()),
            'registered_edge_length_ratio_p05_p95':np.percentile(ed/rest_lengths,[5,95]).tolist(),'nail_pair_distances_mm':(sep*1000).tolist()}
    anchors=[rows[f] for f in (1,39,78)]
    low=min(a['volume_m3'] for a in anchors);high=max(a['volume_m3'] for a in anchors)
    floor=min(a['principal_rms_mm'][0] for a in anchors)
    checks={'volume_range_relative_to_endpoint_range':[min(r['volume_m3'] for r in rows.values())/low,max(r['volume_m3'] for r in rows.values())/high],
            'minimum_relative_thickness':min(r['principal_rms_mm'][0] for r in rows.values())/floor,
            'smallest_nail_separation_mm':min(min(r['nail_pair_distances_mm']) for r in rows.values()),
            'minimum_edge_length_ratio_p05':min(r['registered_edge_length_ratio_p05_p95'][0] for r in rows.values()),
            'maximum_edge_length_ratio_p95':max(r['registered_edge_length_ratio_p05_p95'][1] for r in rows.values())}
    rest_gap=anchors[0]['registered_central_palm_gap_mm']
    gaps=[r['registered_central_palm_gap_mm'] for r in rows.values()]
    checks['opposing_central_skin_patch_gap_mm']=[min(gaps),max(gaps)]
    checks['central_gap_range_vs_signed_warm']=[min(gaps)/rest_gap,max(gaps)/rest_gap]
    checks['worst_distal_envelope_frame']=min(rows,key=lambda f:rows[f]['volume_m3'])
    # The distal hull spans fingers, thumb and some deforming wrist. Changing
    # finger fan and wrist flexion alter this envelope. Keep its full series
    # alongside the central-palm measurement and rendered camera evidence.
    ok=(min(gaps)/rest_gap>.85 and max(gaps)/rest_gap<1.15 and
        checks['smallest_nail_separation_mm']>8 and checks['minimum_relative_thickness']>.80)
    result={'input_file':Path(bpy.data.filepath).name,'input_sha256':hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest(),
            'status':'PASS' if ok else 'FAIL','sampled_distal_vertices':len(distal),'registered_edges':len(edges),
            'fixed_central_patch_region_vertices':int(core.sum()),'dorsal_vertices':int(dorsal.sum()),'volar_vertices':int(volar.sum()),
            'summary':checks,'frames':rows,'definition':'Fixed dorsal and volar vertex patches from a central 56 mm wide palm strip between 26% and 60% of wrist–nail reach. At each frame a rigid fit of the same central vertices transports the rest palm normal. The separation projected onto that normal measures central thickness. Whole distal envelope, edge strain and projected hull are separately recorded because thumb, fingers and wrist change orientation.'}
    Path(path).write_text(json.dumps(result,indent=2))
    print('D2 palm volume',result['status'],checks,flush=True)
    if not ok:raise RuntimeError('D2 hand volume gate failed')


if __name__=='__main__':
    measure(sys.argv[sys.argv.index('--')+1])
