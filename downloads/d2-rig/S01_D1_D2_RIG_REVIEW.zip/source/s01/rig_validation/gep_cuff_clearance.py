"""Check both pieces of the elevated sleeve against the rendered D2 worktop.

Run using the saved D2 file and pass the JSON output pathname after --.
"""
import json
import sys
from pathlib import Path
import bpy
from mathutils import Vector

sys.path.insert(0,str(Path(__file__).resolve().parent))
from gesture_clearance import SCENE, RIG, CUFF_PARTS, WORKSHOP_TARGETS, contact, direct_parts, evaluated_surface


def measure(path):
    sc=bpy.data.scenes[SCENE]
    bpy.context.window.scene=sc
    sc.frame_set(1)
    dg=bpy.context.evaluated_depsgraph_get()
    rig=sc.objects[RIG]
    static={name:evaluated_surface(direct_parts(sc,dg,lambda o:o.name.startswith(tags)))
            for name,tags in WORKSHOP_TARGETS}
    data={}
    for f in range(sc.frame_start,sc.frame_end+1):
        sc.frame_set(f)
        dg=bpy.context.evaluated_depsgraph_get()
        cuff=evaluated_surface(direct_parts(sc,dg,lambda o:o.parent==rig and any(s in o.name for s in CUFF_PARTS)))
        direction=sc.camera.matrix_world.to_quaternion()@Vector((0,0,1))
        record={name:contact(cuff,b,direction,True)[0] for name,b in static.items()}
        data[f]=record
        if f in (1,22,25,35,39,63,78):print('Cuff',f,record,flush=True)
    count=sum(row['intersecting_triangle_pairs'] for f in data.values() for row in f.values())
    result={'status':'PASS' if count==0 else 'FAIL','tested_frames':len(data),'intersecting_triangle_pairs':count,'frames':data}
    Path(path).write_text(json.dumps(result,indent=2))
    if count:raise RuntimeError('Evaluated sleeve crosses a rendered workshop surface')
    return result


if __name__=='__main__':
    measure(sys.argv[sys.argv.index('--')+1])
