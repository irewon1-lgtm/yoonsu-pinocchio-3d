"""Photograph the live D2 performances and encode a synchronized review film.

blender -b FILE.blend -P test_film.py -- render GEP OUT --first 1 --last 84
python test_film.py assemble OUT BOARDS
Every numbered film frame uses two real camera renders at the same rig frame.
"""
import argparse
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

SCENES = {"GEP":"D2_GEP_PERFORMANCE", "PIN":"D2_PIN_CONTROLS"}
PANEL=432
FPS=24
FONT="/usr/share/fonts/opentype/noto/NotoSansCJK-{}.ttc"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def json_file(path,obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")


def kind(name):
    name=name.lower()
    if any(k in name for k in ("right hand /","right finger","right index","right thumb","right middle")):
        return "hand"
    if any(k in name for k in ("boot /","boot ground","boot welt","work shoe","shoe counter","shoe laces","oxford")):
        return "foot"
    if any(k in name for k in ("continuous face","spectacle","nose","eyes","eye ","eye /","ear ","hair","beard","moustache","mouth","maple head"," cap /"," hat /","chin","cheek","eyelid","pupil")):
        return "face"
    return "body"


def evaluated_parts(scene, actor):
    import bpy
    graph=bpy.context.evaluated_depsgraph_get()
    parts={}
    for inst in graph.object_instances:
        o=inst.object
        if o.type not in {"MESH","CURVE","SURFACE"} or o.hide_render:
            continue
        if not o.name.upper().startswith("D2 "+actor+" |"):
            continue
        if o.type=="MESH":
            vertices=o.data.vertices
            coords=np.empty((len(vertices),3),dtype='f')
            vertices.foreach_get("co",coords.ravel())
            # The fully evaluated mesh is used, including action-driven shape keys.
            indices=np.unique(np.r_[np.arange(0,len(coords),max(1,len(coords)//350)),
                                   coords.argmin(axis=0),coords.argmax(axis=0)])
            coords=coords[indices]
        else:
            # Character envelope and feature framing are determined by the solid surfaces.
            continue
        m=np.array(inst.matrix_world)
        parts[o.name]=coords@m[:3,:3].T+m[:3,3]
    if not parts:
        raise RuntimeError("No evaluated character meshes in "+scene.name)
    return parts


def center_extent(points):
    lo,hi=points.min(0),points.max(0)
    return (lo+hi)/2,hi-lo


def selected(parts,target):
    chosen=[p for n,p in parts.items() if kind(n)==target]
    if not chosen:
        raise RuntimeError("Camera feature absent: "+target)
    return np.concatenate(chosen)


def direction_of_camera(scene):
    import bpy
    from mathutils import Vector
    bpy.context.view_layer.update()
    c=scene.camera.evaluated_get(bpy.context.evaluated_depsgraph_get())
    d=np.array(c.matrix_world.to_quaternion()@Vector((0,0,1)))
    d[2]=0
    d/=max(np.linalg.norm(d),1e-8)
    d[2]=.12
    return d/np.linalg.norm(d)


def projected_fit(pts,direction,margin):
    right=np.cross(np.array([0.,0.,1.]),direction)
    right/=np.linalg.norm(right)
    up=np.cross(direction,right)
    lo,hi=pts.min(0),pts.max(0)
    center=(lo+hi)/2
    x,y=pts@right,pts@up
    center+=(.5*(x.min()+x.max())-center@right)*right
    center+=(.5*(y.min()+y.max())-center@up)*up
    span=max(float(np.ptp(x)),float(np.ptp(y)))*margin
    return center,span


def build_stage(scene,actor,center,floor_z,height,direction,samples,threads):
    import bpy
    from mathutils import Vector
    scene.render.engine='CYCLES'
    scene.cycles.device='CPU'
    scene.cycles.samples=samples
    scene.cycles.use_denoising=False
    scene.cycles.use_adaptive_sampling=False
    scene.cycles.seed=19
    scene.cycles.use_animated_seed=False
    scene.cycles.max_bounces=2
    scene.cycles.diffuse_bounces=1
    scene.cycles.glossy_bounces=1
    scene.cycles.transparent_max_bounces=2
    scene.render.use_persistent_data=True
    scene.render.threads_mode='FIXED'
    scene.render.threads=threads
    scene.render.film_transparent=False
    scene.render.use_compositing=False
    scene.render.use_sequencer=False
    scene.render.use_motion_blur=False
    scene.render.resolution_x=PANEL
    scene.render.resolution_y=PANEL
    scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG'
    scene.render.image_settings.color_mode='RGB'
    scene.render.image_settings.color_depth='8'
    scene.render.image_settings.compression=35
    scene.view_settings.view_transform='AgX'
    scene.view_settings.look='AgX - Medium High Contrast'
    scene.view_settings.exposure=-.35
    world=bpy.data.worlds.new("D2 film · studio bounce")
    scene.world=world
    world.use_nodes=True
    bg=world.node_tree.nodes.get("Background")
    bg.inputs[0].default_value=(.44,.51,.53,1)
    bg.inputs[1].default_value=.34
    deck=bpy.data.meshes.new("D2 film · floor")
    cx,cy=center[:2]
    deck.from_pydata([(cx+u*height*150,cy+v*height*150,floor_z) for u,v in ((-1,-1),(1,-1),(1,1),(-1,1))],[],[(0,1,2,3)])
    obj=bpy.data.objects.new("D2 film · contact floor",deck);scene.collection.objects.link(obj)
    mat=bpy.data.materials.new("D2 film · slate green");mat.diffuse_color=(.070,.115,.107,1)
    mat.use_nodes=True
    mat.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value=(.070,.115,.107,1)
    mat.node_tree.nodes["Principled BSDF"].inputs["Roughness"].default_value=.85
    deck.materials.append(mat)
    right=np.cross([0.,0.,1.],direction);right/=np.linalg.norm(right)
    for name,x,y,z,energy,size,color in (
        ("Soft key",-.92,1.10,1.15,110,1.25,(1,.87,.71)),
        ("Soft fill",.95,.62,.52,39,1.13,(.77,.88,1)),
        ("Edge",.54,-.98,.98,102,.87,(1,.82,.57)),
    ):
        light=bpy.data.lights.new(name,"AREA");light.energy=energy*height**2;light.shape="DISK";light.size=size*height;light.color=color
        lamp=bpy.data.objects.new("D2 film · "+name,light);scene.collection.objects.link(lamp)
        position=center+height*(x*right+y*direction+np.array([0,0,z]))
        lamp.location=position;lamp.rotation_euler=(Vector(center)-lamp.location).to_track_quat('-Z','Y').to_euler()
    data=bpy.data.cameras.new("D2 film · orthographic")
    cam=bpy.data.objects.new("D2 film · proof camera",data);scene.collection.objects.link(cam)
    cam.data.type='ORTHO';cam.data.clip_end=200
    scene.camera=cam
    return cam


def camera_at(cam,center,width,direction):
    from mathutils import Vector
    cam.location=Vector(center)+Vector(direction)*8
    cam.rotation_euler=(-Vector(direction)).to_track_quat('-Z','Y').to_euler()
    cam.data.ortho_scale=width


def detail_for(actor,frame):
    if actor=="GEP":
        return "foot" if 48<=frame<=65 else "face"
    return "hand" if frame<=26 else ("foot" if 56<=frame<=75 else "face")


def draw_text(im,xy,text,size,color="#ecf1e9",bold=False):
    font=ImageFont.truetype(FONT.format("Bold" if bold else "Regular"),size,index=1)
    ImageDraw.Draw(im).text(xy,text,font=font,fill=color,anchor="lt")


def spatial_filter(im):
    # Single-frame joint bilateral filtering. The RGB range guide preserves eye, finger and seam edges.
    a=np.asarray(im,dtype=np.float32)
    guide=np.asarray(im.filter(ImageFilter.MedianFilter(3)),dtype=np.float32)
    padded=np.pad(a,((2,2),(2,2),(0,0)),mode='edge')
    gp=np.pad(guide,((2,2),(2,2),(0,0)),mode='edge')
    h,w=a.shape[:2]
    total=np.zeros_like(a)
    divisor=np.zeros((h,w),dtype=np.float32)
    for dy in range(-2,3):
        for dx in range(-2,3):
            y=slice(2+dy,2+dy+h);x=slice(2+dx,2+dx+w)
            rgb=((gp[y,x]-guide)**2).sum(axis=2)
            weight=np.exp(-rgb/(2*18**2) -(dx*dx+dy*dy)/(2*1.15**2))
            total+=weight[:,:,None]*padded[y,x]
            divisor+=weight
    return Image.fromarray(np.clip(total/divisor[:,:,None],0,255).astype('uint8'))


def fingertip_markers(parts,center,width,direction):
    lateral=np.cross([0,0,1],direction)
    lateral/=np.linalg.norm(lateral)
    up=np.cross(direction,lateral)
    markers={}
    for name,label in [('index distal','검지'),('middle distal','중지')]:
        pts=next(v for k,v in parts.items() if 'right hand / '+name in k.lower())
        tip=pts.mean(axis=0)-center
        markers[label]=[round(PANEL*(.5+tip@lateral/width)),round(PANEL*(.5-tip@up/width))]
    return markers


def composite(actor,n,target,left,right,output,markers):
    left,right=spatial_filter(left),spatial_filter(right)
    im=Image.new("RGB",(PANEL*2,486),"#213530")
    im.paste(left,(0,0));im.paste(right,(PANEL,0))
    d=ImageDraw.Draw(im)
    for i,(label,point) in enumerate(markers.items()):
        x,y=point
        tx,ty=19,306+i*48
        ink=("#9dd8ed","#ffd38c")[i]
        d.rounded_rectangle((PANEL+tx-4,ty-2,PANEL+tx+42,ty+22),radius=4,fill="#243630")
        draw_text(im,(PANEL+tx,ty+1),label,16,color=ink,bold=True)
        d.line([(PANEL+tx+43,ty+11),(PANEL+x-5,y)],fill="#31413c",width=3)
        d.line([(PANEL+tx+43,ty+11),(PANEL+x-5,y)],fill=ink,width=1)
        d.ellipse((PANEL+x-3,y-3,PANEL+x+3,y+3),fill=ink,outline="#26352f",width=1)
    d.line((PANEL,0,PANEL,PANEL-1),fill="#91a298",width=1)
    char={"GEP":"제페토","PIN":"피노키오"}[actor]
    detail={"face":"얼굴과 시선","hand":"오른손 검지·중지","foot":"발 접지와 무릎"}[target]
    draw_text(im,(16,445),char+"   ·   전신",21,bold=True)
    draw_text(im,(PANEL+15,445),detail,20,bold=True)
    draw_text(im,(PANEL*2-79,448),f"F{n:03d}",16,color="#c5d1c2")
    im.save(output,compress_level=3)


def setup_film_scene(actor, samples=12, threads=3):
    """Make an isolated diagnostic stage sharing only the original animated character collection."""
    import bpy
    source=bpy.data.scenes[SCENES[actor]]
    bpy.context.window.scene=source
    baseline_dir=direction_of_camera(source)
    rig=next(o for o in source.objects if o.type=="ARMATURE" and
             (actor in o.name.upper() or actor=="GEP" and "PERFORMANCE" in o.name.upper()))
    coll=next(c for c in source.collection.children if rig.name in c.all_objects)
    scene=bpy.data.scenes.new("Film | "+SCENES[actor])
    scene.collection.children.link(coll)
    scene.frame_start,scene.frame_end=source.frame_start,source.frame_end
    scene.render.fps,scene.render.fps_base=24,1
    bpy.context.window.scene=scene
    key_frames=sorted(set([scene.frame_start,scene.frame_end,9,14,21,25,48,56,62,66,75]+list(range(scene.frame_start,scene.frame_end+1,9))))
    geometry=[];foot_samples=[];hand_samples=[]
    for n in key_frames:
        scene.frame_set(n);bpy.context.view_layer.update()
        parts=evaluated_parts(scene,actor)
        geometry.append(np.concatenate(list(parts.values())))
        if detail_for(actor,n)=="foot":foot_samples.append(selected(parts,"foot"))
        if detail_for(actor,n)=="hand":hand_samples.append(selected(parts,"hand"))
    all_points=np.concatenate(geometry)
    full_center,full_width=projected_fit(all_points,baseline_dir,1.15)
    floor_z=float(all_points[:,2].min())
    _,extent=center_extent(all_points)
    h=float(extent[2])
    if full_width<.1 or h>12:
        raise RuntimeError(f"Unexpected actor span: {full_width}, {h}")
    locked={}
    if hand_samples:
        direction=np.array([-.49,.84,.23]);direction/=np.linalg.norm(direction)
        center,width=projected_fit(np.concatenate(hand_samples),direction,1.28)
        locked["hand"]=[center.tolist(),max(width,h*.113),direction.tolist()]
    if foot_samples:
        center,width=projected_fit(np.concatenate(foot_samples),baseline_dir,1.20)
        center[2]+=.095*h
        locked["foot"]=[center.tolist(),max(width,h*.40),baseline_dir.tolist()]
    scene.frame_set(scene.frame_start)
    cam=build_stage(scene,actor,full_center,floor_z,h,baseline_dir,samples,threads)
    camera_at(cam,full_center,full_width,baseline_dir)
    return scene,cam,dict(full_center=full_center.tolist(),full_width=full_width,direction=baseline_dir.tolist(),stage_floor_z=floor_z,
        height=h,locked_detail_cameras=locked,evaluated_bounds_min=all_points.min(0).tolist(),evaluated_bounds_max=all_points.max(0).tolist(),armatures=[rig.name])


def render(args):
    import bpy
    actor=args.actor
    out=args.out.resolve()/actor
    out.mkdir(parents=True,exist_ok=True)
    scene,cam,setup=setup_film_scene(actor,args.samples,args.threads)
    baseline_dir=np.array(setup['direction'])
    full_center,full_width,h=setup['full_center'],setup['full_width'],setup['height']
    frames=args.frames or list(range(args.first,max(args.first,min(args.last,scene.frame_end))+1))
    meta=dict(spatial_postfilter="5x5 joint bilateral, single-frame RGB median guide, sigma 1.15px/18 RGB",scene=SCENES[actor],source=Path(bpy.data.filepath).name,source_sha256=sha(bpy.data.filepath),actor=actor,
              engine="Cycles CPU",samples=args.samples,panel_size=PANEL,fps=FPS,
              frame_start=scene.frame_start,frame_end=scene.frame_end,**setup)
    json_file(out/'camera.json',meta)
    for n in frames:
        scene.frame_set(n);bpy.context.view_layer.update()
        parts=evaluated_parts(scene,actor)
        target=detail_for(actor,n)
        detail_points=selected(parts,target)
        if target in setup["locked_detail_cameras"]:
            focus,width,detail_dir=setup["locked_detail_cameras"][target]
            focus,detail_dir=np.array(focus),np.array(detail_dir)
        else:
            detail_dir=baseline_dir
            focus,width=projected_fit(detail_points,detail_dir,1.20)
            width=max(width,.30*h)
        markers=fingertip_markers(parts,focus,width,detail_dir) if target=='hand' else {}
        record={'frame':n,'detail':target,'tip_labels_xy':markers,'mesh_bounds':len(parts),'focus':focus.tolist(),'detail_width':width}
        for label,center,span in [('body',full_center,full_width),('detail',focus,width)]:
            camera_at(cam,center,span,detail_dir if label=="detail" else baseline_dir)
            dst=out/f"{n:04d}_{label}.png"
            scene.render.filepath=str(dst)
            bpy.ops.render.render(write_still=True,scene=scene.name)
        with Image.open(out/f"{n:04d}_body.png") as left,Image.open(out/f"{n:04d}_detail.png") as right:
            composite(actor,n,target,left.convert('RGB'),right.convert('RGB'),out/f"{n:04d}.png",markers)
        json_file(out/f"{n:04d}.json",record)
        print("FILMED",actor,n,target,flush=True)


def assemble(args):
    from review_boards import MotionFrame,d2_sheet
    from check_encoded_motion import verify as verify_encoded_motion
    out=args.out.resolve()
    assembled=out/'sequence';assembled.mkdir(exist_ok=True)
    records=[];check=[];durations={}
    used=0
    movement={}
    for actor in ("GEP","PIN"):
        last_pixels=None;comparison=[]
        folder=out/actor
        setup=json.loads((folder/'camera.json').read_text())
        first,last=setup['frame_start'],setup['frame_end']
        for n in range(first,last+1):
            src=folder/f"{n:04d}.png"
            rec=json.loads((folder/f"{n:04d}.json").read_text())
            if rec['frame']!=n:raise ValueError(src)
            index=used+n-first+1
            path=assembled/f"{index:04d}.png"
            path.unlink(missing_ok=True)
            path.hardlink_to(src)
            with Image.open(src) as im:
                pixels=np.asarray(im.convert('RGB'))[:PANEL].astype(np.int16)
            if last_pixels is not None:
                delta=np.abs(pixels-last_pixels).mean(2)
                comparison.append({'source_frame':n,'mean_L1_8bit':round(float(delta.mean()),4),
                                   'fraction_changed_over_8':round(float((delta>8).mean()),6)})
            last_pixels=pixels
            records.append({'film_frame':index,'source_scene':setup['scene'],'source_frame':n,'detail':rec['detail'],'render_sha256':sha(src)})
        board_set=([(1,"제페토 · 따뜻함"),(40,"놀람 / 손과 얼굴"),(57,"발 접지 / 체중 이동"),(80,"기쁨 / 손을 내밈")]
                   if actor=='GEP' else [(1,"피노키오 · 손의 시작"),(9,"독립된 검지"),(21,"독립된 중지"),(31,"눈 감기"),(44,"고개와 시선"),(66,"무릎과 발 접지")])
        for n,label in board_set:
            index=used+n-first+1
            check.append(MotionFrame(index,label,folder/f"{n:04d}.png"))
        movement[actor]={'compared_views':'Both filtered panel pictures above the frame-number strip',
                          'pairs_with_over_one_percent_changed':sum(d['fraction_changed_over_8']>.01 for d in comparison),
                          'max_changed_fraction':max(d['fraction_changed_over_8'] for d in comparison),'pairs':comparison}
        assert any(d['fraction_changed_over_8']>.08 for d in comparison)
        durations[actor]=last-first+1
        used+=last-first+1
    film=out/'D2_RIG_TEST.mp4'
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','24','-start_number','1','-i',str(assembled/'%04d.png'),
         '-frames:v',str(used),'-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:v','libx264','-preset','medium','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(film)]
    subprocess.run(cmd,check=True)
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries',
        'stream=codec_name,pix_fmt,width,height,r_frame_rate,nb_read_frames:format=duration','-of','json',str(film)]))
    stream=probe['streams'][0]
    assert int(stream['nb_read_frames'])==used and stream['codec_name']=='h264' and stream['pix_fmt']=='yuv420p' and stream['r_frame_rate']=='24/1'
    blob=film.read_bytes()
    assert 0<blob.index(b'moov')<blob.index(b'mdat')
    args.boards.mkdir(exist_ok=True,parents=True)
    d2_sheet(args.boards,check,FPS,1,2)
    hand_board(args.boards,out/'PIN')
    json_file(out/'FILM_QA.json',dict(probe=probe,source_counts=durations,film_sha256=sha(film),faststart=True,
              motion_evidence=movement,total_rendered_views=2*used,encoder=cmd,camera_setup={a:json.loads((out/a/'camera.json').read_text()) for a in durations},frames=records))
    encoded_report=out/'D2_ENCODED_MOTION.json'
    verify_encoded_motion(out,encoded_report)
    verification=json.loads(encoded_report.read_text())
    summary=json.loads((out/'FILM_QA.json').read_text())
    summary['decoded_frames']={k:verification[k] for k in (
        'check','frames_compared','native_resolution','mean_absolute_decoded_vs_render_rgb',
        'maximum_frame_mean_absolute_decoded_vs_render_rgb','timestamp_increment_seconds')}
    json_file(out/'FILM_QA.json',summary)



def hand_board(folder,frames):
    from story_shots.review_boards import sheet,lettering,photo,GREEN
    canvas=sheet("C05  ·  오른손 손가락 제어","같은 카메라와 같은 배율에서 검지와 중지 끝마디를 표시했습니다.",1036,1294)
    examples=[(1,"기본 자세"),(9,"검지 제어"),(21,"중지 제어"),(25,"기본 자세 복귀")]
    for i,(frame,label) in enumerate(examples):
        x=42+(i%2)*486; y=210+(i//2)*533
        lettering(canvas,(x,y),f"F{frame:03d}   ·   {label}",28,True,GREEN)
        with Image.open(frames/f"{frame:04d}.png") as film:
            detail=film.crop((PANEL,0,PANEL*2,PANEL))
            photo(canvas,detail,(x,y+48),466,466)
    canvas.save(folder/'D2_C05_HAND_DETAIL.png',optimize=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);commands=p.add_subparsers(dest="mode",required=True)
    r=commands.add_parser('render');r.add_argument('actor',choices=SCENES);r.add_argument('out',type=Path)
    r.add_argument('--first',type=int,default=1);r.add_argument('--last',type=int,default=84);r.add_argument('--frames',nargs='+',type=int)
    r.add_argument('--samples',type=int,default=12);r.add_argument('--threads',type=int,default=3)
    a=commands.add_parser('assemble');a.add_argument('out',type=Path);a.add_argument('boards',type=Path)
    args=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else None)
    (render if args.mode=='render' else assemble)(args)


if __name__=='__main__':
    main()
