"""Measure the evaluated Geppetto offering gesture in the D2 workshop scene.

blender -b FILE.blend --python-exit-code 1 --python gesture_clearance.py -- REPORT.json

The scene is read only. Reported nearest distances are bidirectional evaluated
vertex-to-surface witnesses. A separate exact triangle intersection test covers
crossings between sampled vertices.
"""

import argparse
from collections import defaultdict
from dataclasses import dataclass
import hashlib
import itertools
import json
from pathlib import Path
import sys

import bpy
from bpy_extras.object_utils import world_to_camera_view
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform, intersect_ray_tri


SCENE = "D2_GEP_PERFORMANCE"
CHECKPOINTS = (1, 39, 78)
RIG = "GEP_Performance_Rig"
SKIN = "Open hand and forearm"
HAND_BONE = "Hand.R"
OFFER_PARTS = (SKIN, "Natural nail", "Open palm crease")
CUFF_PARTS = ("Gathered linen sleeve 1", "Double rolled sleeve 1")
PIN_TARGETS = ("PIN_right_hand", "PIN_shins_boots", "PIN_thighs_shorts")
WORKSHOP_TARGETS = (
    ("work_linen", ("Work linen •", "Woven selvedge folded", "C06 folded flax")),
    ("painted_bench_top", ("Painted top • traced shadow receiver",)),
)


@dataclass
class Surface:
    points: list
    triangles: list
    vertex_owners: list
    triangle_owners: list
    tree: BVHTree
    coordinates: np.ndarray

    def digest(self):
        fingerprint = hashlib.sha256()
        fingerprint.update(self.coordinates.astype("<f4").tobytes())
        fingerprint.update(np.asarray(self.triangles, dtype="<i4").tobytes())
        return fingerprint.hexdigest()


class SurfaceBuilder:
    def __init__(self):
        self.points = []
        self.triangles = []
        self.vertices = []
        self.faces = []
        self.seen = set()

    def add(self, obj, matrix):
        name = obj.name
        mesh = obj.to_mesh()
        try:
            if not mesh or not mesh.polygons:
                return
            # A curve can appear as both a true curve and its evaluated
            # conversion. Retain distinct surfaces with identical names.
            key = (name, tuple(value for row in matrix for value in row),
                   len(mesh.vertices), len(mesh.polygons))
            if key in self.seen:
                return
            self.seen.add(key)
            mesh.calc_loop_triangles()
            offset = len(self.points)
            self.points.extend(matrix @ vertex.co for vertex in mesh.vertices)
            self.vertices.extend((name, vertex.index) for vertex in mesh.vertices)
            for tri in mesh.loop_triangles:
                self.triangles.append(tuple(offset + i for i in tri.vertices))
                self.faces.append((name, tri.index, tuple(tri.vertices)))
        finally:
            obj.to_mesh_clear()

    def finish(self):
        if not self.triangles:
            raise ValueError("No evaluated triangles in measured part")
        return Surface(self.points, self.triangles, self.vertices, self.faces,
                       BVHTree.FromPolygons(self.points, self.triangles, all_triangles=True),
                       np.asarray(self.points, dtype=np.float64))


def evaluated_surface(parts):
    result = SurfaceBuilder()
    for obj, matrix in parts:
        result.add(obj, matrix)
    return result.finish()


def direct_parts(scene, depsgraph, condition):
    for obj in scene.objects:
        if obj.type in {"MESH", "CURVE"} and not obj.hide_render and condition(obj):
            evaluated = obj.evaluated_get(depsgraph)
            yield evaluated, evaluated.matrix_world.copy()


def pin_region(name):
    name = name.lower()
    if "right hand /" in name:
        return "PIN_right_hand"
    if any(part in name for part in (" boot /", " leg / shin", " leg / knee")):
        return "PIN_shins_boots"
    if any(part in name for part in (" leg / thigh", "shorts", "outseam topstitch")):
        return "PIN_thighs_shorts"
    return None


def pin_surfaces(root, depsgraph):
    groups = {key: SurfaceBuilder() for key in PIN_TARGETS}
    for instance in depsgraph.object_instances:
        if not instance.is_instance or instance.parent is None or instance.parent.original != root:
            continue
        obj = instance.object
        region = pin_region(obj.name)
        if region and obj.type in {"MESH", "CURVE"} and not obj.hide_render:
            # Evaluated instance handles expire with the iterator.
            groups[region].add(obj, instance.matrix_world.copy())
    return {key: group.finish() for key, group in groups.items()}


def shop_surfaces(scene, depsgraph, definitions=WORKSHOP_TARGETS):
    return {
        key: evaluated_surface(direct_parts(scene, depsgraph, lambda obj: obj.name.startswith(prefixes)))
        for key, prefixes in definitions
    }


def triangle_world(surface, index):
    return [surface.points[i] for i in surface.triangles[index]]


def crossing_witness(a, b):
    for first, second in ((a, b), (b, a)):
        for start, end in zip(first, first[1:] + first[:1]):
            segment = end - start
            if segment.length_squared < 1e-14:
                continue
            contact = intersect_ray_tri(*second, segment, start, True)
            if contact is not None and (contact - start).dot(segment) >= -1e-9 and (
                    contact - start).length <= segment.length + 1e-6:
                return list(contact)
    return None


def nearest(offer, target, lens_direction):
    closest = None
    for first, second in ((offer, target), (target, offer)):
        lo, hi = second.coordinates.min(axis=0), second.coordinates.max(axis=0)
        axis_gaps = np.maximum(0, np.maximum(lo - first.coordinates, first.coordinates - hi))
        lower_bounds = np.sum(axis_gaps * axis_gaps, axis=1)
        if closest is None:
            indices = np.argsort(lower_bounds)
        else:
            indices = np.flatnonzero(lower_bounds <= closest["bu"] ** 2 + 1e-10)
        for index in indices:
            if closest is not None and lower_bounds[index] > closest["bu"] ** 2 + 1e-10:
                continue
            vertex = first.points[index]
            if closest is None:
                point, _, tri, gap = second.tree.find_nearest(vertex)
            else:
                point, _, tri, gap = second.tree.find_nearest(vertex, closest["bu"] + 1e-6)
            if point is None or (closest is not None and gap >= closest["bu"]):
                continue
            vertex_part = first.vertex_owners[index]
            face_part = second.triangle_owners[tri]
            if first is offer:
                offered, other, offered_part, target_part = vertex, point, vertex_part, face_part[:2]
            else:
                offered, other, offered_part, target_part = point, vertex, face_part[:2], vertex_part
            closest = {
                "bu": gap,
                "offering_xyz": list(offered),
                "target_xyz": list(other),
                "offering_object": offered_part[0],
                "target_object": target_part[0],
                "offering_index": offered_part[1],
                "target_index": target_part[1],
                "source_feature": "offering vertex" if first is offer else "target vertex",
                "offering_minus_target_toward_lens_bu": (offered - other).dot(lens_direction),
            }
    if closest is None:
        raise ValueError("Closest distance query returned no witness")
    return closest


def contact(offer, target, lens_direction, with_distance=True):
    pairs = sorted(offer.tree.overlap(target.tree))
    collision_parts = defaultdict(int)
    result = {"intersecting_triangle_pairs": len(pairs)}
    if pairs:
        for ia, ib in pairs:
            owners = (offer.triangle_owners[ia][0], target.triangle_owners[ib][0])
            collision_parts[owners] += 1
        result["collision_pairs_by_object"] = [
            [*names, count] for names, count in sorted(collision_parts.items())
        ]
        for ia, ib in pairs:
            point = crossing_witness(triangle_world(offer, ia), triangle_world(target, ib))
            if point is not None:
                result["intersection_witness"] = {
                    "xyz": point,
                    "offering_object_triangle": list(offer.triangle_owners[ia][:2]),
                    "target_object_triangle": list(target.triangle_owners[ib][:2]),
                }
                break
    if pairs:
        result["reported_clearance_bu"] = 0.0
    elif with_distance:
        result["closest_vertex_to_surface"] = nearest(offer, target, lens_direction)
        result["reported_clearance_bu"] = result["closest_vertex_to_surface"]["bu"]
    return result, pairs


def bench_penetration(offer, target, scene):
    """Depth below the actual receiving geometry, only at XY coordinates it covers."""
    ceiling = max(point.z for point in target.points)
    down = Vector((0, 0, -1))
    camera = scene.camera.evaluated_get(bpy.context.evaluated_depsgraph_get())
    count = 0
    worst = None
    for index, point in enumerate(offer.points):
        if point.z >= ceiling:
            continue
        hit, _, triangle, _ = target.tree.ray_cast(Vector((point.x, point.y, ceiling + .05)), down, 4)
        if hit is None or hit.z - point.z <= 1e-5:
            continue
        count += 1
        depth = hit.z - point.z
        if worst is None or depth > worst["depth_bu"]:
            uv = world_to_camera_view(scene, camera, point)
            worst = {"depth_bu": depth, "offering_xyz": list(point), "surface_xyz": list(hit),
                     "offering_object_vertex": list(offer.vertex_owners[index]),
                     "surface_object_triangle": list(target.triangle_owners[triangle][:2]),
                     "screen_px": [uv.x * scene.render.resolution_x,
                                   (1 - uv.y) * scene.render.resolution_y]}
    return {"vertices_below_surface_xy": count, "deepest": worst}


def cuff_contact(offer, cuff, skin_name, rest_points, wrist, fore_direction, weights, lens_direction):
    result, pairs = contact(offer, cuff, lens_direction, with_distance=False)
    # The cuff intentionally encloses proximal forearm skin. Label the actual
    # intersection on the skin's rest-side wrist plane, away from skin weights.
    from_wrist = [(point - wrist).dot(fore_direction) for point in rest_points]
    distal_count = 0
    max_weight = 0.0
    for a, b in pairs:
        mesh_name, tri_index, vertices = offer.triangle_owners[a]
        if mesh_name != skin_name:
            # The other offering surfaces are palms creases and fingernails,
            # both distal to the wrist by construction.
            distal_count += 1
            continue
        max_weight = max(max_weight, *(weights[i] for i in vertices))
        distances = [from_wrist[i] for i in vertices]
        if max(distances) <= 0:
            continue
        skin_triangle = triangle_world(offer, a)
        hit = crossing_witness(skin_triangle, triangle_world(cuff, b))
        distance = min(distances)
        if hit is not None:
            rest = barycentric_transform(Vector(hit), *skin_triangle, *(rest_points[i] for i in vertices))
            distance = (rest - wrist).dot(fore_direction)
        if distance <= 0:
            continue
        distal_count += 1
        if hit and ("distal_intersection_witness" not in result
                    or distance > result["distal_intersection_witness"]["rest_distance_past_wrist_bu"]):
            result["distal_intersection_witness"] = {
                "xyz": hit, "rest_distance_past_wrist_bu": distance,
                "offering_object_triangle": [mesh_name, tri_index],
                "cuff_object_triangle": list(cuff.triangle_owners[b][:2]),
            }
    result["proximal_forearm_cuff_pairs"] = len(pairs) - distal_count
    result["unexpected_distal_hand_cuff_pairs"] = distal_count
    result["maximum_hand_skin_weight_on_overlapping_triangles"] = max_weight
    return result


def ranges(frames):
    result = []
    for _, group in itertools.groupby(enumerate(frames), key=lambda pair: pair[1] - pair[0]):
        seq = [frame for _, frame in group]
        result.append([seq[0], seq[-1]])
    return result


def approved_shot(scene_name):
    scene = bpy.data.scenes[scene_name]
    bpy.context.window.scene = scene
    scene.frame_set(1)
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    lens = scene.camera.evaluated_get(depsgraph).matrix_world.to_quaternion() @ Vector((0, 0, 1))
    root = next(o for o in scene.objects if o.instance_collection and o.name.startswith("GEP " + scene_name))
    offer_builder = SurfaceBuilder()
    for instance in depsgraph.object_instances:
        if instance.is_instance and instance.parent and instance.parent.original == root:
            obj = instance.object
            if obj.type in {"MESH", "CURVE"} and not obj.hide_render and any(t in obj.name for t in OFFER_PARTS):
                offer_builder.add(obj, instance.matrix_world.copy())
    offer = offer_builder.finish()
    return scene, depsgraph, lens, root, offer


def approved_warm_comparison():
    scene, depsgraph, lens, root, offer = approved_shot("C06_B")
    worktop = (("shared_runner", ("Work linen •", "Woven selvedge folded")),
               ("sleeping_folded_linen", ("C06 folded flax",)), WORKSHOP_TARGETS[1])
    comparisons = {}
    for name, target in shop_surfaces(scene, depsgraph, worktop).items():
        comparisons[name] = contact(offer, target, lens)[0]
        comparisons[name]["vertical_penetration"] = bench_penetration(offer, target, scene)
    return {
        "scene": scene.name, "camera": scene.camera.name, "root": root.name,
        "offering_minimum_z_bu": min(p.z for p in offer.points),
        "contacts": comparisons,
    }


def approved_joy_comparison(d2_joy):
    scene, depsgraph, lens, root, offer = approved_shot("C07_JOY")
    pin = next(o for o in scene.objects if o.instance_collection and o.name.startswith("PIN_ROOT"))
    targets = pin_surfaces(pin, depsgraph)
    targets.update(shop_surfaces(scene, depsgraph))
    contacts = {key: contact(offer, target, lens)[0] for key, target in targets.items()}
    differences = {
        key: d2_joy[key]["reported_clearance_bu"] - d1["reported_clearance_bu"]
        for key, d1 in contacts.items()
    }
    return {"scene": scene.name, "camera": scene.camera.name, "root": root.name,
            "contacts": contacts, "frame_78_minus_D1_clearance_bu": differences}


def audit(scene, with_distance=True, all_distances=False):
    bpy.context.window.scene = scene
    rig = scene.objects[RIG]
    root = next(o for o in scene.objects if o.name.startswith("PIN_ROOT") and o.instance_collection)
    skin = next(o for o in scene.objects if o.parent == rig and SKIN in o.name)
    hand_group = skin.vertex_groups[HAND_BONE].index
    weights = [next((g.weight for g in vertex.groups if g.group == hand_group), 0.0)
               for vertex in skin.data.vertices]
    rest = [vertex.co.copy() for vertex in skin.data.vertices]
    wrist = rig.data.bones[HAND_BONE].head_local
    fore_direction = (wrist - rig.data.bones["Forearm.R"].head_local).normalized()
    frames = {}
    reference_targets = None
    for frame in range(scene.frame_start, scene.frame_end + 1):
        scene.frame_set(frame)
        bpy.context.view_layer.update()
        dg = bpy.context.evaluated_depsgraph_get()
        lens = scene.camera.evaluated_get(dg).matrix_world.to_quaternion() @ Vector((0, 0, 1))
        targets = pin_surfaces(root, dg)
        targets.update(shop_surfaces(scene, dg))
        target_digests = {key: surface.digest() for key, surface in targets.items()}
        if reference_targets is None:
            reference_targets = target_digests
        if target_digests != reference_targets:
            raise ValueError(f"Fixed PIN/workshop geometry changed at frame {frame}")
        offer = evaluated_surface(direct_parts(
            scene, dg, lambda o: o.parent == rig and any(t in o.name for t in OFFER_PARTS)))
        cuff = evaluated_surface(direct_parts(
            scene, dg, lambda o: o.parent == rig and any(t in o.name for t in CUFF_PARTS)))
        if sum(name == skin.name for name, _ in offer.vertex_owners) != len(weights):
            raise ValueError("Offering skin topology no longer matches authored weights")
        distance_frame = with_distance and (all_distances or frame in CHECKPOINTS)
        measurements = {key: contact(offer, target, lens, distance_frame)[0] for key, target in targets.items()}
        measurements["same_arm_cuff"] = cuff_contact(
            offer, cuff, skin.name, rest, wrist, fore_direction, weights, lens)
        for key, _ in WORKSHOP_TARGETS:
            measurements[key]["vertical_penetration"] = bench_penetration(offer, targets[key], scene)
        measurements["offering_minimum_z_bu"] = min(p.z for p in offer.points)
        frames[frame] = measurements
        if frame in CHECKPOINTS or any(v["intersecting_triangle_pairs"] for k, v in measurements.items()
                                       if k in targets):
            print(f"Gesture {frame}: " + ", ".join(
                f"{k}={v.get('reported_clearance_bu', 'no distance')}/{v['intersecting_triangle_pairs']}"
                for k, v in measurements.items() if k in targets or k == "same_arm_cuff"), flush=True)
    summary = {}
    for key in (*targets, "same_arm_cuff"):
        records = [(frame, record[key]) for frame, record in frames.items()]
        overlap_key = ("unexpected_distal_hand_cuff_pairs" if key == "same_arm_cuff"
                       else "intersecting_triangle_pairs")
        collisions = [frame for frame, record in records if record[overlap_key]]
        summary[key] = {"collision_frame_ranges_inclusive": ranges(collisions),
                        "maximum_intersecting_triangle_pairs": max(r[overlap_key] for _, r in records)}
        if with_distance and key != "same_arm_cuff":
            measured = [(frame, record) for frame, record in records if "reported_clearance_bu" in record]
            frame, record = min(measured, key=lambda pair: pair[1]["reported_clearance_bu"])
            summary[key].update(minimum_clearance_bu=record["reported_clearance_bu"], minimum_frame=frame,
                                separation_distance_frames=[f for f, r in measured if r.get("closest_vertex_to_surface")],
                                minimum_witness=record.get("intersection_witness")
                                or record.get("closest_vertex_to_surface"))
        if "vertical_penetration" in records[0][1]:
            depths = [(frame, record["vertical_penetration"]["deepest"])
                      for frame, record in records if record["vertical_penetration"]["deepest"]]
            if depths:
                frame, deepest = max(depths, key=lambda pair: pair[1]["depth_bu"])
                summary[key].update(maximum_vertical_penetration=deepest, maximum_penetration_frame=frame)
            summary[key]["under_surface_frame_ranges_inclusive"] = ranges([frame for frame, _ in depths])
    return {
        "scene": scene.name,
        "stage_camera": scene.camera.name,
        "fixed_pin_root": root.name,
        "offering_skin": skin.name,
        "authored_hand_bone": HAND_BONE,
        "external_clearance_status": "FAIL" if any(
            summary[key]["collision_frame_ranges_inclusive"]
            or summary[key].get("under_surface_frame_ranges_inclusive") for key in targets
        ) else "PASS",
        "same_arm_cuff_status": "FAIL" if summary["same_arm_cuff"]["collision_frame_ranges_inclusive"] else "PASS",
        "frame_range_inclusive": [scene.frame_start, scene.frame_end],
        "frames_evaluated": len(frames),
        "fps": scene.render.fps / scene.render.fps_base,
        "fixed_target_geometry_sha256": reference_targets,
        "checkpoint_frames": {frame: frames[frame] for frame in CHECKPOINTS},
        "minimum_offering_z_across_frames_bu": min(r["offering_minimum_z_bu"] for r in frames.values()),
        "summary": summary,
        "frames": frames,
        "limits": "Evaluated mesh intersections at every integer frame. Closest separated gaps use "
                  "bidirectional vertex-to-triangle witnesses at reported distance frames. Hidden layout "
                  "proxies and unrelated bodies are outside this audit.",
    }


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--overlap-only", action="store_true",
                        help="Run just the same swept intersection checks for debugging")
    parser.add_argument("--all-distances", action="store_true",
                        help="Measure separated vertex-to-surface distances at every frame, not just checkpoints")
    args = parser.parse_args(argv)
    source = Path(bpy.data.filepath)
    fingerprint = hashlib.sha256(source.read_bytes()).hexdigest()
    report = audit(bpy.data.scenes[SCENE], with_distance=not args.overlap_only, all_distances=args.all_distances)
    report["status"] = ("PASS" if report["external_clearance_status"] == report["same_arm_cuff_status"] == "PASS"
                        else "FAIL")
    report["approved_D1_WARM_context"] = approved_warm_comparison()
    if not args.overlap_only:
        report["approved_D1_JOY_comparison"] = approved_joy_comparison(report["checkpoint_frames"][78])
    if hashlib.sha256(source.read_bytes()).hexdigest() != fingerprint:
        raise ValueError("Input file changed on disk during the audit")
    report["input_blend_sha256"] = fingerprint
    report["blender_version"] = bpy.app.version_string
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(f"{report['status']} {report['frames_evaluated']} frames: {args.output}", flush=True)


if __name__ == "__main__":
    main(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else [])
