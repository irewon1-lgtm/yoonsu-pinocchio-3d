# 3·4·5화 수정 대본 + 모든 대사 음성 연기 제작 묶음

## 먼저 볼 자료

1. docs/series_v2/S03_S05_CORRECTION_AND_VOICE_REPORT.md — 무엇을 수정했고 어디까지 확인했는지.
2. docs/series_v2/VOICE_PERFORMANCE_BIBLE_V2_1.md — 피노키오·제페토·내레이션·파란 요정·귀뚜라미·마라·핍의 고정 목소리와 상황별 말투.
3. docs/series_v2/CODEX_VOICE_ACTING_HANDOFF.md — Codex가 실제 음성 엔진에 연결할 방법.
4. scenes/S03, S04, S05의 script_v2_draft.md — 모든 대사 옆에 연기 지시가 있는 읽기용 대본.
5. 같은 폴더의 voice_direction_plan.json / voice_direction_sheet.csv — 실제 음성 제작용 340개 작업표.

## 완료한 범위

- 3·4·5화 오류 9건·연결 위험 10건 수정 반영.
- 본편 310개 대사 + 별도 참여 예시 30개 모두 개별 연기 지시 작성.
- 원본 발화 72개와 원본 이야기·스토리보드 및 기존 승인 성우 MP3 네 개 보존.
- 150컷. 본편 계획 시간은 3화 9:58, 4화 8:47, 5화 7:52. 실제 오디오·영상 길이가 아님.
- 전체 7명 목소리 기준 작성. 기존 승인 A/A/A/C 유지. 귀뚜라미·마라·핍은 승인 음색 참조가 아직 없음.

## 사용 방법

기존 프로젝트에서는 동일한 상대 경로에 이 수정 자료를 반영한다. 별도 폴더에 풀어 자료를 읽고 준비 검사를 실행할 수도 있다. 이 압축파일은 수정 대본·음성 연기 제작 자료이며 전체 Blender 프로젝트나 새 완성 영상/음성 파일이 아니다.

S01·S02는 사용자가 완료했다. 수정·재합성·재렌더·제작 검사 재실행 대상에서 제외한다. 포함된 scenes/S02/scene_design_v2.json은 변경하지 않은 기본 데이터 형식 참조이며 2화 재제작 지시가 아니다. ZIP에 있는 assets/voice_refs/v6/*.mp3는 새 대사가 아니라 기존 승인 음색 참조다.

저장소 루트 또는 압축 해제 루트에서:

```bash
python3 scripts/voice_direction_tools.py validate --scenes S03 S04 S05
python3 scripts/s03_approved_voice_tts.py --export-jobs /tmp/S03_voice_jobs.json
python3 scripts/s04_approved_voice_tts.py --export-jobs /tmp/S04_voice_jobs.json
python3 scripts/s05_voice_preflight.py --export-jobs /tmp/S05_voice_jobs.json
```

이 명령은 합성하지 않고 데이터·참조 검사 및 작업표 내보내기만 수행한다. 실제 설치 엔진의 지원 기능을 확인해 instruct_prompt_en과 문장별 지시를 전달해야 한다. spoken_text만 읽고 연기 지시·앞뒤 문맥은 읽지 않는다. 기존 --synthesize는 지시를 무시하던 중립 합성을 반복하지 않도록 DIRECTED_ADAPTER_REQUIRED / 종료 코드 2로 차단돼 있다.

실제 합성·연기 지시 전달·청취·립싱크·영상·기기 입력은 NOT_RUN이다. 귀뚜라미가 필요한 4·5화는 최종 참조 음색 확보 전 BLOCKED_RESOURCE다. 다른 캐릭터 목소리로 대신 채우지 않는다. 기존 승인 성우를 다시 고를 필요는 없다.

reviews/는 수정 전 검사 기록이다. 현재 결과는 docs/series_v2/의 CORRECTION 보고서와 검증 JSON을 따른다. PACK_SHA256.json으로 포함 파일의 정확한 바이트를 확인할 수 있다.
