import bpy,sys
from pathlib import Path
from mathutils import Vector
s=bpy.data.scenes['C07 gate'];bpy.context.window.scene=s
Path("frames").mkdir(exist_ok=True)
kind=sys.argv[sys.argv.index('--')+1];nums=list(map(int,sys.argv[sys.argv.index('--')+2:]))
if not nums:nums=list(range(1,49 if kind=='gep' else 61))
if kind=='gep':
 c=s.camera.copy();c.data=c.data.copy();s.collection.objects.link(c);c.animation_data_clear();c.parent=None;s.camera=c
 for co in list(c.constraints):c.constraints.remove(co)
 target=Vector((-3.03,-.49,1.68));direction=Vector((.45,-.91,.16)).normalized();c.location=target+direction*9;c.rotation_euler=(-direction).to_track_quat('-Z','Y').to_euler();c.data.ortho_scale=3.04;c.data.shift_x=c.data.shift_y=0
 s.use_nodes=False;s.render.film_transparent=True
 # Neutral review background with alpha; retain workshop lighting.
 s.use_nodes=True;s.node_tree.nodes.clear();nodes=s.node_tree.nodes;layer=nodes.new('CompositorNodeRLayers');over=nodes.new('CompositorNodeAlphaOver');over.inputs[1].default_value=(.14,.115,.085,1);out=nodes.new('CompositorNodeComposite');s.node_tree.links.new(layer.outputs['Image'],over.inputs[2]);s.node_tree.links.new(over.outputs['Image'],out.inputs[0])
 # Remove plate-only occluders and the second actor in this isolated performance close-up.
 for o in s.objects:
  if o.type in ('MESH','CURVE','SURFACE','FONT') and o.parent!=s.objects['GEP_Performance_Rig']:o.hide_render=True
  if o.instance_type=='COLLECTION':o.hide_render=True
for n in nums:
 p=Path(f'frames/{kind}-{n:03}.png').resolve()
 if p.exists():continue
 s.frame_set(n);s.render.filepath=str(p);bpy.ops.render.render(write_still=True,scene=s.name);print('OUTPUT',kind,n,flush=True)
