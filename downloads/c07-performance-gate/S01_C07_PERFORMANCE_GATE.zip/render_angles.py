import bpy,sys
from pathlib import Path
s=bpy.data.scenes['C07 gate'];bpy.context.window.scene=s
Path("frames").mkdir(exist_ok=True)
kind=sys.argv[-1]
s.camera=s.objects[{'side':'SIDE','threequarter':'THREE_QUARTER'}[kind]]
s.render.resolution_x=800;s.render.resolution_y=600;s.render.resolution_percentage=100;s.render.film_transparent=True;s.cycles.samples=5;s.render.threads=3
s.use_nodes=True;nodes=s.node_tree.nodes;nodes.clear();layer=nodes.new('CompositorNodeRLayers');bg=nodes.new('CompositorNodeAlphaOver');bg.inputs[1].default_value=(.13,.125,.12,1);o=nodes.new('CompositorNodeComposite');s.node_tree.links.new(layer.outputs['Image'],bg.inputs[2]);s.node_tree.links.new(bg.outputs['Image'],o.inputs[0])
for obj in s.objects:
 if obj.parent==s.objects['GEP_Performance_Rig'] or obj.instance_type=='COLLECTION':obj.hide_render=True
for f in range(1,61):
 s.frame_set(f);p=Path(f'frames/{kind}-{f:03}.png').resolve();s.render.filepath=str(p);bpy.ops.render.render(write_still=True,scene=s.name);print('OUTPUT',kind,f,flush=True)
