"""Compare the reopened shot file with the delivered layout and ray-test its visible supports."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import bpy
import numpy as np
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector
from mathutils.bvhtree import BVHTree

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lookdev'))
from world_study import points_for, cloud

def tree(obj):
    ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh=ev.to_mesh()
    try:
        return BVHTree.FromPolygons([ev.matrix_world @ v.co for v in mesh.vertices],
                                   [p.vertices[:] for p in mesh.polygons])
    finally:
        ev.to_mesh_clear()


def screen(scene, point):
    cam=scene.camera.evaluated_get(bpy.context.evaluated_depsgraph_get())
    uv=world_to_camera_view(scene,cam,Vector(point))
    return [round(uv.x*scene.render.resolution_x,2), round((1-uv.y)*scene.render.resolution_y,2)]


def sample(scene, cut, old_metrics):
    bpy.context.window.scene=scene
    bpy.context.view_layer.update()
    pin=next(o for o in scene.objects if o.name.startswith('PIN_ROOT'))
    adult=next(o for o in scene.objects if o.instance_collection and
               (o.instance_collection.name.startswith('GEP_') or o.name.startswith('GEP • adult')))
    parts=points_for([pin])[0]
    assert parts
    # Sort coordinates in stable object-name order, then compare every point.
    h=hashlib.sha256()
    for name,coords in sorted(parts.items()):
        h.update(name.encode()+b'\0')
        h.update(np.ascontiguousarray(coords,dtype='<f8').tobytes())
    if cut=='C06':
        obj=next(o for o in scene.objects if o.name.startswith('C06 folded flax'))
        groups={key:stats['closest_world_xyz'] for key,stats in old_metrics['linen_contact'].items()}
    else:
        obj=next(o for o in scene.objects if o.name.startswith('Work linen'))
        groups={}
        for side in ('Left','Right'):
            points=cloud(parts,lambda n:f'{side} boot / outsole' in n)
            bottom=points[points[:,2]<=points[:,2].min()+.0001]
            # Choose an actual bottom vertex in the interior of the footprint.
            center=bottom.mean(axis=0)
            groups[side]=bottom[np.argmin(np.linalg.norm(bottom-center,axis=1))].tolist()
    surface=tree(obj)
    contacts={}
    for key,w in groups.items():
        point=Vector(w)
        hit,normal,index,dist=surface.ray_cast(point+Vector((0,0,.03)),Vector((0,0,-1)),.08)
        if hit is None:
            raise ValueError(f'{scene.name} {key} misses {obj.name} at {w}')
        gap=point.z-hit.z
        assert -.001<gap<.0015, (scene.name,key,gap)
        pixel=screen(scene,w)
        contacts[key]={'xyz':list(w),'vertical_separation_bu':gap,'surface':obj.name,'screen_px':pixel,
                       'in_frame':0<=pixel[0]<scene.render.resolution_x and 0<=pixel[1]<scene.render.resolution_y}
    return {'pin_evaluated_sha256':h.hexdigest(),'pin_vertices':sum(len(v) for v in parts.values()),
            'pin_matrix':np.array(pin.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world).tolist(),
            'gep_instance_matrix':np.array(adult.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world).tolist(),
            'samples':contacts}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('baseline',type=Path)
    parser.add_argument('measurements',type=Path)
    parser.add_argument('report',type=Path)
    parser.add_argument('--shots',type=Path)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
    old_metrics=json.loads(args.measurements.read_text())['states']
    result={'source':{},'shots':{}}
    bpy.ops.wm.open_mainfile(filepath=str(args.baseline.resolve()))
    for cut,name in [('C06','C06_STATIC_SLEEP'),('C07','C07_STATIC_STAND')]:
        result['source'][cut]=sample(bpy.data.scenes[name],cut,old_metrics[cut])
    if args.shots:
        bpy.ops.wm.open_mainfile(filepath=str(args.shots.resolve()))
        for shot in ('C06_A','C06_B','C07_A','C07_B','C07_JOY'):
            cut=shot[:3]
            s=next(s for s in bpy.data.scenes if s.name==shot or s.get('shot_id')==shot)
            actual=sample(s,cut,old_metrics[cut])
            prev=result['source'][cut]
            for key in ('pin_evaluated_sha256','pin_matrix','gep_instance_matrix'):
                assert actual[key]==prev[key], (shot,key)
            assert all(v['in_frame'] for v in actual['samples'].values()),(shot,actual['samples'])
            result['shots'][shot]=actual
    args.report.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('PASS verified ray hits at measured body and foot supports.',list(result['shots']))

if __name__=='__main__':
    main()
