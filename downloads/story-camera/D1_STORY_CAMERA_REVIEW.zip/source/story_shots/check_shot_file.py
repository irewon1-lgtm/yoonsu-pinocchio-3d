"""Reopen the delivery file; check content and editable scene entry points."""
import hashlib
import json
import sys
from pathlib import Path
import bpy

root=Path(sys.argv[sys.argv.index('--')+1])
bpy.ops.wm.open_mainfile(filepath=str(root/'D1_STORY_SHOTS.blend'))
required={'C06_A':'WARM','C06_B':'WARM','C07_A':'SHOCK','C07_B':'SHOCK','C07_JOY':'JOY'}
assert set(bpy.data.scenes.keys())==set(required)
report={'blender':bpy.app.version_string,'scenes':{},'images':{},'file_sha256':hashlib.sha256((root/'D1_STORY_SHOTS.blend').read_bytes()).hexdigest()}
for name,variant in required.items():
    scene=bpy.data.scenes[name];bpy.context.window.scene=scene
    actors=[o for o in scene.objects if o.instance_collection and o.instance_collection.name.startswith('GEP_')]
    assert len(actors)==1 and actors[0].instance_collection.name=='GEP_'+variant
    assert scene.camera and scene.frame_start==scene.frame_end==1
    assert scene.cycles.device=='CPU' and scene.render.engine=='CYCLES' and scene.use_nodes
    report['scenes'][name]={'camera':scene.camera.name,'acting':variant,'frame_range':[1,1],
                           'geometry':len(actors[0].instance_collection.all_objects),'cpu_samples':scene.cycles.samples,
                           'colour':scene.view_settings.view_transform,'resolution':[scene.render.resolution_x,scene.render.resolution_y]}
for im in bpy.data.images:
    if im.source=='FILE' and im.type=='IMAGE':
        assert im.packed_file,im.name
        report['images'][im.name]=dict(size=list(im.size),sha256=hashlib.sha256(im.packed_file.data).hexdigest())
assert '18ebc03242c327d2f262a7e6dfa945917d8ca499abe3233af50b547592cbb1fa' in [v['sha256'] for v in report['images'].values()]
report.update(actions=len(bpy.data.actions),armatures=len(bpy.data.armatures),linked_libraries=len(bpy.data.libraries))
assert not any(report[k] for k in ('actions','armatures','linked_libraries'))
(root/'qa/SCENE_READBACK.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASS reopened five static shots, embedded source and derived plates, zero character rigs or animation actions.')
