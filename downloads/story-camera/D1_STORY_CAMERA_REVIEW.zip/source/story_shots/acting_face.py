"""Static facial acting studies for the Geppetto D1 portrait, in rest-head space."""
import math
from pathlib import Path
import re
import sys

import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lookdev"))
from head import Portrait

pi = math.pi
sin, cos, exp, sqrt = math.sin, math.cos, math.exp, math.sqrt


def label(obj):
    return re.sub(r'(?:\.\d+)+$', '', obj.name).partition(" · ")[2]


def clamp(t,a=0,b=1):
    return max(a,min(b,t))


def smooth(t):
    t=clamp(t)
    return t*t*(3-2*t)


class ActingGroom(Portrait):
    def __init__(self, collection, source):
        self.collection=collection
        self.placement=source.matrix_world.copy()

    def mesh(self,name,verts,faces,mat):
        ob=super().mesh(name,verts,faces,mat)
        ob.matrix_world=self.placement.copy()
        return ob

    def groom_finish(self,ob,n,rows,mat):
        # Each new lock uses the pigment of its neighbor. UV follows hair growth.
        mesh=ob.data
        uv=mesh.uv_layers.new(name="Groom")
        for poly in mesh.polygons:
            vals=[mesh.loops[i].vertex_index % n for i in poly.loop_indices]
            wraps=max(vals)-min(vals)>n//2
            for i,k in zip(poly.loop_indices,vals):
                idx=mesh.loops[i].vertex_index
                uv.data[i].uv=((n if wraps and k==0 else k)/n, (idx//n)/(rows-1))
        return ob


class Face:
    def __init__(self,coll,variant):
        self.coll=coll
        self.variant=variant
        self.objects={}
        for ob in list(coll.all_objects):
            self.objects.setdefault(label(ob),[]).append(ob)
        self.skin=self.objects['Continuous face sculpt'][0]
        self.groom=ActingGroom(coll,self.objects['Silver hair mass'][0])
        self.surface=None

    def field(self,x,y,z):
        # Redistribute the existing malar mass and raise it naturally into the lids.
        front=smooth((-y-.029)/.073)
        q=exp(-((abs(x)-.103)/.047)**2-((z-1.454)/.041)**2)*front
        amt={'warm':.012,'shock':.008,'joy':.016}[self.variant]
        smile={'warm':.004,'shock':-.002,'joy':.008}[self.variant]
        muzzle=.008*exp(-(x/.065)**2-((z-1.408)/.024)**2)*front
        oral=0
        if self.variant=='shock':
            r=sqrt((x/.031)**2+((z-1.372)/.034)**2)
            oral=(.014*exp(-(r/.74)**2)-.0024*exp(-((r-1)/.19)**2))*front
        return Vector((x+math.copysign(.0043*q,x),y-amt*q-muzzle+oral,z+smile*q))

    def sculpt_skin(self):
        me=self.skin.data
        col=me.color_attributes.get('Complexion')
        for v in me.vertices:
            x,y,z=v.co
            v.co=self.field(x,y,z)
            if col is not None:
                cheek=exp(-((abs(x)-.100)/.051)**2-((z-1.448)/.033)**2)*smooth((-y-.046)/.063)
                c=col.data[v.index].color
                c[0]=clamp(c[0]*(1+.115*cheek))
                c[1]=clamp(c[1]*(1-.105*cheek))
                c[2]=clamp(c[2]*(1-.11*cheek))
        me.update()
        self.surface=BVHTree.FromPolygons([v.co.copy() for v in me.vertices],
                                          [p.vertices[:] for p in me.polygons])

    def skin_y(self,x,z):
        hit=self.surface.ray_cast(Vector((x,-.42,z)),Vector((0,1,0)),.6)[0]
        return hit.y if hit is not None else -.10

    @staticmethod
    def edit(obj,fn):
        if obj.type=='MESH':
            for v in obj.data.vertices:
                v.co=fn(v.co,v.index)
            obj.data.update()
        else:
            for s in obj.data.splines:
                for i,v in enumerate(s.bezier_points):
                    v.co=fn(v.co,i)
            obj.data.update_tag()

    def sculpt_eyes(self):
        # Eye/lid geometry is evaluated on the new cheek surface. Gaze moves
        # around this dome so both irises follow the same three-dimensional target.
        params={
            'warm': (.83,.71,.53,.19,.96),
            'shock': (1.16,1.10,.22,.12,.80),
            'joy': (.70,.38,.39,.22,.96)}
        upper,lower,gaze_x,gaze_z,iris_scale=params[self.variant]
        circles={'Limbal ring':(.54,.67,.00055),'Amber iris':(.50,.63,.00085),
                 'Pupil':(.354,.47,.00125),'Window glint':(.143,.148,.00172),
                 'Small glint':(.050,.050,.00175)}
        for name in ['Almond sclera','Upper eyelid','Lower eyelid','Upper lash line',*circles]:
            for ob in self.objects[name]:
                source=ob.data.vertices[0].co if ob.type=='MESH' else ob.data.splines[0].bezier_points[0].co
                side=1 if source.x>0 else -1
                def bounds(u):
                    arc=sqrt(max(0,1-u*u))*(1-.10*u)
                    lift=.19*(1-u*u) if self.variant=='joy' else 0
                    return (-lower*.75*arc+lift,upper*.95*arc+lift)
                def eye(u,v,d=0):
                    x=side*(.058+.032*u)
                    z=1.502+.032*v+.0025*u
                    # Ellipsoid is parameterized by the current open height, not
                    # by a compressed projection of the old pupil.
                    radius=min(1,u*u+(v/(upper if v>=0 else lower))**2)
                    y=self.skin_y(x,z)-.0018-.017*(max(0,1-radius)**.75)-d
                    return Vector((x,y,z))
                def transform(pt,index):
                    if name in circles:
                        row,col=divmod(index,40)
                        a=col*2*pi/40
                        r=row/9
                        rx,rz,dep=circles[name]
                        iris_x=gaze_x*side-.085
                        iris_z=gaze_z
                        if name=='Window glint':
                            iris_x-=.145*side
                            iris_z+=.22
                        elif name=='Small glint':
                            iris_x+=.14*side
                            iris_z-=.16
                        u=clamp(iris_x+rx*iris_scale*r*cos(a),-.986,.986)
                        v=iris_z+rz*iris_scale*r*sin(a)
                        lo,hi=bounds(u)
                        # Hide the portion of the iris behind the lid.
                        return eye(u,clamp(v,lo+.012,hi-.012),dep)
                    if name=='Almond sclera':
                        row,col=divmod(index,49)
                        u=col/24-1
                        lo,hi=bounds(u)
                        return eye(u,lo+(hi-lo)*row/18)
                    if name=='Upper lash line':
                        u=(pt.x*side-.058)/.032
                        return eye(u,bounds(u)[1],.00155)
                    row,col=divmod(index,45)
                    u=col/22-1
                    top=name=='Upper eyelid'
                    b=bounds(u)[int(top)]
                    p=eye(u,b)
                    o=eye(u*1.13,b*(1.27 if top else 1.25)+(.24 if top else -.20))
                    o.y=self.skin_y(o.x,o.z)+.0011
                    t=row/9
                    v=p.lerp(o,t)
                    v.y-=.0013*(1-t)+.0023*sin(t*pi)
                    return v
                self.edit(ob,transform)
        for name in ('Swept eyebrow','Eyebrow hair'):
            for ob in self.objects[name]:
                def brow(p,_):
                    x,y,z=p
                    u=clamp((abs(x)-.021)/.080)
                    offset={'warm':.002+.007*(1-u)-.006*sin(pi*u),
                            'shock':.020+.009*(1-u)+.004*sin(pi*u),
                            'joy':.007-.005*u-.004*sin(pi*u)}[self.variant]
                    asymmetry={'warm':.004,'shock':.003,'joy':.0055}[self.variant]
                    offset+=asymmetry*(1 if x>0 else -1)*(1-u)
                    if self.variant=='joy': offset-=.005*cos(u*pi)
                    z2=z+offset
                    return (x,y+self.skin_y(x,z2)-self.skin_y(x,z),z2)
                self.edit(ob,brow)
        for ob in self.objects['Smile fold']:
            self.edit(ob,lambda p,i:self.field(*p))
        for ob in self.objects['Forehead crease']:
            dz={'warm':.0005,'shock':.013,'joy':.003}[self.variant]
            self.edit(ob,lambda p,i:(p.x,p.y+self.skin_y(p.x,p.z+dz)-self.skin_y(p.x,p.z),p.z+dz))

    def lips(self,u):
        q=max(0,1-u*u)**.68
        if self.variant=='warm':
            c=1.381+.013*u*u+.0017*u
            return .066*u,c-.0057*q,c+.0045*q
        if self.variant=='shock':
            c=1.373+.003*u+.0018*u*u
            q=sqrt(max(0,1-u*u))
            return .029*u,c-.034*q,c+.031*q-.0028*exp(-(u/.28)**2)*q
        c=1.385+.023*u*u+.0022*u
        return .085*u,c-.040*q,c+.011*q

    def sculpt_mouth(self):
        for name in ['Open smile','Smile · upper teeth','Tongue in smile','Lower lip']:
            for ob in self.objects[name]:
                def mouth(p,index):
                    if name=='Open smile':
                        row,col=divmod(index,61)
                        u=col/30-1
                        x,b,t=self.lips(u)
                        z=b+(t-b)*row/18
                        depth=.0026
                    elif name=='Lower lip':
                        u=[-.99,-.83,-.55,-.26,0,.26,.55,.83,.99][index]
                        x,b,t=self.lips(u)
                        z=b-.0009
                        depth=.0030
                    elif name=='Smile · upper teeth':
                        row,col=divmod(index,41)
                        u=(col/20-1)*.90
                        x,b,t=self.lips(u)
                        thick={'warm':.0007,'shock':.0018,'joy':.010}[self.variant]
                        z=t-thick*(1-row/5)*max(0,1-(u/.9)**2)**.65
                        depth=.0034
                    else:
                        row,col=divmod(index,37)
                        u=(col/18-1)*.71
                        x,b,t=self.lips(u)
                        thick={'warm':.0009,'shock':.006,'joy':.016}[self.variant]
                        z=b+thick*(1-(u/.71)**2)*row/12
                        depth=.0033
                    return (x,self.skin_y(x,z)-depth,z)
                self.edit(ob,mouth)
        if self.variant=='shock':
            us=[-.999,-.87,-.63,-.36,0,.36,.63,.87,.999]
            points=[]
            for u in us:
                x,b,z=self.lips(u)
                points.append((x,self.skin_y(x,z)-.003,z+.0004))
            mat=self.objects['Lower lip'][0].data.materials[0]
            arc=self.groom.stroke("Surprise · upper vermilion",points,.00255,mat,[.15,.66,.95,1,.78,1,.95,.66,.15])
            arc.matrix_world=self.groom.placement.copy()
        for name in ('Handlebar moustache','Moustache hair'):
            for ob in self.objects[name]:
                def whisker(p,_):
                    x,y,z=p
                    u=clamp(abs(x)/.094)
                    dz={'warm':-.002+.003*u,'shock':-.009*u**1.5,'joy':.009*u**1.4}[self.variant]
                    return (x,y+.002*u,z+dz)
                self.edit(ob,whisker)

    def groom_hair(self):
        # Give the existing high part a rolled crest and turn the tips around
        # the skull. A few broad S-shaped locks bind the cap to the sideburns.
        for name in ('Parted fringe','Sweeping front wave','Temple wave','Combed crown wave'):
            for ob in self.objects[name]:
                def wave(p,i):
                    x,y,z=p
                    u=i//32/(len(ob.data.vertices)//32-1)
                    if name=='Temple wave':
                        return (x* (1+.045*sin(pi*u)),y+.015*u*u,z+.009*u**3)
                    if name=='Parted fringe':
                        return (x*(1+.026*sin(pi*u)),y-.007*sin(pi*u),z+.010*sin(pi*u)**2)
                    return (x*(1+.019*sin(pi*u)),y+.006*u*u,z+.003*sin(pi*u))
                self.edit(ob,wave)
        ivory=self.objects['Parted fringe'][1].data.materials[0]
        silver=self.objects['Parted fringe'][0].data.materials[0]
        # Three interlocking lobes trace the broad S in the illustrated part.
        # The middle ridge rises free of the prior crown and turns back onto it.
        crest=[
            ([(.060,-.067,1.696),(.053,-.072,1.731),(.030,-.068,1.756),
              (-.005,-.066,1.765),(-.049,-.080,1.746),(-.089,-.103,1.707),
              (-.132,-.101,1.675),(-.163,-.081,1.661),(-.184,-.061,1.669),(-.184,-.053,1.683)],
             [.002,.013,.026,.034,.035,.031,.027,.021,.011,.0004],
             [.002,.010,.020,.024,.024,.021,.018,.015,.009,.0005],ivory),
            ([(.052,-.086,1.694),(.046,-.098,1.721),(.023,-.100,1.746),
              (-.011,-.099,1.751),(-.057,-.118,1.719),(-.101,-.129,1.674),
              (-.143,-.116,1.651),(-.172,-.095,1.648),(-.186,-.082,1.659)],
             [.002,.013,.017,.024,.027,.026,.023,.015,.0005],
             [.001,.008,.012,.016,.019,.019,.015,.010,.0004],silver),
            ([(.053,-.044,1.709),(.033,-.025,1.743),(.004,-.021,1.754),
              (-.044,-.037,1.748),(-.099,-.046,1.720),(-.147,-.049,1.686),
              (-.178,-.022,1.675),(-.185,-.006,1.690)],
             [.003,.015,.024,.026,.031,.030,.017,.0004],
             [.002,.009,.015,.020,.020,.018,.011,.0004],silver)]
        for pts,ws,hs,mat in crest:
            self.groom.lock("Lifted silver forelock",pts,ws,hs,self.groom.hair_normal,mat,.21)
        for k,(pts,w,h) in enumerate([
            ([(-.144,-.088,1.641),(-.159,-.103,1.621),(-.180,-.094,1.600),
              (-.195,-.071,1.590),(-.203,-.053,1.594),(-.207,-.046,1.608),(-.202,-.048,1.619)],
             [.002,.014,.023,.023,.017,.007,.0004],[.001,.009,.016,.017,.012,.006,.0003]),
            ([(-.160,-.062,1.599),(-.175,-.078,1.577),(-.194,-.069,1.555),
              (-.201,-.045,1.545),(-.210,-.024,1.550),(-.212,-.019,1.562),(-.207,-.023,1.571)],
             [.001,.013,.019,.020,.014,.006,.0004],[.001,.008,.013,.014,.010,.005,.0003]),
            ([(-.158,.034,1.556),(-.179,.035,1.532),(-.192,.058,1.511),
              (-.199,.079,1.502),(-.204,.089,1.508),(-.201,.090,1.520)],
             [.001,.013,.017,.017,.009,.0004],[.001,.009,.013,.013,.008,.0004])]):
            self.groom.lock("Turned ear wisp",pts,w,h,self.groom.hair_normal,ivory if k==1 else silver,.20)
        # The lateral sweeps start under the cap and finish at a recurved tip.
        for side in (-1,1):
            routes=[
                ([(.083,-.097,1.682),(.124,-.118,1.646),(.153,-.109,1.602),
                  (.172,-.087,1.578),(.180,-.059,1.580),(.173,-.044,1.591)],
                 [.003,.013,.021,.020,.011,.0003]),
                ([(.144,-.082,1.604),(.153,-.091,1.578),(.167,-.083,1.552),
                  (.179,-.061,1.541),(.182,-.038,1.547),(.176,-.031,1.559)],
                 [.003,.013,.018,.017,.011,.0003]),
                ([(.146,.047,1.557),(.170,.052,1.536),(.184,.069,1.510),
                  (.183,.089,1.496),(.169,.103,1.504),(.161,.103,1.516)],
                 [.003,.013,.018,.019,.010,.0003])]
            for k,(pts,w) in enumerate(routes):
                if side>0 and k==0:
                    pts=pts[1:]; w=w[1:]
                path=[(side*x,y,z+(.006 if side>0 else 0)) for x,y,z in pts]
                self.groom.lock("Loose silver curl",path,w,[.54*a for a in w],self.groom.hair_normal,
                                ivory if k==1 else silver,.22)

    def seat_beard(self):
        original=self.objects['Forked chin beard mass'][0]
        me=original.data
        n=96
        edge=list(range(n))
        edge += [r*n+n-1 for r in range(1,39)]
        edge += [38*n+j for j in range(n-2,-1,-1)]
        edge += [r*n for r in range(37,0,-1)]
        outer=[me.vertices[i].co.copy() for i in edge]
        # Backing follows the inner cheek and jaw, closing the opening exposed
        # between the flat base surface and the tapering face in oblique views.
        rows=[]
        for t in [0,.25,.55,.79,1]:
            row=[]
            for p in outer:
                x,y,z=p
                bulge=sin(pi*t)
                row.append((x*(1-.36*t)+math.copysign(.002*bulge,x),
                            y*(1-.55*t)+.018*t-.002*bulge,
                            z+.012*t-.0015*bulge))
            rows.extend(row)
        m=len(outer)
        faces=[(r*m+i,r*m+(i+1)%m,(r+1)*m+(i+1)%m,(r+1)*m+i)
               for r in range(4) for i in range(m)]
        self.groom.mesh('Beard · continuous cheek and jaw backing',rows,faces,me.materials[0])
        ivory=self.objects['Chin curl'][1].data.materials[0]
        # Short, overlapping waves lift the beard's upper edge into the jowls.
        # Their tips change direction and height along each cheek.
        for k,u in enumerate([-.74,-.59,-.43,-.24,-.06,.15,.33,.52,.69]):
            pts=[]
            for j,(v,shift) in enumerate([(.39,-.10),(.29,-.056),(.17,.005),(.063,.058),(.00,.09),(-.029,.102)]):
                p=self.groom.beard_point(u+shift*(1 if u>=0 else -1),v,.0025)
                if j==4: p.z+=.002
                if j==5: p.z+=.0015*cos(k*2.1)
                pts.append(p)
            self.groom.lock("Rising cheek wave",pts,[.002,.010,.013,.010,.005,.00025],
                            [.001,.004,.006,.005,.003,.00025],
                            lambda p,t:(p.x*5,-max(.23,-p.y*6),-.09),ivory,.22)
        for side in (-1,1):
            # Two diagonally combed cheek locks knit sideburn, cheek and chin.
            for k in range(2):
                pts=[(.162,-.034,1.443),(.161,-.045,1.428),(.158,-.057,1.407),
                     (.153,-.068,1.388),(.143,-.086,1.371),(.141,-.095,1.367)]
                path=[(side*(x+.003*k),y+.010*k,z-.022*k) for x,y,z in pts]
                self.groom.lock("Cheek whisker",path,[.001,.007,.010,.011,.007,.0003],
                                [.001,.004,.006,.006,.004,.0002],
                                (side*.80,-.60,.06),ivory,.22)

    def execute(self):
        self.sculpt_skin()
        self.sculpt_eyes()
        self.sculpt_mouth()
        self.groom_hair()
        self.seat_beard()
        self.coll['static_face_expression']=self.variant


def apply_face(head_collection,variant):
    """Apply one static expression to a privately copied Geppetto head collection."""
    if variant not in ('warm','shock','joy'):
        raise ValueError("variant must be warm, shock or joy")
    if head_collection.get('static_face_expression'):
        raise ValueError("Use a fresh head copy for each static expression")
    Face(head_collection,variant).execute()
    return head_collection
