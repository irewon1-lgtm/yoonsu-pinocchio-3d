"""Verify which photographed actor meshes stayed identical through the last sight-line adjustment."""
import hashlib
import json
from pathlib import Path
import sys

import bpy
import numpy as np


def inspect(path):
    bpy.ops.wm.open_mainfile(filepath=str(path))
    result={}
    for state in ('warm','shock','joy'):
        scene=bpy.data.scenes['Acting '+state]
        bpy.context.window.scene=scene
        bpy.context.view_layer.update()
        deps=bpy.context.evaluated_depsgraph_get()
        root=bpy.data.collections['GEP_'+state.upper()]
        items={}
        for part in root.children:
            h=hashlib.sha256()
            feet=[]
            for ob in sorted(part.objects,key=lambda o:o.name):
                if ob.type not in {'MESH','CURVE'}: continue
                ev=ob.evaluated_get(deps)
                mesh=ev.to_mesh()
                pts=np.empty(len(mesh.vertices)*3,dtype=np.float32)
                mesh.vertices.foreach_get('co',pts)
                matrix=np.array(ev.matrix_world)
                coords=pts.reshape(-1,3)@matrix[:3,:3].T+matrix[:3,3]
                h.update(ob.name.encode()+b'\0')
                h.update(np.ascontiguousarray(coords,'<f8').tobytes())
                if 'sole' in ob.name.lower() and len(coords):feet.append(float(coords[:,2].min()))
                ev.to_mesh_clear()
            items['head' if 'Face' in part.name else 'body']={'evaluated_sha256':h.hexdigest(),'sole_floor_z':feet}
        result[state]=items
    return result

if __name__=='__main__':
    older,newer,out=(Path(s) for s in sys.argv[sys.argv.index('--')+1:])
    before,after=inspect(older),inspect(newer)
    assert before['warm']==after['warm'] and before['joy']==after['joy']
    assert before['shock']['body']==after['shock']['body'] and before['shock']['head']!=after['shock']['head']
    out.write_text(json.dumps({'before':before,'after':after,'changed':'shock head only','method':'evaluated mesh positions in studio space including rendered curves, as 64-bit coordinate arrays in stable object order'},indent=2))
    print('PASS final geometry identical for warm, joy and shock body. Shock face direction revised.')
