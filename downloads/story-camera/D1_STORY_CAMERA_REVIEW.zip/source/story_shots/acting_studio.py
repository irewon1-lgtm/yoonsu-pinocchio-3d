"""Freeze three D1 sculpt / pose alternatives in a Blender library, and photograph them."""
import argparse
import hashlib
import json
import math
import sys
from pathlib import Path
import bpy
from mathutils import Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))

SOURCE = '0a00ae2ff46e46bacfd75bf6cb086deb8985afe802866fdfc0fd62fa65cab8c0'
STATES = ('warm', 'shock', 'joy')


def copy_part(original, variant):
    part = bpy.data.collections.new(original.name + ' | ' + variant)
    for original_obj in original.objects:
        assert original_obj.parent is None, original_obj.name
        obj = original_obj.copy()
        if obj.data:
            obj.data = original_obj.data.copy()
        obj['study_source_object'] = original_obj.name
        part.objects.link(obj)
    return part


def photograph(scene, head, composition):
    scene.camera.data.type = 'ORTHO'
    scene.render.resolution_x = 680
    scene.render.resolution_y = 680
    scene.render.resolution_percentage = 100
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = 3
    scene.cycles.samples = 32
    scene.cycles.use_denoising = False
    scene.cycles.device = 'CPU'
    # Track the sculpt centre in face close-ups, leaving head tilt visible.
    if composition == 'face':
        skin = next(ob for ob in head.all_objects if 'Continuous face sculpt' in ob.name)
        center = sum((skin.matrix_world @ Vector(corner) for corner in skin.bound_box), Vector()) / 8
        center.y -= .04
        center.z += .022
        angle, width = -10, .73
    else:
        center = Vector((.10, -.025, .88))
        angle, width = -10, 1.92
    direction = Vector((math.sin(math.radians(angle)), -math.cos(math.radians(angle)), .09))
    cam = scene.camera
    cam.data.ortho_scale = width
    cam.location = center + 2.4 * direction
    cam.rotation_euler = (center - cam.location).to_track_quat('-Z', 'Y').to_euler()


def one_render(scene, head, composition, target):
    bpy.context.window.scene = scene
    bpy.context.view_layer.update()
    photograph(scene, head, composition)
    scene.render.filepath = str(target)
    bpy.ops.render.render(write_still=True)


def build_library(scene, folder):
    from acting_face import apply_face
    from acting_body import apply_body
    original = bpy.data.collections['GEP_LOOKDEV']
    records = {}
    for variant in STATES:
        posed_scene = scene.copy()
        posed_scene.name = 'Acting ' + variant
        posed_scene.use_fake_user = True
        bpy.context.window.scene = posed_scene
        # The optics are independent, so the three scenes can also be reviewed in Blender.
        prior_cam = posed_scene.camera
        cam = prior_cam.copy()
        cam.data = prior_cam.data.copy()
        posed_scene.collection.objects.link(cam)
        posed_scene.collection.objects.unlink(prior_cam)
        posed_scene.camera = cam
        posed_scene.collection.children.unlink(original)
        root = bpy.data.collections.new('GEP_' + variant.upper())
        posed_scene.collection.children.link(root)
        head = copy_part(next(c for c in original.children if 'Face' in c.name),variant)
        body = copy_part(next(c for c in original.children if 'body' in c.name),variant)
        root.children.link(head)
        root.children.link(body)
        bpy.context.view_layer.update()
        apply_face(head, variant)
        bpy.context.view_layer.update()
        apply_body(body, head, variant)
        bpy.context.view_layer.update()
        root['D1_static_expression'] = variant
        root['source_sha256'] = SOURCE
        records[variant] = dict(objects=len(root.all_objects),head=len(head.all_objects),body=len(body.all_objects))
        photograph(posed_scene,head,'pose')
    bpy.context.window.scene = bpy.data.scenes['Acting warm']
    bpy.context.preferences.filepaths.save_version=0
    (folder/'qa'/'ACTING_BUILD.json').write_text(json.dumps(records,indent=2))
    assert len(bpy.data.armatures)==0 and len(bpy.data.actions)==0
    bpy.ops.wm.save_as_mainfile(filepath=str(folder/'GEP_ACTING.blend'),compress=True)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode',choices=('baseline','library','portraits'))
    p.add_argument('source',type=Path)
    p.add_argument('folder',type=Path)
    p.add_argument('--variants',nargs='+',choices=STATES,default=list(STATES))
    a=p.parse_args(sys.argv[sys.argv.index('--')+1:]); r=a.folder.resolve()
    if a.mode=='portraits':
        bpy.ops.wm.open_mainfile(filepath=str(r/'GEP_ACTING.blend'))
        for composition in ('pose','face'):
            for variant in a.variants:
                sc=bpy.data.scenes['Acting '+variant]
                coll=bpy.data.collections['GEP_'+variant.upper()]
                head=next(c for c in coll.children if 'Face' in c.name)
                one_render(sc,head,composition,r/'portraits'/f'{variant}_{composition}.png')
        return
    assert hashlib.sha256(a.source.read_bytes()).hexdigest()==SOURCE
    bpy.ops.wm.open_mainfile(filepath=str(a.source.resolve()))
    sc=bpy.context.scene
    if a.mode=='baseline':
        head=next(c for c in bpy.data.collections['GEP_LOOKDEV'].children if 'Face' in c.name)
        one_render(sc,head,'face',r/'portraits'/'previous_face.png')
    else:
        build_library(sc,r)


if __name__=='__main__':
    main()
