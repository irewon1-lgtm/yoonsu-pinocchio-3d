"""Save a derived D2 review blend with a slower Pinocchio gesture recovery."""
import sys
from pathlib import Path

import bpy

destination = Path(sys.argv[sys.argv.index("--") + 1]).resolve()
assert not destination.exists(), destination
scene = bpy.data.scenes["D2_PIN_CONTROLS"]
bpy.context.window.scene = scene
rig = scene.objects["PIN_D2_RIG"]
action = rig.animation_data.action
# Start the turn at the neck and carry it into the arms. Leave the diagnostic
# peak unchanged and unwind the upper body as the existing crouch begins.
timing = {"neck": (43, 39, 60, 62), "head": (45, 41, 60, 63)}
for joint, start, end in [
    ("shoulder", 40, 62), ("upper_arm", 41, 63),
    ("forearm", 42, 64), ("hand", 43, 64),
]:
    for side in ("L", "R"):
        timing[f"{joint}.{side}"] = (44, start, 61, end)

for name, (old_start, start, old_end, end) in timing.items():
    path = rig.pose.bones[name].path_from_id("rotation_quaternion")
    curves = [curve for curve in action.fcurves if curve.data_path == path]
    assert len(curves) == 4, name
    for curve in curves:
        keys = {int(key.co.x): key for key in curve.keyframe_points}
        assert set(keys) == {1, old_start, 51, 56, old_end, 80}, (name, keys)
        curve.keyframe_points.remove(keys[56])
        for key in curve.keyframe_points:
            frame = int(key.co.x)
            if frame == old_start:
                key.co.x = start
            elif frame == old_end:
                key.co.x = end
            key.interpolation = "BEZIER"
            key.handle_left_type = "AUTO_CLAMPED"
            key.handle_right_type = "AUTO_CLAMPED"
        curve.update()
    print(name, start, 51, end, flush=True)

bpy.ops.wm.save_as_mainfile(filepath=str(destination), compress=True)
