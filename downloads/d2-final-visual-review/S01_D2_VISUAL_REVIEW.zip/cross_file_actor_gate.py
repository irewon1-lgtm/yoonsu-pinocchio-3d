"""Compare fresh D1/D2 Blender evaluations and recorded film surface signatures."""
import hashlib
import json
import sys
from pathlib import Path

root, output = map(Path, sys.argv[1:])

def read(path):
    return json.loads((root / path).read_text())

def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()

d1, d2 = [read(f"{name}.snapshot.json") for name in ("D1", "D2")]
original = read("d2/QA/D1_FINAL_SNAPSHOT.json")
technical = read("d2/QA/D2_INDEPENDENT_QA.json")
film = read("d2/QA/FILM_QA.json")
scenes = ("C05_END_HOLD", "C06_A", "C06_B", "C07_A", "C07_B", "C07_JOY")
checks = {
    "same_six_retained_scenes": set(d1["scenes"]) == set(d2["scenes"]) == set(scenes),
    "fresh_d1_matches_archived_d1": d1 == original,
    "same_blender_file_as_technical_QA": d2["file_sha256"] == technical["sha256"],
    "same_packed_workshop": d2["approved_bg"] == d1["approved_bg"],
    "retained_material_graphs": all(d2["materials"].get(k) == v for k, v in d1["materials"].items()),
    "retained_packed_images": all(d2["images"].get(k) == v for k, v in d1["images"].items()),
}
static = {}
for scene in scenes:
    before, after = d1["scenes"][scene], d2["scenes"][scene]
    differences = [key for key in before.keys() | after.keys() if before.get(key) != after.get(key)]
    checks[scene] = not differences and set(before["actors"]) == {"GEP", "PIN", "FAI"}
    static[scene] = {
        "same": checks[scene],
        "different_fields": differences,
        "actors": {
            name: {
                "parts": len(parts),
                "d1_signature": digest([parts, before["roots"][name], before["bounds"][name]]),
                "d2_signature": digest([after["actors"][name], after["roots"][name], after["bounds"][name]]),
            }
            for name, parts in before["actors"].items()
        },
    }

motion = {}
for actor, frame_count in (("GEP", 84), ("PIN", 80)):
    fresh = read(f"{actor}.fresh.json")
    parity = read(f"d2/QA/D2_{actor}_FILM_PARITY.json")
    before = {row["frame"]: row for row in parity["frames"]}
    after = {row["frame"]: row for row in fresh["frames"]}
    different = [f for f in sorted(before.keys() | after.keys()) if before.get(f) != after.get(f)]
    source_link = parity["film_input_sha256"] == film["camera_setup"][actor]["source_sha256"]
    checks[actor] = (
        not different and fresh["actor"] == parity["actor"] == actor
        and fresh["parts"] == parity["parts"] and len(before) == len(after) == frame_count
        and sorted(after) == list(range(1, frame_count + 1))
        and fresh["source_sha256"] == parity["integrated_sha256"] == d2["file_sha256"]
        and parity["result"] == "PASS" and source_link
    )
    motion[actor] = {
        "same": checks[actor], "parts": fresh["parts"], "frames": len(after),
        "different_frames": different, "archived_film_input_sha256": parity["film_input_sha256"],
        "archived_film_input_hash_matches_media_log": source_link,
        "fresh_surfaces": fresh["frames"],
    }

report = {
    "status": "PASS" if all(checks.values()) else "FAIL",
    "d1_sha256": d1["file_sha256"], "d2_sha256": d2["file_sha256"],
    "scope": "Fresh D1 and D2 comparisons. Standalone film blends were represented by sealed prior parity signatures.",
    "checks": checks, "static_scene_actors": static, "motion": motion,
}
output.write_text(json.dumps(report, indent=2) + "\n")
print(report["status"], sum(checks.values()), "/", len(checks), "cross-file checks")
for scene in scenes:
    print(scene, "actor counts", {name: r["parts"] for name, r in static[scene]["actors"].items()})
for actor, row in motion.items():
    print(actor, row["frames"], "frames", row["parts"], "parts. Differences:", row["different_frames"])
assert report["status"] == "PASS", checks
