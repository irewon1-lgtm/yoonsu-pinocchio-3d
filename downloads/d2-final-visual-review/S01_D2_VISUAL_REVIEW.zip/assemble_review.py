"""Replace the edited Pinocchio frames and validate the resulting review MP4."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image

root, output = map(Path, sys.argv[1:])
source = root / "d2/D2_RIG_TEST.mp4"
movie = output / "D2_RIG_VISUAL_REVIEW.mp4"
patch = root / "render-patch/PIN"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

frames = []
for n in range(1, 165):
    pin = n - 84
    rendered = 40 <= pin <= 63
    path = patch / f"{pin:04d}.png" if rendered else root / f"decoded/{n:03d}.png"
    frames.append((path, rendered))
    assert path.is_file(), path

with subprocess.Popen([
    "ffmpeg", "-v", "error", "-nostdin", "-n", "-f", "rawvideo", "-pix_fmt", "rgb24",
    "-video_size", "864x486", "-framerate", "24", "-i", "pipe:0",
    "-vf", "scale=in_range=full:out_range=tv:out_color_matrix=bt709",
    "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
    "-c:v", "libx264", "-threads", "2", "-preset", "medium", "-crf", "13",
    "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(movie),
], stdin=subprocess.PIPE) as encoder:
    for path, _ in frames:
        with Image.open(path) as image:
            assert image.size == (864, 486), (path, image.size)
            encoder.stdin.write(image.convert("RGB").tobytes())
    encoder.stdin.close()
    if encoder.wait():
        raise RuntimeError("FFmpeg encoding failed")

probe = json.loads(subprocess.check_output([
    "ffprobe", "-v", "error", "-count_frames",
    "-show_entries", "stream=codec_name,width,height,avg_frame_rate,nb_read_frames:format=duration",
    "-of", "json", str(movie),
]))
stream, = probe["streams"]
assert (stream["width"], stream["height"], stream["avg_frame_rate"], stream["nb_read_frames"]) == (864, 486, "24/1", "164")
assert abs(float(probe["format"]["duration"]) - 164/24) < 1e-6
raw = subprocess.check_output([
    "ffmpeg", "-v", "error", "-xerror", "-i", str(movie), "-threads", "2",
    "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1",
])
decoded = np.frombuffer(raw, dtype=np.uint8).reshape(164, 486, 864, 3)
frame_stats = []
for n, (pixels, (path, rendered)) in enumerate(zip(decoded, frames), 1):
    with Image.open(path) as image:
        error = np.abs(pixels.astype(np.int16) - np.asarray(image.convert("RGB"))).mean()
    frame_stats.append({
        "movie_frame_1_based": n, "scene_frame": n if n <= 84 else n - 84,
        "scene_actor": "GEP" if n <= 84 else "PIN",
        "source": "new_blender_render" if rendered else "original_decoded_mp4",
        "input_png_sha256": sha(path), "decoded_mae_rgb": round(float(error), 5),
    })

report = {
    "probe": probe, "source_mp4_sha256": sha(source), "review_mp4_sha256": sha(movie),
    "reused_frames": 140, "rendered_frames": 24,
    "max_decoded_mae_rgb": max(row["decoded_mae_rgb"] for row in frame_stats),
    "frames": frame_stats,
}
(output / "REVIEW_VIDEO_QA.json").write_text(json.dumps(report, indent=2) + "\n")
print("PASS fully decoded all frames. Original images reused: 140. Updated Blender renders: 24.")
print("Maximum per-frame average RGB decoding difference:", report["max_decoded_mae_rgb"])
