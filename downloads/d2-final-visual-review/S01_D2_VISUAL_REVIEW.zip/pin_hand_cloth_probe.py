"""Measure distal hand to visible clothing intersections during the edited gesture."""
import json
import sys
from pathlib import Path

import bpy
from mathutils.bvhtree import BVHTree

output = Path(sys.argv[sys.argv.index("--") + 1])
scene = bpy.data.scenes["D2_PIN_CONTROLS"]
bpy.context.window.scene = scene
rig = scene.objects["PIN_D2_RIG"]
parts = [
    obj for obj in scene.objects
    if obj.parent == rig and obj.type == "MESH" and not obj.hide_render
]
hands, clothing = [], []
for obj in parts:
    name = obj.name.lower()
    if " hand / " in name and any(
        token in name for token in ("/ palm", " proximal", " distal")
    ) and "crease" not in name:
        hands.append(obj)
    if any(token in name for token in (
        "linen shirt body", "shorts", "shirt sleeve", "rolled cuff",
        "cuff edge", "sleeve gathering", "suspender", "linen collar",
        "red bow loop", "bow knot", "bow pinch crease", "bow lower crease", "shirt button",
    )) and "boot" not in name:
        clothing.append(obj)
assert len(hands) == 22 and len(clothing) >= 20, (len(hands), len(clothing))

def tree(obj, graph):
    evaluated = obj.evaluated_get(graph)
    mesh = evaluated.to_mesh()
    try:
        world = evaluated.matrix_world
        return BVHTree.FromPolygons(
            [world @ v.co for v in mesh.vertices],
            [tuple(poly.vertices) for poly in mesh.polygons],
        )
    finally:
        evaluated.to_mesh_clear()

hits = {}
for sample in range(78, 129):
    frame, half = divmod(sample, 2)
    scene.frame_set(frame, subframe=half / 2)
    graph = bpy.context.evaluated_depsgraph_get()
    hand_trees = [(obj.name, tree(obj, graph)) for obj in hands]
    cloth_trees = [(obj.name, tree(obj, graph)) for obj in clothing]
    overlaps = [
        [hand, cloth, len(pairs)]
        for hand, hand_tree in hand_trees
        for cloth, cloth_tree in cloth_trees
        if (pairs := hand_tree.overlap(cloth_tree))
    ]
    if overlaps:
        hits[str(sample / 2)] = overlaps
report = {
    "samples": 51, "frame_range": [39, 64], "sampling_step": 0.5,
    "hand_parts": [obj.name for obj in hands],
    "cloth_parts": [obj.name for obj in clothing], "overlaps": hits,
}
output.write_text(json.dumps(report, indent=2) + "\n")
print("Hand/clothing triangle intersections at times:", list(hits), flush=True)
