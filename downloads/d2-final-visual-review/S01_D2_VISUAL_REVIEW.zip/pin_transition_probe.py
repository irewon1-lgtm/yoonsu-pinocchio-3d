"""Measure angular motion in the reopened Pinocchio diagnostic scene."""
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Quaternion

output = Path(sys.argv[sys.argv.index("--") + 1])
scene = bpy.data.scenes["D2_PIN_CONTROLS"]
bpy.context.window.scene = scene
rig = scene.objects["PIN_D2_RIG"]
names = ["neck", "head"] + [
    f"{joint}.{side}"
    for joint in ("shoulder", "upper_arm", "forearm", "hand")
    for side in ("L", "R")
]
neutral = Quaternion()
poses = {name: {} for name in names}
for frame in range(37, 64):
    scene.frame_set(frame)
    evaluated = rig.evaluated_get(bpy.context.evaluated_depsgraph_get())
    for name in names:
        rotation = evaluated.pose.bones[name].rotation_quaternion.normalized()
        poses[name][frame] = rotation.copy()

def degrees(a, b):
    delta = (a.conjugated() @ b).normalized()
    return math.degrees(2 * math.atan2(math.hypot(delta.x, delta.y, delta.z), abs(delta.w)))

rows = {}
for name, frames in poses.items():
    peak = frames[51]
    neutral_return = [
        degrees(frames[frame], neutral) for frame in range(51, 64)
    ]
    increments = {
        frame: degrees(frames[frame - 1], frames[frame])
        for frame in range(38, 64)
    }
    opposed = [
        frame for frame in range(52, 64)
        if degrees(frames[frame], peak) > degrees(peak, neutral) + 0.1
    ]
    rows[name] = {
        "peak_quaternion_at_51": list(peak),
        "peak_angle_from_neutral_deg": degrees(peak, neutral),
        "peak_angular_step_deg_per_frame": max(increments.values()),
        "peak_angular_step_frame": max(increments, key=increments.get),
        "past_neutral_frames": opposed,
        "return_angles_from_neutral_deg": neutral_return,
        "angular_steps_deg": increments,
    }
output.write_text(json.dumps(rows, indent=2) + "\n")
failed = [name for name, row in rows.items() if row["past_neutral_frames"]]
print("Reversal past neutral:", failed, flush=True)
if failed:
    raise AssertionError("The return crosses beyond the neutral pose")
