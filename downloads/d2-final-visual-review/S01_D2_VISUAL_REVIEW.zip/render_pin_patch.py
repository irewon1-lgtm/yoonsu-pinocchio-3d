"""Render the affected D2 frames using the archived diagnostic stage settings."""
import argparse
import json
import sys
from pathlib import Path

import bpy
import numpy as np

root, output = map(Path, sys.argv[sys.argv.index("--") + 1:])
sys.path.insert(0, str(root / "d2/source/s01/rig_validation"))
import test_film

config = json.loads((root / "d2/QA/FILM_QA.json").read_text())["camera_setup"]["PIN"]

def archived_stage(actor, samples, threads):
    source = bpy.data.scenes[config["scene"]]
    bpy.context.window.scene = source
    rig = source.objects[config["armatures"][0]]
    collection = next(c for c in source.collection.children if rig.name in c.all_objects)
    scene = bpy.data.scenes.new("Film | " + source.name)
    scene.collection.children.link(collection)
    scene.frame_start, scene.frame_end = source.frame_start, source.frame_end
    scene.render.fps, scene.render.fps_base = 24, 1
    bpy.context.window.scene = scene
    scene.frame_set(scene.frame_start)
    camera = test_film.build_stage(
        scene, actor, np.array(config["full_center"]), config["stage_floor_z"],
        config["height"], np.array(config["direction"]), samples, threads,
    )
    stage_keys = (
        "full_center", "full_width", "direction", "stage_floor_z", "height",
        "locked_detail_cameras", "evaluated_bounds_min", "evaluated_bounds_max", "armatures",
    )
    return scene, camera, {key: config[key] for key in stage_keys}

test_film.setup_film_scene = archived_stage
test_film.render(argparse.Namespace(
    actor="PIN", out=output, samples=config["samples"], threads=3,
    frames=list(range(40, 64)),
))
