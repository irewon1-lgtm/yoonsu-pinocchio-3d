"""Rebuild the two editions from the included picture master and the 26 original MP3s."""
from pathlib import Path
import shutil,subprocess as sp,sys
build=Path('build');build.mkdir(exist_ok=True);Path('review').mkdir(exist_ok=True)
shutil.copyfile('media/PICTURE.mp4',build/'PICTURE.mp4')
sp.run([sys.executable,'project/src/sound.py'],check=True)
sp.run([sys.executable,'project/src/master.py','--use-picture'],check=True)
