from pathlib import Path
import csv,json
p=Path('review/BEATS_54.tsv')
r=list(csv.DictReader(p.open(),delimiter='\t'));t=json.load(open('review/TIMELINE.json'))
edges=[[0,3.2,7.6,8.4,10.5,12.0],[0,1.55,3,5.8,7.95],[0,1.23,2.06,2.95,4,5,9.3],[0,2.8,4.55,5.75,6.5,7.38],[0,.72,1.86,3.55,4.72],[0,1.70],[0,.36,1.11,1.45,2.3,2.86,3.22,3.96,5.22,7.30,8.75,12.8],[0,3.3,4.7,6.2,7.6,8.99],[0,1.37,2.98,3.75,5.85]]
# Editorial intervals may contain a response hold. The review frame is an actual decoded frame.
idx=0
for c,seq in zip(t['cuts'],edges):
 vals=[c['start']+round(f*24) for f in seq]+[c['end']]
 for start,end in zip(vals,vals[1:]):
  x=r[idx];assert start<=int(x['review_frame_zero'])<end,(x,start,end);x['start_frame_zero']=start;x['end_frame_exclusive']=end;idx+=1
with p.open('w') as out:
 w=csv.DictWriter(out,fieldnames=list(r[0]),delimiter='\t');w.writeheader();w.writerows(r)
