"""Pose both arms in a shared chest-height working space, with separate outer elbow guides."""
import bpy,math,sys,json,numpy as np
from mathutils import Vector,Matrix,Quaternion
from bpy_extras.object_utils import world_to_camera_view
from scipy.optimize import minimize_scalar
from pathlib import Path
s=bpy.context.scene;s.frame_set(50);g=s.objects['GEP_Performance_Rig'];bpy.context.view_layer.update()
def pose(n):return g.evaluated_get(bpy.context.evaluated_depsgraph_get()).pose.bones[n]
def point(n):return g.matrix_world@pose(n).head
d=Vector((.5,-.86,.14)).normalized();right=Vector((0,0,1)).cross(d).normalized();Z=Vector((0,0,1));front=Vector((d.x,d.y,0)).normalized()
c=s.camera.copy();c.data=c.data.copy();s.collection.objects.link(c);s.camera=c;c.location=Vector((-3.04,-.43,1.37))+d*9;c.rotation_euler=(-d).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=3.0
for o in s.objects:
 if (o.type in ('MESH','CURVE','SURFACE','FONT') and o.parent!=g) or o.instance_type=='COLLECTION':o.hide_render=True
s.use_nodes=False;s.render.film_transparent=True;s.render.image_settings.color_mode='RGBA';s.render.resolution_x=900;s.render.resolution_y=1050;s.render.resolution_percentage=100;s.cycles.samples=10
center=(point('UpperArm.R')+point('UpperArm.L'))/2
controls={}
for side,sign in [('L',-1),('R',1)]:
 def empty(n):
  o=bpy.data.objects.new(n,None);s.collection.objects.link(o);return o
 t=empty('S01 • cradle wrist '+side);pole=empty('S01 • cradle elbow '+side);t.location=center+front*.34+right*sign*.22-Z*.25
 pole.location=point('UpperArm.'+side)+right*(.40*sign)-Z*.42+front*.06
 lo=g.pose.bones['Forearm.'+side];ik=lo.constraints.new('IK');ik.target=t;ik.pole_target=pole;ik.chain_count=2;ik.use_stretch=False
 bpy.context.view_layer.update()
 def err(a):
  ik.pole_angle=a;bpy.context.view_layer.update();A=point('UpperArm.'+side);B=point('Forearm.'+side);axis=(t.location-A).normalized();v=B-A;u=pole.location-A
  return 1-(v-axis*v.dot(axis)).normalized().dot((u-axis*u.dot(axis)).normalized())
 angles=np.linspace(-math.pi,math.pi,9);a=min(angles,key=err);a=minimize_scalar(err,bounds=(a-.8,a+.8),method='bounded').x;ik.pole_angle=(a+math.pi)%(2*math.pi)-math.pi;controls[side]=t
shots=[(f'carving-{j:02}',j/8) for j in range(9)]+[(f'lifting-{j:02}',j/16) for j in range(17)]
parts=[o for o in s.objects if o.parent==g and o.type in ('MESH','CURVE')]
out=Path('project/layers')
for i,(name,v) in enumerate(shots):
 s.frame_set(50);iswork=name.startswith('carving')
 for side,sign in [('R',1),('L',-1)]:
  x=sign*(.18 if iswork else .25);h=(-.30 if iswork else -.29+.29*v)
  if iswork and side=='R':x-=.07+.04*v;h+=.10-.04*v
  controls[side].location=center+right*x+Z*h+front*(.43 if not iswork else .40+.025*v)
  controls[side].keyframe_insert('location',frame=50)
 # Direct attention downward to the carving, then to the doll held in both hands.
 head=g.pose.bones['Head'];head.rotation_quaternion=Quaternion(head.bone.matrix_local.to_3x3().inverted()@Vector((1,0,0)),math.radians(16 if iswork else 15-12*v));head.keyframe_insert('rotation_quaternion',frame=50)
 for o in parts:o.hide_render=False
 bpy.context.view_layer.update()
 coords={}
 for side in 'LR':
  b=pose('Hand.'+side);pos=g.matrix_world@b.head.lerp(b.tail,.8);q=world_to_camera_view(s,c,pos);coords[side]=[q.x*900,(1-q.y)*1050]
 (out/(name+'.json')).write_text(json.dumps(coords))
 for mask in [False,True]:
  if mask:
   for o in parts:o.hide_render='hand and forearm' not in o.name.lower()
  tag=name+('-hands' if mask else '');s.render.filepath=str((out/(tag+'.png')).resolve());bpy.ops.render.render(write_still=True)
  print('PLATE',tag,coords,flush=True)
