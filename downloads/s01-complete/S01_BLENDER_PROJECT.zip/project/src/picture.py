"""S01 edit. Coordinates are in a 1280×720 layout; the delivery encoder outputs 1920×1080."""
import json,math,subprocess as sp,sys
from pathlib import Path
from functools import lru_cache
from PIL import Image,ImageDraw,ImageFilter,ImageEnhance,ImageOps
import numpy as np
P=Path('project/layers');T=json.load(open('review/TIMELINE.json'));W,H=1280,720
S=math.sin;C=math.cos;pi=math.pi;L=Image.Resampling
def ease(x):x=max(0,min(1,x));return x*x*(3-2*x)
def tween(x,a,b):return ease((x-a)/(b-a))
def mix(a,b,t):return a+(b-a)*t
@lru_cache(130)
def get(name):
 p=P/(name+'.webp')
 if not p.exists():p=P/(name+'.png')
 im=Image.open(p).convert('RGBA')
 if name.startswith(('rise-','wake-','finger-','actor-','fairy-','wave-','carving-','lifting-','work0','work1','work2','cradle')):im=im.filter(ImageFilter.MedianFilter(3))
 return im
@lru_cache(64)
def flat(name):return get(name).convert('RGB').resize((W,H),L.LANCZOS)
def crop(im,x,y,w):
 h=w*H/W;x=max(w/2,min(W-w/2,x));y=max(h/2,min(H-h/2,y))
 return im.transform((W,H),Image.Transform.EXTENT,(x-w/2,y-h/2,x+w/2,y+h/2),L.BICUBIC)
@lru_cache(300)
def resized(name,w,flip=False,turn=0):
 a=get(name);a=a.crop(a.getchannel('A').getbbox());a=a.resize((max(1,w),max(1,round(a.height*w/a.width))),L.LANCZOS)
 if flip:a=ImageOps.mirror(a)
 if turn:a=a.rotate(turn,L.BICUBIC,expand=True)
 return a
def paste(im,a,x,y):
 im.paste(a,(round(x),round(y)),a)
def sprite(im,name,x,y,w,flip=False,turn=0):
 a=resized(name,max(1,round(w)),flip,turn);paste(im,a,x-a.width/2,y-a.height/2);return a
def gleam(im,x,y,r,level=1,blue=False):
 if level<=0 or r<1:return
 d=round(r*5);xx,yy=np.meshgrid(np.arange(-d,d+1),np.arange(-d,d+1));rr=np.hypot(xx,yy)
 alpha=level*(100*np.exp(-rr**2/(3*r*r))+135*np.exp(-(abs(xx)+abs(yy)*.17)/(.16*r))*np.exp(-rr/r)+135*np.exp(-(abs(yy)+abs(xx)*.17)/(.16*r))*np.exp(-rr/r))
 glow=Image.new('RGBA',(2*d+1,2*d+1),(174,225,255) if blue else (255,226,152));glow.putalpha(Image.fromarray(np.uint8(np.clip(alpha,0,250))))
 paste(im,glow,x-d,y-d)
def fairy(im,x,y,h,t,flip=False,tilt=0,gesture=False):
 frame=int(t*(5 if gesture else 9))%8;layer=('wave-' if gesture else 'fairy-')+str(frame);im0=get(layer);b=im0.getbbox();w=round(h*(b[2]-b[0])/(b[3]-b[1]))
 sprite(im,layer,x,y+S(t*3.3)*2.0,w,flip,round(tilt))
 return (x+(-1 if flip else 1)*w*.405,y-h*.435)
def props(name):return json.load(open(P/('actor-'+name+'.json')))
geo={n:props(n) for n in ['carve','stroke','proud','lonely','lift','look','joy','listen']}
def actor(im,n,palmx,palmy,scale,dy=0):
 im0=get('actor-'+n);b=im0.getbbox();ax,ay=geo[n]['palm'];x=palmx-(ax-b[0])*scale;y=palmy-(ay-b[1])*scale+dy
 a=resized('actor-'+n,round((b[2]-b[0])*scale));paste(im,a,x,y)
def chisel(im,x,y,t,held):
 # Grip, brass ferrule, bevel and glint. The point follows the same stroke as the wood shavings.
 d=ImageDraw.Draw(im);dx,dy=(33,24) if held else (28,-4)
 d.line((x-dx*.68,y-dy*.68,x,y),fill=(61,36,23),width=9);d.line((x-dx*.68,y-dy*.68-2,x,y-2),fill=(180,113,54),width=4)
 d.line((x,y,x+dx*.22,y+dy*.22),fill=(218,172,86),width=6);d.line((x+dx*.22,y+dy*.22,x+dx,y+dy),fill=(179,179,164),width=4);d.line((x+dx*.22,y+dy*.22,x+dx,y+dy-1),fill=(244,218,163),width=1)
def room(t,opened=0,dawn=0):
 im=flat('workshop').copy();d=ImageDraw.Draw(im)
 # Keep the arch, outer jambs and painted mullion edges. Reveal the sky as the two casements swing inward.
 if opened>0 or dawn>0:
  box=(815,53,1051,294);w=236;h=241
  pane=im.crop(box);sky=pane.copy()
  for xc,src in [(113,96),(118,128)]:
   sky.paste(sky.crop((src,0,src+1,h)).resize((7,h)),(xc-3,0))
  sky.paste(sky.crop((0,100,w,101)).resize((w,13)),(0,108))
  if dawn:
   xx,yy=np.meshgrid(np.arange(w)/w,np.arange(h)/h);night=np.array(sky).astype(float)
   morning=np.stack((140+107*yy,176+46*yy,202-53*yy),axis=-1)
   sil=np.clip((77-night[:,:,2])/52,0,1)*np.clip((yy-.43)*7,0,1)
   morning=morning*(1-.49*sil[:,:,None])+np.stack((15*sil,33*sil,12*sil),axis=-1)
   sky=Image.fromarray(np.uint8(night*(1-dawn)+morning*dawn))
  overlay=sky.copy()
  for side in (0,1):
   sl=pane.crop((0 if not side else 116,0,120 if not side else 236,h));sw=max(6,round(120*(1-.83*opened)))
   if dawn:
    raw=np.asarray(sl,dtype=float);blue=(raw[:,:,2]>raw[:,:,0]*.96+7)
    mask=Image.fromarray((blue*255*dawn).astype('uint8'));lit=ImageEnhance.Brightness(sl).enhance(1+.25*dawn)
    sl=Image.composite(sky.crop((side*116,0,side*116+120,h)),lit,mask)
   overlay.paste(sl.resize((sw,h),L.BICUBIC),(0 if not side else w-sw,0))
  mask=Image.new('L',(w,h));md=ImageDraw.Draw(mask);md.ellipse((0,0,w,154),fill=255);md.rectangle((0,79,w,h),fill=255)
  im.paste(overlay,box[:2],mask)
  if opened:
   for xa,width,sgn in [(744,68,-1),(1053,65,1)]:
    tile=flat('workshop').crop((xa,169,xa+width,345));m=Image.new('L',tile.size);ImageDraw.Draw(m).polygon([(28,0),(47,0),(width,169),(0,169)],fill=200)
    disp=round(4*opened*S(t*3.4)*sgn);im.paste(tile,(xa+disp,169),m.filter(ImageFilter.GaussianBlur(2)))
 if dawn<.95:
  for j,(x,y) in enumerate([(990,110),(869,119),(948,74),(1031,147)]):gleam(im,x,y,2+.5*S(t*2+j),(.7+.3*S(t*1.9+j))*(1-dawn),True)
 return im
bench_mask=Image.new('L',(W,H));ImageDraw.Draw(bench_mask).polygon([(0,400),(77,401),(134,411),(207,403),(280,392),(350,382),(508,369),(508,396),(477,408),(458,571),(413,575),(418,427),(183,484),(165,520),(0,556)],fill=255)
@lru_cache(90)
def contacts(name):return json.load(open(P/(name+'.json')))
def cradle(im,pose,x,y,k,puppet=True,tool=False):
 # x,y anchor the camera-space point (400,600). Both actor and prop use the two evaluated wrists.
 def xy(pt):return (x+(pt[0]-400)*k,y+(pt[1]-600)*k)
 a=get(pose);bbox=a.getbbox();sa=resized(pose,round((bbox[2]-bbox[0])*k));paste(im,sa,*xy(bbox[:2]))
 Lp,Rp=[xy(contacts(pose)[n]) for n in 'LR'];mx=(Lp[0]+Rp[0])/2;my=(Lp[1]+Rp[1])/2
 if puppet:
  width=round((246 if not tool else 192)*k);toy=resized('sleep',width,False,-12 if not tool else -3)
  # Neck and hips span the two hands; palms overlap the two lower support points.
  paste(im,toy,mx-toy.width*.49,my-toy.height*.75-3*k)
  hand=get(pose+'-hands')
  for px,py in contacts(pose).values():
   box=(int(px-22),int(py-7),int(px+22),int(py+24));part=hand.crop(box).resize((max(1,round(44*k)),max(1,round(31*k))),L.LANCZOS);paste(im,part,*xy(box[:2]))
 if tool:
  chisel(im,Rp[0]+3*k,Rp[1]-4*k,0,True)
 return mx,my
def closest(prefix,idx,fallback):
 name=prefix+f'-{idx:02}'
 return name if (P/(name+'.png')).exists() or (P/(name+'.webp')).exists() else fallback
def wide(t,pose='carve',lifting=0,fai=None,openwin=0,dawn=0,carving=False):
 im=room(t,openwin,dawn);rest=im.copy()
 if carving:
  n=closest('carving',round(4+4*S(t*6)),'work1');cradle(im,n,275,397,.60,False)
 else:actor(im,pose,304,321,.55,1.0*S(t*1.8))
 im.paste(rest,(0,0),bench_mask);sprite(im,'sleep',310,390,122,False,-3)
 if carving:chisel(im,284+2*S(t*6),387+S(t*6)*2,t,True)
 if fai:fairy(im,*fai,t)
 return im
def toolclose(t):
 idx=round(4+4*S(t*6));pose=closest('carving',idx,'work'+str(round(idx/4)))
 im=flat('bench').copy();mx,my=cradle(im,pose,562,429,1.20,True,True)
 d=ImageDraw.Draw(im)
 for j in range(8):
  u=(t*1.45+j*.137)%1;x=mx+37+u*(14+j*2);y=my+19-24*S(pi*u)+u*18;d.arc((x,y,x+7,y+4),0,210,fill=(222,161+j*4,87),width=2)
 return crop(im,566,365,840-12*t)
def held(t):
 u=tween(t,.02,1.55)*(1-tween(t,7.9,10.25))
 n=closest('lifting',round(u*16),'cradle'+str(round(u*3)))
 im=flat('bench').copy();mx,my=cradle(im,n,632,445,1.19)
 if t<3:return crop(im,617,325,957)
 if t<5.8:return crop(im,mx+17,my-35,667)
 if t<7.9:return crop(im,mx-52,my-43,590)
 return crop(im,627,363,933)
def frame_at(name,fr,step=3,last=214):
 fr=min(last,max(1,fr));a=1+int((fr-1)//step)*step;b=min(last,a+step);u=(fr-a)/step
 f=lambda x:flat(name+(f'{x:03d}' if name=='rise-' else f'{x:02d}'))
 if b==a or u<.001:return f(a).copy()
 return Image.blend(f(a),f(b),u)
def sleep_scene(t,fai=True):
 im=flat('sleep-shot').copy()
 if fai:fairy(im,690,153,105,t,True,3*S(t))
 return im
def magic(t):
 im=sleep_scene(t,False);wt= np.clip(t-6.3,0,3);x,y=fairy(im,659+14*S(t*.75),138,145,t,True,-5+7*S(t*.8),True)
 power=tween(t,4.9,5.95)*(1-tween(t,7.35,8.1));gleam(im,x,y,7+7*power,power,True)
 if t>6.0:
  for j in range(8):
   u=tween(t-j*.055,6.05,7.45);xx=mix(x,1024,u);yy=mix(y,342,u)-90*S(pi*u);gleam(im,xx,yy,9.3-j*.80,(1-j*.07)*(1-tween(t,7.5,8.55)),True)
  gleam(im,1024,342,10,tween(t,7.1,7.6)*(1-tween(t,8.2,9.7)),True)
 if t<2.8:return crop(im,422,395,884)
 if t<5.75:return crop(im,630,302,1072)
 return crop(im,866,259,798+80*tween(t,7,9))
def together(t,expression='standing'):
 im=flat('stage-empty').copy();u=tween(t,0,1.10)
 actor(im,'joy',mix(676,765,u),mix(391,314,u),1.08)
 pin=get(expression).resize((W,H),L.LANCZOS);paste(im,pin,0,0)
 return im
def c07(t):
 # Timed inserts use continuous poses from a single Blender action and keep the same world anchors.
 if t>=12.8:return crop(together(t-12.8),660,293,978+15*S(t*.4))
 if t<1.45:
  wf=1+24*tween(t,.05,1.43);im=frame_at('wake-',wf,3,25)
  if t<.35:gleam(im,1024,342,5,1-t/.35,True)
  return crop(im,699,281,752-142*tween(t,0,1.4))
 fr=np.interp(t,[1.45,1.76,2.6,3.7,4.6,5.25,6.95,7.8,8.7,10.9,14.0],[12,23,48,68,98,120,163,183,197,210,214])
 im=flat(f'rise-{round(fr):03}').copy();extra=max(0,t-8.65)
 if t<1.65:
  im=crop(im,864,300,545+27*t)
 elif t<3.22:im=crop(im,858,342,748)
 elif t<5.22:im=crop(im,860,385,648+20*(t-3.22))
 elif t<7.65:im=crop(im,852,420-45*tween(t,5.22,7.65),788)
 elif t<12.8:im=crop(im,825,331,939+35*S(extra*.6))
 else:
  im=crop(together(t-12.8),660,293,978+15*S(t*.4))
 return im
def morning(im,k):
 if k<=0:return im
 warm=ImageEnhance.Brightness(im).enhance(1+.10*k);wash=Image.new('RGB',im.size,(255,213,143));im=Image.blend(warm,wash,.08*k)
 ray=Image.new('RGBA',im.size);d=ImageDraw.Draw(ray)
 for x,w in [(850,75),(925,36),(1005,66)]:d.polygon([(x,75),(x+w,75),(x-340+w*2,720),(x-430,720)],fill=(255,222,147,round(27*k)))
 ray=ray.filter(ImageFilter.GaussianBlur(17));paste(im,ray,0,0);return im
def adult_reaction(tag,u,anchor,scale,background):
 idx=min(8,max(0,round(8*u)));n=f'{tag}-{idx:02}'
 a=get(n);box=a.getbbox()
 # The same camera rectangle for every pose preserves the position of the grounded body.
 p=(anchor[0]+(box[0]-600)*scale,anchor[1]+(box[1]-430)*scale)
 im=background.copy();paste(im,resized(n,round((box[2]-box[0])*scale)),*p);return im
def picture(c,t):
 if c==1:
  if t<3.2:
   im=wide(t,carving=True);return crop(im,640-130*tween(t,0,3.2),357,1280-180*tween(t,0,3.2))
  if t<7.6:return toolclose(t-3.2)
  if t<10.5:
   im=flat('bench').copy();cradle(im,'cradle0',627,436,1.09);chisel(im,812,427,t,False);return crop(im,609,343,949)
  im=wide(t,'lonely');return crop(im,mix(664,318,tween(t,11,14.7)),mix(352,416,tween(t,11,14.7)),1005)
 if c==2:return held(t)
 if c==3:
  approach=tween(t,.1,4.1);fx=mix(967,705,approach);fy=mix(171,257,approach)-30*S(pi*approach);fh=24+81*approach
  if 1.23<=t<2.06:
   im=adult_reaction('notice',tween(t,1.23,2.03),(538,406),1.15,flat('bench'));return crop(im,386,328,745)
  if t<4:
   im=wide(t,'look' if t>1.55 else 'listen',fai=(fx,fy,fh) if t>2.05 else None,openwin=tween(t,1.5,2.9));gleam(im,fx,fy,6+5*(1-approach),1-tween(t,2.4,3.8),True)
   return crop(im,mix(872,705,tween(t,2,4)),249,714+210*tween(t,2,4))
  if t<5.0:return crop(adult_reaction('notice',1,(540,406),1.15,flat('bench')),388,326,719)
  im=sleep_scene(t,False);hx,hy=fairy(im,661,159,148,t,True,4*S(t));gleam(im,hx,hy,4,tween(t,11.7,14.2),True)
  return crop(im,648,255,804 if t<9.3 else 1000)
 if c==4:return magic(t)
 if c==5:
  if t<3.55:
   fr=np.interp(t,[0,.50,.74,1.48,1.98,2.65,3.52],[1,4,2,11,16,24,33]);im=frame_at('finger-',fr,2,33);return crop(im,640,365,1240-38*tween(t,0,3))
  return crop(sleep_scene(t),665,368,1200-62*tween(t,3.6,6.1))
 if c==6:
  if t<1.7:return crop(adult_reaction('question',tween(t,.03,1.35),(542,408),1.22,flat('sleep-clean')),403,336,832+52*tween(t,0,1.7))
  return flat('sleep-shot').copy()
 if c==7:return c07(t)
 if c==8:
  ex='ask' if 6.2<=t<7.6 else 'nod' if t>=7.6 else 'soft';im=together(2,ex);fx=665-13*tween(t,0,2);fy=75+26*tween(t,0,2);fairy(im,fx,fy,116,t,False,3*S(t*1.5))
  if t<3.4:return crop(im,773,236,875)
  if t<6.2:return crop(im,641,196,640)
  if t<7.6:return crop(im,816,240,650)
  return crop(im,666,334,1172)
 if c==9:
  u=tween(t,.2,3.45);k=tween(t,3.25,6.25)
  if t<5.85 or t>7.55:
   # Preserve the two characters on the bench in the wide view.
   im=room(t,1-.65*k,k);actor(im,'joy',300,321,.57);im.paste(room(t,1-.65*k,k),(0,0),bench_mask)
   sprite(im,'standing',327,341,56)
   if u<1:fairy(im,mix(641,972,u),mix(245,137,u)-48*S(pi*u),mix(115,13,u),t,False,10*S(t*4),True)
   gleam(im,972,137,7,tween(t,2.3,3.25)*(1-tween(t,3.4,4.1)),True)
   return morning(crop(im,697,320,1210+70*tween(t,2,4.8)),k)
  return morning(crop(together(2,'soft'),660,323,1100+102*tween(t,6,9)),k)
 raise ValueError(c)
def run(c):
 cut=T['cuts'][c-1];p=Path(f'build/cut-{c:02}.mp4')
 enc=sp.Popen(['ffmpeg','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','24','-i','pipe:0','-c:v','libx264','-threads','2','-crf','17','-preset','veryfast','-pix_fmt','yuv420p',str(p)],stdin=sp.PIPE)
 n=cut['end']-cut['start']
 for j in range(n):
  im=picture(c,j/24)
  if c==1 and j<14:im=Image.blend(Image.new('RGB',im.size,(33,22,31)),im,.15+.85*ease(j/13))
  if c==9 and j>n-22:im=Image.blend(im,Image.new('RGB',im.size,(49,35,37)),.94*tween(j,n-22,n-1))
  enc.stdin.write(im.convert('RGB').tobytes())
 enc.stdin.close();assert enc.wait()==0
if __name__=='__main__':
 for a in sys.argv[1:]:run(int(a))
