import bpy,math
from mathutils import Vector
from pathlib import Path
s=bpy.context.scene;r=s.objects['PIN_D2_RIG'];b=r.pose.bones['pelvis'];hand=s.objects['PIN • palm target.L']
def e(f,a,b):
 t=min(1,max(0,(f-a)/(b-a)));return t*t*(3-2*t)
names=['PIN • knee pole.'+q for q in 'LR']+['PIN • elbow pole.L',hand.name]
objs=[s.objects[n] for n in names]
rows=[]
for f in range(1,241):
 s.frame_set(f);rows.append(([o.location.copy() for o in objs],b.location.copy()))
for f,(pos,hips) in enumerate(rows,1):
 s.frame_set(f);lean=e(f,110,150);lift=e(f,137,181)
 for i,o in enumerate(objs[:2]):
  # Steer the knee forward as the pelvis moves above each fixed boot.
  target=Vector((pos[i].x,.18,1.87));o.location=pos[i].lerp(target,lean);o.keyframe_insert('location',frame=f)
 spread=e(f,108,121)*(1-e(f,153,177))
 el=objs[2];el.location=pos[2]+Vector((.19*spread,-.16*spread,0));el.keyframe_insert('location',frame=f)
 clear=.053*e(f,20,30)*(1-e(f,37,49))+.111*spread
 hand.location=pos[3]+Vector((clear,-.02*spread,.042*spread+.066*lift));hand.keyframe_insert('location',frame=f)
 z=.006*e(f,109,116)*(1-e(f,129,149))+.064*lift
 b.location=hips+b.bone.matrix_local.to_3x3().inverted()@(r.matrix_world.to_3x3().inverted()@Vector((0,0,z)));b.keyframe_insert('location',frame=f)
s.frame_set(1);bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(Path('project/S01_PERFORMANCES.blend').resolve()),compress=True,relative_remap=False)
