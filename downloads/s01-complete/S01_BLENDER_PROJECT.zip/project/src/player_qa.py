from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,wave,numpy as np,sys
root=Path('review');source=(root/'S01_COMPLETE_OFFLINE_PLAYER.html').resolve().as_uri()
kind=sys.argv[-1];out={'case':kind,'externalRequests':[],'pageErrors':[],'assertions':[]}
rate=48000
if kind=='vad':
 t=np.arange(rate*5)/rate;y=.15*np.sin(2*np.pi*310*t)*((t>.9)&(t<2.0))
 with wave.open('build/mic-fixture.wav','wb') as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes((32767*y).astype('<i2').tobytes())
with sync_playwright() as pw:
 args=['--no-sandbox','--disable-dev-shm-usage']
 if kind=='vad':args+=['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--use-file-for-fake-audio-capture='+str(Path('build/mic-fixture.wav').resolve())]
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=args)
 ctx=browser.new_context(viewport=({'width':390,'height':844} if kind=='mobile' else {'width':875,'height':500}),has_touch=kind=='mobile',is_mobile=kind=='mobile')
 local='http://localhost:62841/S01_COMPLETE_OFFLINE_PLAYER.html'
 out['transport']='Playwright supplies the file bytes at a loopback origin, then disconnects networking'
 def block(r):
  if r.request.url==local and r.request.is_navigation_request():r.fulfill(path=str(root/'S01_COMPLETE_OFFLINE_PLAYER.html'),content_type='text/html; charset=utf-8')
  elif r.request.url.startswith(('http://','https://')):out['externalRequests'].append(r.request.url);r.abort()
  else:r.continue_()
 ctx.route('**/*',block);page=ctx.new_page();page.on('pageerror',lambda error:out['pageErrors'].append(str(error)));page.goto(local);ctx.set_offline(True)
 page.wait_for_function('screen.readyState>=2'.replace('screen.',"document.getElementById('screen')."),timeout=20000)
 assert page.evaluate('M.events.length===6 && M.cues.length===26')
 def check(condition,desc):
  assert condition,desc;out['assertions'].append(desc)
 def wait(fn,ms=25000):page.wait_for_function(fn,timeout=ms)
 def click(q):page.locator(q).click()
 def go(c):
  if not page.locator('details').evaluate('(el) => el.open'):click('summary')
  page.select_option('#chapter',str(c));click('#go')
 if kind=='full':
  click('#play')
  wait("active?.id==='S01-U001'");click('#play');a=page.evaluate('[v.currentTime,audio.currentTime]');page.wait_for_timeout(400);b=page.evaluate('[v.currentTime,audio.currentTime]');check(max(abs(x-y) for x,y in zip(a,b))<.06,'pause preserves picture and original MP3 clocks');click('#play')
  wait("waiting?.id==='X01'",40000);click('#play');page.wait_for_timeout(3200);check(page.evaluate("waiting?.id==='X01'"),'optional timeout suspends on pause');click('#play')
  wait("waiting?.id==='I01'",75000);page.wait_for_timeout(3700);go(8);check(page.evaluate("waiting?.id==='I01' && !required && nowCut().cut===6"),'required wait persists beyond timeout and blocks forward chapter navigation')
  click('#mic');page.wait_for_timeout(600);click('#respond');page.evaluate("document.getElementById('respond').click()")
  wait("ended===true",65000);log=page.evaluate('storyEvidence')
  check([x['id'] for x in log if x['type']=='voiceEnd']==[f'S01-U{i:03}' for i in range(1,27)],'all 26 original MP3 ended once in sequence')
  check(len([x for x in log if x['type']=='timeout'])==5,'all five optional waits auto-resume')
  check(len([x for x in log if x['type']=='manual' and x['id']=='I01'])==1,'double tap releases I01 once')
 elif kind=='vad':
  go(6);click('#play');wait("waiting?.id==='I01'");click('#mic');wait("storyEvidence.some(x=>x.type==='vad'&&x.id==='I01')",16000)
  check(page.evaluate('required && !signal && context===null'),'audio-activity fixture released I01 and microphone tracks stopped')
  click('#play');go(7);click('#play');wait("nowCut().cut===7");click('#restart');wait("generation>1 && v.currentTime<2")
  check(page.evaluate('!required && !responded.size'),'restart clears generation and required response')
  log=page.evaluate('storyEvidence')
 elif kind=='mobile':
  check(page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'390px mobile viewport has no horizontal overflow')
  go(2);click('#play');wait("waiting?.id==='X01'");page.locator('#screen').tap();wait("responded.has('X01')")
  go(4);wait("waiting?.id==='X03'");page.locator('#screen').tap();wait("responded.has('X03')")
  check(page.evaluate("storyEvidence.filter(e=>e.type==='touch').length===2"),'both object/light touch prompts resumed the movie')
  go(6);wait("waiting?.id==='I01'");page.locator('#respond').tap();wait("required===true")
  log=page.evaluate('storyEvidence')
 else:raise ValueError(kind)
 out['events']=log
 check(not out['externalRequests'],'offline document made zero external requests');check(not out['pageErrors'],'browser script exceptions zero')
 browser.close()
(root/('PLAYER_QA_'+kind+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2));print(kind,out['assertions'])
