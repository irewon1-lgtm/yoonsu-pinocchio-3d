"""Author a reclined prelude, a planted rise, and a quiet standing look in the working copy."""
import bpy,math,sys,json
from pathlib import Path
from mathutils import Quaternion,Vector
s=bpy.context.scene;p=s.objects['PIN_D2_RIG'];g=s.objects['GEP_Performance_Rig']
def smooth(x):x=max(0,min(1,x));return x*x*(3-2*x)
def lerp(a,b,t):return a+(b-a)*t
def shift(a,offset):
 for fc in a.fcurves:
  for k in fc.keyframe_points:
   k.co.x+=offset;k.handle_left.x+=offset;k.handle_right.x+=offset
for obj in [p,g]+[o for o in s.objects if o.name.startswith('PIN •')]:
 if obj.animation_data and obj.animation_data.action:shift(obj.animation_data.action,49)
s.frame_set(50);hand={q:s.objects['PIN • palm target.'+q] for q in 'LR'}
b=p.pose.bones['pelvis'];base=b.location.copy()
def rot(bone,axis,angle):
 b=p.pose.bones[bone];b.rotation_quaternion=Quaternion(b.bone.matrix_local.to_3x3().inverted()@Vector(axis),math.radians(angle));b.keyframe_insert('rotation_quaternion')
def pelvis_offset(offset):
 b.location=base+b.bone.matrix_local.to_3x3().inverted()@(p.matrix_world.to_3x3().inverted()@Vector(offset));b.keyframe_insert('location')
def keyhand(q,pos):
 hand[q].location=pos;hand[q].keyframe_insert('location')
s.frame_set(50);first={q:hand[q].location.copy() for q in 'LR'}
s.frame_set(109);end={q:hand[q].location.copy() for q in 'LR'};rot0={q:hand[q].rotation_quaternion.copy() for q in 'LR'}
for f in range(1,50):
 s.frame_set(f);u=smooth((f-10)/39);head=smooth((f-5)/25);lean=lerp(-69,42,u)
 for n,a in [('pelvis',lean*.24),('spine',lean*.76),('neck',lerp(-1,-9,head)),('head',lerp(12,-12,head))]:rot(n,(1,0,0),a)
 pelvis_offset((0,.012*(1-u),.009*(1-u)))
 for q in 'LR':
  v=first[q]+Vector(((-.01 if q=='R' else .01)*(1-u),.40*(1-u),.003*(1-u)));keyhand(q,v)
  eyelid=p.pose.bones['blink.'+q];eyelid['closure']=1-smooth((f-3-(q=='L'))/11);eyelid.keyframe_insert('["closure"]')
s.frame_set(109);base=b.location.copy()
for f in range(110,241):
 s.frame_set(f);leanin=smooth((f-109)/23);rise=smooth((f-128)/54);settle=smooth((f-183)/22);look=smooth((f-188)/33)
 lean=23+12*leanin-31*rise-3*settle
 for n,a in [('pelvis',lean*.24),('spine',lean*.76),('neck',-8+8*rise),('head',-14+16*rise)]:rot(n,(1,0,0),a)
 h=p.pose.bones['head'];h.rotation_quaternion=h.rotation_quaternion@Quaternion(h.bone.matrix_local.to_3x3().inverted()@Vector((0,0,1)),math.radians(-20*look));h.keyframe_insert('rotation_quaternion')
 pelvis_offset((-.022*rise,-.105*leanin-.281*rise,.013*leanin+.384*rise-.008*settle))
 for q in 'LR':
  sign=1 if q=='L' else -1;release=smooth((f-(119 if q=='R' else 125))/43)
  final=Vector((-1.745+sign*(.255 if q=='R' else .205),.60 if q=='R' else .655,2.07 if q=='R' else 2.015))
  keyhand(q,end[q].lerp(final,release))
  hand[q].rotation_quaternion=Quaternion(Vector((0,1,0)),math.radians(sign*(-57)*release))@rot0[q];hand[q].keyframe_insert('rotation_quaternion')
  if f==110:hand[q].keyframe_insert('rotation_quaternion',frame=109)
for q in 'LR':
 h=hand[q]
 for f in (1,50,108):h.rotation_quaternion=rot0[q];h.keyframe_insert('rotation_quaternion',frame=f)
for obj in [p,g,*hand.values()]:
 for fc in obj.animation_data.action.fcurves:
  for k in fc.keyframe_points:k.handle_left_type=k.handle_right_type='AUTO_CLAMPED'
p.animation_data.action.name='S01 • awaken, brace, plant, stand and meet gaze'
s.name='C07 • Awakening';s.frame_start=1;s.frame_end=240
s.timeline_markers.clear()
for f,n in [(1,'Rest'),(4,'Eyes open'),(12,'Lift head'),(50,'Reach'),(61,'Right palm planted'),(66,'Left palm planted'),(70,'Lift chest'),(110,'Load boots'),(130,'Hips rise'),(183,'Settle'),(207,'Look to Geppetto')]:s.timeline_markers.new(n,frame=f)
s.frame_set(1);bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(Path('project/S01_PERFORMANCES.blend').resolve()),compress=True,relative_remap=False)
