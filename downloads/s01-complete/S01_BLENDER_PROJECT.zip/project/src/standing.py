import bpy,sys,math
from pathlib import Path
from mathutils import Vector,Quaternion
s=bpy.context.scene;r=s.objects['PIN_D2_RIG'];g=s.objects['GEP_Performance_Rig'];s.frame_set(210)
for o in s.objects:
 if o.parent!=r and (o.type in ('MESH','CURVE','FONT','SURFACE') or o.instance_type=='COLLECTION'):o.hide_render=True
s.use_nodes=False;s.render.film_transparent=True;s.render.image_settings.color_mode='RGBA';s.render.resolution_percentage=100;s.render.resolution_x=960;s.render.resolution_y=540;s.cycles.samples=10
for name,tilt,yaw in [('standing',0,0),('ask',-10,5),('nod',8,-4),('soft',-3,-9)]:
 s.frame_set(210);b=r.pose.bones['head'];q=b.rotation_quaternion.copy()
 for axis,a in [((0,1,0),tilt),((0,0,1),yaw)]:q=q@Quaternion(b.bone.matrix_local.to_3x3().inverted()@Vector(axis),math.radians(a))
 b.rotation_quaternion=q;b.keyframe_insert('rotation_quaternion',frame=210);s.render.filepath=str(Path('project/layers/'+name+'.png').resolve());bpy.ops.render.render(write_still=True)
