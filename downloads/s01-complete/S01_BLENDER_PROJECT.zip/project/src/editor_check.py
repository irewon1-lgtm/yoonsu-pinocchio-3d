import bpy,json
from pathlib import Path
s=bpy.context.scene;seq=s.sequence_editor.sequences_all
movies=sorted((x for x in seq if x.type=='MOVIE'),key=lambda x:x.frame_final_start)
speech=sorted((x for x in seq if x.type=='SOUND' and x.name.startswith('S01-U')),key=lambda x:x.frame_start)
assert len(movies)==9 and len(speech)==26 and len([x for x in seq if x.type=='TEXT'])==26
assert movies[0].frame_final_start==1 and movies[-1].frame_final_end==2623
assert all(x.frame_final_end==y.frame_final_start for x,y in zip(movies,movies[1:]))
paths={x.filepath for x in movies}|{x.sound.filepath for x in seq if x.type=='SOUND'}
assert all(p.startswith('//media/') and Path(bpy.path.abspath(p)).is_file() for p in paths)
assert len(s.timeline_markers)==60
print('EDITOR QA 9 contiguous picture strips, 26 approved voices, score and foley, 26 caption strips, 54 beat and 6 event markers. Relative media paths resolved:',len(paths))
