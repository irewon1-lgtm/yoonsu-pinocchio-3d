"""Assemble the nine 24-fps reels, timed dialogue, English subtitle master and offline presentation."""
import subprocess as sp,json,base64,html,sys,csv
from pathlib import Path
t=json.load(open('review/TIMELINE.json'));out=Path('review');build=Path('build')
def run(args):sp.run(['ffmpeg','-v','error','-y',*args],check=True)
if __name__=='__main__':
 concat=build/'shots.ffconcat';concat.write_text('ffconcat version 1.0\n'+''.join(f"file 'cut-{i:02}.mp4'\n" for i in range(1,10)))
 if '--use-picture' not in sys.argv:run(['-f','concat','-safe','0','-i',str(concat),'-an','-c:v','copy','-movflags','+faststart','build/PICTURE.mp4'])
 # Frame-accurate 1080p captions, with line lengths designed for a phone held in landscape.
 def assclock(s):
  u=round(s*100);return f'{u//360000}:{u//6000%60:02}:{u//100%60:02}.{u%100:02}'
 hdr='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Voice,DejaVu Sans,49,&H00FFFFFF,&H00FFFFFF,&H30241E19,&H70201914,0,0,0,0,100,100,0,0,3,9,0,2,130,130,51,1
Style: Turn,DejaVu Sans,39,&H00C8E8FF,&H00FFFFFF,&H30241E19,&H70201914,0,0,0,0,100,100,0,0,3,8,0,2,120,120,55,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 lines=[]
 for c in t['cues']:
  words=c['text'];lines.append(f"Dialogue: 0,{assclock(c['start'])},{assclock(c['end'])},Voice,,0,0,0,,{words}")
 for e in t['events']:lines.append(f"Dialogue: 1,{assclock(e['time'])},{assclock(e['time']+3)},Turn,,0,0,0,,Your turn  ·  {e['prompt']}")
 (out/'MOVIE_CAPTIONS.ass').write_text(hdr+'\n'.join(lines)+'\n')
 (out/'MOVIE_RESPONSE_EVENTS.json').write_text(json.dumps([dict(event=e['id'],policy='DEMO_RESPONSE_COMPLETE' if e['required'] else 'OPTIONAL_TIMEOUT',movie_frame=e['frame']+72) for e in t['events']],indent=2))
 meta=';FFMETADATA1\ntitle=Geppetto’s Little Workshop\n'
 for c in t['cuts']:meta+=f"[CHAPTER]\nTIMEBASE=1/24\nSTART={c['start']}\nEND={c['end']}\ntitle=C{c['cut']:02}\n"
 (build/'chapters.ffmeta').write_text(meta)
 run(['-i','build/PICTURE.mp4','-i','build/MIX.wav','-f','ffmetadata','-i','build/chapters.ffmeta','-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-vf','scale=1920:1080:flags=lanczos,ass=review/MOVIE_CAPTIONS.ass','-c:v','libx264','-threads','4','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart',str(out/'S01_COMPLETE_MOVIE_1080P.mp4')])
 run(['-i','build/PICTURE.mp4','-i','build/ME.wav','-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-movflags','+faststart','build/PLAYER_MEDIA.mp4'])
 def enc(p):return base64.b64encode(p.read_bytes()).decode()
 voices={c['id']:enc(next((Path('media/voices') if Path('media/voices').exists() else Path('build/locked')).rglob(c['id']+'.mp3'))) for c in t['cues']}
 page=Path('project/src/player.template.html').read_text().replace('__MANIFEST__',json.dumps(t,ensure_ascii=False)).replace('__FILM__',enc(build/'PLAYER_MEDIA.mp4')).replace('__VOICES__',json.dumps(voices))
 (out/'S01_COMPLETE_OFFLINE_PLAYER.html').write_text(page)
