import bpy
from pathlib import Path
s=bpy.context.scene
for f in range(1,34,2):
 s.frame_set(f);s.render.filepath=str(Path(f'project/layers/finger-{f:02}.png').resolve());bpy.ops.render.render(write_still=True)
