import bpy,numpy as np,re,math
from mathutils import Vector,Matrix
from pathlib import Path
bpy.context.preferences.filepaths.save_version=0
live=bpy.context.scene;bed=bpy.data.scenes['C06_B'];rig=live.objects['PIN_D2_RIG']
def norm(n):return re.sub(r'\.\d+$','',n.replace('D2 PIN | ','').replace('PIN | ','')).lower()
def take(e,m):
 me=e.to_mesh();v=np.empty((len(me.vertices),3),'f');me.vertices.foreach_get('co',v.ravel());e.to_mesh_clear();M=np.asarray(m);return v@M[:3,:3].T+M[:3,3]
bpy.context.window.scene=bed;bed.frame_set(1);bpy.context.view_layer.update();root=bed.objects['PIN_ROOT'];dg=bpy.context.evaluated_depsgraph_get()
for inst in dg.object_instances:
 if inst.parent and inst.parent.original==root and 'carved maple head' in inst.object.name.lower():dst=take(inst.object,inst.matrix_world);break
bpy.context.window.scene=live;live.frame_set(1);bpy.context.view_layer.update()
head=[o for o in live.objects if o.parent==rig and (o.parent_bone in ['head','neck'] or o.parent_bone.startswith(('blink.','gaze.'))) and o.type in ['MESH','CURVE']]
src=next(o for o in head if 'carved maple head' in o.name.lower()).evaluated_get(bpy.context.evaluated_depsgraph_get());x=take(src,src.matrix_world)
assert x.shape==dst.shape
U,sv,V=np.linalg.svd((x-x.mean(0)).T@(dst-dst.mean(0)));R=V.T@U.T
assert np.linalg.det(R)>.99
sc=sv.sum()/np.sum((x-x.mean(0))**2);H=np.eye(4);H[:3,:3]=sc*R;H[:3,3]=dst.mean(0)-H[:3,:3]@x.mean(0)
err=np.max(np.linalg.norm(x@H[:3,:3].T+H[:3,3]-dst,axis=1));print('FIT',err,sc,flush=True);assert err<.003
names={norm(o.name) for o in head}
for o in list(root.instance_collection.all_objects):
 if not o:continue
 if norm(o.name) in names or 'closed eyelid' in o.name.lower():o.hide_render=True
bed.render.resolution_percentage=100;bed.render.resolution_x=1152;bed.render.resolution_y=648;bed.cycles.samples=8;bed.cycles.use_denoising=False
for f in [1,4,7,10,13,16,19,22,25]:
 bpy.context.window.scene=live;live.frame_set(f);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();added=[]
 # Preserve the neck socket while allowing a measured head turn during the close-up.
 ref=next(o for o in head if 'carved maple head' in o.name.lower()).evaluated_get(dg);v=take(ref,ref.matrix_world)
 u,sv,vh=np.linalg.svd((v-v.mean(0)).T@(dst-dst.mean(0)));F=np.eye(4);F[:3,:3]=sc*vh.T@u.T;F[:3,3]=dst.mean(0)-F[:3,:3]@v.mean(0)
 v0=Vector(dst.mean(0));shift=Matrix.Translation(v0+Vector((0,0,.028*(f/25)**2)))@Matrix.Rotation(.12*(f/25)**2,4,'Y')@Matrix.Translation(-v0)
 for o in head:
  e=o.evaluated_get(dg)
  if e.hide_render:continue
  me=bpy.data.meshes.new_from_object(e,depsgraph=dg);ob=bpy.data.objects.new('Awake '+o.name,me);ob.matrix_world=shift@Matrix(F.tolist())@e.matrix_world;added.append(ob)
 bpy.context.window.scene=bed
 for ob in added:bed.collection.objects.link(ob)
 bed.render.filepath=str(Path(f'project/layers/wake-{f:02}.png').resolve());bpy.ops.render.render(write_still=True,scene=bed.name);print('PLATE wake',f,flush=True)
 for ob in added:
  me=ob.data;bpy.data.objects.remove(ob,do_unlink=True);bpy.data.meshes.remove(me)
