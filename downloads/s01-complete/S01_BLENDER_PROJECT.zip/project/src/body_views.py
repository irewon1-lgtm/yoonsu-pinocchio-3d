import bpy,numpy as np,ctypes as C,subprocess,sys,json,math
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
tag='C07';new=True
s=bpy.data.scenes['C07 • Awakening']
bpy.context.window.scene=s
W,H=440,320
lib=C.CDLL(str(Path('build/project.so').resolve()));p=C.c_void_p
lib.project.argtypes=[C.c_int,C.c_int,p,p,p,p,C.c_int,p,C.c_int,p,p,C.c_float]
def unit(x):return x/np.linalg.norm(x)
def mat(v):return np.ascontiguousarray(v,dtype='f')
def draw(buf,img,vertices,norm,tri,cam,color,scale):
 a=[v.ctypes.data for v in (buf,img,vertices,norm,tri,cam,color)]
 lib.project(W,H,a[0],a[1],a[2],a[3],len(vertices),a[4],len(tri),a[5],a[6],scale)
def encoder(name,width,height):
 return subprocess.Popen(['ffmpeg','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{width}x{height}','-r','24','-i','pipe:0','-threads','2','-c:v','libx264','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart','review/'+name],stdin=subprocess.PIPE)
def color(o):
 m=o.active_material
 c=np.array(m.diffuse_color[:3]) if m else np.array([.5]*3)
 if m and m.use_nodes:
  node=next((n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED'),None)
  if node:c=np.asarray(node.inputs['Base Color'].default_value[:3])
 # Signed colour cues on tiny wooden segments kept visible in inspection views.
 return mat(np.clip(c,0,1)**(1/2.2)*218+16)
def init(actor):
 r=s.objects['PIN_D2_RIG' if actor==0 else 'GEP_Performance_Rig']
 objects=[o for o in s.objects if o.parent==r and o.type in ('MESH','CURVE') and not o.hide_render]
 if actor==0:objects += [o for o in s.objects if o.name.startswith(('C06 folded flax','Painted top'))]
 return [(o,color(o)) for o in objects]
objs=[init(0)]
views=['FRONT','SIDE','3/4'];cam=[];scale=[]
for actor in [0,1]:
 front=unit((np.array([-.064,-.998,0]) if new else np.array([-.56,-.83,0])) if actor==0 else np.array([.88,-.47,0]))
 lateral=unit(np.cross([0,0,1.],front));center=([-1.72,.80,2.03] if new else [-1.86,.87,2.02]) if actor==0 else [-3.05,-.48,1.20]
 directions=[front,lateral,(front+lateral)*.707]
 mats=[]
 for d in directions:
  z=unit(d+[0,0,.16]);x=unit(np.cross([0,0,1.],z));y=np.cross(z,x);mats.append(mat(np.r_[x,y,z,center]))
 cam.append(mats);scale.append((205 if new else 208) if actor==0 else 122)
records={};fd=encoder('C07_THREE_VIEWS.mp4',W*3,H+30)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
for f in range(1,215):
 s.frame_set(f);dg=bpy.context.evaluated_depsgraph_get();bands=[]
 for act,parts in enumerate(objs):
  imgs=[np.full((H,W,3),[55,59,65],dtype='B') for i in views];depths=[np.full((H,W),-999,'f') for i in views]
  for o,col in parts:
   if o.hide_render:continue
   ev=o.evaluated_get(dg);converted=ev.type!='MESH';me=ev.to_mesh() if converted else ev.data
   nv=len(me.vertices)
   if not nv:continue
   V=np.empty((nv,3),'f');N=np.empty_like(V);me.vertices.foreach_get('co',V.ravel());me.vertices.foreach_get('normal',N.ravel())
   key=(o.name,nv,len(me.polygons))
   if key not in records:
    me.calc_loop_triangles();t=np.empty((len(me.loop_triangles),3),'i');me.loop_triangles.foreach_get('vertices',t.ravel());records[key]=t
   t=records[key];m=np.asarray(ev.matrix_world);v=mat(V@m[:3,:3].T+m[:3,3]);n=mat(N@np.linalg.inv(m[:3,:3]));n/=np.maximum(np.linalg.norm(n,axis=1)[:,None],1e-12)
   for j in range(3):draw(depths[j],imgs[j],v,n,t,cam[act][j],col,scale[act])
   if converted:ev.to_mesh_clear()
  bands.append(np.concatenate(imgs,axis=1))
 page=Image.new('RGB',(W*3,H+30),(29,29,33));dr=ImageDraw.Draw(page)
 for i,band in enumerate(bands):
  off=i*(H+30);page.paste(Image.fromarray(band),(0,off+30))
  for j,lab in enumerate(views):dr.text((j*W+8,off+5),f'{"PIN" if not i else "GEP"}   {lab}   /   F{f:03}   /   {"GATE" if new else "REJECTED"}',font=font,fill='white')
 fd.stdin.write(page.tobytes())

fd.stdin.close();assert fd.wait()==0
