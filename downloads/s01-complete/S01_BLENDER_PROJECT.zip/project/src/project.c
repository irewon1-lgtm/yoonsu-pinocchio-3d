#include <math.h>
#include <stdint.h>
void project(int W,int H,float *zbuf,uint8_t *rgb,const float *v,const float *norm,int nv,const int *tri,int nt,const float *cam,const float *c0,float scale){
 float xy[nv][4]; const float *x=cam,*y=cam+3,*z=cam+6,*o=cam+9;
 for(int i=0;i<nv;i++){
 const float *p=v+3*i,*n=norm+3*i;float a=p[0]-o[0],b=p[1]-o[1],c=p[2]-o[2];
 xy[i][0]=W*.5f+scale*(a*x[0]+b*x[1]+c*x[2]);xy[i][1]=H*.5f-scale*(a*y[0]+b*y[1]+c*y[2]);xy[i][2]=a*z[0]+b*z[1]+c*z[2];
 float L=.42f*(n[0]*x[0]+n[1]*x[1]+n[2]*x[2])+.56f*(n[0]*y[0]+n[1]*y[1]+n[2]*y[2])+.71f*(n[0]*z[0]+n[1]*z[1]+n[2]*z[2]);xy[i][3]=.63f+.37f*fmaxf(0,L);}
 for(int j=0;j<nt;j++){
 const float *a=xy[tri[3*j]],*b=xy[tri[3*j+1]],*c=xy[tri[3*j+2]];
 float dx=b[0]-a[0],dy=b[1]-a[1],ex=c[0]-a[0],ey=c[1]-a[1],det=dx*ey-dy*ex;
 if(fabsf(det)<.015f)continue;
 int x0=fmaxf(0,floorf(fminf(a[0],fminf(b[0],c[0])))),x1=fminf(W-1,ceilf(fmaxf(a[0],fmaxf(b[0],c[0]))));
 int y0=fmaxf(0,floorf(fminf(a[1],fminf(b[1],c[1])))),y1=fminf(H-1,ceilf(fmaxf(a[1],fmaxf(b[1],c[1]))));
 for(int h=y0;h<=y1;h++)for(int w=x0;w<=x1;w++){
 float u=((w+.5f-a[0])*ey-(h+.5f-a[1])*ex)/det,vv=(dx*(h+.5f-a[1])-dy*(w+.5f-a[0]))/det;
 if(u<0||vv<0||u+vv>1)continue;float t=1-u-vv,depth=t*a[2]+u*b[2]+vv*c[2];int k=h*W+w;
 if(depth<zbuf[k])continue;zbuf[k]=depth;float l=t*a[3]+u*b[3]+vv*c[3];for(int q=0;q<3;q++)rgb[3*k+q]=(uint8_t)fminf(255,c0[q]*l);}
 }}
