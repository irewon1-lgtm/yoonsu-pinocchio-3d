from pathlib import Path
import json,csv,hashlib,subprocess as sp,math,zipfile,shutil
from io import StringIO
base=Path('build/locked');locked=base/'01_LOCKED_SOURCE';review=Path('review');review.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,it in json.loads((base/'HANDOFF_SHA256_MANIFEST.json').read_text()).items():
 p=base/name;assert sha(p)==it['sha256'] and p.stat().st_size==it['bytes'],p
hist=list(csv.DictReader(open('inputs/D0_SHA256_REGISTRY_UPDATED.tsv'),delimiter='\t'))
for it in hist:
 n=it['locked_relative_path'];p=locked/n if not n.startswith('APPROVED_BG/') else locked/'APPROVED_BG/BG_WORKSHOP_02.png'
 assert sha(p)==it['sha256'],p
v=json.loads((locked/'V7_manifest.json').read_text());story=(locked/'01_STORY_MASTER_V1_1.md').read_text()
assert all(item['text'] in story for item in v['items'])
gates={6:('X01','Tap Pinocchio.'),8:('X02','Hello, Blue Fairy!'),13:('X03','Touch the magic light.'),16:('I01','He is moving!'),20:('X04','Hello, my friend!'),24:('X05','Tell the truth!')}
cuts=[];cues=[];events=[];cursor=0
nums=[[1,2,3],[4,5,6],[7,8,9,10],[11,12,13],[14,15],[16],[17,18,19,20],[21,22,23,24],[25,26]]
def clock(f):return f/24
def srt_time(t):
 m=round(t*1000);return f'{m//3600000:02}:{m//60000%60:02}:{m//1000%60:02},{m%1000:03}'
srcqa=json.load(open('inputs/REFERENCE_PCM.json'))
for cut,ns in enumerate(nums,1):
 start=cursor;cursor+=[49,14,19,12,15,8,210,14,18][cut-1]
 for i in ns:
  item=v['items'][i-1];uid=item['id'];assert uid==f'S01-U{i:03}'
  p=next(locked.rglob(uid+'.mp3'));data=sp.check_output(['ffmpeg','-loglevel','error','-xerror','-i',str(p),'-f','s16le','-c:a','pcm_s16le','-']);ref=srcqa['V7_AUDIO_MP3/'+p.name]
  assert hashlib.sha256(data).hexdigest()==ref['pcm_s16le_sha256'] and sha(p)==item['sha256']
  n=ref['pcm_frames'];dur=n/ref['sample_rate'];cue=dict(id=uid,cut=cut,speaker=item['speaker'],text=item['text'],frame=cursor,start=clock(cursor),end=clock(cursor)+dur,duration=dur,original_sha256=sha(p),decoded_sha256=ref['pcm_s16le_sha256'])
  cues.append(cue);cursor+=math.ceil(dur*24)
  if i in gates:
   cursor+=2;gid,prompt=gates[i];events.append(dict(id=gid,cut=cut,after=uid,frame=cursor,time=clock(cursor),prompt=prompt,seconds=3,required=i==16));cursor+=72
  cursor+={3:13,6:10,10:8,13:10,15:10,16:4,20:12,24:12,26:75}.get(i,11)
 cuts.append(dict(cut=cut,start=start,end=cursor))
t=dict(fps=24,frames=cursor,cuts=cuts,cues=cues,events=events)
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2))
dump(review/'TIMELINE.json',t)
(review/'subtitles.en.srt').write_text('\n\n'.join(f"{i+1}\n{srt_time(c['start'])} --> {srt_time(c['end'])}\n{c['text']}" for i,c in enumerate(cues))+'\n')
with (review/'VOICE_LOCK.tsv').open('w') as out:
 writer=csv.writer(out,delimiter='\t');writer.writerow(['utterance','speaker','voice','source_sha256','decoded_pcm_sha256','start_s','duration_s','text'])
 for c in cues:writer.writerow([c['id'],c['speaker'],v['voice_references'][c['speaker']]['choice'],c['original_sha256'],c['decoded_sha256'],c['start'],c['duration'],c['text']])
print('35 historical assets verified, 26 original and decoded hashes matched;',len(cuts),'cuts,',len(events),'events,',cursor,'frames',sum(c['duration'] for c in cues),'seconds dialogue')
