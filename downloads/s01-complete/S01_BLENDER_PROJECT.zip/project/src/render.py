"""Render film plates, actor poses and animation samples from the saved editable performance."""
from pathlib import Path
import bpy,sys,math
from mathutils import Vector,Quaternion,Matrix
kind=sys.argv[sys.argv.index('--')+1];s=bpy.context.scene
out=Path('project/layers');out.mkdir(parents=True,exist_ok=True)
def render(n):
 path=out/(n+'.png')
 if path.exists():return
 s.render.filepath=str(path.resolve());bpy.ops.render.render(write_still=True,scene=s.name);print('PLATE',n,flush=True)
def cam(target,direction,scale):
 c=s.camera.copy();c.data=c.data.copy();s.collection.objects.link(c);c.animation_data_clear();s.camera=c
 d=Vector(direction).normalized();c.location=Vector(target)+d*9;c.rotation_euler=(-d).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=scale
def cfg(w,h,samples):
 s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100;s.cycles.samples=samples;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=3
 s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA'
if kind=='sleep':
 s=bpy.data.scenes['C06_B'];bpy.context.window.scene=s
 for o in s.objects:
  if o.instance_type=='COLLECTION' and 'sleep' in o.instance_collection.name.lower():continue
  if o.type not in ['CAMERA','LIGHT'] and o.instance_type=='COLLECTION' or o.type in ['MESH','CURVE','FONT','SURFACE']:o.hide_render=True
 s.use_nodes=False;s.render.film_transparent=True;cfg(1280,720,12);render('sleep')
elif kind=='rise':
 cfg(1152,648,6)
 nums=[int(a) for a in sys.argv[sys.argv.index('--')+2:]] or sorted(set(list(range(1,217,3))+[240]))
 for f in nums:s.frame_set(f);render(f'rise-{f:03}')
elif kind=='gep':
 cfg(900,1050,10);s.use_nodes=False;s.render.film_transparent=True;g=s.objects['GEP_Performance_Rig']
 for o in s.objects:
  if o.type in ('MESH','CURVE','SURFACE','FONT') and o.parent!=g or o.instance_type=='COLLECTION':o.hide_render=True
 cam((-3.04,-.43,1.37),(.5,-.86,.14),3.1)
 original=g.animation_data.action
 for name,frame,tilt,turn,arm in [('carve',50,12,1,-17),('stroke',50,16,3,-21),('proud',96,5,2,-9),('lonely',50,1,-17,-14),('lift',50,8,0,4),('look',72,-2,14,-2),('joy',96,0,-2,-4),('listen',50,0,7,-7)]:
  g.animation_data.action=original.copy();s.frame_set(frame)
  def rotate(n,axis,a):
   b=g.pose.bones[n];b.rotation_quaternion=b.rotation_quaternion@Quaternion(b.bone.matrix_local.to_3x3().inverted()@Vector(axis),math.radians(a));b.keyframe_insert('rotation_quaternion',frame=frame)
  rotate('Head',(1,0,0),tilt);rotate('Head',(0,0,1),turn);rotate('UpperArm.R',(0,1,0),arm)
  bpy.context.view_layer.update();render('actor-'+name)
  from bpy_extras.object_utils import world_to_camera_view
  import json
  pts={}
  e=g.evaluated_get(bpy.context.evaluated_depsgraph_get())
  for label,bone,t in [('palm','Hand.R',.66),('wrist','Hand.R',0),('near','Hand.L',.45),('head','Head',.55)]:
   b=e.pose.bones[bone];pos=e.matrix_world@b.head.lerp(b.tail,t);z=world_to_camera_view(s,s.camera,pos);pts[label]=[z.x*900,(1-z.y)*1050]
  (out/('actor-'+name+'.json')).write_text(json.dumps(pts))
elif kind in ('fairy','wave'):
 cfg(520,560,12);s.use_nodes=False;s.render.film_transparent=True
 fai=next(o for o in s.objects if o.instance_type=='COLLECTION' and 'FAI' in o.name)
 for o in s.objects:
  if o!=fai and (o.type in ('MESH','CURVE','SURFACE','FONT') or o.instance_type=='COLLECTION'):o.hide_render=True
 fai.hide_render=False;coll=fai.instance_collection;obs=[o for o in coll.all_objects if o.type in ('MESH','CURVE')]
 mat=fai.matrix_world.copy();bb=[mat@o.matrix_local@Vector(c) for o in obs for c in o.bound_box];mid=Vector([(min(p[i] for p in bb)+max(p[i] for p in bb))*.5 for i in range(3)])
 cam(mid,(.14,-1,.1),max(max(p[i] for p in bb)-min(p[i] for p in bb) for i in (0,2))*1.13)
 orig={o:o.matrix_local.copy() for o in obs}
 center=mat.inverted()@mid
 fore=next(o for o in obs if o.name=='Fairy forearm 1')
 palm=next(o for o in obs if o.name=='Fairy wand palm')
 def geom(o):
  me=o.to_mesh();pts=[o.matrix_local@v.co for v in me.vertices];o.to_mesh_clear();return pts
 pv=sum(geom(palm),Vector())/len(geom(palm));fv=geom(fore);elbow=max(fv,key=lambda x:(x-pv).length)
 for i in range(8):
  t=i*math.pi/4
  for o in obs:
   n=o.name.lower();wing='wing' in n or 'vein' in n;skirt='skirt' in n or 'sash' in n
   if kind=='wave' and (o==fore or 'wand' in n):
    pivot=elbow;ang=math.radians(11*math.sin(t));o.matrix_world=Matrix.Translation(pivot)@Matrix.Rotation(ang,4,'Y')@Matrix.Translation(-pivot)@orig[o]
   if wing or skirt:
    ang=(1 if 'left' in n else -1)*math.sin(t)*(.22 if wing else .018)
    o.matrix_world=Matrix.Translation(center)@Matrix.Rotation(ang,4,'Z' if wing else 'Y')@Matrix.Translation(-center)@orig[o]
  bpy.context.view_layer.update();render(kind+'-'+str(i))
