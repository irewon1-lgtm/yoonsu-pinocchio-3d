#!/usr/bin/env bash
set -euo pipefail
mkdir -p build project/layers
scene=project/S01_PERFORMANCES.blend
for layer in gep fairy wave sleep;do blender -b "$scene" --python-exit-code 1 -P project/src/render.py -- "$layer";done
blender -b "$scene" --python-exit-code 1 -P project/src/render.py -- rise $(seq 1 214)
for run in standing cleanplate reactions cradle wakeface;do blender -b "$scene" --python-exit-code 1 -P "project/src/$run.py";done
blender -b project/S01_FINGERS.blend --python-exit-code 1 -P project/src/render_finger_scene.py
python project/src/picture.py 1 2 3 4 5 6 7 8 9
python project/src/sound.py
python project/src/master.py
