import bpy
from pathlib import Path
s=bpy.context.scene;s.frame_set(211);p=s.objects['PIN_D2_RIG'];g=s.objects['GEP_Performance_Rig'];s.render.resolution_x=1152;s.render.resolution_y=648;s.render.resolution_percentage=100;s.cycles.samples=12;s.cycles.use_denoising=False
for o in s.objects:
 if o.parent==p:o.hide_render=True
s.render.filepath=str(Path('project/layers/stage-adult.png').resolve());bpy.ops.render.render(write_still=True)
for o in s.objects:
 if o.parent==g:o.hide_render=True
s.render.filepath=str(Path('project/layers/stage-empty.png').resolve());bpy.ops.render.render(write_still=True)
