"""Create the editable nine-reel film timeline in Blender's Video Sequencer."""
import bpy,json,csv,sys
from pathlib import Path
root=Path(sys.argv[-1]).resolve();timeline=json.load(open('review/TIMELINE.json'))
bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;s.name='S01 • Geppetto’s Little Workshop';s.frame_start=1;s.frame_end=timeline['frames'];s.render.fps=24;s.render.resolution_x=1920;s.render.resolution_y=1080;s.render.resolution_percentage=100
s.view_settings.view_transform='Standard';s.view_settings.look='None';s.render.image_settings.file_format='FFMPEG';s.render.ffmpeg.format='MPEG4';s.render.ffmpeg.codec='H264';s.render.ffmpeg.audio_codec='AAC';s.render.filepath='//S01_EDIT_RENDER.mp4'
seq=s.sequence_editor_create().sequences
for c in timeline['cuts']:
 st=seq.new_movie(f"C{c['cut']:02} • picture",str(root/'media/PICTURE.mp4'),10,1)
 st.frame_offset_start=c['start'];st.frame_offset_end=timeline['frames']-c['end'];st.channel=1;st.transform.scale_x=st.transform.scale_y=1.5
 assert st.frame_final_start==c['start']+1 and st.frame_final_end==c['end']+1
 st.filepath='//media/PICTURE.mp4'
bg=seq.new_sound('Room, score and foley',str(root/'media/ROOM_AND_SCORE.m4a'),2,1);bg.sound.filepath='//media/ROOM_AND_SCORE.m4a'
gain=json.load(open('review/AUDIO_QA.json'))['gain']
for cue in timeline['cues']:
 id=cue['id'];a=seq.new_sound(id+' • '+cue['speaker'],str(root/'media/voices'/(id+'.mp3')),3,cue['frame']+1);a.sound.filepath='//media/voices/'+id+'.mp3';a.volume=gain
 end=1+round(cue['end']*24);sub=seq.new_effect(id+' • EN','TEXT',4,cue['frame']+1,frame_end=end);sub.text=cue['text'];sub.font_size=46;sub.location=(.5,.055);sub.align_x='CENTER';sub.wrap_width=.85;sub.use_box=True;sub.box_color=(.04,.03,.02,.83)
for beat in csv.DictReader(open('review/BEATS_54.tsv'),delimiter='\t'):s.timeline_markers.new(beat['beat'],frame=int(beat['review_frame_zero'])+1)
for e in timeline['events']:s.timeline_markers.new(e['id']+' '+e['prompt'],frame=e['frame']+1)
s['offline_gate']='I01 after U016; VAD/manual in the HTML edition.';s.frame_set(1)
area=next((a for a in bpy.context.screen.areas if a.type=='VIEW_3D'),None)
if area:area.type='SEQUENCE_EDITOR';area.spaces.active.view_type='SEQUENCER_PREVIEW'
bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=str(root/'S01_EDITOR.blend'),compress=True,relative_remap=False)
