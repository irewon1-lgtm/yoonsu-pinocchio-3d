"""Original small-room score, foley and untrimmed, independently hash-locked voices."""
import numpy as np,subprocess as sp,json,math,wave
from pathlib import Path
from scipy.signal import butter,sosfilt
T=json.load(open('review/TIMELINE.json'));R=48000;N=T['frames']*2000
rng=np.random.default_rng(824);bed=np.zeros((N,2),np.float32);voice=np.zeros(N,np.float32)
def add(y,start,pan=0):
 a=round(start*R);k=min(len(y),N-a)
 if a<0 or k<=0:return
 bed[a:a+k,0]+=y[:k]*np.sqrt((1-pan)/2);bed[a:a+k,1]+=y[:k]*np.sqrt((1+pan)/2)
def tone(start,midi,volume=.035,length=2.7,pan=0,bell=False):
 f=440*2**((midi-69)/12);t=np.arange(round(length*R))/R
 y=np.sin(2*np.pi*f*t)+.32*np.sin(2*np.pi*f*(2.003 if bell else 2)*t)*np.exp(-3*t)+.12*np.sin(2*np.pi*f*(3.98 if bell else 3)*t)*np.exp(-4*t)
 y*=volume*(1-np.exp(-t*80))*np.exp(-t*(2 if bell else 1.7))*np.minimum(1,(length-t)*8)
 add(y,start,pan)
def noise(start,length,band,vol,pan,fall):
 t=np.arange(round(length*R))/R;x=sosfilt(butter(2,band,fs=R,btype='bandpass',output='sos'),rng.normal(size=len(t)))
 y=x/(np.sqrt(np.mean(x*x))+.000001)*vol*np.sin(np.pi*t/length)**.65*np.exp(-fall*t)
 add(y,start,pan)
for j in range(0,math.ceil(N/R),7):
 noise(j,7,(75,340),.0011,-.2,0)
for k,cut in enumerate(T['cuts']):
 at=cut['start']/24;end=cut['end']/24;chords=[(50,57,62,66),(55,59,62,67),(52,59,64,67),(57,61,64,69),(54,57,62,66),(52,55,59,64),(55,59,62,69),(50,57,62,66),(55,59,62,67)];ch=chords[k]
 for i,sec in enumerate(np.arange(at+.3,end-1,.94)):
  if i%8 in (3,6):continue
  tone(sec,ch[[0,1,3,2,1,2,3,2][i%8]],.018 if i%4 else .023,2.4,(-1)**i*.32)
 if k in (2,3,6,8):
  for i,n in enumerate([74,78,81]):tone(at+.15+i*.23,n,.025,2.5,.38,True)
 if k==0:
  for t in [1.4,2.17,3.0,3.83,4.7,5.55,6.4]:
   noise(at+t,.24,(800,3600),.021,-.42,4)
 if k==2:noise(at+1.7,.9,(280,1850),.013,.35,1.8)
 if k==4:
  for t in [.7,1.7]:noise(at+t,.09,(160,1200),.024,.15,7)
 if k==6:
  for t in [3.2,3.6,5.9,7.6]:noise(at+t,.2,(90,540),.012,.16,5)
 if k==8:
  for j in range(4):
   t=np.arange(12000)/R;add(.012*np.sin(2*np.pi*(2300*t+1600*t*t))*np.sin(np.pi*t/.25)**2,end-3.2+j*.52,(-1)**j*.6)
for c in T['cues']:
 p=next((Path('media/voices') if Path('media/voices').exists() else Path('build/locked')).rglob(c['id']+'.mp3'));y=np.frombuffer(sp.check_output(['ffmpeg','-v','error','-xerror','-i',str(p),'-ar',str(R),'-ac','1','-f','f32le','-']),np.float32)
 i=c['frame']*2000;voice[i:i+len(y)]+=y
 # Lower music throughout the actual utterance, with attack and release in the gaps.
 a=max(0,i-5760);b=min(N,i+len(y)+11520);env=np.interp(np.arange(a,b),[a,i,i+len(y),b],[1,.44,.44,1])
 bed[a:b]*=env[:,None]
full=voice[:,None]+bed
gain=min(.97/(abs(full).max()+1e-6),1.15)
def wav(path,x):
 with wave.open(path,'wb') as w:w.setparams((2,2,R,0,'NONE','not compressed'));w.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
wav('build/MIX.wav',gain*full);wav('build/ME.wav',gain*bed)
json.dump(dict(peak=float(np.abs(full*gain).max()),gain=float(gain),samples=N,voice_seconds=sum(c['duration'] for c in T['cues']),score='Original synthesis for S01, released for project use and redistribution, CC0',foley='Original seeded synthesis, CC0'),open('review/AUDIO_QA.json','w'),indent=2)
