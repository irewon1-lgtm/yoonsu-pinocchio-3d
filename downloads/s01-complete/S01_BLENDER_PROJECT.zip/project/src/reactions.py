import bpy,math,json
from mathutils import Vector,Quaternion
from bpy_extras.object_utils import world_to_camera_view
from pathlib import Path
s=bpy.context.scene;g=s.objects['GEP_Performance_Rig'];out=Path('project/layers')
c=s.camera.copy();c.data=c.data.copy();s.collection.objects.link(c);s.camera=c;d=Vector((.50,-.86,.14)).normalized();c.location=Vector((-3.04,-.43,1.37))+d*9;c.rotation_euler=(-d).to_track_quat('-Z','Y').to_euler();c.data.type='ORTHO';c.data.ortho_scale=3.1
for o in s.objects:
 if o.parent!=g and (o.type in ('MESH','CURVE','SURFACE','FONT') or o.instance_type=='COLLECTION'):o.hide_render=True
s.use_nodes=False;s.render.film_transparent=True;s.render.image_settings.color_mode='RGBA';s.render.resolution_x=900;s.render.resolution_y=1050;s.render.resolution_percentage=100;s.cycles.samples=10
action=g.animation_data.action
for tag in ['question','notice']:
 for j in range(9):
  f=(50 if tag=='question' else 50+3*j);g.animation_data.action=action.copy();s.frame_set(f);t=j/8;q=t*t*(3-2*t)
  h=g.pose.bones['Head'];h.rotation_quaternion=h.rotation_quaternion@Quaternion(h.bone.matrix_local.to_3x3().inverted()@Vector((0,0,1)),math.radians((-27 if tag=='question' else 12)*q));h.keyframe_insert('rotation_quaternion',frame=f)
  if tag=='question':
   for field,amount in [('Eyes_Shock',.22),('Brows_Shock',.39),('Mouth_Shock',.17)]:
    g[field]=q*amount;g.keyframe_insert('["'+field+'"]',frame=f)
  bpy.context.view_layer.update();n=tag+f'-{j:02}';s.render.filepath=str((out/(n+'.png')).resolve());bpy.ops.render.render(write_still=True)
  print('PLATE',n,flush=True)
bed=bpy.data.scenes['C06_B'];bpy.context.window.scene=bed;bed.frame_set(1)
for o in bed.objects:
 if o.instance_type=='COLLECTION' and 'GEP' in o.name:o.hide_render=True
bed.render.resolution_percentage=100;bed.render.resolution_x=1152;bed.render.resolution_y=648;bed.cycles.samples=8;bed.cycles.use_denoising=False;bed.render.filepath=str((out/'sleep-clean.png').resolve());bpy.ops.render.render(write_still=True,scene=bed.name)
