import hashlib,json,subprocess as sp,os,math,sys
from pathlib import Path
import numpy as np
from scipy.signal import correlate,correlation_lags
from PIL import Image,ImageDraw
out=Path('review');t=json.load(open(out/'TIMELINE.json'));movie=out/'S01_COMPLETE_MOVIE_1080P.mp4'
def probe(path):
 return json.loads(sp.check_output(['ffprobe','-v','error','-show_format','-show_chapters','-show_streams','-count_frames','-of','json',str(path)]))
def pcm(path,channels=2):
 return np.frombuffer(sp.check_output(['ffmpeg','-v','error','-xerror','-i',str(path),'-vn','-map','0:a:0','-ar','48000','-ac',str(channels),'-f','f32le','-']),np.float32).reshape(-1,channels)
p=probe(movie);v=next(s for s in p['streams'] if s['codec_type']=='video');a=next(s for s in p['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],int(v['nb_read_frames']),v['avg_frame_rate'])==(1920,1080,t['frames'],'24/1')
assert len(p['chapters'])==9 and a['channels']==2
ts=json.loads(sp.check_output(['ffprobe','-v','error','-select_streams','v','-show_entries','frame=best_effort_timestamp_time','-of','json',str(movie)]))['frames']
assert len(ts)==t['frames'] and max(abs(i/24-float(row['best_effort_timestamp_time'])) for i,row in enumerate(ts))<1e-5
mix=pcm(movie).mean(axis=1);bed=pcm('build/ME.wav').mean(axis=1);mix=mix[:len(bed)]
assert len(mix)==len(bed);recovered=mix-bed;dialog=[];gain=json.load(open(out/'AUDIO_QA.json'))['gain']
for c in t['cues']:
 voice=next((Path('media/voices') if Path('media/voices').exists() else Path('build/locked')).rglob(c['id']+'.mp3'))
 src=pcm(voice,1)[:,0]*gain;i=round(c['start']*48000);y=recovered[i:i+len(src)];corr=float(np.corrcoef(y,src)[0,1]);assert corr>.972,(c['id'],corr)
 # Determine onset shift using a ±50 ms search and the full utterance.
 margin=2400;candidate=recovered[i-margin:i+len(src)+margin:3];ref=src[::3]
 off=(int(np.argmax(correlate(candidate,ref,mode='valid',method='fft')))*3-margin)/48
 voiced=np.where(np.abs(src)>max(src.std()*.07,.002))[0];edge=[]
 for ix in [voiced[0],max(voiced[0],voiced[-1]-2880)]:
  q=slice(ix,ix+2880);edge.append(float(np.corrcoef(y[q],src[q])[0,1]))
 assert min(edge)>.90 and abs(off)<3,(c['id'],edge,off)
 db=float(20*np.log10(np.sqrt(np.mean(src**2))/(np.sqrt(np.mean(bed[i:i+len(src)]**2))+1e-9)))
 dialog.append(dict(id=c['id'],correlation=round(corr,6),start_and_tail_correlation=[round(e,6) for e in edge],lag_ms=round(off,4),voice_over_bed_db=round(db,2)))
# Decode every display frame. Retain thumbnail evidence at every supplied visual beat.
import csv
beats=list(csv.DictReader(open('build/locked/02_PRODUCTION_SPEC/S01_BEATS_54_V2_0.tsv',encoding='utf-8-sig'),delimiter='\t'))
times=[[.7,4.8,7.96,9.5,11.15,13.8],[.8,2.01,3.94,6.86,9.83],[.63,1.67,2.27,3.2,4.48,5.8,13.8],[1.15,3.4,5.2,6.0,6.84,7.49],[.57,1.28,2.55,3.88,5.45],[.83,3.1],[.17,.77,1.33,1.88,2.56,2.96,3.75,4.38,6.09,7.64,10.19,14.05],[1.5,3.6,5.5,6.55,7.99,9.6],[.96,2.12,3.24,4.75,8.31]]
anchors=[(cut['start']+round(sec*24),sec,cut) for cut,seq in zip(t['cuts'],times) for sec in seq]
assert len(beats)==len(anchors)==54
wanted={f:(i,b['beat_id']) for i,(b,(f,sec,cut)) in enumerate(zip(beats,anchors))}
board=Image.new('RGB',(6*244,9*158),'#292520');draw=ImageDraw.Draw(board)
proc=sp.Popen(['ffmpeg','-v','error','-xerror','-i',str(movie),'-an','-vf','scale=240:135','-threads','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1'],stdout=sp.PIPE)
cutstats=[];last=None
for f in range(t['frames']):
 data=proc.stdout.read(240*135*3);assert len(data)==240*135*3
 arr=np.frombuffer(data,dtype='B');cut=next(c for c in t['cuts'] if c['start']<=f<c['end'])
 if f==cut['start']:cutstats.append(dict(cut=cut['cut'],frames=0,min_luma=255,largest_mean_frame_change=0));last=None
 d=cutstats[-1];d['frames']+=1;d['min_luma']=min(d['min_luma'],round(float(arr.mean()),2))
 if last is not None:d['largest_mean_frame_change']=max(d['largest_mean_frame_change'],round(float(np.abs(arr.astype('i2')-last).mean()),3))
 last=arr.astype('i2')
 if f in wanted:
  i,bid=wanted[f];x=(i%6)*244;y=i//6*158;board.paste(Image.frombytes('RGB',(240,135),data),(x,y));draw.text((x+3,y+137),f'{bid}   {f/24:.2f}s',fill='#fff6e8')
assert proc.stdout.read(1)==b'' and proc.wait()==0 and min(x['min_luma'] for x in cutstats)>10
board.save(out/'BEATS_54_CONTACT.jpg',quality=90)
with (out/'BEATS_54.tsv').open('w') as file:
 w=csv.writer(file,delimiter='\t');w.writerow(['beat','cut','source_cue','direction','start_frame_zero','review_frame_zero','end_frame_exclusive','review_seconds','movie'])
 for i,(b,(f,sec,cut)) in enumerate(zip(beats,anchors)):
  l=(anchors[i-1][0]+f)//2 if i and anchors[i-1][2]==cut else cut['start'];h=(anchors[i+1][0]+f)//2 if i+1<len(beats) and anchors[i+1][2]==cut else cut['end']
  w.writerow([b['beat_id'],b['cut_id'],b['cue_or_action'],b['required_visual_event'],l,f,h,round(f/24,3),movie.name])
summary=dict(movie=movie.name,sha256=hashlib.sha256(movie.read_bytes()).hexdigest(),fps=24,frames=t['frames'],width=v['width'],height=v['height'],duration_seconds=float(v['duration']),codec=v['codec_name'],audio_codec=a['codec_name'],chapters=len(p['chapters']),cuts=cutstats,original_to_final_mix=dialog)
(out/'MOVIE_QA.json').write_text(json.dumps(summary,indent=2))
print(summary['duration_seconds'],len(dialog),min(x['correlation'] for x in dialog),min(x['voice_over_bed_db'] for x in dialog))

sp.run([sys.executable, str(Path(__file__).with_name('beat_intervals.py'))], check=True)
