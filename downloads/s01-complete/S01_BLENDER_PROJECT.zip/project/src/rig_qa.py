import bpy,json,sys,re,itertools,numpy as np
from mathutils.bvhtree import BVHTree
from mathutils import Vector
from pathlib import Path
from scipy.spatial.transform import Rotation
def surfaces(scene, dg):
    surfaces={}
    for o in scene.objects:
        if o.name.startswith(('C06 folded flax','Work linen','Painted top','Floor • shadow receiver')):
            ev=o.evaluated_get(dg)
            mesh=ev.to_mesh()
            try:
                surfaces[o.name]=BVHTree.FromPolygons([ev.matrix_world@v.co for v in mesh.vertices],
                                                       [p.vertices[:] for p in mesh.polygons])
            finally:
                ev.to_mesh_clear()
    return surfaces
tag=sys.argv[-1];new=tag=='new';s=bpy.data.scenes['C07 • Awakening' if new else 'C07 B • Wake and balance'];bpy.context.window.scene=s
s.frame_set(1 if new else 25);dg=bpy.context.evaluated_depsgraph_get();pin,gep=[s.objects[n] for n in ['PIN_D2_RIG','GEP_Performance_Rig']]
trees=[t for n,t in surfaces(s,dg).items() if not n.startswith('Floor')]
def mesh(o,dg):
 e=o.evaluated_get(dg);m=np.array(e.matrix_world);me=e.data;vs=np.empty((len(me.vertices),3),'f');me.vertices.foreach_get('co',vs.ravel())
 return vs@m[:3,:3].T+m[:3,3],me
def ids(o):
 n=o.name.lower()
 if o.parent==pin:
  for side in ('left','right'):
   if side not in n:continue
   if side+' hand /' in n and any(k in n for k in ['/ palm',' proximal',' distal']) and 'crease' not in n:return side+' hand'
   for k,t in [('forearm / wood','forearm'),('upper arm / wood','upper'),('leg / shin','shin'),('leg / thigh','thigh'),('boot / outsole','sole'),('boot / shaft','boot'),('boot / toe box','boot')]:
    if k in n and 'grain' not in n:return side+' '+t
  for k,t in [('linen shirt body','shirt'),('full teal shorts leg','shorts'),('carved maple head','head')]:
   if k in n:return t
 if o.parent==gep:
  for k,t in [('hand and forearm','hand'),('gathered linen sleeve','sleeve'),('double rolled sleeve','cuff'),('continuous face sculpt','face'),('ivory gathered','chest'),('waistcoat body','chest'),('trouser legs','legs')]:
   if k in n:return 'G '+t+' '+('R' if ('open hand' in n or 'sleeve 1' in n) else 'L')
objs={o:ids(o) for o in s.objects if o.type=='MESH' and ids(o)}
pairs=[]
for a,b in itertools.combinations(objs,2):
 i,j=objs[a],objs[b]
 if (i.startswith('G ') != j.startswith('G ')) or i==j:continue
 if i.startswith('G '):
  t,u=i.split()[1],j.split()[1];eligible= 'hand' in (t,u) and (t!=u and (('sleeve' not in (t,u) and 'cuff' not in (t,u)) or i[-1]!=j[-1]) or (t==u and i[-1]!=j[-1]))
 else:
  # Working arm shells and boot shells, excluding joint socket insertions.
  ia=i.split();ja=j.split();t,u=ia[-1],ja[-1];k={t,u}
  eligible=bool(k & {'hand','forearm','upper','boot','sole','shin'}) and not (len(ia)==len(ja)==2 and ia[0]==ja[0] and k in [{'hand','forearm'},{'forearm','upper'},{'boot','sole'},{'boot','shin'},{'sole','shin'},{'shin','thigh'}]) and not (k in [{'upper','shirt'},{'shin','shorts'},{'sole','shorts'},{'boot','shorts'}])
 if eligible:pairs.append((a,b))
tagfile=Path('build/C07_BODY.json')
# Reference rest skin lengths, prior to facial/body shape drivers.
oldact=gep.animation_data.action;prop={k:gep[k] for k in gep.keys() if k.endswith(('_Shock','_Joy'))}
gep.animation_data.action=None
for k in prop:gep[k]=0.
gep.data.pose_position='REST';bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();refs={}
for o,group in objs.items():
 if not group.startswith(('G hand','G cuff','G sleeve')):continue
 v,me=mesh(o,dg);e=np.empty((len(me.edges),2),'i');me.edges.foreach_get('vertices',e.ravel());length=np.linalg.norm(v[e[:,0]]-v[e[:,1]],axis=1);e=e[length>.001];refs[o]=(e,length[length>.001])
gep.data.pose_position='POSE';gep.animation_data.action=oldact
for k,z in prop.items():gep[k]=z
from functools import lru_cache
@lru_cache(maxsize=400000)
def top(x,y):
 return max((h.z for t in trees if (h:=t.ray_cast(Vector((x,y,4)),Vector((0,0,-1)),5)[0]) is not None),default=-5)
rows=[];prev={};meta={}
for f in (range(1,215) if new else range(25,217)):
 s.frame_set(f);dg=bpy.context.evaluated_depsgraph_get();row={'f':f,'limbs':{},'strain':{},'hits':[],'table':{},'target_error_m':{}}
 for r in (pin,gep):
  er=r.evaluated_get(dg);isPin=r==pin;rw=np.array(er.matrix_world);R=rw[:3,:3];R=R/np.linalg.norm(R[:,0])
  for side in 'LR':
   ns=[q+'.'+side for q in (('upper_arm','forearm','hand','thigh','shin','foot_ik') if isPin else ('UpperArm','Forearm','Hand','Thigh','Shin','Foot'))]
   bones=[er.pose.bones[n] for n in ns];p=np.array([er.matrix_world@b.head for b in bones]);basis=np.array([np.asarray(er.matrix_world@b.matrix)[:3,:3] for b in bones]);basis/=np.linalg.norm(basis,axis=1)[:,None,:]
   angle=lambda a,b:float(np.degrees(np.arccos(np.clip(a@b/np.linalg.norm(a)/np.linalg.norm(b),-1,1))))
   key=('PIN' if isPin else 'GEP')+'.'+side
   dat=dict(shoulder_xyz=p[0].tolist(),elbow_xyz=p[1].tolist(),wrist_xyz=p[2].tolist(),elbow_angle=angle(p[0]-p[1],p[2]-p[1]),knee_angle=angle(p[3]-p[4],p[5]-p[4]))
   chest=er.pose.bones['spine' if isPin else 'Chest'];head=er.matrix_world@chest.head
   front=np.array(er.matrix_world.to_3x3()@chest.matrix.to_3x3()@chest.bone.matrix_local.to_3x3().inverted()@Vector((0,-1,0)));front/=np.linalg.norm(front);dat['wrist_forward_of_chest_m']=float((p[2]-np.array(head))@front)
   if key in prev:
    rv=Rotation.from_matrix(np.transpose(prev[key],(0,2,1))@basis).as_rotvec()*180/np.pi
    dat['relative_frame_rotation_deg']=np.linalg.norm(rv,axis=1).tolist();dat['long_axis_component_deg']=rv[:,1].tolist()
   prev[key]=basis;row['limbs'][key]=dat
   if new and isPin:
    row['target_error_m'][side]=float(np.linalg.norm(p[2]-np.array(s.objects['PIN • palm target.'+side].evaluated_get(dg).matrix_world.translation)))
 buffers={};bvh={};mins={};hand={}
 for o,g in objs.items():
  v,me=mesh(o,dg);buffers[o]=(v,me,v.min(0),v.max(0))
  if o in refs:
   e,l=refs[o];ratio=np.linalg.norm(v[e[:,0]]-v[e[:,1]],axis=1)/l
   row['strain'][o.name]=[float(x) for x in np.percentile(ratio,[1,99])]
  if new and o.parent==pin and g not in ('head','shirt'):
   # Exact surface casts on all vertices below the top of the folded work cloth.
   close=v[v[:,2]<1.62];gaps=[z-top(round(x,5),round(y,5)) for x,y,z in close];mins[g]=min(mins.get(g,5),min(gaps,default=5))
   if g.endswith(('hand','sole')):hand.setdefault(g,[]).append(v)
 if new:
  row['table']={k:float(v) for k,v in mins.items() if v<1};row['centers']={k:np.vstack(v).mean(0).tolist() for k,v in hand.items()}
 def tree(o):
  if o not in bvh:
   v,me,_,_=buffers[o];me.calc_loop_triangles();t=np.empty((len(me.loop_triangles),3),'i');me.loop_triangles.foreach_get('vertices',t.ravel());bvh[o]=BVHTree.FromPolygons(v,t,all_triangles=True)
  return bvh[o]
 for a,b in pairs:
  v,m,lo,hi=buffers[a];v,m,l,h=buffers[b]
  if np.any(hi<l) or np.any(h<lo):continue
  ov=tree(a).overlap(tree(b))
  if ov:row['hits'].append([a.name,b.name,len(ov)])
 rows.append(row)
tagfile.write_text(json.dumps({'pair_count':len(pairs),'rows':rows}));print('frames',len(rows),'pairs',len(pairs))
