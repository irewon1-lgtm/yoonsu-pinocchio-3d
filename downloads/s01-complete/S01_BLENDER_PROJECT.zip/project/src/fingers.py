import bpy,math,numpy as np
from pathlib import Path
from mathutils import Vector, Matrix
s=bpy.data.scenes['C06_B'];bpy.context.window.scene=s;s.frame_set(1);p=s.objects['PIN_ROOT'];w=p.matrix_world.copy()
objs=[o for o in p.instance_collection.objects if 'Right hand /' in o.name]
bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get()
w=p.evaluated_get(dg).matrix_world.copy()
geometry={};rest={}
for inst in dg.object_instances:
 if inst.is_instance and inst.parent and inst.parent.original==p and 'Right hand /' in inst.object.name:
  e=inst.object;m=e.to_mesh();geometry[e.name]=np.array([inst.matrix_world@v.co for v in m.vertices]);e.to_mesh_clear();rest[e.name]=w.inverted()@inst.matrix_world
def coords(o):return geometry[o.name]
def part(q):return next(o for o in objs if ('/ '+q+'.') in o.name)
def vec(o):return Vector(coords(o).mean(0))
palm=vec(part('palm'));print('TARGET',palm,flush=True);cam=s.camera.copy();cam.data=cam.data.copy();s.collection.objects.link(cam);s.camera=cam
direction=Vector((-.18,-.85,.75)).normalized();target=palm+(vec(part('index distal'))-palm)*.44
cam.location=target+direction*5;cam.rotation_euler=(-direction).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=.42
s.render.image_settings.color_mode='RGBA';s.use_nodes=False;s.render.film_transparent=True;s.render.resolution_x=820;s.render.resolution_y=460;s.render.resolution_percentage=100;s.cycles.samples=12;s.cycles.use_denoising=False
for o in s.objects:
 if o!=p and o.instance_type=='COLLECTION':o.hide_render=True
for digit,a,b,angle in [('index',1,17,20),('middle',14,32,16)]:
 prox=part(digit+' proximal');tip=part(digit+' distal');fold=part(digit+' hinge crease')
 v=(vec(tip)-vec(prox)).normalized();axis=v.cross(Vector((0,0,1))).normalized()
 start=vec(prox)-(vec(tip)-vec(prox))*.48;knuckle=vec(fold);bodies=[prox,tip,fold];orig=[rest[o.name] for o in bodies]
 for f in range(1,34):
  amp=math.sin(math.pi*max(0,min(1,(f-a)/(b-a))))**2*math.radians(angle)
  R=Matrix.Translation(start)@Matrix.Rotation(amp,4,axis)@Matrix.Translation(-start)
  for o,old in zip(bodies,orig):
   H=Matrix.Translation(knuckle)@Matrix.Rotation(-amp*.5,4,axis)@Matrix.Translation(-knuckle) if o==tip else Matrix.Identity(4)
   o.matrix_world=w.inverted()@R@H@w@old;o.keyframe_insert('location',frame=f);o.keyframe_insert('rotation_euler',frame=f)
s.frame_start=1;s.frame_end=33;s.frame_set(1);s.name='C05 • First fingers';bpy.context.preferences.filepaths.save_version=0
# Keep a lightweight stand-alone editing scene; the main project retains all other shots.
for scene in list(bpy.data.scenes):
 if scene!=s:bpy.data.scenes.remove(scene)
bpy.ops.wm.save_as_mainfile(filepath=str(Path('project/S01_FINGERS.blend').resolve()),compress=True,relative_remap=False)
for f in range(1,34,2):
 s.frame_set(f);s.render.filepath=str(Path(f'project/layers/finger-{f:02}.png').resolve());bpy.ops.render.render(write_still=True);print('PLATE finger',f,flush=True)
