# S01 · 할아버지의 작은 작업실

S01_EDITOR.blend를 열면 편집 가능한 전체 영화가 나온다. 1번 채널은 9개의 컷, 2번은 창작 음악·효과음, 3번은 개별 V7 MP3 26개, 4번은 영어 자막이다. 컷마다 화면을 분리해 길이와 순서를 바꿀 수 있다. 타임라인 마커는 54개 연출 비트와 참여 6회의 위치를 표시한다. media 폴더는 Blender 파일과 같은 폴더에 둔다.

project/S01_PERFORMANCES.blend에는 C06 B와 피노키오의 기상 동작이 있다. 손·발 목표와 좌우 팔꿈치·무릎 폴, 골반·흉곽·눈꺼풀·시선을 편집할 수 있다. project/S01_FINGERS.blend에는 실제 손가락 확대 장면과 오른손 검지·중지 키가 있다. 제페토의 조각·들어 올리기, 질문 반응, 요정의 비행·날갯짓·손목, 눈 뜨기와 카메라 컷 연결은 project/src의 제작 스크립트에서 수정한다. 최종 편집에 쓰인 완성 화면은 media/PICTURE.mp4에 있다.

## 편집과 재생성

Blender 4.3.2, FFmpeg, Python 3, NumPy, SciPy, Pillow를 사용했다. 명령은 ZIP을 푼 폴더에서 실행한다. 새 결과는 review에 생성된다.

- 포함된 화면 원본과 26개 MP3로 영화와 HTML을 다시 합성하려면 `python project/src/build_delivery.py`를 실행한다.
- 장면 리그나 합성 방식을 수정한 뒤 원화부터 전체 화면을 다시 렌더하려면 `bash project/src/render_layers.sh`를 실행한다. 그림 레이어는 project/layers, 중간 영상은 build에 생성된다. 기존 작업을 보존하려면 편집본 복사본에서 실행한다.
- 큐와 시간은 review/TIMELINE.json, 프레임별 연출 지점은 review/BEATS_54.tsv에 있다. Blender 편집본의 자막 위치와 영상을 직접 배포한 영화판의 자막 렌더링은 각각 편집할 수 있다.
- 재생기는 원본 영어 MP3가 끝나는 이벤트로 발화 진행을 제어한다. HTML에는 영상·음향·원본 음성이 모두 들어 있다. 마이크는 기기 권한이 있을 때 소리 활동만 감지한다.

캐릭터·작업실·대본·V7 음성은 승인된 프로젝트 검토용 자산이다. 새 실내음·목공·창문·마법·새소리와 음악은 이 S01을 위해 합성했으며 CC0로 재배포할 수 있다. 기존 모델과 원화의 출처는 review/SOURCE_LICENSES.tsv에 있다.

승인 원장을 다시 만들 때는 제공받은 D0 ZIP을 build/locked에 풀고 python project/src/timeline.py를 실행한다. 두 배포본을 재합성할 때는 이 절차를 생략할 수 있다.
